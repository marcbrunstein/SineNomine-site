"use strict";

const $ = (s) => document.querySelector(s);
// Séparateur catégorie / clé des exceptions : il passe par un attribut HTML (data-cle), où le navigateur remplace
// le caractère nul (U+0000) par « � » ; avec lui, l'exception arrivait au serveur sans séparateur (« expected 2, got 1 »).
const SEP_CLE = "␟";
const etat = {
  config: null,
  acceptation: null,
  fichiers: [],          // [{fichier: File, chemin: "dossier/nom.docx"}]
  lot: null,
  entites: [],
  sensibles: [],
  actions: {},
  exclusions: new Set(), // "categorie" + SEP_CLE + "cle"
  onglet: "personne",
  selectionFusion: new Set(),
  variantesDepliees: new Set(),
  prochainId: -1,
};
const VARIANTES_VISIBLES = 5;
const PLURIELS = { personne: "Personnes", societe: "Sociétés", produit: "Produits", lieu: "Lieux" };
const pluriel = (c, n) => PLURIELS[c] || n + "s";

const ACTIONS = { conserver: "Conserver", pseudonymiser: "Pseudonymiser", supprimer: "Supprimer" };
// Dates : généralisation à l'année (« 2026 [Date_KQXMB] » en pseudonymisation, « 2026 » seul sans conservation).
const ACTION_ANNEE = { annee: "Année" };
const actionsPour = (categorie) => (categorie === "date" || categorie === "date_naissance" ? { ...ACTIONS, ...ACTION_ANNEE } : ACTIONS);

function echapper(t) {
  return String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function contexteHtml(c) {
  return echapper(c).replace(/⟦(.*?)⟧/g, "<mark>$1</mark>");
}
function pourcent(x) { return Math.round(x * 100) + " %"; }

// Miniatures des images d'un fichier ; un clic ouvre une version plus grande dans un nouvel onglet.
function vignettes(images) {
  if (!images || !images.length) return "";
  const base = `/api/lots/${etat.lot.id}/apercu/`;
  return `<div class="vignettes">${images.map((im) => {
    const legende = `${echapper(im.nom)}${im.occurrences > 1 ? ` · ×${im.occurrences}` : ""}`;
    const visuel = im.accessible
      ? `<a href="${base}${im.index}?taille=1600" target="_blank" title="Voir en grand"><img src="${base}${im.index}?taille=320" alt="${echapper(im.nom)}" loading="lazy" class="vignette-image"></a>`
      : "";
    return `<figure class="${im.accessible ? "" : "illisible"}">${visuel}
      <span class="sans-apercu">${echapper(im.note || "Aperçu impossible pour ce format.")}</span>
      <figcaption>${legende}</figcaption></figure>`;
  }).join("")}</div>`;
}

// Miniature illisible : sans gestionnaire inline (la politique de sécurité n'autorise que les scripts du programme).
document.addEventListener("error", (e) => {
  if (e.target && e.target.classList && e.target.classList.contains("vignette-image")) {
    const figure = e.target.closest("figure");
    if (figure) figure.classList.add("illisible");
  }
}, true);

const alerter = (message) => window.alert(traduire(String(message)));
const confirmer = (message) => window.confirm(traduire(String(message)));

const jetonCsrf = () => (document.querySelector('meta[name="csrf"]') || {}).content || "";
async function api(url, options = {}) {
  // La langue de l'interface accompagne chaque appel (les rapports sont rédigés dans cette langue).
  const reponse = await fetch(url, { ...options, headers: { ...(options.headers || {}), "X-Langue": LANGUE, "X-CSRF-Token": jetonCsrf() } });
  const donnees = await reponse.json().catch(() => ({}));
  if (!reponse.ok) {
    const erreur = new Error(traduire(donnees.erreur || t("Erreur {n}", { n: reponse.status })));
    if (donnees.candidats) erreur.candidats = donnees.candidats;
    throw erreur;
  }
  return donnees;
}

// ------------------------------------------------------------------ navigation

const ORDRE = ["avertissement", "fichiers", "validation", "resultats"];
function afficher(ecran, etapeActive = ecran) {
  document.querySelectorAll(".ecran").forEach((e) => (e.hidden = e.id !== "ecran-" + ecran));
  const rang = ORDRE.indexOf(etapeActive);
  document.querySelectorAll("#etapes li").forEach((li) => {
    const i = ORDRE.indexOf(li.dataset.etape);
    li.classList.toggle("active", i === rang);
    li.classList.toggle("faite", i < rang);
  });
  document.body.classList.toggle("validation", ecran === "validation");
  $("#etapes").hidden = rang < 0;                  // les étapes n'ont de sens que dans le parcours d'un lot
  etat.ecran = ecran;
  $("#btn-menu").hidden = ["progression", "menu", "arret", "erreur"].includes(ecran);
  if (ecran === "menu") egaliserMenu();
  window.scrollTo(0, 0);
}

function erreurFatale(message) {
  $("#message-erreur").textContent = message;
  afficher("erreur", "fichiers");
}

// ------------------------------------------------------------------ état des modèles

async function rafraichirModeles() {
  try {
    const e = await api("/api/etat");
    etat.config = etat.config || e;
    etat.config.modeles = e.modeles;
    const m = $("#modeles");
    m.className = "modeles" + (e.modeles.pret ? (e.modeles.erreurs.length ? " erreur" : " pret") : "");
    m.textContent = e.modeles.pret
      ? (e.modeles.erreurs.length ? "Modèles : attention" : "Modèles prêts")
      : "Modèles : " + e.modeles.etat + "…";
    m.title = e.modeles.erreurs.join("\n") || "spaCy" + (e.modeles.gliner ? " + GLiNER" : "");
    if (!e.modeles.pret) setTimeout(rafraichirModeles, 1500);
  } catch {
    $("#modeles").textContent = "Serveur injoignable";
    $("#modeles").className = "modeles erreur";
    setTimeout(rafraichirModeles, 3000);
  }
}

// ------------------------------------------------------------------ 1. avertissement

// Textes légaux dans la langue de l'interface (le serveur fournit les deux).
const avertissementLangue = () => (etat.config.avertissements && etat.config.avertissements[LANGUE]) || etat.config.avertissement;

function preparerAvertissement() {
  const a = avertissementLangue();
  $("#txt-propriete").textContent = a.propriete;
  $("#txt-composants").textContent = a.composants;
  $("#txt-responsabilite").textContent = a.responsabilite;
  $("#txt-fiabilite").textContent = a.fiabilite;
  $("#txt-confidentialite").textContent = a.confidentialite;
  $("#txt-pseudonymisation").textContent = a.pseudonymisation;
  $("#txt-loi").textContent = a.loi;
  $("#mention").textContent = a.mention;
  if (a.email) {
    $("#contact-email").textContent = a.email;
    $("#contact-email").href = "mailto:" + a.email;
    $("#contact-telephone").textContent = a.telephone;
    $("#contact-telephone").href = "tel:" + a.telephone.replace(/\s/g, "");
  }
  $("#accepter").checked = false;
  $("#btn-accepter").disabled = true;
}
$("#accepter").addEventListener("change", (e) => ($("#btn-accepter").disabled = !e.target.checked));
$("#btn-accepter").addEventListener("click", () => {
  etat.acceptation = new Date().toLocaleString("fr-FR");
  const suite = etat.suite || (() => afficher("fichiers"));
  etat.suite = null;
  suite();
});

// ------------------------------------------------------------------ 2. fichiers

let EXTENSIONS = [".docx", ".pptx", ".xlsx", ".md", ".markdown", ".txt", ".csv", ".tsv", ".html", ".htm"]; // remplacé par la liste du serveur
let EXTENSIONS_ENTREE = [...EXTENSIONS, ".pdf"];   // à analyser : les PDF s'y ajoutent (ni restauration ni correction)
function ajouterFichier(fichier, chemin, liste = etat.fichiers) {
  const nom = chemin || fichier.name;
  if (fichier.name.startsWith("~$")) return;
  const autorisees = liste === etat.fichiers ? EXTENSIONS_ENTREE : EXTENSIONS;
  if (!autorisees.some((x) => nom.toLowerCase().endsWith(x))) return;
  if (liste.some((f) => f.chemin === nom)) return;
  liste.push({ fichier, chemin: nom });
}
function afficherFichiers() {
  const ul = $("#liste-fichiers");
  ul.innerHTML = etat.fichiers
    .map((f, i) => `<li><span>${echapper(f.chemin)}</span><button data-i="${i}" title="Retirer">✕</button></li>`)
    .join("");
  // Les options PDF (format de sortie, reconnaissance de caractères) n'apparaissent que si un PDF est déposé,
  // ou si l'on indique un dossier (son contenu n'est pas connu du navigateur).
  const avecPdf = etat.fichiers.some((f) => f.chemin.toLowerCase().endsWith(".pdf")) || $("#dossier").value.trim() !== "";
  $("#options-pdf").hidden = !avecPdf;
  const ocr = etat.config && etat.config.pdf && etat.config.pdf.ocr;
  $("#info-ocr").textContent = ocr && !ocr.disponible ? ocr.message : "";
  $("#info-ocr").hidden = !$("#info-ocr").textContent;
}
$("#dossier").addEventListener("input", afficherFichiers);
$("#liste-fichiers").addEventListener("click", (e) => {
  if (e.target.dataset.i !== undefined) {
    etat.fichiers.splice(Number(e.target.dataset.i), 1);
    afficherFichiers();
  }
});

async function lireEntree(entree, prefixe = "", liste = etat.fichiers) {
  if (entree.isFile) {
    const fichier = await new Promise((ok, ko) => entree.file(ok, ko));
    ajouterFichier(fichier, prefixe + fichier.name, liste);
  } else if (entree.isDirectory) {
    const lecteur = entree.createReader();
    let lot;
    do {
      lot = await new Promise((ok, ko) => lecteur.readEntries(ok, ko));
      for (const e of lot) await lireEntree(e, prefixe + entree.name + "/", liste);
    } while (lot.length);
  }
}

const depot = $("#depot");
["dragenter", "dragover"].forEach((t) =>
  depot.addEventListener(t, (e) => { e.preventDefault(); depot.classList.add("survol"); }));
["dragleave", "drop"].forEach((t) =>
  depot.addEventListener(t, (e) => { e.preventDefault(); depot.classList.remove("survol"); }));
depot.addEventListener("drop", async (e) => {
  const entrees = [...e.dataTransfer.items].map((i) => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  if (entrees.length) for (const en of entrees) await lireEntree(en);
  else [...e.dataTransfer.files].forEach((f) => ajouterFichier(f));
  afficherFichiers();
});
$("#btn-parcourir").addEventListener("click", () => $("#selecteur").click());
depot.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") $("#selecteur").click(); });
$("#selecteur").addEventListener("change", (e) => {
  [...e.target.files].forEach((f) => ajouterFichier(f));
  e.target.value = "";
  afficherFichiers();
});

$("#btn-analyser").addEventListener("click", async () => {
  const erreur = $("#erreur-fichiers");
  erreur.hidden = true;
  const dossier = $("#dossier").value.trim();
  if (!etat.fichiers.length && !dossier) {
    erreur.textContent = "Déposez des fichiers ou indiquez un dossier à traiter.";
    erreur.hidden = false;
    return;
  }
  const donnees = new FormData();
  donnees.append("avertissement_accepte", etat.acceptation);
  donnees.append("dossier_sortie", $("#dossier-sortie").value.trim());
  donnees.append("mode", document.querySelector("input[name=mode]:checked").value);
  donnees.append("langue", LANGUE);
  donnees.append("format_pdf", $("#format-pdf").value);
  donnees.append("termes_imposes", $("#termes-imposes").value);
  if ($("#profil-choix").value) donnees.append("profil_id", $("#profil-choix").value);
  etat.formatDemande = $("#format-sortie").value;
  const portee = champsPortee();
  if (portee.erreur) { erreur.textContent = portee.erreur; erreur.hidden = false; return; }
  for (const [cle, valeur] of Object.entries(portee.champs)) donnees.append(cle, valeur);
  if (etat.fichiers.length) etat.fichiers.forEach((f) => donnees.append("fichiers", f.fichier, f.chemin));
  else donnees.append("dossier", dossier);
  $("#btn-analyser").disabled = true;
  try {
    const { id } = await api("/api/lots", { method: "POST", body: donnees });
    etat.lot = { id };
    $("#progression-titre").textContent = "Analyse en cours";
    afficher("progression", "fichiers");
    suivre();
  } catch (e) {
    erreur.textContent = e.message;
    erreur.hidden = false;
  } finally {
    $("#btn-analyser").disabled = false;
  }
});

// ------------------------------------------------------------------ progression

async function suivre() {
  if (!etat.lot) return;                 // lot abandonné (menu, nouveau lot, arrêt) : on cesse d'interroger le serveur
  const id = etat.lot.id;
  let lot;
  try {
    lot = await api(`/api/lots/${id}`);
  } catch (e) {
    if (!etat.lot || etat.lot.id !== id) return;      // réponse tardive d'un lot abandonné
    return erreurFatale(e.message);
  }
  if (!etat.lot || etat.lot.id !== id) return;
  etat.lot = lot;
  if (lot.etat === "erreur") return erreurFatale(lot.erreur);
  if (lot.etat === "a_valider") return preparerValidation(lot);
  if (lot.etat === "bloque") return afficherBlocage(lot);
  if (lot.etat === "provisoire") return afficherProvisoire(lot);
  if (lot.etat === "termine") return afficherResultats(lot);
  afficherProgression(lot);
  setTimeout(suivre, 1000);   // interrogation chaque seconde : l'affichage est donc rafraîchi bien plus souvent que toutes les 5 s
}

const NOMS_COMPTEURS = { personne: "Personnes", societe: "Sociétés", produit: "Produits et marques", lieu: "Lieux",
  sensible: "Informations sensibles", image: "Images supprimées" };

function duree(secondes) {
  const s = Math.max(0, Math.round(secondes));
  if (s < 60) return `${s} s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} min ${String(s % 60).padStart(2, "0")} s`;
  return `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")} min`;
}
const nombre = (n) => Number(n || 0).toLocaleString(LANGUE === "en" ? "en-GB" : "fr-FR");
function cartes(liste) {
  return liste.map(([titre, valeur]) =>
    `<div class="stat"><span class="stat-titre">${echapper(titre)}</span><span class="stat-valeur">${valeur}</span></div>`).join("");
}
function compteurs(objet, ordre) {
  return cartes(ordre.filter((c) => c in objet || c !== "image").map((c) => [NOMS_COMPTEURS[c], String(objet[c] || 0)]));
}

let horloge = null;
function afficherProgression(lot) {
  const p = lot.progression;
  const analyse = p.groupe === "analyse";
  const pct = Math.round(p.fraction * 100);
  $("#progression-titre").textContent = analyse ? "Analyse en cours"
    : (lot.mode === "anonymisation" ? "Anonymisation en cours" : "Pseudonymisation en cours");
  $("#phases").innerHTML = p.phases.map((ph) => `<li class="${ph.etat}">${echapper(ph.libelle)}</li>`).join("");
  $("#barre").style.width = pct + "%";
  $("#progression-pct").textContent = pct + " %";
  $("#progression-etape").textContent = p.etape + (p.detail ? ` — ${p.detail}` : "");
  $("#progression-fichier").textContent = p.fichier ? `Fichier en cours : ${p.fichier}` : "";
  const enCours = ["lecture", "detection", "remplacement"].includes(p.phase);
  const fichiers = p.phase === "modeles" ? 0 : (enCours ? Math.min(p.courant + 1, p.total) : p.total);
  $("#stats-progression").innerHTML = cartes([
    ["Durée écoulée", `<span id="stat-ecoule">${duree(p.ecoule)}</span>`],
    ["Temps restant estimé", p.restant == null ? "calcul en cours…" : "≈ " + duree(p.restant)],
    ["Fichiers", `${fichiers} / ${p.total}`],
    // Serveur plus ancien que la page : pas de compteur plutôt qu'un « 0 / 0 » trompeur (relancer Sine Nomine).
    ...(p.mots_total === undefined ? [] : [["Mots", `${nombre(p.mots)} / ${nombre(p.mots_total)}`]]),
  ]);
  if (analyse) {
    $("#titre-compteurs").textContent = "Détectés jusqu'ici (formes distinctes)";
    $("#compteurs-progression").innerHTML = compteurs(p.decouverts, ["personne", "societe", "produit", "lieu", "sensible"]);
  } else {
    const total = ["personne", "societe", "produit", "lieu", "sensible"].reduce((a, c) => a + (p.substitutions[c] || 0), 0);
    $("#titre-compteurs").textContent = `Substitutions effectuées : ${total}`;
    $("#compteurs-progression").innerHTML = compteurs(p.substitutions, ["personne", "societe", "produit", "lieu", "sensible", "image"]);
  }
  // Horloge locale : la durée écoulée et « mis à jour il y a » avancent chaque seconde, même entre deux réponses.
  etat.chrono = { base: p.ecoule, maj: p.derniere_maj, recu: performance.now(), actif: true };
  if (!horloge) horloge = setInterval(tictac, 1000);
  tictac();
}
function tictac() {
  const c = etat.chrono;
  if (!c || !c.actif) return;
  const depuis = (performance.now() - c.recu) / 1000;
  const el = $("#stat-ecoule");
  if (el) el.textContent = duree(c.base + depuis);
  const maj = Math.round(c.maj + depuis);
  $("#progression-maj").textContent = maj <= 2 ? "À jour." : `Dernière mise à jour du traitement il y a ${maj} s. Un long document peut prendre plusieurs minutes.`;
}

// ------------------------------------------------------------------ 3. validation

function preparerValidation(lot) {
  etat.mode = lot.mode;
  // « Toujours détecter » écrirait des noms réels dans les dictionnaires : impossible en anonymisation.
  $("#ajout-dictionnaire").closest("label").hidden = lot.mode === "anonymisation";
  $("#ajout-dictionnaire").checked = false;
  $("#btn-confirmer").textContent = lot.mode === "anonymisation" ? "Confirmer et anonymiser (irréversible)" : "Confirmer et pseudonymiser";
  etat.entites = lot.entites.map((e) => ({ ...e, variantes: [...e.variantes] }));
  etat.sensibles = lot.sensibles;
  etat.actions = { ...etat.config.actions_par_defaut };
  for (const c of Object.keys(etat.config.categories_sensibles)) etat.actions[c] ||= "conserver";
  etat.images = etat.config.images_par_defaut === "supprimer" ? "supprimer" : "conserver";
  etat.nbImages = lot.images || {};
  etat.apercus = lot.apercus || {};
  etat.exclusions = new Set();
  etat.selectionFusion = new Set();
  etat.historiqueFusions = [];
  etat.compteFusions = 0;
  etat.fusionsRefusees = new Set();
  etat.termesRetires = new Set(lot.termes_retires || []);
  etat.passages = (lot.passages || []).map((p) => ({ texte: p.texte, cles: p.cles, occurrences: [], total: p.cles.length }));
  etat.decisions = { occurrences: 0, masquages: 0 };
  if (lot.choix_precedent) {                       // reprise après un blocage : les choix précédents sont conservés
    etat.actions = { ...etat.actions, ...(lot.choix_precedent.actions || {}) };
    etat.exclusions = new Set((lot.choix_precedent.exclusions || []).map((x) => x.join(SEP_CLE)));
    etat.images = lot.choix_precedent.images || etat.images;
  }
  vueTexte = { fichier: null, debut: 0, total: 0 };
  $("#passage-fichier").innerHTML = "";
  etat.onglet = "personne";
  etat.vus = new Set(["personne"]);
  appliquerProfilAuLot({ ...lot, formatDemande: etat.formatDemande });
  $("#seuil").textContent = pourcent(etat.config.seuil);
  $("#ajout-categorie").innerHTML = Object.entries(etat.config.categories_entites)
    .map(([c, n]) => `<option value="${c}">${n}</option>`).join("");

  $("#resume-lot").textContent = `${lot.fichiers.length} fichier(s) · lot ${lot.id}`;
  const rappel = $("#portee-lot");
  rappel.textContent = lot.portee ? libellePortee(lot.portee) : "";
  rappel.hidden = !lot.portee;
  const alertes = [];
  if (lot.ignores.length) alertes.push(`Fichiers ignorés (format non pris en charge) : ${lot.ignores.map(echapper).join(", ")}`);
  for (const [f, m] of Object.entries(lot.erreurs_lecture)) alertes.push(`Impossible de lire ${echapper(f)} : ${echapper(m)}`);
  for (const m of etat.config.modeles.erreurs) alertes.push(echapper(m));
  for (const m of (lot.langues ? lot.langues.avertissements : [])) alertes.push("⚠ " + echapper(traduire(m)));
  $("#alertes-lot").innerHTML = alertes.map((a) => `<div class="alerte">${a}</div>`).join("");

  afficher("validation");
  dessinerValidation();
}

// Les codes sont tirés au hasard à la confirmation. Un nom déjà anonymisé garde son code (archive) ; les autres en reçoivent un nouveau.
// En anonymisation : numéros dans l'ordre d'apparition, sans archive.
function libelles() {
  const resultat = {};
  const compteurs = {};
  const anonymisation = etat.mode === "anonymisation";
  for (const e of etat.entites) {
    if (!e.selection) continue;
    const nom = etat.config.categories_entites[e.categorie];
    if (anonymisation) {
      compteurs[e.categorie] = (compteurs[e.categorie] || 0) + 1;
      resultat[e.id] = `${nom}_${compteurs[e.categorie]}`;
    } else {
      resultat[e.id] = e.code || `${nom}_·····`;
    }
  }
  return resultat;
}

function dessinerOnglets() {
  const nb = (c) => etat.entites.filter((e) => e.categorie === c).length;
  const classes = (c) => [etat.onglet === c ? "actif" : "", etat.vus.has(c) ? "" : "a-verifier"].join(" ");
  const onglets = Object.entries(etat.config.categories_entites).map(([c, n]) =>
    `<button data-onglet="${c}" class="${classes(c)}">${pluriel(c, n)} <span class="compte">${nb(c)}</span></button>`);
  onglets.push(`<button data-onglet="fusion" class="${classes("fusion")}">Rapprochements <span class="compte">${etat.historiqueFusions.length}</span></button>`);
  onglets.push(`<button data-onglet="passages" class="${classes("passages")}">Passages à masquer <span class="compte">${etat.passages.length}</span></button>`);
  onglets.push(`<button data-onglet="sensibles" class="${classes("sensibles")}">Informations sensibles et images <span class="compte">${etat.sensibles.length}</span></button>`);
  $("#onglets").innerHTML = onglets.join("");
}
$("#onglets").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  ouvrirOnglet(b.dataset.onglet);
});
function ouvrirOnglet(onglet) {
  etat.onglet = onglet;
  etat.vus.add(onglet);
  etat.selectionFusion.clear();
  dessinerValidation();
}
const NOMS_ONGLETS = () => ({ ...Object.fromEntries(Object.entries(etat.config.categories_entites).map(([c, n]) => [c, pluriel(c, n)])),
  fusion: "Rapprochements", passages: "Passages à masquer", sensibles: "Informations sensibles et images" });

function dessinerValidation() {
  dessinerOnglets();
  const sensiblesVisible = etat.onglet === "sensibles";
  const fusionVisible = etat.onglet === "fusion", passagesVisible = etat.onglet === "passages";
  $("#panneau-entites").hidden = sensiblesVisible || fusionVisible || passagesVisible;
  $("#panneau-sensibles").hidden = !sensiblesVisible;
  $("#panneau-fusion").hidden = !fusionVisible;
  $("#panneau-passages").hidden = !passagesVisible;
  if (sensiblesVisible) dessinerSensibles();
  else if (fusionVisible) dessinerFusion();
  else if (passagesVisible) dessinerPassages();
  else dessinerEntites();
  dessinerRecap();
}

function dessinerEntites() {
  const lib = libelles();
  const recherche = $("#recherche").value.trim().toLowerCase();
  const cochesSeulement = $("#filtre-coches").checked;
  const options = Object.entries(etat.config.categories_entites);
  const lignes = etat.entites
    .filter((e) => e.categorie === etat.onglet)
    .filter((e) => !cochesSeulement || e.selection)
    .filter((e) => !recherche || e.variantes.some((v) => v.toLowerCase().includes(recherche)) || e.canonique.toLowerCase().includes(recherche))
    .map((e) => {
      const autres = e.variantes.filter((v) => v !== e.canonique);
      const visibles = etat.variantesDepliees.has(e.id) ? autres : autres.slice(0, VARIANTES_VISIBLES);
      const masquees = autres.length - visibles.length;
      const sources = (e.sources || []).map((src) => traduire(src)).join(", ");
      const fichiers = Object.entries(e.fichiers || {}).map(([f, n]) => `${f} (${n})`).join(" · ");
      const impose = (e.termes || []).length > 0;
      const proches = (e.approximatives || []).filter((a) => !e.variantes.includes(a.texte));
      return `<tr data-id="${e.id}" class="${e.selection ? "" : "decoche"}">
        <td><input type="checkbox" class="fusion" ${etat.selectionFusion.has(e.id) ? "checked" : ""} title="Sélectionner pour fusionner"></td>
        <td><input type="checkbox" class="selection" ${e.selection ? "checked" : ""} ${impose ? "disabled" : ""} title="${impose ? "Terme imposé : à retirer explicitement de la liste pour le décocher" : "Remplacer cette entité"}"></td>
        <td>
          <input class="nom-canonique" value="${echapper(e.canonique)}" title="Nom de référence (modifiable)">
          <div class="puces">${visibles.map((v) => `<span class="puce">${echapper(v)}<button data-variante="${echapper(v)}" title="Retirer cette variante">✕</button></span>`).join("")}
            ${masquees ? `<button class="lien petit deplier" title="Afficher toutes les variantes recherchées">+ ${masquees} autres</button>` : ""}
            <input class="puce-ajout" placeholder="+ variante" title="Ajouter une variante, puis Entrée"></div>
          ${impose ? `<div class="sources"><span class="etiquette-imposee">${echapper(t("Fourni par l'utilisateur"))}</span>
            ${e.occurrences === 0 ? echapper(t("0 occurrence : un pseudonyme est tout de même attribué.")) : ""}
            <button class="lien petit retirer-terme">${echapper(t("Retirer de la liste imposée"))}</button></div>` : ""}
          ${proches.length ? `<details><summary class="sources">${proches.length} ${echapper(t("forme(s) proche(s) à valider"))}</summary>${proches.map((a) =>
            `<p class="contexte">${contexteHtml(a.contexte)} <button class="petit ajouter-approx" data-texte="${echapper(a.texte)}">${echapper(t("Ajouter comme variante"))}</button></p>`).join("")}</details>` : ""}
          ${e.contextes && e.contextes.length ? `<details><summary class="sources">Contexte · ${echapper(fichiers)}</summary>${e.contextes.map((c) => `<p class="contexte">${contexteHtml(c)}</p>`).join("")}</details>` : ""}
        </td>
        <td><select class="categorie">${options.map(([c, n]) => `<option value="${c}" ${c === e.categorie ? "selected" : ""}>${n}</option>`).join("")}</select>
          <div class="remplace-par">${e.selection ? `${echapper(traduire("remplacé par"))} <span class="libelle">${echapper(lib[e.id])}</span>` : echapper(traduire("non remplacé"))}</div></td>
        <td class="num">${e.occurrences ?? "—"}</td>
        <td class="num ${e.score < etat.config.seuil ? "confiance-basse" : ""}" title="${echapper(sources)}">${pourcent(e.score)}<div class="sources">${echapper(sources)}</div></td>
        <td class="actions-ligne"><button class="petit examiner" title="Voir les passages où ce terme apparaît">Examiner le contexte</button>
          <button class="petit ignorer" title="Décocher et ne plus jamais détecter ce terme">Toujours ignorer</button></td>
      </tr>`;
    });
  $("#tableau-entites tbody").innerHTML = lignes.join("");
  $("#vide-entites").hidden = lignes.length > 0;
  $("#btn-fusionner").disabled = etat.selectionFusion.size < 2;
}

function entite(id) { return etat.entites.find((e) => e.id === id); }
function idLigne(el) { return Number(el.closest("tr").dataset.id); }

const tbody = $("#tableau-entites tbody");
tbody.addEventListener("change", (e) => {
  const t = e.target;
  if (!t.closest("tr")) return;
  const en = entite(idLigne(t));
  if (t.classList.contains("selection")) en.selection = t.checked;
  else if (t.classList.contains("fusion")) {
    t.checked ? etat.selectionFusion.add(en.id) : etat.selectionFusion.delete(en.id);
    $("#btn-fusionner").disabled = etat.selectionFusion.size < 2;
    return;
  } else if (t.classList.contains("categorie")) en.categorie = t.value;
  else if (t.classList.contains("nom-canonique")) {
    const nouveau = t.value.trim();
    if (!nouveau) { t.value = en.canonique; return; }
    en.canonique = nouveau;
    if (!en.variantes.includes(nouveau)) en.variantes.unshift(nouveau);
  } else return;
  dessinerValidation();
});
tbody.addEventListener("keydown", (e) => {
  if (e.target.classList.contains("puce-ajout") && e.key === "Enter") {
    e.preventDefault();
    const v = e.target.value.trim();
    const en = entite(idLigne(e.target));
    if (v && !en.variantes.includes(v)) en.variantes.push(v);
    dessinerValidation();
  }
});
tbody.addEventListener("click", async (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const en = entite(idLigne(b));
  if (b.dataset.variante !== undefined) {
    en.variantes = en.variantes.filter((v) => v !== b.dataset.variante);
    dessinerValidation();
  } else if (b.classList.contains("deplier")) {
    etat.variantesDepliees.add(en.id);
    dessinerEntites();
  } else if (b.classList.contains("retirer-terme")) {
    if (!confirmer(t("Retirer ce terme de la liste imposée ? Il ne sera plus vérifié dans les fichiers produits."))) return;
    for (const id of en.termes) etat.termesRetires.add(id);
    en.termes = [];
    dessinerValidation();
  } else if (b.classList.contains("ajouter-approx")) {
    if (!en.variantes.includes(b.dataset.texte)) en.variantes.push(b.dataset.texte);
    dessinerValidation();
  } else if (b.classList.contains("examiner")) {
    examinerContexte(en);
  } else if (b.classList.contains("ignorer")) {
    en.selection = false;
    b.disabled = true;
    try {
      await api("/api/dictionnaire", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lot: etat.lot.id, liste: "exclusions", terme: en.canonique }) });
    } catch (err) { alerter(err.message); }
    dessinerValidation();
  }
});

// Examiner le contexte : les passages du lot où apparaît le terme (ou l'une de ses variantes), puis retour à la validation
// à l'endroit où l'on était, avec toutes les coches et modifications intactes.
let examen = null;   // { variantes, defilement, id }

async function chargerExtraits() {
  const liste = $("#contexte-liste");
  $("#contexte-info").textContent = traduire("Recherche des passages…");
  try {
    const r = await api(`/api/lots/${etat.lot.id}/occurrences`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ variantes: examen.variantes, mots: Number($("#contexte-mots").value) }) });
    const en = entite(examen.id);
    const impose = (en.termes || []).length > 0;
    $("#contexte-info").textContent = r.total === 0 ? t("Aucun passage trouvé : ce terme a été ajouté à la main ou n'apparaît plus tel quel dans le texte.")
      : r.total > r.occurrences.length ? t("{n} passage(s) au total, les {m} premiers sont affichés.", { n: r.total, m: r.occurrences.length })
      : t("{n} passage(s).", { n: r.total });
    $("#contexte-portee").textContent = (etat.lot.portee ? libellePortee(etat.lot.portee) + " " : "")
      + t("Ces décisions ne concernent que ce lot et ce périmètre.")
      + (impose ? " " + t("Terme imposé : toutes les occurrences sont remplacées.") : "");
    $("#contexte-actions").hidden = impose;
    liste.innerHTML = r.occurrences.map((x) => `<blockquote class="extrait"><label class="case">
      <input type="checkbox" class="occurrence" data-cle="${x.cle}" ${(en.gardees || []).includes(x.cle) ? "" : "checked"} ${impose ? "disabled" : ""}>
      <span>${echapper(t("Remplacer cette occurrence"))}</span></label><p>${contexteHtml(x.extrait)}</p>
      <footer>${echapper(x.fichier)}</footer></blockquote>`).join("");
  } catch (e) {
    $("#contexte-info").textContent = e.message;
    liste.innerHTML = "";
  }
}

function examinerContexte(en) {
  examen = { variantes: [...new Set([en.canonique, ...en.variantes])], defilement: window.scrollY, id: en.id };
  $("#contexte-terme").textContent = en.canonique;
  $("#contexte-liste").innerHTML = "";
  afficher("contexte", "validation");
  window.scrollTo(0, 0);
  chargerExtraits();
}
$("#contexte-mots").addEventListener("change", () => examen && chargerExtraits());
$("#contexte-liste").addEventListener("change", (e) => {
  if (!e.target.classList.contains("occurrence") || !examen) return;
  const en = entite(examen.id);
  const cle = e.target.dataset.cle;
  en.gardees = e.target.checked ? (en.gardees || []).filter((c) => c !== cle) : [...new Set([...(en.gardees || []), cle])];
  etat.decisions.occurrences++;
});
$("#btn-tout-remplacer").addEventListener("click", () => {          // décision globale : toutes les occurrences de ce terme dans ce lot
  const en = entite(examen.id);
  en.gardees = [];
  en.selection = true;
  etat.decisions.occurrences++;
  chargerExtraits();
});
$("#btn-tout-conserver").addEventListener("click", () => {
  const en = entite(examen.id);
  if (!confirmer(t("Conserver toutes les occurrences de ce terme dans ce lot (le terme sera décoché) ?"))) return;
  en.selection = false;
  etat.decisions.occurrences++;
  chargerExtraits();
});
$("#btn-retour-validation").addEventListener("click", () => {
  const depart = examen;
  examen = null;
  afficher("validation");
  dessinerValidation();
  window.scrollTo(0, depart ? depart.defilement : 0);
  const ligne = depart && document.querySelector(`#tableau-entites tr[data-id="${depart.id}"]`);
  if (ligne) {                                    // la ligne examinée est brièvement mise en évidence
    ligne.classList.add("examinee");
    setTimeout(() => ligne.classList.remove("examinee"), 2500);
  }
});

$("#recherche").addEventListener("input", dessinerEntites);
$("#filtre-coches").addEventListener("change", dessinerEntites);
function cocherTout(valeur) {
  etat.entites.filter((e) => e.categorie === etat.onglet).forEach((e) => (e.selection = valeur));
  dessinerValidation();
}
$("#btn-tout-cocher").addEventListener("click", () => cocherTout(true));
$("#btn-tout-decocher").addEventListener("click", () => cocherTout(false));

$("#btn-fusionner").addEventListener("click", () => {
  fusionner(etat.entites.filter((e) => etat.selectionFusion.has(e.id)).map((e) => e.id));
  dessinerValidation();
});

$("#form-ajout").addEventListener("submit", async (e) => {
  e.preventDefault();
  const nom = $("#ajout-nom").value.trim();
  const categorie = $("#ajout-categorie").value;
  if (!nom) return;
  etat.entites.push({ id: etat.prochainId--, categorie, canonique: nom, variantes: [nom], score: 1,
    sources: ["manuel"], selection: true, occurrences: null, fichiers: {}, contextes: [] });
  if ($("#ajout-dictionnaire").checked) {
    try {
      await api("/api/dictionnaire", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lot: etat.lot.id, liste: categorie, terme: nom }) });
    } catch (err) { alerter(err.message); }
  }
  $("#ajout-nom").value = "";
  etat.onglet = categorie;
  etat.vus.add(categorie);
  dessinerValidation();
});

function dessinerSensibles() {
  const parCategorie = {};
  for (const s of etat.sensibles) (parCategorie[s.categorie] ||= []).push(s);
  const blocs = Object.entries(etat.config.categories_sensibles).map(([c, nom]) => {
    const items = parCategorie[c] || [];
    const radios = Object.entries(actionsPour(c)).map(([a, n]) =>
      `<label><input type="radio" name="action-${c}" value="${a}" data-categorie="${c}" ${etat.actions[c] === a ? "checked" : ""} ${items.length ? "" : "disabled"}>${n}</label>`).join("");
    const lignes = items.map((s) => {
      const cle = c + SEP_CLE + s.cle;
      return `<tr>
        <td><label class="case"><input type="checkbox" class="exclure" data-cle="${echapper(cle)}" ${etat.exclusions.has(cle) ? "checked" : ""} ${etat.actions[c] === "conserver" ? "disabled" : ""}><span>Conserver</span></label></td>
        <td class="valeur">${s.valeurs.map(echapper).join("<br>")}</td>
        <td class="num">${s.occurrences}</td>
        <td class="num">${pourcent(s.score)}</td>
        <td>${s.contextes.map((x) => `<p class="contexte">${contexteHtml(x)}</p>`).join("")}</td>
      </tr>`;
    }).join("");
    return `<div class="categorie-sensible ${items.length ? "" : "sans-occurrence"}">
      <header><h3>${nom} <span class="compte discret">(${items.length})</span></h3><div class="choix-action">${radios}</div></header>
      ${items.length ? `<details ${items.length <= 5 ? "open" : ""}><summary>Voir les éléments détectés et exclure ceux à conserver</summary>
        <table class="tableau"><thead><tr><th>Exception</th><th>Valeur</th><th class="num">Occ.</th><th class="num">Confiance</th><th>Contexte</th></tr></thead><tbody>${lignes}</tbody></table></details>`
        : `<p class="discret">Aucun élément détecté.</p>`}
    </div>`;
  });
  const totalImages = Object.values(etat.nbImages).reduce((a, b) => a + b, 0);
  const radiosImages = [["conserver", "Conserver"], ["supprimer", "Supprimer"]].map(([a, n]) =>
    `<label><input type="radio" name="action-images" value="${a}" data-images ${etat.images === a ? "checked" : ""} ${totalImages ? "" : "disabled"}>${n}</label>`).join("");
  blocs.push(`<div class="categorie-sensible ${totalImages ? "" : "sans-occurrence"}">
    <header><h3>Images <span class="compte discret">(${totalImages})</span></h3><div class="choix-action">${radiosImages}</div></header>
    <p class="discret">Les images ne sont pas analysées : logos, signatures et captures d'écran peuvent contenir des informations identifiantes.
      Supprimées, elles sont remplacées par le texte « [image supprimée] ». Les graphiques, zones de texte et SmartArt sont conservés.</p>
    ${totalImages ? Object.entries(etat.nbImages).map(([f, n]) =>
        `<p class="contexte"><strong>${echapper(f)}</strong> : ${n} image(s)</p>${vignettes(etat.apercus[f])}`).join("")
      : `<p class="discret">Aucune image détectée.</p>`}
  </div>`);
  blocs.push(blocNonAnalyses(), blocFormatSortie(), blocProfilLot());
  $("#panneau-sensibles").innerHTML = blocs.join("");
}
$("#panneau-sensibles").addEventListener("change", (e) => {
  const t = e.target;
  if (t.name === "politique") {
    etat.politique = t.value;
    if (t.value === "renforcee") etat.images = "supprimer";             // la politique renforcée supprime les images
    dessinerValidation();
  } else if (t.id === "format-general") {
    etat.formatSortie = t.value;
    etat.formatsFichiers = {};
    dessinerValidation();
  } else if (t.classList.contains("format-fichier")) {
    etat.formatsFichiers[t.dataset.fichier] = t.value;
  } else if (t.type === "radio" && t.dataset.images !== undefined) {
    etat.images = t.value;
    dessinerRecap();
  } else if (t.type === "radio") {
    etat.actions[t.dataset.categorie] = t.value;
    dessinerValidation();
  } else if (t.classList.contains("exclure")) {
    t.checked ? etat.exclusions.add(t.dataset.cle) : etat.exclusions.delete(t.dataset.cle);
    dessinerRecap();
  }
});

function dessinerRecap() {
  const retenues = etat.entites.filter((e) => e.selection);
  const nb = (c) => retenues.filter((e) => e.categorie === c).length;
  const sensiblesTraitees = etat.sensibles.filter((s) => etat.actions[s.categorie] !== "conserver" && !etat.exclusions.has(s.categorie + SEP_CLE + s.cle)).length;
  $("#recap-validation").textContent =
    `À remplacer : ${nb("personne")} personne(s), ${nb("societe")} société(s), ${nb("produit")} produit(s), ${nb("lieu")} lieu(x), ${sensiblesTraitees} information(s) sensible(s)` +
    (etat.images === "supprimer" ? ", images supprimées." : ".");
  // Parcours guidé : on passe d'onglet en onglet, et on ne peut confirmer que sur le dernier, après les avoir tous ouverts.
  const noms = NOMS_ONGLETS();
  const ordre = Object.keys(noms);
  const rang = ordre.indexOf(etat.onglet);
  const dernier = rang === ordre.length - 1;
  const restants = ordre.filter((o) => !etat.vus.has(o));
  const reste = $("#reste-a-verifier");
  reste.className = dernier && !restants.length ? "fait" : "";
  reste.innerHTML = !dernier
    ? `Onglet ${rang + 1} sur ${ordre.length} : ${noms[etat.onglet]}`
    : (restants.length
      ? "Reste à vérifier avant de confirmer : " + restants.map((o) => `<button class="lien" data-aller="${o}">${noms[o]}</button>`).join(", ")
      : "Tous les onglets ont été vérifiés.");
  $("#btn-precedent").hidden = rang <= 0;
  $("#btn-suivant").hidden = dernier;
  $("#btn-suivant").title = dernier ? "" : `Suivant : ${noms[ordre[rang + 1]]}`;
  $("#btn-confirmer").hidden = !dernier;
  $("#btn-confirmer").disabled = restants.length > 0;
  $("#mention-attestation").hidden = !dernier;
}
function changerOnglet(decalage) {
  const ordre = Object.keys(NOMS_ONGLETS());
  const cible = ordre[ordre.indexOf(etat.onglet) + decalage];
  if (cible) { ouvrirOnglet(cible); window.scrollTo(0, 0); }
}
$("#btn-suivant").addEventListener("click", () => changerOnglet(1));
$("#btn-precedent").addEventListener("click", () => changerOnglet(-1));
$("#reste-a-verifier").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-aller]");
  if (b) { ouvrirOnglet(b.dataset.aller); window.scrollTo(0, 0); }
});

$("#btn-confirmer").addEventListener("click", async () => {
  const choix = {
    politique: etat.politique, format_sortie: etat.formatSortie, formats_fichiers: etat.formatsFichiers,
    provisoire: true,                  // résultats provisoires, contrôles et comparaison avant l'export définitif
    verification_confirmee: true,      // la confirmation sur le dernier onglet vaut attestation (mention affichée au-dessus)
    entites: etat.entites.map((e) => ({ id: e.id > 0 ? e.id : null, categorie: e.categorie, canonique: e.canonique,
      variantes: e.variantes, selection: e.selection, score: e.score, sources: e.sources,
      termes: e.termes || [], gardees: e.gardees || [] })),
    termes_retires: [...etat.termesRetires],
    passages: etat.passages.filter((p) => p.cles.length).map((p) => ({ texte: p.texte, cles: p.cles })),
    fusions: etat.historiqueFusions.length,
    actions: etat.actions,
    exclusions: [...etat.exclusions].map((k) => k.split(SEP_CLE)),
    images: etat.images,
  };
  $("#btn-confirmer").disabled = true;
  try {
    await api(`/api/lots/${etat.lot.id}/valider`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(choix) });
    $("#progression-titre").textContent = "Anonymisation en cours";
    $("#barre").style.width = "0";
    afficher("progression", "validation");
    suivre();
  } catch (e) {
    alerter(e.message);
    $("#btn-confirmer").disabled = false;
  }
});


// ------------------------------------------------------------------ rapprochements (étape distincte de fusion)

const copie = (x) => JSON.parse(JSON.stringify(x));
function fusionner(ids, referenceId) {
  const choisies = ids.map(entite).filter(Boolean);
  if (choisies.length < 2) return;
  const cible = choisies.find((e) => e.id === referenceId) || choisies[0];
  const autres = choisies.filter((e) => e !== cible);
  const entree = { numero: ++etat.compteFusions, cible: copie(cible), retirees: autres.map(copie), libelle: choisies.map((e) => e.canonique).join(" + ") };
  for (const a of autres) {
    for (const v of a.variantes) if (!cible.variantes.includes(v)) cible.variantes.push(v);
    cible.occurrences = (cible.occurrences || 0) + (a.occurrences || 0);
    cible.score = Math.max(cible.score, a.score);
    cible.contextes = [...(cible.contextes || []), ...(a.contextes || [])].slice(0, 3);
    cible.fichiers = cible.fichiers || {};
    for (const [f, n] of Object.entries(a.fichiers || {})) cible.fichiers[f] = (cible.fichiers[f] || 0) + n;
    cible.sources = [...new Set([...(cible.sources || []), ...(a.sources || [])])];
    cible.termes = [...new Set([...(cible.termes || []), ...(a.termes || [])])];       // une exigence d'absence n'est jamais perdue
    cible.gardees = [...new Set([...(cible.gardees || []), ...(a.gardees || [])])];
    cible.approximatives = [...(cible.approximatives || []), ...(a.approximatives || [])];
  }
  cible.selection = true;
  const aRetirer = new Set(autres.map((a) => a.id));
  etat.entites = etat.entites.filter((e) => !aRetirer.has(e.id));
  etat.historiqueFusions.push(entree);
  etat.selectionFusion.clear();
}
function annulerFusion(numero) {
  const h = etat.historiqueFusions.find((x) => x.numero === numero);
  const cible = h && entite(h.cible.id);
  if (!cible || !confirmer(t("Séparer cette fusion ? Les modifications faites depuis sur le terme de référence seront perdues."))) return;
  etat.entites = [...etat.entites.filter((e) => e !== cible), copie(h.cible), ...h.retirees.map(copie)];
  etat.historiqueFusions = etat.historiqueFusions.filter((x) => x !== h);
}
const cleProposition = (p) => [...p.formes].sort((a, b) => a - b).join("-");
const RAISONS = { accents: "Même nom, accents ou séparateurs différents.", abrege: "Forme abrégée du même nom.",
  nom_seul: "Le nom seul figure aussi dans un nom complet.", orthographe: "Orthographe très proche (faute de frappe possible)." };

async function dessinerFusion() {
  const liste = $("#liste-fusions");
  liste.innerHTML = `<p class="discret">${echapper(t("Recherche des rapprochements…"))}</p>`;
  let propositions = [];
  try {
    const r = await api(`/api/lots/${etat.lot.id}/fusions`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ entites: etat.entites.map((e) => ({ id: e.id, categorie: e.categorie, canonique: e.canonique, occurrences: e.occurrences || 0, contextes: e.contextes || [] })) }) });
    propositions = r.propositions;
  } catch (e) { liste.innerHTML = `<p class="erreur">${echapper(e.message)}</p>`; }
  const visibles = propositions.filter((p) => !etat.fusionsRefusees.has(cleProposition(p)) && p.formes.every((id) => entite(id)));
  liste.innerHTML = visibles.length ? visibles.map((p) => {
    const [a, b] = p.formes.map(entite);
    const option = (e) => `<option value="${e.id}" ${e.id === p.reference ? "selected" : ""}>${echapper(e.canonique)}</option>`;
    return `<div class="proposition ${p.ambigu ? "ambigu" : ""}" data-cle="${cleProposition(p)}" data-formes="${p.formes.join(",")}">
      <p><strong>${echapper(a.canonique)}</strong> ⇄ <strong>${echapper(b.canonique)}</strong>
        <span class="discret">· ${echapper(t(RAISONS[p.code] || p.raison))} · ${p.occurrences} ${echapper(t("occurrence(s)"))}</span></p>
      ${p.ambigu ? `<p class="erreur">${echapper(t("Attention : ce nom seul peut désigner plusieurs personnes. Vérifiez les contextes."))}</p>` : ""}
      ${(p.contextes || []).slice(0, 3).map((c) => `<p class="contexte">${contexteHtml(c)}</p>`).join("")}
      <div class="actions-ligne"><label>${echapper(t("Forme de référence"))} <select class="reference">${option(a)}${option(b)}</select></label>
        <button class="petit principal accepter-fusion">${echapper(t("Fusionner"))}</button>
        <button class="petit refuser-fusion">${echapper(t("Ne pas fusionner"))}</button></div></div>`;
  }).join("") : `<p class="discret">${echapper(t("Aucun rapprochement à proposer."))}</p>`;
  $("#historique-fusions").innerHTML = etat.historiqueFusions.length ? etat.historiqueFusions.map((h) =>
    `<p>${echapper(h.libelle)} <button class="lien petit separer-fusion" data-numero="${h.numero}">${echapper(t("Séparer"))}</button></p>`).join("")
    : `<p class="discret">${echapper(t("Aucune fusion décidée."))}</p>`;
  $("#refus-fusions").innerHTML = etat.fusionsRefusees.size ? [...etat.fusionsRefusees].map((c) =>
    `<p>${echapper(c.split("-").map((id) => (entite(Number(id)) || { canonique: "?" }).canonique).join(" ⇄ "))}
      <button class="lien petit annuler-refus" data-cle="${c}">${echapper(t("Annuler ce refus"))}</button></p>`).join("")
    : `<p class="discret">${echapper(t("Aucun refus."))}</p>`;
}
$("#panneau-fusion").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const carte = b.closest(".proposition");
  if (b.classList.contains("accepter-fusion")) {
    fusionner(carte.dataset.formes.split(",").map(Number), Number(carte.querySelector(".reference").value));
  } else if (b.classList.contains("refuser-fusion")) {
    etat.fusionsRefusees.add(carte.dataset.cle);
  } else if (b.classList.contains("separer-fusion")) {
    annulerFusion(Number(b.dataset.numero));
  } else if (b.classList.contains("annuler-refus")) {
    etat.fusionsRefusees.delete(b.dataset.cle);
  } else return;
  dessinerValidation();
});

// ------------------------------------------------------------------ masquage manuel de passages

let vueTexte = { fichier: null, debut: 0, total: 0 };
const TRANCHE = 20000;
async function chargerTexte(fichier, debut = 0) {
  try {
    const r = await api(`/api/lots/${etat.lot.id}/texte?fichier=${encodeURIComponent(fichier)}&debut=${debut}&taille=${TRANCHE}`);
    vueTexte = { fichier: r.fichier, debut: r.debut, total: r.total };
    if (!$("#passage-fichier").options.length) {
      $("#passage-fichier").innerHTML = r.fichiers.map((f) => `<option value="${echapper(f)}">${echapper(f)}</option>`).join("");
    }
    $("#passage-fichier").value = r.fichier;
    $("#passage-texte").value = r.texte;
    $("#passage-position").textContent = t("Caractères {a} à {b} sur {c}", { a: r.debut + 1, b: Math.min(r.debut + TRANCHE, r.total), c: r.total });
    $("#passage-precedent").disabled = r.debut <= 0;
    $("#passage-suivant").disabled = r.debut + TRANCHE >= r.total;
  } catch (e) { $("#passage-info").textContent = e.message; }
}
function dessinerPassages() {
  if (!vueTexte.fichier && etat.lot.fichiers.length) chargerTexte(etat.lot.fichiers.find((f) => true) );
  const anonyme = etat.mode === "anonymisation";
  $("#liste-passages").innerHTML = etat.passages.length ? etat.passages.map((p, i) => `<div class="passage-masque" data-i="${i}">
      <p><code>${echapper(p.texte.length > 90 ? p.texte.slice(0, 90) + "…" : p.texte)}</code>
        <span class="discret">· ${t("{n} occurrence(s) masquée(s) sur {m}", { n: p.cles.length, m: p.total })} · ${echapper(anonyme ? "[passage supprimé]" : "[Passage_·····]")}</span>
        <button class="lien petit retirer-passage">${echapper(t("Annuler ce masquage"))}</button></p>
      ${p.total > 1 ? `<details><summary class="sources">${echapper(t("Autres occurrences identiques : examiner les contextes"))}</summary>
        ${p.occurrences.map((o) => `<label class="case"><input type="checkbox" class="occ-passage" data-cle="${o.cle}" ${p.cles.includes(o.cle) ? "checked" : ""}>
          <span>${contexteHtml(o.extrait)} <span class="discret">${echapper(o.fichier)}</span></span></label>`).join("")}</details>` : ""}
    </div>`).join("") : `<p class="discret">${echapper(t("Aucun passage masqué."))}</p>`;
}
$("#passage-fichier").addEventListener("change", () => chargerTexte($("#passage-fichier").value, 0));
$("#passage-precedent").addEventListener("click", () => chargerTexte(vueTexte.fichier, Math.max(vueTexte.debut - TRANCHE, 0)));
$("#passage-suivant").addEventListener("click", () => chargerTexte(vueTexte.fichier, vueTexte.debut + TRANCHE));
$("#btn-masquer-passage").addEventListener("click", async () => {
  const zone = $("#passage-texte");
  const a = zone.selectionStart, b = zone.selectionEnd;
  const info = $("#passage-info");
  info.textContent = "";
  if (a === b) { info.textContent = t("Sélectionnez d'abord un passage dans le texte."); return; }
  try {
    const p = await api(`/api/lots/${etat.lot.id}/passage`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fichier: vueTexte.fichier, debut: vueTexte.debut + a, fin: vueTexte.debut + b }) });
    let existant = etat.passages.find((x) => x.texte === p.texte);
    if (!existant) etat.passages.push(existant = { texte: p.texte, cles: [], occurrences: p.occurrences, total: p.total });
    if (!existant.cles.includes(p.cle)) existant.cles.push(p.cle);
    etat.decisions.masquages++;
    dessinerValidation();
  } catch (e) { info.textContent = e.message; }
});
$("#liste-passages").addEventListener("click", (e) => {
  if (!e.target.classList.contains("retirer-passage")) return;
  etat.passages.splice(Number(e.target.closest(".passage-masque").dataset.i), 1);
  dessinerValidation();
});
$("#liste-passages").addEventListener("change", (e) => {
  if (!e.target.classList.contains("occ-passage")) return;
  const p = etat.passages[Number(e.target.closest(".passage-masque").dataset.i)];
  p.cles = e.target.checked ? [...new Set([...p.cles, e.target.dataset.cle])] : p.cles.filter((c) => c !== e.target.dataset.cle);
  if (!p.cles.length) etat.passages = etat.passages.filter((x) => x !== p);
  etat.decisions.occurrences++;
  dessinerValidation();
});

// ------------------------------------------------------------------ blocage et vérification finale

function afficherBlocage(lot) {
  if (etat.chrono) etat.chrono.actif = false;
  const v = lot.verification || { restes: [], non_verifiables: [] };
  $("#tableau-blocage tbody").innerHTML = (v.blocages || []).map((b) =>
    `<tr><td>${echapper(traduire(b.libelle))}</td><td>${echapper(b.fichier)}</td><td class="num">${b.nombre}</td></tr>`).join("") + v.restes.map((r) =>
    `<tr><td>${echapper(r.terme_nom)}</td><td>${echapper(r.fichier)}</td><td class="num">${r.occurrences}</td></tr>`).join("");
  $("#blocage-nonverifiables").innerHTML = v.non_verifiables.length
    ? `<h3>${echapper(t("Parties non vérifiables"))}</h3>` + v.non_verifiables.map((n) => `<p class="contexte">⚠ ${echapper(n.fichier)} : ${echapper(traduire(n.raison))}</p>`).join("")
    : "";
  afficher("blocage", "validation");
}
$("#btn-reprendre").addEventListener("click", async () => {
  try {
    await api(`/api/lots/${etat.lot.id}/reprendre`, { method: "POST" });
    preparerValidation(await api(`/api/lots/${etat.lot.id}`));
  } catch (e) { alerter(e.message); }
});
function dessinerVerification(lot) {
  const v = lot.verification && (lot.verification.termes || lot.verification.non_verifiables.length) ? lot.verification : null, cadre = $("#verification-resultat");
  cadre.hidden = !v;
  if (!v) return;
  const ok = `<strong>${echapper(t("Termes imposés"))} :</strong> ${echapper(t("aucun des {n} terme(s) ne subsiste dans les fichiers produits.", { n: v.termes }))}`;
  const limites = v.non_verifiables.length
    ? `<br>⚠ ${echapper(t("L'absence complète de ces termes ne peut pas être vérifiée dans les parties suivantes (ce n'est pas un contrôle réussi) :"))}`
      + v.non_verifiables.map((n) => `<br>· ${echapper(n.fichier)} : ${echapper(traduire(n.raison))}`).join("") : "";
  cadre.innerHTML = ok + limites;
}

// ------------------------------------------------------------------ résultats provisoires : contrôles, comparaison, export

const TITRES_ANOMALIES = {
  variante_en_clair: "Nom connu resté en clair", fusion_incoherente: "Fusion incohérente",
  identite_plusieurs_codes: "Même nom sous plusieurs codes", code_inconnu: "Code inconnu de ce périmètre", code_degrade: "Code abîmé ou incomplet",
};
const CONSEILS_ANOMALIES = {
  variante_en_clair: "Revenez aux décisions : vérifiez le terme, ajoutez la variante oubliée ou examinez le contexte.",
  fusion_incoherente: "Revenez aux décisions et séparez cette fusion dans l'onglet « Rapprochements ».",
  identite_plusieurs_codes: "Revenez aux décisions et fusionnez ces termes s'ils désignent la même chose.",
  code_inconnu: "Ce code figure déjà dans le document d'origine : il vient peut-être d'un autre périmètre. Il ne sera pas restauré ici.",
  code_degrade: "Ce texte ressemble à un code altéré : vérifiez-le dans le document.",
};
let provisoire = { lot: null, fichier: null, debut: 0, total: 0, modifications: [], courante: -1 };

function afficherProvisoire(lot) {
  if (etat.chrono) etat.chrono.actif = false;
  provisoire = { lot, fichier: null, debut: 0, total: 0, modifications: [], courante: -1 };
  const v = lot.verification && (lot.verification.termes || !lot.verification.ok || lot.verification.non_verifiables.length) ? lot.verification : null;
  const cadre = $("#provisoire-verification");
  cadre.hidden = !v;
  if (v) {
    cadre.className = v.ok ? "alerte" : "alerte erreur";
    cadre.innerHTML = v.ok
      ? `<strong>${echapper(t("Termes imposés"))} :</strong> ${echapper(t("aucun des {n} terme(s) ne subsiste dans les fichiers produits.", { n: v.termes }))}`
        + (v.non_verifiables.length ? `<br>⚠ ${echapper(t("L'absence complète de ces termes ne peut pas être vérifiée dans les parties suivantes (ce n'est pas un contrôle réussi) :"))}`
          + v.non_verifiables.map((n) => `<br>· ${echapper(n.fichier)} : ${echapper(traduire(n.raison))}`).join("") : "")
      : `<strong>${echapper(t("Finalisation bloquée"))} :</strong> ` + v.restes.map((r) => `${echapper(r.terme_nom)} (${echapper(r.fichier)}, ${r.occurrences})`).join(" · ")
        + (v.blocages && v.blocages.length ? "<br>" + v.blocages.map((b) => `${echapper(b.fichier)} : ${echapper(traduire(b.libelle))} (${b.nombre})`).join("<br>") + `<br>${echapper(t("Confidentialité renforcée : ces contenus ne sont pas analysés et ne peuvent pas être supprimés."))}` : "")
        + `<br>${echapper(t("Revenez aux décisions pour corriger, ou retirez explicitement le terme de la liste."))}`;
  }
  $("#provisoire-anomalies").innerHTML = lot.anomalies.length ? lot.anomalies.map((a) => `<div class="proposition ${a.gravite === "alerte" ? "ambigu" : ""}">
      <p><strong>${echapper(t(TITRES_ANOMALIES[a.type] || a.type))}</strong>
        ${a.fichier ? `<span class="discret">· ${echapper(a.fichier)}</span>` : ""}
        ${a.terme ? `· ${echapper(a.terme)}` : ""}${a.code ? ` · <code>${echapper(a.code)}</code>` : ""}${a.codes ? ` · ${a.codes.map((c) => `<code>${echapper(c)}</code>`).join(", ")}` : ""}
        ${a.occurrences ? `<span class="discret">· ${a.occurrences} ${echapper(t("occurrence(s)"))}</span>` : ""}</p>
      ${a.contexte ? `<p class="contexte">${contexteHtml(a.contexte)}</p>` : ""}
      ${a.groupes ? `<p class="contexte">${a.groupes.map((g) => echapper(g.join(" / "))).join(" ≠ ")}</p>` : ""}
      <p class="discret">${echapper(t(CONSEILS_ANOMALIES[a.type] || ""))}</p></div>`).join("")
    : `<p class="discret">${echapper(t("Aucune anomalie détectée par les contrôles automatiques."))}</p>`;
  $("#tableau-provisoire tbody").innerHTML = lot.resultats.map((r) => `<tr>
      <td>${r.erreur ? `<span class="erreur">${echapper(r.sortie_relative)} — ${echapper(r.erreur)}</span>` : echapper(r.livrables.join(" + "))}
        ${r.pdf ? `<a href="/api/lots/${lot.id}/apercu-pdf/${r.pdf.split("/").map(encodeURIComponent).join("/")}" target="_blank" rel="noopener">${echapper(t("Aperçu du PDF"))}</a>` : ""}
        ${r.conversion_erreur ? `<div class="erreur">${echapper(t("Conversion PDF impossible : {x}", { x: r.conversion_erreur }))}</div>` : ""}
        ${r.avertissements.map((a) => `<div class="contexte">⚠ ${echapper(traduire(a))}</div>`).join("")}</td>
      <td class="discret">${echapper(r.source)}</td><td class="num">${r.entites}</td><td class="num">${r.sensibles}</td>
      <td>${r.erreur ? "" : `<button class="petit comparer" data-source="${echapper(r.source)}">${echapper(t("Comparer avant / après"))}</button>`}</td></tr>`).join("");
  $("#comparaison").hidden = true;
  $("#erreur-provisoire").hidden = true;
  $("#btn-finaliser").disabled = !!(v && !v.ok);
  afficher("provisoire", "validation");
  window.scrollTo(0, 0);
}
$("#tableau-provisoire").addEventListener("click", (e) => {
  const b = e.target.closest("button.comparer");
  if (b) chargerComparaison(b.dataset.source, 0);
});
async function chargerComparaison(fichier, debut) {
  try {
    const r = await api(`/api/lots/${etat.lot.id}/comparaison?fichier=${encodeURIComponent(fichier)}&debut=${debut}&nombre=300`);
    provisoire.fichier = fichier;
    provisoire.debut = debut;
    provisoire.total = r.total;
    provisoire.modifications = r.modifications;
    const segments = (liste) => liste.map(([texte, modifie]) => modifie ? `<mark>${echapper(texte)}</mark>` : echapper(texte)).join("");
    $("#cmp-lignes").innerHTML = r.lignes.map((l) => `<div class="cmp-ligne ${l.modif ? "modif" : ""}" data-n="${l.n}">
        <span class="n">${l.n + 1}</span><div>${segments(l.o)}</div><div>${segments(l.r)}</div></div>`).join("");
    $("#comparaison-fichier").textContent = `${fichier} → ${r.sortie}`;
    $("#cmp-position").textContent = t("{n} modification(s)", { n: r.nombre_modifications });
    $("#cmp-page-precedente").disabled = debut <= 0;
    $("#cmp-page-suivante").disabled = debut + 300 >= r.total;
    $("#comparaison").hidden = false;
    $("#comparaison").scrollIntoView({ behavior: "smooth" });
  } catch (e) { $("#erreur-provisoire").textContent = e.message; $("#erreur-provisoire").hidden = false; }
}
async function aller(n) {
  if (n < provisoire.debut || n >= provisoire.debut + 300) await chargerComparaison(provisoire.fichier, Math.floor(n / 300) * 300);
  document.querySelectorAll(".cmp-ligne.actuelle").forEach((x) => x.classList.remove("actuelle"));
  const ligne = document.querySelector(`.cmp-ligne[data-n="${n}"]`);
  if (ligne) { ligne.classList.add("actuelle"); ligne.scrollIntoView({ block: "center" }); }
}
function modificationVoisine(sens) {
  const m = provisoire.modifications;
  if (!m.length) return;
  provisoire.courante = Math.min(Math.max(provisoire.courante + sens, 0), m.length - 1);
  $("#cmp-position").textContent = t("Modification {i} sur {n}", { i: provisoire.courante + 1, n: m.length });
  aller(m[provisoire.courante]);
}
$("#cmp-suivante").addEventListener("click", () => modificationVoisine(1));
$("#cmp-precedente").addEventListener("click", () => modificationVoisine(-1));
$("#cmp-page-suivante").addEventListener("click", () => chargerComparaison(provisoire.fichier, provisoire.debut + 300));
$("#cmp-page-precedente").addEventListener("click", () => chargerComparaison(provisoire.fichier, Math.max(provisoire.debut - 300, 0)));
$("#btn-corriger").addEventListener("click", async () => {
  try {
    await api(`/api/lots/${etat.lot.id}/reprendre`, { method: "POST" });
    preparerValidation(await api(`/api/lots/${etat.lot.id}`));
  } catch (e) { alerter(e.message); }
});
$("#btn-abandonner").addEventListener("click", async () => {
  if (!confirmer(t("Abandonner ce traitement ? Rien ne sera publié ni conservé."))) return;
  try {
    await api(`/api/lots/${etat.lot.id}/abandonner`, { method: "POST" });
    nouveauLot();
  } catch (e) { alerter(e.message); }
});
$("#btn-finaliser").addEventListener("click", async () => {
  $("#btn-finaliser").disabled = true;
  try {
    await api(`/api/lots/${etat.lot.id}/finaliser`, { method: "POST" });
    $("#progression-titre").textContent = "Export en cours";
    $("#barre").style.width = "0";
    afficher("progression", "validation");
    suivre();
  } catch (e) {
    $("#erreur-provisoire").textContent = e.message;
    $("#erreur-provisoire").hidden = false;
    $("#btn-finaliser").disabled = false;
  }
});

// ------------------------------------------------------------------ profils, format de sortie, contenus non analysables

const NOMS_POLITIQUES = { preservation: "Préservation", renforcee: "Confidentialité renforcée" };
const NOMS_FORMATS = { origine: "Format d'origine", pdf: "PDF", les_deux: "Les deux" };
const NOMS_PORTEES = { document: "Document", projet: "Projet", client: "Client" };
let profilsConnus = [];
function resumeReglages(r) {
  const a = r.actions || {};
  return [`${t("Images")} : ${t(r.images === "supprimer" ? "supprimer" : "conserver")}`, `${t("Contenus non analysables")} : ${t(NOMS_POLITIQUES[r.politique])}`,
    `${t("Dates")} : ${t(ACTIONS[a.date] || (a.date === "annee" ? "Année" : "Conserver"))}`, `${t("Format")} : ${t(NOMS_FORMATS[r.format_sortie])}`,
    `${t("Périmètre")} : ${t(NOMS_PORTEES[r.portee])}`].join(" · ");
}
async function chargerProfils() {
  const r = await api("/api/profils");
  profilsConnus = r.profils;
  return r;
}
async function remplirProfils() {
  try {
    await chargerProfils();
    const memoire = localStorage.getItem("sn_profil") || "";
    $("#profil-choix").innerHTML = `<option value="">${echapper(t("Aucun (réglages par défaut)"))}</option>` + profilsConnus.map((p) =>
      `<option value="${echapper(p.id)}" ${p.id === memoire ? "selected" : ""}>${echapper(p.standard ? t(p.nom) : p.nom)}${p.standard ? " (" + echapper(t("standard")) + ")" : ""}</option>`).join("");
    majProfil();
  } catch (e) { $("#profil-resume").textContent = e.message; }
  const conv = etat.config.conversion || { disponible: false };
  for (const o of $("#format-sortie").options) if (o.value !== "origine") o.disabled = !conv.disponible;
  $("#info-conversion").textContent = conv.disponible ? t("Conversion locale par LibreOffice : la mise en page du PDF peut différer ; conservez la version modifiable pour les restaurations futures.")
    : t("Export PDF indisponible : LibreOffice (composant facultatif) n'est pas installé.");
}
function profilChoisi() { return profilsConnus.find((p) => p.id === $("#profil-choix").value) || null; }
function majProfil() {
  const p = profilChoisi();
  localStorage.setItem("sn_profil", p ? p.id : "");
  $("#profil-resume").textContent = p ? `${p.description ? t(p.description) + " " : ""}${resumeReglages(p.reglages)}` : t("Réglages par défaut de l'application (Outils, Options par défaut).");
  if (p) {                                                  // le profil propose le périmètre et le format ; tout reste modifiable pour ce lot
    document.querySelector(`input[name=portee][value=${p.reglages.portee}]`).checked = true;
    if (!$("#format-sortie").options[["origine", "pdf", "les_deux"].indexOf(p.reglages.format_sortie)].disabled) $("#format-sortie").value = p.reglages.format_sortie;
    majPortee();
  }
}
$("#profil-choix").addEventListener("change", majProfil);

// Réglages du lot courant (profil + modifications pour ce lot), à l'écran de validation.
function appliquerProfilAuLot(lot) {
  const p = lot.profil;
  etat.profil = p ? { id: p.id, nom: p.nom, reglages: copie(p.reglages) } : null;
  if (p) {
    etat.actions = { ...etat.actions, ...p.reglages.actions };
    etat.images = p.reglages.images;
    etat.politique = p.reglages.politique;
  } else {
    etat.politique = "preservation";
  }
  etat.formatSortie = (lot.formatDemande || $("#format-sortie").value) || "origine";
  etat.formatsFichiers = {};
  etat.nonAnalyses = lot.non_analyses || {};
}
function reglagesCourants() {
  return { actions: { ...etat.actions }, images: etat.images, politique: etat.politique, format_sortie: etat.formatSortie,
    portee: (etat.lot && etat.lot.portee && etat.lot.portee.type) || (etat.profil ? etat.profil.reglages.portee : "projet"),
    lieux_preselectionnes: etat.profil ? !!etat.profil.reglages.lieux_preselectionnes : false };
}
function blocProfilLot() {
  const modifie = etat.profil && JSON.stringify(reglagesCourants()) !== JSON.stringify(etat.profil.reglages);
  const perso = etat.profil && !etat.profil.id.startsWith("standard:");
  return `<div class="categorie-sensible"><header><h3>${echapper(t("Profil"))} : ${echapper(etat.profil ? (etat.profil.id.startsWith("standard:") ? t(etat.profil.nom) : etat.profil.nom) : t("Aucun (réglages par défaut)"))}
      ${modifie ? `<span class="etiquette-imposee">${echapper(t("modifié pour ce lot"))}</span>` : ""}</h3></header>
    <p class="discret">${echapper(t("Vos modifications ne s'appliquent qu'à ce lot : le profil enregistré n'est jamais modifié sans votre demande."))}</p>
    <div class="actions gauche">
      ${modifie ? `<button class="petit" id="btn-retablir-profil">${echapper(t("Rétablir les réglages du profil"))}</button>` : ""}
      ${modifie && perso ? `<button class="petit" id="btn-maj-profil">${echapper(t("Enregistrer dans ce profil"))}</button>` : ""}
      <button class="petit" id="btn-nouveau-profil">${echapper(t("Enregistrer sous un nouveau profil…"))}</button>
      <span class="discret" id="etat-profil-lot"></span></div></div>`;
}
function blocNonAnalyses() {
  const lignes = Object.entries(etat.nonAnalyses).filter(([, el]) => el.length).map(([f, el]) =>
    `<p class="contexte"><strong>${echapper(f)}</strong> : ${el.map((x) => `${echapper(traduire(x.libelle))} (${x.nombre})${x.supprimable ? "" : " ⚠"}`).join(" · ")}</p>`).join("");
  return `<div class="categorie-sensible"><header><h3>${echapper(t("Contenus non analysables"))}</h3><div class="choix-action">
      ${Object.entries(NOMS_POLITIQUES).map(([p, n]) => `<label><input type="radio" name="politique" value="${p}" ${etat.politique === p ? "checked" : ""}>${echapper(t(n))}</label>`).join("")}</div></header>
    <p class="discret">${echapper(t("Préservation : les éléments non traités sont conservés, avec leurs limites ci-dessous. Confidentialité renforcée : les images et les parties XML personnalisées sont supprimées ; un autre contenu non analysé bloque la publication, avec l'explication."))}</p>
    ${lignes || `<p class="discret">${echapper(t("Aucun contenu non analysé détecté dans ces fichiers."))}</p>`}</div>`;
}
function blocFormatSortie() {
  const conv = etat.config.conversion || { disponible: false };
  const fichiers = (etat.lot.fichiers || []).filter((f) => /\.(docx|pptx|xlsx|html?|txt)$/i.test(f));
  const option = (v, sel) => Object.entries(NOMS_FORMATS).map(([k, n]) => `<option value="${k}" ${k === sel ? "selected" : ""} ${k !== "origine" && !conv.disponible ? "disabled" : ""}>${echapper(t(n))}</option>`).join("");
  return `<div class="categorie-sensible"><header><h3>${echapper(t("Format de sortie"))}</h3>
      <div class="choix-action"><select id="format-general">${option("", etat.formatSortie)}</select></div></header>
    <p class="discret">${echapper(conv.disponible ? t("Conversion PDF locale (LibreOffice) après le traitement ; tous les fichiers produits, PDF compris, sont contrôlés. Seuls Word, PowerPoint, Excel, HTML et texte sont convertibles.")
      : t("Export PDF indisponible : LibreOffice (composant facultatif) n'est pas installé."))}</p>
    ${conv.disponible && fichiers.length ? `<details><summary>${echapper(t("Choix fichier par fichier"))}</summary>${fichiers.map((f) =>
      `<p><select class="format-fichier" data-fichier="${echapper(f)}">${option("", etat.formatsFichiers[f] || etat.formatSortie)}</select> ${echapper(f)}</p>`).join("")}</details>` : ""}</div>`;
}
document.addEventListener("click", async (e) => {
  const b = e.target.closest("button");
  if (!b || !["btn-retablir-profil", "btn-maj-profil", "btn-nouveau-profil"].includes(b.id)) return;
  const info = $("#etat-profil-lot");
  try {
    if (b.id === "btn-retablir-profil") {
      appliquerProfilAuLot({ profil: etat.profil, formatDemande: etat.formatSortie, non_analyses: etat.nonAnalyses });
      dessinerValidation();
    } else if (b.id === "btn-maj-profil") {
      await api(`/api/profils/${encodeURIComponent(etat.profil.id)}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reglages: reglagesCourants() }) });
      etat.profil.reglages = copie(reglagesCourants());
      dessinerValidation();
    } else {
      const nom = prompt(t("Nom du nouveau profil :"));
      if (!nom || !nom.trim()) return;
      const p = await api("/api/profils", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nom: nom.trim(), reglages: reglagesCourants() }) });
      etat.profil = { id: p.id, nom: p.nom, reglages: copie(p.reglages) };
      dessinerValidation();
    }
  } catch (err) { if (info) info.textContent = err.message; else alerter(err.message); }
});

async function chargerOutilProfils() {
  try {
    const r = await chargerProfils();
    const perso = r.profils.filter((p) => !p.standard).length;
    $("#compte-profils").textContent = t("{n} profil(s) sur {m} au plus ({p} personnel(s) sur {q}).", { n: r.profils.length, m: r.maximum, p: perso, q: r.personnels_maximum });
    $("#tableau-profils tbody").innerHTML = r.profils.map((p) => `<tr data-id="${echapper(p.id)}"><td>${echapper(p.standard ? t(p.nom) : p.nom)}</td>
      <td>${echapper(t(p.standard ? "Standard (lecture seule)" : "Personnel"))}</td>
      <td class="discret">${p.description ? echapper(t(p.description)) + "<br>" : ""}${echapper(resumeReglages(p.reglages))}</td>
      <td><button class="lien petit dupliquer-profil">${echapper(t("Dupliquer"))}</button>
        ${p.standard ? "" : `<button class="lien petit renommer-profil">${echapper(t("Renommer"))}</button> <button class="lien petit supprimer-profil">${echapper(t("Supprimer"))}</button>`}</td></tr>`).join("");
    $("#etat-profils").textContent = "";
  } catch (e) { $("#etat-profils").textContent = e.message; }
}
$("#tableau-profils").addEventListener("click", async (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const id = b.closest("tr").dataset.id;
  const profil = profilsConnus.find((p) => p.id === id);
  const envoyer = (url, methode, corps) => api(url, { method: methode, headers: { "Content-Type": "application/json" }, body: corps ? JSON.stringify(corps) : undefined });
  try {
    if (b.classList.contains("dupliquer-profil")) {
      const nom = prompt(t("Nom du nouveau profil :"), `${profil.nom} (copie)`);
      if (nom && nom.trim()) await envoyer("/api/profils", "POST", { nom: nom.trim(), reglages: profil.reglages });
    } else if (b.classList.contains("renommer-profil")) {
      const nom = prompt(t("Nouveau nom :"), profil.nom);
      if (nom && nom.trim()) await envoyer(`/api/profils/${encodeURIComponent(id)}`, "PUT", { nom: nom.trim() });
    } else if (b.classList.contains("supprimer-profil")) {
      if (confirmer(t("Supprimer ce profil ?"))) await envoyer(`/api/profils/${encodeURIComponent(id)}`, "DELETE");
    }
    chargerOutilProfils();
  } catch (err) { $("#etat-profils").textContent = err.message; }
});

async function chargerOutilLangues() {
  try {
    const r = await api("/api/langues");
    $("#tableau-langues tbody").innerHTML = r.langues.map((l) => `<tr data-code="${l.code}">
      <td><input type="checkbox" class="langue-active" ${l.active ? "checked" : ""} ${l.code === "en" ? "disabled" : ""}></td>
      <td>${echapper(t(l.nom))}</td>
      <td>${l.test ? `<span class="etiquette-imposee">${echapper(t("Version de test"))}</span>` : echapper(t(l.statut))}
        ${l.avertissement ? `<div class="discret">${echapper(traduire(l.avertissement))}</div>` : ""}</td>
      <td class="discret">${echapper(l.modeles)}</td><td>${echapper(t(l.formats_locaux ? "oui" : "non"))}</td></tr>`).join("");
    $("#etat-langues").textContent = "";
  } catch (e) { $("#etat-langues").textContent = e.message; }
}
$("#btn-enregistrer-langues").addEventListener("click", async () => {
  const actives = [...document.querySelectorAll("#tableau-langues tr")].filter((tr) => tr.querySelector(".langue-active").checked).map((tr) => tr.dataset.code);
  try {
    await api("/api/langues", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ actives }) });
    $("#etat-langues").textContent = t("Enregistré. Relancez Sine Nomine pour charger les modèles.");
  } catch (e) { $("#etat-langues").textContent = e.message; }
});

// ------------------------------------------------------------------ 4. résultats

function afficherResultats(lot) {
  if (etat.chrono) etat.chrono.actif = false;
  const p = lot.progression;
  const subs = p.substitutions || {};
  const total = ["personne", "societe", "produit", "lieu", "sensible"].reduce((a, c) => a + (subs[c] || 0), 0);
  $("#titre-resultat").textContent = lot.mode === "anonymisation" ? "Anonymisation terminée" : "Pseudonymisation terminée";
  $("#resume-traitement").innerHTML = cartes([
    ["Fichiers traités", String(lot.resultats.length)],
    ["Mots traités", nombre(p.mots_total)],
    ["Substitutions", String(total)],
    ["Durée de l'analyse", duree(p.durees.analyse || 0)],
    ["Durée du traitement", duree(p.durees.traitement || 0)],
  ]);
  $("#resume-categories").innerHTML = cartes([
    ...["personne", "societe", "produit", "lieu", "sensible"].map((c) => [NOMS_COMPTEURS[c], String(subs[c] || 0)]),
    ...(subs.image ? [[NOMS_COMPTEURS.image, String(subs.image)]] : []),
  ]);
  const base = `/api/lots/${lot.id}/sortie/`;
  const lienFichier = (chemin) => base + chemin.split("/").map(encodeURIComponent).join("/");
  $("#lien-rapport").href = lienFichier(lot.rapport);
  dessinerVerification(lot);
  $("#tableau-resultats tbody").innerHTML = lot.resultats.map((r) => `<tr>
      <td>${r.erreur ? `<span class="erreur">${echapper(r.sortie_relative)} — ${echapper(r.erreur)}</span>` : `<a href="${lienFichier(r.sortie_relative)}" download>${echapper(r.sortie_relative)}</a>`}
        ${r.images ? `<div class="contexte">${r.images} image(s) supprimée(s)</div>` : ""}
        ${r.avertissements.map((a) => `<div class="contexte">⚠ ${echapper(a)}</div>`).join("")}
        ${r.images ? "" : vignettes((lot.apercus || {})[r.source])}</td>
      <td class="discret">${echapper(r.source)}</td>
      <td class="num">${r.entites}</td><td class="num">${r.sensibles}</td><td class="num">${r.conservees}</td></tr>`).join("");
  const anonymise = lot.mode === "anonymisation";
  $("#btn-ouvrir-correspondances").hidden = anonymise;
  $("#info-correspondances").innerHTML = anonymise
    ? `<strong>Anonymisation irréversible :</strong> ${echapper(avertissementLangue().anonymisation)}`
    : `<strong>${echapper(traduire("Correspondances"))} :</strong> ${echapper(traduire("Les correspondances sont conservées dans le coffre chiffré de cet ordinateur ; aucune table en clair n'a été écrite."))}`
      + (lot.correspondances ? `<br>${echapper(traduire("Table exportée (en clair) :"))} <code>${echapper(lot.correspondances)}</code>` : "")
      + `<br>${echapper(avertissementLangue().pseudonymisation)}`;
  afficher("resultats");
}
async function ouvrir(cible) {
  try {
    await api(`/api/lots/${etat.lot.id}/ouvrir`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ cible }) });
  } catch (e) { alerter(e.message); }
}
$("#btn-ouvrir-sortie").addEventListener("click", () => ouvrir("sortie"));
$("#btn-ouvrir-correspondances").addEventListener("click", async () => {
  // Export en clair : jamais automatique, et seulement après confirmation.
  if (!confirmer("Ce fichier contiendra les noms d'origine en clair, à côté de leurs pseudonymes : toute personne qui l'ouvre pourra lever la pseudonymisation. Il n'est pas nécessaire à la restauration (le coffre chiffré suffit). Continuer ?")) return;
  try {
    const r = await api(`/api/lots/${etat.lot.id}/exporter-correspondances`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirmation: true }) });
    etat.lot.correspondances = r.fichier;
    afficherResultats(etat.lot);
    await ouvrir("correspondances");
  } catch (e) { alerter(e.message); }
});

function nouveauLot() {
  etat.fichiers = [];
  etat.lot = null;
  afficherFichiers();
  $("#dossier").value = "";
  allerMenu();
}
$("#btn-nouveau").addEventListener("click", nouveauLot);
$("#btn-recommencer").addEventListener("click", nouveauLot);

// ------------------------------------------------------------------ désanonymisation

const restauration = { fichiers: [], id: null };

function afficherListeRestauration() {
  $("#liste-restauration").innerHTML = restauration.fichiers
    .map((f, i) => `<li><span>${echapper(f.chemin)}</span><button data-i="${i}" title="Retirer">✕</button></li>`).join("");
}
$("#liste-restauration").addEventListener("click", (e) => {
  if (e.target.dataset.i !== undefined) {
    restauration.fichiers.splice(Number(e.target.dataset.i), 1);
    afficherListeRestauration();
  }
});
const depotRestauration = $("#depot-restauration");
["dragenter", "dragover"].forEach((t) =>
  depotRestauration.addEventListener(t, (e) => { e.preventDefault(); depotRestauration.classList.add("survol"); }));
["dragleave", "drop"].forEach((t) =>
  depotRestauration.addEventListener(t, (e) => { e.preventDefault(); depotRestauration.classList.remove("survol"); }));
depotRestauration.addEventListener("drop", async (e) => {
  const entrees = [...e.dataTransfer.items].map((i) => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  if (entrees.length) for (const en of entrees) await lireEntree(en, "", restauration.fichiers);
  else [...e.dataTransfer.files].forEach((f) => ajouterFichier(f, null, restauration.fichiers));
  afficherListeRestauration();
});
$("#btn-parcourir-restauration").addEventListener("click", () => $("#selecteur-restauration").click());
$("#selecteur-restauration").addEventListener("change", (e) => {
  [...e.target.files].forEach((f) => ajouterFichier(f, null, restauration.fichiers));
  e.target.value = "";
  afficherListeRestauration();
});

async function ouvrirRestauration() {
  restauration.fichiers = [];
  afficherListeRestauration();
  $("#dossier-restauration").value = "";
  $("#erreur-restauration").hidden = true;
  $("#resultat-restauration").hidden = true;
  $("#champ-perimetre-restauration").hidden = true;
  $("#info-perimetre-restauration").hidden = true;
  $("#apercu-restauration").hidden = true;
  $("#btn-confirmer-restauration").hidden = true;
  try {
    const e = await api("/api/etat");
    const a = e.archive;
    $("#info-archive").innerHTML = a.entites || a.sensibles
      ? `<strong>Archive des codes :</strong> ${a.entites} nom(s) et ${a.sensibles} information(s) sensible(s) archivés.<br><code>${echapper(a.chemin)}</code>`
      : `<strong>Archive vide :</strong> aucun lot n'a encore été anonymisé avec cette installation.`;
  } catch (err) { $("#info-archive").textContent = err.message; }
  afficher("restauration", "");
}
$("#btn-retour-restauration").addEventListener("click", () => allerMenu());

async function lancerRestauration() {
  const erreur = $("#erreur-restauration");
  erreur.hidden = true;
  const dossier = $("#dossier-restauration").value.trim();
  if (!restauration.fichiers.length && !dossier) {
    erreur.textContent = "Déposez des fichiers ou indiquez un dossier à désanonymiser.";
    erreur.hidden = false;
    return;
  }
  const donnees = new FormData();
  if (restauration.fichiers.length) restauration.fichiers.forEach((f) => donnees.append("fichiers", f.fichier, f.chemin));
  else donnees.append("dossier", dossier);
  if (!$("#champ-perimetre-restauration").hidden) donnees.append("perimetre_id", $("#perimetre-restauration").value);
  $("#btn-restaurer").disabled = true;
  $("#btn-confirmer-restauration").disabled = true;
  try {
    const r = await api("/api/restaurations", { method: "POST", body: donnees });
    $("#champ-perimetre-restauration").hidden = true;
    $("#info-perimetre-restauration").textContent = t("Périmètre utilisé : {nom}", { nom: r.perimetre ? r.perimetre.libelle : "" })
      + (r.detecte ? " " + t("(reconnu d'après les codes)") : "");
    $("#info-perimetre-restauration").hidden = false;
    restauration.id = r.id;
    const lien = (chemin) => `/api/restaurations/${r.id}/` + chemin.split("/").map(encodeURIComponent).join("/");
    $("#tableau-restauration tbody").innerHTML = r.resultats.map((x) => `<tr>
        <td>${x.erreur ? `<span class="erreur">${echapper(x.sortie)} — ${echapper(x.erreur)}</span>` : `<a href="${lien(x.sortie)}" download>${echapper(x.sortie)}</a>`}</td>
        <td class="discret">${echapper(x.source)}</td>
        <td class="num">${x.remplacements}</td>
        <td>${x.inconnus.length ? `<span class="erreur">${x.inconnus.map(echapper).join(", ")}</span>` : (x.remplacements ? "—" : "<span class='discret'>Aucun code trouvé</span>")}</td></tr>`).join("");
    $("#resultat-restauration").hidden = false;
    $("#apercu-restauration").hidden = true;
    $("#btn-confirmer-restauration").hidden = true;
  } catch (e) {
    if (e.candidats) proposerPerimetres("restauration", e.candidats);
    erreur.textContent = e.message;
    erreur.hidden = false;
  } finally {
    $("#btn-restaurer").disabled = false;
    $("#btn-confirmer-restauration").disabled = false;
  }
}

function formulaireRestauration() {
  const erreur = $("#erreur-restauration");
  erreur.hidden = true;
  const dossier = $("#dossier-restauration").value.trim();
  if (!restauration.fichiers.length && !dossier) {
    erreur.textContent = "Déposez des fichiers ou indiquez un dossier à désanonymiser.";
    erreur.hidden = false;
    return null;
  }
  const donnees = new FormData();
  if (restauration.fichiers.length) restauration.fichiers.forEach((f) => donnees.append("fichiers", f.fichier, f.chemin));
  else donnees.append("dossier", dossier);
  if (!$("#champ-perimetre-restauration").hidden) donnees.append("perimetre_id", $("#perimetre-restauration").value);
  return donnees;
}
// Avant d'écrire quoi que ce soit : fichiers, périmètre, catégories de données réintroduites, codes inconnus.
$("#btn-restaurer").addEventListener("click", async () => {
  const donnees = formulaireRestauration();
  if (!donnees) return;
  const erreur = $("#erreur-restauration");
  $("#btn-restaurer").disabled = true;
  try {
    const r = await api("/api/restaurations/apercu", { method: "POST", body: donnees });
    $("#champ-perimetre-restauration").hidden = true;
    const noms = { ...etat.config.categories_entites, ...Object.fromEntries(Object.entries(etat.config.categories_sensibles).map(([c, n]) => [c, n])), passage: "Passages masqués" };
    const categories = Object.entries(r.categories).map(([c, n]) => `${echapper(t(noms[c] || c))} : ${n}`).join(" · ") || echapper(t("aucune"));
    const total = r.fichiers.reduce((a, f) => a + f.codes, 0);
    $("#apercu-restauration").innerHTML = `<strong>${echapper(t("Avant d'écrire"))} :</strong> ${echapper(t("Périmètre utilisé : {nom}", { nom: r.perimetre ? r.perimetre.libelle : "" }))}
      ${r.detecte ? echapper(t("(reconnu d'après les codes)")) : ""}<br>
      ${echapper(t("{n} fichier(s), {m} code(s) à remplacer par des données d'origine en clair.", { n: r.fichiers.length, m: total }))}<br>
      ${echapper(t("Catégories réintroduites"))} : ${categories}
      ${r.inconnus.length ? `<br><span class="erreur">${echapper(t("Codes inconnus (laissés tels quels) :"))} ${r.inconnus.map(echapper).join(", ")}</span>` : ""}
      <br>${echapper(t("Les fichiers restaurés sont écrits dans un dossier distinct marqué CONFIDENTIEL ; les fichiers déposés ne sont pas modifiés."))}`;
    $("#apercu-restauration").hidden = false;
    $("#btn-confirmer-restauration").hidden = false;
  } catch (e) {
    if (e.candidats) proposerPerimetres("restauration", e.candidats);
    erreur.textContent = e.message;
    erreur.hidden = false;
  } finally {
    $("#btn-restaurer").disabled = false;
  }
});
$("#btn-confirmer-restauration").addEventListener("click", () => lancerRestauration());
$("#btn-ouvrir-restauration").addEventListener("click", async () => {
  try { await api(`/api/restaurations/${restauration.id}/ouvrir`, { method: "POST" }); } catch (e) { alerter(e.message); }
});

// ------------------------------------------------------------------ menu principal

// Toutes les cartes du menu ont la même taille : la hauteur de la plus haute s'applique à toutes.
function egaliserMenu() {
  const cartes = [...document.querySelectorAll("#menu-principal .menu-option")];
  cartes.forEach((c) => (c.style.minHeight = ""));
  const hauteur = Math.max(0, ...cartes.map((c) => c.offsetHeight));
  if (hauteur) cartes.forEach((c) => (c.style.minHeight = hauteur + "px"));
}
window.addEventListener("resize", () => { if (etat.ecran === "menu") egaliserMenu(); });

function allerMenu() {
  if (etat.chrono) etat.chrono.actif = false;
  afficher("menu", "");
}
// L'avertissement est à accepter avant chaque lot ; pour consulter ou dé-pseudonymiser, une fois par session suffit.
function avecAcceptation(suite, chaqueFois = false) {
  if (etat.acceptation && !chaqueFois) return suite();
  etat.suite = suite;
  preparerAvertissement();
  afficher("avertissement");
}
function ouvrirFichiers(mode) {
  etat.fichiers = [];
  afficherFichiers();
  document.querySelector(`input[name=mode][value=${mode}]`).checked = true;
  $("#choix-portee").hidden = mode !== "pseudonymisation";
  $("#listes-anonymisation").hidden = mode === "pseudonymisation";
  remplirPerimetres();
  remplirProfils();
  $("#titre-fichiers").textContent = mode === "anonymisation" ? "Fichiers à anonymiser" : "Fichiers à pseudonymiser";
  $("#erreur-fichiers").hidden = true;
  afficher("fichiers");
}
$("#menu-principal").addEventListener("click", (e) => {
  const b = e.target.closest("[data-action]");
  if (!b) return;
  switch (b.dataset.action) {
    case "anonymiser": avecAcceptation(() => ouvrirFichiers("anonymisation"), true); break;
    case "pseudonymiser": avecAcceptation(() => ouvrirFichiers("pseudonymisation"), true); break;
    case "corriger": avecAcceptation(ouvrirCorrection); break;
    case "consulter": avecAcceptation(ouvrirPseudonymes); break;
    case "depseudonymiser": avecAcceptation(ouvrirRestauration); break;
    case "outils": ouvrirOutils(); break;
    case "quitter": $("#btn-quitter").click(); break;
  }
});
$("#btn-menu").addEventListener("click", () => {
  if (etat.ecran === "validation" && !confirmer("Abandonner la validation en cours ? Les choix faits seront perdus.")) return;
  allerMenu();
});
$("#btn-retour-fichiers").addEventListener("click", () => allerMenu());

// ------------------------------------------------------------------ corriger des pseudonymes

const correction = { fichiers: [], regles: [], id: null, signature: null, apercuFait: false };

function afficherListeCorrection() {
  $("#liste-correction").innerHTML = correction.fichiers
    .map((f, i) => `<li><span>${echapper(f.chemin)}</span><button data-i="${i}" title="Retirer">✕</button></li>`).join("");
}
function afficherRegles() {
  $("#liste-regles").innerHTML = correction.regles.map((r, i) =>
    `<li><span><code>${echapper(r.texte)}</code> → ${echapper(r.libelle)}</span><button data-i="${i}" title="Retirer">✕</button></li>`).join("");
}
function invaliderApercu() {
  correction.apercuFait = false;
  $("#btn-appliquer-correction").disabled = true;
  $("#apercu-correction").hidden = true;
}
$("#liste-correction").addEventListener("click", (e) => {
  if (e.target.dataset.i === undefined) return;
  correction.fichiers.splice(Number(e.target.dataset.i), 1);
  afficherListeCorrection();
  invaliderApercu();
});
$("#liste-regles").addEventListener("click", (e) => {
  if (e.target.dataset.i === undefined) return;
  correction.regles.splice(Number(e.target.dataset.i), 1);
  afficherRegles();
  invaliderApercu();
});
const depotCorrection = $("#depot-correction");
["dragenter", "dragover"].forEach((t) =>
  depotCorrection.addEventListener(t, (e) => { e.preventDefault(); depotCorrection.classList.add("survol"); }));
["dragleave", "drop"].forEach((t) =>
  depotCorrection.addEventListener(t, (e) => { e.preventDefault(); depotCorrection.classList.remove("survol"); }));
depotCorrection.addEventListener("drop", async (e) => {
  const entrees = [...e.dataTransfer.items].map((i) => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  if (entrees.length) for (const en of entrees) await lireEntree(en, "", correction.fichiers);
  else [...e.dataTransfer.files].forEach((f) => ajouterFichier(f, null, correction.fichiers));
  afficherListeCorrection();
  invaliderApercu();
});
$("#btn-parcourir-correction").addEventListener("click", () => $("#selecteur-correction").click());
$("#selecteur-correction").addEventListener("change", (e) => {
  [...e.target.files].forEach((f) => ajouterFichier(f, null, correction.fichiers));
  e.target.value = "";
  afficherListeCorrection();
  invaliderApercu();
});
["#corr-auto", "#corr-prenoms", "#dossier-correction"].forEach((s) => $(s).addEventListener("input", invaliderApercu));

function ouvrirCorrection() {
  Object.assign(correction, { fichiers: [], regles: [], id: null, signature: null, apercuFait: false });
  afficherListeCorrection();
  afficherRegles();
  $("#dossier-correction").value = "";
  $("#corr-auto").checked = true;
  $("#corr-prenoms").checked = false;
  $("#regle-texte").value = "";
  $("#regle-code").value = "";
  $("#regle-type").value = "personne";
  $("#regle-code").hidden = true;
  $("#champ-perimetre-correction").hidden = true;
  $("#info-perimetre-correction").hidden = true;
  $("#erreur-correction").hidden = true;
  $("#resultat-correction").hidden = true;
  invaliderApercu();
  afficher("correction", "");
}

$("#regle-type").addEventListener("change", () => {
  $("#regle-code").hidden = $("#regle-type").value !== "existant";
});
let minuterieCodes = null;
$("#regle-code").addEventListener("input", () => {
  clearTimeout(minuterieCodes);
  minuterieCodes = setTimeout(async () => {
    try {
      const r = await api(`/api/pseudonymes?q=${encodeURIComponent($("#regle-code").value.trim())}`);
      $("#liste-codes").innerHTML = r.resultats.filter((x) => x.type === "entite").slice(0, 20)
        .map((x) => `<option value="${echapper(x.code)}">${echapper(x.valeur)}</option>`).join("");
    } catch { /* la saisie reste libre */ }
  }, 250);
});

// « Code ou nom » saisi → code d'entité de l'archive (erreur claire si aucun ou plusieurs).
async function resoudreCode(saisie) {
  const r = await api(`/api/pseudonymes?q=${encodeURIComponent(saisie)}`);
  const entites = r.resultats.filter((x) => x.type === "entite");
  const exact = entites.find((x) => x.code.toLowerCase() === saisie.toLowerCase());
  if (exact) return exact;
  if (entites.length === 1) return entites[0];
  throw new Error(entites.length ? `Plusieurs pseudonymes correspondent à « ${saisie} » : précisez le code (par exemple ${entites[0].code}).`
    : `Aucun pseudonyme ne correspond à « ${saisie} » dans l'archive.`);
}
$("#form-regle").addEventListener("submit", async (e) => {
  e.preventDefault();
  const erreur = $("#erreur-correction");
  erreur.hidden = true;
  const texte = $("#regle-texte").value.trim();
  const type = $("#regle-type").value;
  try {
    let regle;
    if (type === "existant") {
      const x = await resoudreCode($("#regle-code").value.trim());
      regle = { texte, cible: { code: x.code }, libelle: `variante de ${x.code} (${x.valeur})` };
    } else {
      regle = { texte, cible: { categorie: type }, libelle: `nouveau : ${etat.config.categories_entites[type].toLowerCase()}` };
    }
    correction.regles.push(regle);
    afficherRegles();
    invaliderApercu();
    $("#regle-texte").value = "";
    $("#regle-code").value = "";
  } catch (err) {
    erreur.textContent = err.message;
    erreur.hidden = false;
  }
});

function parametresCorrection() {
  return { regles: correction.regles.map(({ texte, cible }) => ({ texte, cible })),
    automatique: $("#corr-auto").checked, prenoms_seuls: $("#corr-prenoms").checked };
}
// Les fichiers sont envoyés une seule fois ; l'aperçu et l'application réutilisent la même session côté serveur.
async function assurerSessionCorrection() {
  const dossier = $("#dossier-correction").value.trim();
  const signature = correction.fichiers.length ? correction.fichiers.map((f) => f.chemin).join("|") : "dossier:" + dossier;
  if (correction.id && correction.signature === signature) return;
  if (correction.id) await fetch(`/api/corrections/${correction.id}`, { method: "DELETE", headers: { "X-CSRF-Token": jetonCsrf() } }).catch(() => {});
  correction.id = null;
  if (!correction.fichiers.length && !dossier) throw new Error("Déposez des fichiers ou indiquez un dossier à corriger.");
  const donnees = new FormData();
  if (correction.fichiers.length) correction.fichiers.forEach((f) => donnees.append("fichiers", f.fichier, f.chemin));
  else donnees.append("dossier", dossier);
  if (!$("#champ-perimetre-correction").hidden) donnees.append("perimetre_id", $("#perimetre-correction").value);
  let r;
  try {
    r = await api("/api/corrections", { method: "POST", body: donnees });
  } catch (e) {
    if (e.candidats) proposerPerimetres("correction", e.candidats);
    throw e;
  }
  $("#champ-perimetre-correction").hidden = true;
  $("#info-perimetre-correction").textContent = t("Périmètre utilisé : {nom}", { nom: r.perimetre ? r.perimetre.libelle : "" });
  $("#info-perimetre-correction").hidden = false;
  Object.assign(correction, { id: r.id, signature });
}
const post = (url, corps) => api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corps) });

$("#btn-apercu-correction").addEventListener("click", async () => {
  const erreur = $("#erreur-correction");
  erreur.hidden = true;
  $("#btn-apercu-correction").disabled = true;
  try {
    await assurerSessionCorrection();
    const r = await post(`/api/corrections/${correction.id}/apercu`, parametresCorrection());
    const lignes = [
      ...r.regles.map((x) => `<tr><td>Règle : <code>${echapper(x.texte)}</code>${x.nouveau ? " (nouveau pseudonyme)" : ""}</td>
        <td><code>${echapper(x.code)}</code></td><td class="num">${x.occurrences}</td>
        <td>${x.contextes.map((c) => `<p class="contexte">${contexteHtml(c)}</p>`).join("")}</td></tr>`),
      ...r.automatique.map((x) => `<tr><td>Archive</td><td><code>${echapper(x.code)}</code></td><td class="num">${x.occurrences}</td>
        <td>${x.contextes.map((c) => `<p class="contexte">${contexteHtml(c)}</p>`).join("")}</td></tr>`),
    ];
    $("#tableau-apercu tbody").innerHTML = lignes.join("") || `<tr><td colspan="4" class="discret">Rien à corriger avec ces réglages.</td></tr>`;
    $("#tableau-apercu-fichiers tbody").innerHTML = r.fichiers.map((f) => `<tr>
        <td>${echapper(f.source)}${f.erreur ? ` <span class="erreur">${echapper(f.erreur)}</span>` : ""}</td>
        <td class="num">${f.corrections}</td>
        <td class="discret">${f.nouveau_nom ? echapper(f.nouveau_nom) : "—"}</td></tr>`).join("");
    $("#resume-apercu").textContent = r.total
      ? `${r.total} correction(s) seraient faites dans ${r.fichiers.filter((f) => f.corrections).length} fichier(s). Rien n'est encore écrit.`
      : "Aucune correction à faire avec ces réglages.";
    $("#apercu-correction").hidden = false;
    correction.apercuFait = true;
    $("#btn-appliquer-correction").disabled = !r.total;
  } catch (e) {
    erreur.textContent = e.message;
    erreur.hidden = false;
  } finally {
    $("#btn-apercu-correction").disabled = false;
  }
});
$("#btn-appliquer-correction").addEventListener("click", async () => {
  if (!correction.apercuFait) return;
  const erreur = $("#erreur-correction");
  erreur.hidden = true;
  $("#btn-appliquer-correction").disabled = true;
  try {
    const r = await post(`/api/corrections/${correction.id}/appliquer`, parametresCorrection());
    correction.id = null;           // session terminée côté serveur
    correction.sortie = r.id;
    const lien = (chemin) => `/api/restaurations/${r.id}/` + chemin.split("/").map(encodeURIComponent).join("/");
    $("#tableau-correction tbody").innerHTML = r.resultats.map((x) => `<tr>
        <td>${x.erreur ? `<span class="erreur">${echapper(x.sortie)} — ${echapper(x.erreur)}</span>` : `<a href="${lien(x.sortie)}" download>${echapper(x.sortie)}</a>`}</td>
        <td class="discret">${echapper(x.source)}</td><td class="num">${x.corrections}</td></tr>`).join("");
    $("#resultat-correction").hidden = false;
    $("#apercu-correction").hidden = true;
    correction.apercuFait = false;
  } catch (e) {
    erreur.textContent = e.message;
    erreur.hidden = false;
    $("#btn-appliquer-correction").disabled = false;
  }
});
$("#btn-ouvrir-correction").addEventListener("click", async () => {
  try { await api(`/api/restaurations/${correction.sortie}/ouvrir`, { method: "POST" }); } catch (e) { alerter(e.message); }
});
$("#btn-retour-correction").addEventListener("click", async () => {
  if (correction.id) await fetch(`/api/corrections/${correction.id}`, { method: "DELETE", headers: { "X-CSRF-Token": jetonCsrf() } }).catch(() => {});
  correction.id = null;
  allerMenu();
});

// ------------------------------------------------------------------ consulter un pseudonyme

function ouvrirPseudonymes() {
  $("#q-pseudonyme").value = "";
  $("#tableau-pseudonyme tbody").innerHTML = "";
  $("#info-pseudonyme").textContent = "";
  afficher("pseudonyme", "");
  rechercherPseudonyme();
  $("#q-pseudonyme").focus();
}
async function rechercherPseudonyme() {
  const q = $("#q-pseudonyme").value.trim();
  try {
    const r = await api(`/api/pseudonymes?q=${encodeURIComponent(q)}`);
    const nom = (x) => (x.type === "entite" ? etat.config.categories_entites : etat.config.categories_sensibles)[x.categorie] || x.categorie;
    $("#tableau-pseudonyme tbody").innerHTML = r.resultats.map((x) => `<tr>
        <td><code>${echapper(x.code)}</code></td><td>${echapper(nom(x))}</td>
        <td class="valeur">${echapper(x.valeur)}</td>
        <td class="discret">${echapper(x.variantes.slice(0, 6).join(" · "))}${x.variantes.length > 6 ? " …" : ""}</td>
        <td class="discret">${echapper((x.lots || []).join(", "))}</td>
        <td class="discret">${echapper(libelleType(x.perimetre))}</td></tr>`).join("");
    $("#info-pseudonyme").textContent = r.resultats.length
      ? `${r.resultats.length} résultat(s)${r.tronque ? " (liste tronquée : précisez la recherche)" : ""}.`
      : (r.total_archive.entites || r.total_archive.sensibles ? "Aucun résultat." : "L'archive est vide : aucun lot n'a encore été pseudonymisé.");
  } catch (e) { $("#info-pseudonyme").textContent = e.message; }
}
$("#form-pseudonyme").addEventListener("submit", (e) => { e.preventDefault(); rechercherPseudonyme(); });
$("#btn-retour-pseudonyme").addEventListener("click", () => allerMenu());

// ------------------------------------------------------------------ périmètres (documents, projets, clients)

const NOUVEAU = "__nouveau__";
const TYPES_PERIMETRE = { client: "Client", projet: "Projet", historique: "Archive historique", document: "Document" };
function libelleType(p) {
  if (!p) return "";
  return p.type === "historique" ? t("Archive historique") : `${t(TYPES_PERIMETRE[p.type])} « ${p.libelle || p.nom || ""} »`;
}
function libellePortee(p) {
  if (p.type === "document") return t("Périmètre des pseudonymes : chaque document a ses propres pseudonymes.");
  if (p.type === "client") return t("Périmètre des pseudonymes : client « {nom} ».", { nom: p.client_nom })
    + " " + t("Tous les projets de ce client partagent leurs pseudonymes.");
  return t("Périmètre des pseudonymes : projet « {nom} ».", { nom: p.projet_nom })
    + (p.client_nom ? " " + t("Rattaché au client « {nom} ».", { nom: p.client_nom }) : "");
}
let perimetresConnus = [];
async function remplirPerimetres() {
  try {
    const r = await api("/api/perimetres");
    perimetresConnus = r.perimetres;
    const projets = perimetresConnus.filter((p) => p.type === "projet");
    const clients = perimetresConnus.filter((p) => p.type === "client");
    const option = (v, l) => `<option value="${echapper(v)}">${echapper(l)}</option>`;
    $("#projet-choix").innerHTML = option(NOUVEAU, t("Nouveau projet…")) + projets.map((p) => option(p.id, p.nom)).join("");
    $("#client-choix").innerHTML = option(NOUVEAU, t("Nouveau client…")) + clients.map((p) => option(p.id, p.nom)).join("");
    $("#projet-nom").value = r.nom_projet_par_defaut;
    $("#client-nom").value = "";
    $("#listes-choix").innerHTML = option("", t("Aucune"))
      + [...clients, ...projets].map((p) => option(p.id, libelleType(p))).join("");
    majPortee();
  } catch (e) { $("#resume-portee").textContent = e.message; }
}
function majPortee() {
  const type = document.querySelector("input[name=portee]:checked").value;
  $("#portee-projet").hidden = type !== "projet";
  $("#portee-client").hidden = type !== "client";
  $("#champ-projet-nom").hidden = $("#projet-choix").value !== NOUVEAU;
  $("#champ-client-nom").hidden = $("#client-choix").value !== NOUVEAU;
  const lignes = { document: t("Chaque document aura ses propres pseudonymes."),
    projet: $("#projet-choix").value === NOUVEAU
      ? t("Un nouveau projet « {nom} » sera créé ; son nom reste modifiable ensuite.", { nom: $("#projet-nom").value.trim() || "Nouveau projet" })
      : t("Les pseudonymes du projet « {nom} » seront réutilisés.", { nom: ($("#projet-choix").selectedOptions[0] || {}).textContent }),
    client: $("#client-choix").value === NOUVEAU
      ? t("Un nouveau client « {nom} » sera créé.", { nom: $("#client-nom").value.trim() })
      : t("Les pseudonymes du client « {nom} » seront réutilisés.", { nom: ($("#client-choix").selectedOptions[0] || {}).textContent }) };
  $("#resume-portee").textContent = lignes[type];
}
function champsPortee() {
  const mode = document.querySelector("input[name=mode]:checked").value;
  if (mode !== "pseudonymisation") {
    const p = perimetresConnus.find((x) => x.id === $("#listes-choix").value);
    return { champs: p ? { portee: p.type, [p.type === "client" ? "client_id" : "projet_id"]: p.id } : {} };
  }
  const type = document.querySelector("input[name=portee]:checked").value;
  if (type === "document") return { champs: { portee: "document" } };
  if (type === "projet") {
    const choix = $("#projet-choix").value;
    return { champs: choix === NOUVEAU ? { portee: "projet", nouveau_projet: $("#projet-nom").value.trim() }
                                       : { portee: "projet", projet_id: choix } };
  }
  const choix = $("#client-choix").value;
  if (choix === NOUVEAU) {
    const nom = $("#client-nom").value.trim();
    if (!nom) return { erreur: t("Indiquez le nom du nouveau client, ou choisissez un client existant.") };
    return { champs: { portee: "client", nouveau_client: nom } };
  }
  return { champs: { portee: "client", client_id: choix } };
}
for (const id of ["#projet-choix", "#client-choix", "#projet-nom", "#client-nom"]) $(id).addEventListener("input", majPortee);
document.querySelectorAll("input[name=portee]").forEach((r) => r.addEventListener("change", majPortee));

function proposerPerimetres(ecran, candidats) {
  $("#perimetre-" + ecran).innerHTML = candidats.map((c) =>
    `<option value="${echapper(c.id)}">${echapper(libelleType(c))}</option>`).join("");
  $("#champ-perimetre-" + ecran).hidden = false;
}

async function chargerPerimetres() {
  try {
    const r = await api("/api/perimetres");
    const noms = Object.fromEntries(r.perimetres.map((p) => [p.id, p.nom]));
    $("#tableau-perimetres tbody").innerHTML = r.perimetres.map((p) => `<tr>
        <td>${echapper(p.type === "historique" ? t("Archive historique") : p.nom)}</td>
        <td>${echapper(t(TYPES_PERIMETRE[p.type]))}</td>
        <td class="discret">${echapper(p.parent_id ? noms[p.parent_id] || "" : "—")}</td>
        <td class="num">${p.comptes.identites}</td><td class="num">${p.comptes.sensibles}</td>
        <td>${p.type === "client" || p.type === "projet" ? `<button class="lien" data-renommer="${echapper(p.id)}">${t("Renommer")}</button>` : ""}</td></tr>`).join("");
    $("#etat-perimetres").textContent = "";
  } catch (e) { $("#etat-perimetres").textContent = e.message; }
}
$("#tableau-perimetres").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-renommer]");
  if (!b) return;
  const nom = prompt(t("Nouveau nom :"));
  if (!nom || !nom.trim()) return;
  try {
    await api(`/api/perimetres/${encodeURIComponent(b.dataset.renommer)}`, { method: "PUT",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nom: nom.trim() }) });
    chargerPerimetres();
  } catch (err) { $("#etat-perimetres").textContent = err.message; }
});
$("#form-perimetre").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await api("/api/perimetres", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: $("#type-perimetre-nouveau").value, nom: $("#nom-perimetre-nouveau").value }) });
    $("#nom-perimetre-nouveau").value = "";
    chargerPerimetres();
  } catch (err) { $("#etat-perimetres").textContent = err.message; }
});

// ------------------------------------------------------------------ outils

const AIDES_LISTES = {
  exclusions: "Termes qui ne seront plus jamais détectés comme personne, société, produit ou lieu (faux positifs récurrents).",
  personnes: "Noms de personnes toujours détectés et cochés d'office.",
  societes: "Sociétés toujours détectées et cochées d'office.",
  produits: "Produits et marques toujours détectés et cochés d'office.",
  lieux: "Villes, pays et lieux toujours détectés et cochés d'office (les lieux trouvés par les modèles sont décochés par défaut).",
};
async function remplirPerimetresListe() {
  const nom = $("#choix-liste").value;
  const choisi = $("#perimetre-liste").value;
  const r = await api("/api/perimetres");
  const options = [];
  if (nom === "exclusions") options.push(["general", t("Règles générales (tous les périmètres)")]);
  for (const p of r.perimetres) if (p.type !== "document") options.push([p.id, libelleType(p)]);
  $("#perimetre-liste").innerHTML = options.map(([v, l]) => `<option value="${echapper(v)}">${echapper(l)}</option>`).join("");
  if (options.some(([v]) => v === choisi)) $("#perimetre-liste").value = choisi;
}
async function chargerListe() {
  const nom = $("#choix-liste").value;
  $("#etat-liste").textContent = "";
  try {
    await remplirPerimetresListe();
    const r = await api(`/api/outils/listes/${nom}?perimetre=${encodeURIComponent($("#perimetre-liste").value)}`);
    $("#texte-liste").value = r.termes.join("\n");
    $("#aide-liste").textContent = AIDES_LISTES[nom] || "";
  } catch (e) { $("#etat-liste").textContent = e.message; }
}
$("#choix-liste").addEventListener("change", chargerListe);
$("#perimetre-liste").addEventListener("change", async () => {
  try {
    const r = await api(`/api/outils/listes/${$("#choix-liste").value}?perimetre=${encodeURIComponent($("#perimetre-liste").value)}`);
    $("#texte-liste").value = r.termes.join("\n");
    $("#etat-liste").textContent = "";
  } catch (e) { $("#etat-liste").textContent = e.message; }
});
$("#btn-enregistrer-liste").addEventListener("click", async () => {
  const termes = $("#texte-liste").value.split("\n").map((t) => t.trim()).filter(Boolean);
  try {
    const r = await api(`/api/outils/listes/${$("#choix-liste").value}?perimetre=${encodeURIComponent($("#perimetre-liste").value)}`, { method: "PUT",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify({ termes }) });
    $("#etat-liste").textContent = `Enregistré : ${r.nombre} terme(s). Pris en compte au prochain lot.`;
  } catch (e) { $("#etat-liste").textContent = e.message; }
});

function dessinerOptions(o) {
  const lignesActions = Object.entries(etat.config.categories_sensibles).map(([c, nom]) => `
    <div class="option-ligne"><strong>${echapper(nom)}</strong>${Object.entries(actionsPour(c)).map(([a, n]) =>
      `<label><input type="radio" name="opt-${c}" value="${a}" ${o.actions_par_defaut[c] === a ? "checked" : ""}>${n}</label>`).join("")}</div>`).join("");
  $("#formulaire-options").innerHTML = `
    <h3>Informations sensibles</h3>${lignesActions}
    <h3>Images</h3>
    <div class="option-ligne"><strong>Images des documents</strong>${[["conserver", "Conserver"], ["supprimer", "Supprimer"]].map(([a, n]) =>
      `<label><input type="radio" name="opt-images" value="${a}" ${o.images_par_defaut === a ? "checked" : ""}>${n}</label>`).join("")}</div>
    <h3>Détection</h3>
    <div class="option-ligne"><strong>Lieux détectés par les modèles</strong>
      <label><input type="checkbox" id="opt-lieux" ${o.lieux_preselectionnes ? "checked" : ""}>Cochés par défaut</label></div>
    <div class="option-ligne"><strong>Seuil de présélection</strong>
      <label><input type="number" id="opt-seuil" min="0" max="1" step="0.05" value="${o.seuil_preselection}" style="width:5rem"> confiance minimale pour cocher une entité (0 à 1)</label></div>`;
}
async function chargerOptions() {
  $("#etat-options").textContent = "";
  try { dessinerOptions(await api("/api/outils/options")); } catch (e) { $("#etat-options").textContent = e.message; }
}
$("#btn-enregistrer-options").addEventListener("click", async () => {
  const actions = {};
  for (const c of Object.keys(etat.config.categories_sensibles)) {
    const choisi = document.querySelector(`input[name=opt-${c}]:checked`);
    if (choisi) actions[c] = choisi.value;
  }
  const corps = {
    actions_par_defaut: actions,
    images_par_defaut: document.querySelector("input[name=opt-images]:checked").value,
    lieux_preselectionnes: $("#opt-lieux").checked,
    seuil_preselection: Number($("#opt-seuil").value),
  };
  try {
    const r = await api("/api/outils/options", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corps) });
    etat.config.actions_par_defaut = r.actions_par_defaut;
    etat.config.images_par_defaut = r.images_par_defaut;
    etat.config.seuil = r.seuil_preselection;
    $("#etat-options").textContent = "Enregistré. Appliqué à partir du prochain lot.";
  } catch (e) { $("#etat-options").textContent = e.message; }
});

async function chargerArchive() {
  try {
    const a = (await api("/api/etat")).archive;
    $("#info-archive-outils").innerHTML = a.entites || a.sensibles
      ? `<strong>Archive des codes :</strong> ${a.entites} nom(s) et ${a.sensibles} information(s) sensible(s).<br><code>${echapper(a.chemin)}</code>`
      : `<strong>Archive vide :</strong> aucun lot n'a encore été pseudonymisé.<br><code>${echapper(a.chemin)}</code>`;
  } catch (e) { $("#info-archive-outils").textContent = e.message; }
}
$("#btn-ouvrir-archive").addEventListener("click", async () => {
  try { await api("/api/outils/archive/ouvrir", { method: "POST" }); } catch (e) { alerter(e.message); }
});

// ------------------------------------------------------------------ coffre chiffré
async function chargerCoffre() {
  const info = $("#info-coffre");
  try {
    const c = await api("/api/coffre");
    etat.config.coffre = c;
    if (c.erreur) { info.innerHTML = `<strong>${echapper(traduire("Coffre inutilisable :"))}</strong> ${echapper(c.erreur)}`; return; }
    const lignes = [`${echapper(traduire("Emplacement du coffre :"))} <code>${echapper(c.dossier)}</code>`];
    if (c.migration && c.migration.source) {
      lignes.push(echapper(t("Archive historique migrée le {date} : {n} identité(s) et {m} valeur(s) sensible(s). Les fichiers d'origine n'ont pas été supprimés.",
        { date: c.migration.date.slice(0, 10), n: c.migration.identites, m: c.migration.sensibles })));
    }
    lignes.push(echapper(c.phrase_definie ? traduire("Phrase de récupération définie.")
      : traduire("Aucune phrase de récupération : si votre compte Windows est perdu, le coffre sera définitivement illisible. Créez-la maintenant.")));
    lignes.push(echapper(c.copies_en_clair ? t("{n} ancien(s) fichier(s) en clair (archive JSON, tables Excel) subsiste(nt) : supprimez-les une fois votre sauvegarde faite.", { n: c.copies_en_clair })
      : traduire("Aucun ancien fichier en clair.")));
    info.innerHTML = lignes.join("<br>");
    $("#btn-coffre-supprimer-clair").hidden = !c.copies_en_clair;
  } catch (e) { info.textContent = e.message; }
}
$("#btn-coffre-verifier").addEventListener("click", async () => {
  const retour = $("#retour-coffre");
  retour.textContent = traduire("Vérification en cours…");
  try {
    const r = await api("/api/coffre/verifier", { method: "POST" });
    const n = Object.values(r.comptes).reduce((a, b) => a + b, 0);
    retour.textContent = r.ok ? t("Contrôle terminé : coffre intact ({n} entrées vérifiées).", { n })
      : traduire("Anomalies détectées : ") + r.anomalies.join(" · ");
  } catch (e) { retour.textContent = e.message; }
});
$("#btn-coffre-phrase").addEventListener("click", async () => {
  const retour = $("#retour-coffre");
  let remplacer = false;
  if (etat.config.coffre && etat.config.coffre.phrase_definie) {
    if (!confirmer("Une phrase de récupération existe déjà. La remplacer rend l'ancienne inutilisable. Continuer ?")) return;
    remplacer = true;
  }
  try {
    const r = await api("/api/coffre/phrase", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ remplacer }) });
    retour.innerHTML = `${echapper(traduire("Votre phrase de récupération (notez-la maintenant, elle ne sera plus affichée) :"))} <code style="font-size:1.2em">${echapper(r.phrase)}</code>`;
    chargerCoffre();
  } catch (e) { retour.textContent = e.message; }
});
$("#btn-coffre-sauvegarde").addEventListener("click", async () => {
  const phrase = window.prompt(traduire("Phrase de récupération qui chiffrera la sauvegarde (12 caractères au moins) :"));
  if (!phrase) return;
  try {
    const r = await api("/api/coffre/sauvegarde", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ phrase }) });
    $("#retour-coffre").innerHTML = `${echapper(traduire("Sauvegarde créée :"))} <code>${echapper(r.fichier)}</code>`;
  } catch (e) { $("#retour-coffre").textContent = e.message; }
});
$("#btn-coffre-supprimer-clair").addEventListener("click", async () => {
  if (!confirmer("Supprimer les anciens fichiers en clair ? La suppression ne garantit pas leur effacement physique (disques SSD, copies de synchronisation, corbeille). Vérifiez que vous avez une sauvegarde chiffrée.")) return;
  try {
    const r = await api("/api/coffre/copies-en-clair/supprimer", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accord: true }) });
    $("#retour-coffre").textContent = t("{n} fichier(s) supprimé(s).", { n: r.supprimes.length });
    chargerCoffre();
  } catch (e) { $("#retour-coffre").textContent = e.message; }
});

function montrerOutil(outil) {
  document.querySelectorAll("#onglets-outils button").forEach((b) => b.classList.toggle("actif", b.dataset.outil === outil));
  for (const o of ["listes", "perimetres", "profils", "langues", "options", "archive", "coffre"]) $("#outil-" + o).hidden = o !== outil;
  if (outil === "listes") chargerListe();
  else if (outil === "perimetres") chargerPerimetres();
  else if (outil === "profils") chargerOutilProfils();
  else if (outil === "langues") chargerOutilLangues();
  else if (outil === "options") chargerOptions();
  else if (outil === "coffre") chargerCoffre();
  else chargerArchive();
}
$("#onglets-outils").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-outil]");
  if (b) montrerOutil(b.dataset.outil);
});
function ouvrirOutils() {
  $("#choix-liste").innerHTML = Object.entries(etat.config.listes || {}).map(([nom, libelle]) =>
    `<option value="${nom}">${echapper(libelle)}</option>`).join("");
  afficher("outils", "");
  montrerOutil("listes");
}
$("#btn-retour-outils").addEventListener("click", () => allerMenu());

// ------------------------------------------------------------------ arrêt

$("#btn-quitter").addEventListener("click", async () => {
  if (!confirmer("Arrêter Sine Nomine ?")) return;
  const envoyer = (forcer) => fetch("/api/quitter", { method: "POST", headers: { "Content-Type": "application/json", "X-CSRF-Token": jetonCsrf() },
    body: JSON.stringify({ forcer }) });
  let reponse = await envoyer(false);
  if (reponse.status === 409) {
    if (!confirmer("Un traitement est en cours et sera interrompu. Arrêter quand même ?")) return;
    reponse = await envoyer(true);
  }
  if (reponse.ok) {
    etat.lot = null;
    $("#modeles").textContent = "Arrêté";
    $("#modeles").className = "modeles erreur";
    $("#btn-quitter").hidden = true;
    afficher("arret", "");
  }
});

// ------------------------------------------------------------------ démarrage

(async function demarrer() {
  try {
    etat.config = await api("/api/etat");
  } catch {
    document.body.innerHTML = "<p style='padding:2rem'>Le serveur Sine Nomine ne répond pas. Relancez lancer.bat.</p>";
    return;
  }
  if (etat.config.extensions) EXTENSIONS = etat.config.extensions;
  if (etat.config.extensions_entree) EXTENSIONS_ENTREE = etat.config.extensions_entree;
  $("#selecteur").accept = EXTENSIONS_ENTREE.join(",");
  $("#selecteur-restauration").accept = EXTENSIONS.join(",");
  if (etat.config.pdf) $("#format-pdf").value = etat.config.pdf.format_defaut;
  $("#sortie-defaut").textContent = etat.config.dossiers.sortie;
  $("#dossier").placeholder = etat.config.dossiers.entree;
  rafraichirModeles();
  preparerAvertissement();
  afficherLicence();
  if (etat.config.coffre && etat.config.coffre.erreur) alerter(etat.config.coffre.erreur);
  allerMenu();
})();

// Bandeau de la licence d'évaluation : jours restants, ou raison pour laquelle le traitement de fichiers est bloqué.
const TEXTES_LICENCE = {
  absente: "Sine Nomine n'est pas activé. Saisissez votre clé d'accès. Pour en obtenir une : contact@sinenomine.app.",
  invalide: "La licence est invalide. Saisissez à nouveau votre clé d'accès.",
  horloge: "L'horloge de l'ordinateur est en retard sur la dernière utilisation : corrigez la date et l'heure.",
};
function afficherLicence() {
  const bandeau = $("#bandeau-licence");
  const l = etat.config && etat.config.licence;
  if (!l || l.statut === "non_requise") { bandeau.hidden = true; return; }
  bandeau.hidden = false;
  bandeau.classList.toggle("bloque", l.statut !== "active");
  bandeau.classList.toggle("bientot", l.statut === "active" && !l.a_vie && l.jours_restants <= 7);
  const commerciale = l.type === "commerciale";
  const texte = $("#texte-licence");
  if (l.statut === "active" && l.a_vie) {
    texte.textContent = traduire(commerciale ? "Version commerciale · licence valable à vie"
                                             : "Version d'évaluation · licence sans limite de durée");
  } else if (l.statut === "active") {
    const date = new Date(l.expire_le + "T12:00:00").toLocaleDateString(LANGUE === "en" ? "en-GB" : "fr-FR");
    texte.textContent = t(commerciale ? "Version commerciale · licence valable jusqu'au {date} ({n} jour(s) restant(s))"
                                      : "Version d'évaluation · licence valable jusqu'au {date} ({n} jour(s) restant(s))",
                          { n: l.jours_restants, date });
  } else if (l.statut === "expiree") {
    texte.textContent = l.jours_depuis_expiration
      ? t("Votre licence a expiré depuis {n} jour(s). Saisissez un nouveau code d'activation. La dé-pseudonymisation de vos fichiers reste possible.", { n: l.jours_depuis_expiration })
      : traduire("Votre licence a expiré aujourd'hui. Saisissez un nouveau code d'activation. La dé-pseudonymisation de vos fichiers reste possible.");
  } else {
    texte.textContent = traduire(TEXTES_LICENCE[l.statut] || TEXTES_LICENCE.invalide);
  }
}

// Saisie d'une clé dans l'application : activation en ligne, déclenchée par l'utilisateur.
$("#btn-licence").addEventListener("click", () => {
  $("#retour-licence").textContent = "";
  $("#dialogue-licence").showModal();
  $("#cle-acces").focus();
});
$("#btn-licence-fermer").addEventListener("click", () => $("#dialogue-licence").close());
$("#form-licence").addEventListener("submit", async (e) => {
  e.preventDefault();
  const retour = $("#retour-licence"), bouton = $("#btn-licence-activer");
  const cle = $("#cle-acces").value.trim();
  if (!cle) { retour.textContent = traduire("Saisissez votre clé d'accès."); return; }
  bouton.disabled = true;
  retour.textContent = traduire("Activation en cours…");
  try {
    const r = await api("/api/licence/activer", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cle }) });
    etat.config.licence = r.licence;
    afficherLicence();
    retour.textContent = r.message;
    $("#cle-acces").value = "";
  } catch (erreurActivation) {
    retour.textContent = erreurActivation.message;
  } finally {
    bouton.disabled = false;
  }
});

window.addEventListener("beforeunload", (e) => {
  if (etat.lot && ["a_valider", "traitement"].includes(etat.lot.etat)) e.preventDefault();
});

// Changement de langue : i18n.js traduit ce qui est déjà à l'écran ; on rafraîchit ici ce qui vient du serveur ou du code.
window.surChangementLangue = () => {
  if (!etat.config) return;
  const coche = $("#accepter").checked, actif = !$("#btn-accepter").disabled;
  preparerAvertissement();                         // textes légaux et mention de bas de page dans la nouvelle langue
  $("#accepter").checked = coche;
  $("#btn-accepter").disabled = !actif;
  afficherLicence();
  const seuil = $("#seuil");
  if (seuil && etat.config.seuil !== undefined) seuil.textContent = pourcent(etat.config.seuil);
  if (etat.ecran === "resultats" && etat.lot && etat.lot.etat === "termine") afficherResultats(etat.lot);
};
