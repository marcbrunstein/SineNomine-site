@echo off
rem Sine Nomine - cree les raccourcis du Bureau et du menu Demarrer (lancement sans fenetre noire)
setlocal
set "VENV=%USERPROFILE%\.venvs\sine-nomine"
if not exist "%VENV%\Scripts\pythonw.exe" (
  call "%~dp0installer.bat" || exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$racine = (Resolve-Path '%~dp0').Path.TrimEnd('\');" ^
  "$cible = '%VENV%\Scripts\pythonw.exe';" ^
  "$shell = New-Object -ComObject WScript.Shell;" ^
  "$dossiers = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'));" ^
  "foreach ($d in $dossiers) {" ^
  "  $l = $shell.CreateShortcut((Join-Path $d 'Sine Nomine.lnk'));" ^
  "  $l.TargetPath = $cible; $l.Arguments = '-B -m anonymiseur'; $l.WorkingDirectory = $racine;" ^
  "  $l.IconLocation = (Join-Path $racine 'anonymiseur\static\sine-nomine.ico');" ^
  "  $l.Description = 'Sine Nomine - anonymiseur de fichiers local (Habeas Corpus Consulting)';" ^
  "  $l.Save(); Write-Host ('Raccourci cree : ' + $l.FullName) }"
if errorlevel 1 (
  echo La creation des raccourcis a echoue.
  pause
  exit /b 1
)
