@echo off
rem Sine Nomine - lancement de l interface locale
setlocal
set "VENV=%USERPROFILE%\.venvs\sine-nomine"
set PYTHONDONTWRITEBYTECODE=1
set PYTHONUTF8=1
title Sine Nomine
if not exist "%VENV%\Scripts\python.exe" (
  call "%~dp0installer.bat" || exit /b 1
)
cd /d "%~dp0"
"%VENV%\Scripts\python.exe" -m anonymiseur %*
if errorlevel 1 pause
