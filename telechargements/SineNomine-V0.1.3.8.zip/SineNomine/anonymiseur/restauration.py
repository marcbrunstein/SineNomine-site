"""Désanonymisation : remet les valeurs d'origine à la place des codes (Personne_KQXMB, [Email_ZTRPA]…).

Fonctionne sur tout fichier produit par Sine Nomine, quel que soit le lot, grâce à l'archive des codes.
Les fichiers de départ ne sont jamais modifiés ; les fichiers restaurés vont dans un dossier daté.
"""

from datetime import datetime
from pathlib import Path

from . import config as cfg, formats
from .archive import NOM_FICHIER, Archive, Restaurateur
from .lots import Lot
from .rapport import Journal


def charger_archive(config):
    return Archive.charger(cfg.dossier(config, "correspondances") / NOM_FICHIER)


def nouveau_dossier(config, prefixe="restauration"):
    """Dossier de sortie daté, dans le dossier de sortie configuré (jamais écrasé)."""
    base = cfg.dossier(config, "sortie")
    identifiant = f"{prefixe}_" + datetime.now().strftime("%Y-%m-%d_%H%M%S")
    while (base / identifiant).exists():
        identifiant += "b"
    dossier = base / identifiant
    dossier.mkdir(parents=True)
    return identifiant, dossier


def restaurer(archive, fichiers, dossier_sortie):
    """Restaure chaque fichier ; renvoie un résultat par fichier.

    fichiers : [(chemin source, chemin relatif)]. Un code absent de l'archive reste tel quel et est signalé.
    """
    restaurateur = Restaurateur(archive)
    utilises, resultats = set(), []
    for chemin, relatif in fichiers:
        avant = dict(restaurateur.inconnus)
        journal = Journal()
        sortie_relative = Lot._nom_sortie(relatif, restaurateur, utilises)
        resultat = {"source": relatif, "sortie": sortie_relative, "remplacements": 0, "inconnus": [], "erreur": None}
        try:
            formats.ecrire_anonymise(chemin, Path(dossier_sortie) / sortie_relative, restaurateur, journal,
                                     restaurer=True)
            resultat["remplacements"] = sum(journal.entites.values())
            resultat["inconnus"] = sorted(c for c, n in restaurateur.inconnus.items() if n > avant.get(c, 0))
        except Exception as e:  # noqa: BLE001 — affiché dans l'interface, les autres fichiers continuent
            resultat["erreur"] = f"{type(e).__name__} : {e}"
        resultats.append(resultat)
    return resultats
