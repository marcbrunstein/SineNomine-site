"""Lecture des réglages (config.json à la racine de Sine Nomine)."""

import json
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
FICHIER_CONFIG = RACINE / "config.json"
FICHIER_UTILISATEUR = RACINE / "config.utilisateur.json"

DEFAUTS = {
    "dossiers": {
        "entree": "entree",
        "sortie": "sortie",
        "correspondances": "correspondances",
        "dictionnaires": "dictionnaires",
    },
    "port": 8765,
    "spacy_modele": "fr_core_news_lg",
    "spacy_modele_en": "en_core_web_lg",
    "langues": ["fr", "en"],                  # langues des documents ; ["fr"] pour ne charger que le modèle français
    "gliner": {"actif": True, "modele": "urchade/gliner_multi-v2.1", "seuil": 0.45,
               "seuils": {"personne": 0.55, "entreprise": 0.5, "produit": 0.7, "marque": 0.75,
                          "ville": 0.6, "pays": 0.6}},
    "lieux_preselectionnes": False,           # villes et pays : proposés mais décochés par défaut
    "filtres": {"min_minuscules": 3, "min_minuscules_spacy": 1, "graphies_etrangeres": True,
                "motifs_exclus": [r"^[A-Za-z]\d{1,3}$"]},
    "seuil_preselection": 0.6,
    "images_par_defaut": "conserver",
    "mode_par_defaut": "pseudonymisation",   # ou "anonymisation" (irréversible, rien n'est conservé)
    "actions_par_defaut": {},
    # Motifs (expressions régulières) des références internes à masquer : numéros de dossier, de contrat, de client…
    # Exemple : ["\\bDOS-\\d{6}\\b", "\\bCT\\d{4}-\\d{3}\\b"]
    "references_motifs": [],
}


def _fusion(base, ajout):
    resultat = dict(base)
    for cle, valeur in ajout.items():
        if isinstance(valeur, dict) and isinstance(resultat.get(cle), dict):
            resultat[cle] = _fusion(resultat[cle], valeur)
        else:
            resultat[cle] = valeur
    return resultat


def charger():
    """Réglages : valeurs par défaut, puis config.json, puis config.utilisateur.json (écrit par Outils > Options)."""
    config = DEFAUTS
    if FICHIER_CONFIG.exists():
        config = _fusion(config, json.loads(FICHIER_CONFIG.read_text(encoding="utf-8")))
    if FICHIER_UTILISATEUR.exists():
        config = _fusion(config, json.loads(FICHIER_UTILISATEUR.read_text(encoding="utf-8")))
    return config


def enregistrer_utilisateur(config, options):
    """Enregistre des réglages dans config.utilisateur.json (config.json reste intact) et les applique à `config`."""
    existant = json.loads(FICHIER_UTILISATEUR.read_text(encoding="utf-8")) if FICHIER_UTILISATEUR.exists() else {}
    FICHIER_UTILISATEUR.write_text(json.dumps(_fusion(existant, options), ensure_ascii=False, indent=2),
                                   encoding="utf-8")
    for cle, valeur in options.items():
        config[cle] = _fusion(config.get(cle, {}), valeur) if isinstance(valeur, dict) else valeur


def dossier(config, nom):
    """Chemin absolu d'un dossier configuré (relatif à la racine s'il n'est pas absolu), créé au besoin."""
    chemin = Path(config["dossiers"][nom])
    if not chemin.is_absolute():
        chemin = RACINE / chemin
    chemin.mkdir(parents=True, exist_ok=True)
    return chemin
