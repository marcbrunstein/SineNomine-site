"""Rapport du lot (HTML et Excel) et table de correspondance.

Le rapport va dans le dossier de sortie avec les fichiers anonymisés : il ne contient
aucune valeur d'origine. Les valeurs d'origine ne figurent que dans la table de
correspondance, rangée à part dans le dossier « correspondances ».
"""

import base64
import html
from collections import Counter, defaultdict
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from . import VERSION, sensibles, textes
from .detection import CATEGORIES_ENTITES
from .traductions import traducteur, traduire
from .remplacement import contexte


class Journal:
    """Ce qui a été remplacé ou conservé dans un fichier."""

    def __init__(self):
        self.entites = Counter()          # id -> occurrences
        self.sensibles = Counter()        # catégorie -> remplacements
        self.conservees = []              # (catégorie, score, contexte dans le texte anonymisé)
        self.images_supprimees = 0
        self.parties_reparees = 0          # défauts du fichier d'origine corrigés (Word le jugeait endommagé)

    def noter(self, nouveau_texte, remplacements, conservees):
        for r in remplacements:
            if r.nature == "entite":
                self.entites[r.reference] += 1
            else:
                self.sensibles[r.reference[0]] += 1
        for t, debut, fin in conservees:
            self.conservees.append((t.categorie, t.score, contexte(nouveau_texte, debut, fin)))


def _e(texte):
    return html.escape(str(texte))


LOGO = Path(__file__).resolve().parent / "static" / "habeas-corpus.png"


def _vignettes_html(apercus, langue="fr"):
    """Miniatures des images conservées. Pas de nom de fichier : il pourrait contenir un nom de personne."""
    T = traducteur(langue)
    figures = []
    for numero, im in enumerate(apercus, start=1):
        legende = T("Image {n}", n=numero) + (f" · ×{im['occurrences']}" if im["occurrences"] > 1 else "")
        if im.get("dimensions"):
            legende += f" · {im['dimensions'][0]}×{im['dimensions'][1]} px"
        if im.get("donnees"):
            visuel = f"<img src='data:{im['type']};base64,{im['donnees']}' alt='{_e(legende)}'>"
        else:
            visuel = f"<span>{_e(traduire(im.get('note') or T('Aperçu impossible pour ce format.'), langue))}</span>"
        figures.append(f"<figure>{visuel}<figcaption>{_e(legende)}</figcaption></figure>")
    return f"<div class='vignettes'>{''.join(figures)}</div>"


def _logo_base64():
    """Logo intégré au rapport, pour qu'il reste lisible une fois copié ailleurs."""
    return base64.b64encode(LOGO.read_bytes()).decode("ascii")


STYLE = """
body{font-family:'Segoe UI',system-ui,sans-serif;max-width:1000px;margin:2rem auto;padding:0 1rem;color:#1d2433;background:#fff}
h1{font-size:1.6rem;margin-bottom:.2rem}h2{margin-top:2.2rem;border-bottom:2px solid #e3e6ee;padding-bottom:.3rem}
h3{margin-top:1.6rem}table{border-collapse:collapse;width:100%;margin:.6rem 0;font-size:.9rem}
th,td{border:1px solid #dde1ea;padding:.4rem .6rem;text-align:left;vertical-align:top}th{background:#f3f5f9}
.meta{color:#5b6475}.alerte{background:#fff6e5;border-left:4px solid #e0a100;padding:.6rem 1rem;margin:.8rem 0}
.legal{font-size:.82rem;color:#5b6475;border-top:1px solid #e3e6ee;margin-top:3rem;padding-top:1rem}
code{background:#f3f5f9;padding:0 .25rem;border-radius:3px}.vide{color:#8a93a6;font-style:italic}
.entete{display:flex;justify-content:space-between;align-items:center;gap:1rem}.entete img{border-radius:4px}
.legal a{color:#5b6475}
.vignettes{display:flex;flex-wrap:wrap;gap:.7rem;margin:.6rem 0 1rem}
.vignettes figure{margin:0;width:180px;border:1px solid #dde1ea;border-radius:6px;overflow:hidden}
.vignettes img,.vignettes span{display:block;width:100%;height:140px;object-fit:contain;background:#f3f5f9}
.vignettes span{display:flex;align-items:center;padding:.5rem;font-size:.78rem;color:#5b6475;box-sizing:border-box}
.vignettes figcaption{font-size:.75rem;color:#5b6475;padding:.3rem .5rem;border-top:1px solid #dde1ea}
"""


def ecrire_html(chemin, lot, resultats, libelles, entites, correspondances):
    langue = lot.langue
    T = traducteur(langue)
    categorie_par_id = {e.id: e.categorie for e in entites}
    nom_cat = lambda c: T(sensibles.CATEGORIES[c])            # noqa: E731
    nom_entite = lambda c: T(CATEGORIES_ENTITES[c])            # noqa: E731
    titre = T("Rapport d'anonymisation")
    acceptation = T("Avertissement accepté le {a}. Détections validées par l'utilisateur le {v}.",
                    a=lot.avertissement_accepte, v=lot.date_validation)
    lignes = [f"<!doctype html><html lang='{langue}'><head><meta charset='utf-8'><title>{_e(T('Rapport Sine Nomine — {lot}', lot=lot.id))}</title>"
              f"<style>{STYLE}</style></head><body>",
              f"<header class='entete'><h1>{_e(titre)}</h1>"
              f"<img src='data:image/png;base64,{_logo_base64()}' alt='{_e(textes.EDITEUR)}' width='72' height='72'></header>",
              f"<p class='meta'>{_e(T('Lot'))} <code>{_e(lot.id)}</code> · {_e(lot.date_traitement)} · Sine Nomine {VERSION}</p>",
              f"<p class='meta'><strong>{_e(T('Mode : {mode}', mode=textes.MODES_PAR_LANGUE[langue][lot.mode]))}</strong></p>",
              f"<p class='meta'>{_e(acceptation)}</p>",
              f"<div class='alerte'>{_e(textes.texte('fiabilite', langue))}</div>"]

    total_entites = sum(sum(r["journal"].entites.values()) for r in resultats)
    total_sensibles = sum(sum(r["journal"].sensibles.values()) for r in resultats)
    total_conservees = sum(len(r["journal"].conservees) for r in resultats)
    lignes.append(f"<h2>{_e(T('Synthèse'))}</h2><table><tr><th>{_e(T('Fichiers traités'))}</th><th>{_e(T('Entités remplacées'))}</th>"
                  f"<th>{_e(T('Informations sensibles remplacées'))}</th><th>{_e(T('Informations sensibles conservées'))}</th></tr>"
                  f"<tr><td>{len(resultats)}</td><td>{total_entites}</td><td>{total_sensibles}</td>"
                  f"<td>{total_conservees}</td></tr></table>")

    lignes.append(f"<h2>{_e(T('Choix appliqués aux informations sensibles'))}</h2><table><tr><th>{_e(T('Catégorie'))}</th><th>{_e(T('Action'))}</th>"
                  f"<th>{_e(T('Éléments exclus (conservés)'))}</th></tr>")
    exclus = Counter(c for c, _ in correspondances.exclusions)
    for categorie in sensibles.CATEGORIES:
        lignes.append(f"<tr><td>{_e(nom_cat(categorie))}</td><td>{_e(T(correspondances.actions.get(categorie, 'conserver')))}</td>"
                      f"<td>{exclus.get(categorie, 0)}</td></tr>")
    total_images = sum(r["journal"].images_supprimees for r in resultats)
    lignes.append(f"<tr><td>{_e(T('Images'))}</td><td>{_e(T('supprimer' if lot.supprimer_images else 'conserver'))}</td>"
                  f"<td>—</td></tr></table>")
    if lot.supprimer_images:
        lignes.append(f"<p>{_e(T('{n} image(s) supprimée(s), remplacée(s) par « [image supprimée] ».', n=total_images))}</p>")

    for r in resultats:
        j = r["journal"]
        lignes.append(f"<h2>{_e(r['sortie_relative'])}</h2>")
        if r.get("erreur"):
            lignes.append(f"<div class='alerte'>{_e(T('Erreur : {x}', x=r['erreur']))}</div>")
            continue
        for message in r["avertissements"]:
            lignes.append(f"<div class='alerte'>{_e(traduire(message, langue))}</div>")
        if j.images_supprimees:
            lignes.append(f"<p>{_e(T('{n} image(s) supprimée(s).', n=j.images_supprimees))}</p>")
        if r.get("apercus_rapport"):
            lignes.append(_vignettes_html(r["apercus_rapport"], langue))

        lignes.append(f"<h3>{_e(T('Entités remplacées'))}</h3>")
        if j.entites:
            lignes.append(f"<table><tr><th>{_e(T('Identifiant'))}</th><th>{_e(T('Type'))}</th><th>{_e(T('Occurrences'))}</th></tr>")
            for id_entite, n in sorted(j.entites.items(), key=lambda kv: libelles[kv[0]]):
                lignes.append(f"<tr><td>{_e(libelles[id_entite])}</td>"
                              f"<td>{_e(nom_entite(categorie_par_id[id_entite]))}</td><td>{n}</td></tr>")
            lignes.append("</table>")
        else:
            lignes.append(f"<p class='vide'>{_e(T('Aucune.'))}</p>")

        lignes.append(f"<h3>{_e(T('Informations sensibles remplacées'))}</h3>")
        if j.sensibles:
            lignes.append(f"<table><tr><th>{_e(T('Catégorie'))}</th><th>{_e(T('Remplacements'))}</th></tr>")
            for categorie, n in j.sensibles.items():
                lignes.append(f"<tr><td>{_e(nom_cat(categorie))}</td><td>{n}</td></tr>")
            lignes.append("</table>")
        else:
            lignes.append(f"<p class='vide'>{_e(T('Aucune.'))}</p>")

        lignes.append(f"<h3>{_e(T('Informations potentiellement sensibles conservées'))}</h3>")
        if j.conservees:
            lignes.append(f"<table><tr><th>{_e(T('Catégorie'))}</th><th>{_e(T('Extrait (texte anonymisé)'))}</th><th>{_e(T('Confiance'))}</th></tr>")
            for categorie, score, extrait in j.conservees:
                lignes.append(f"<tr><td>{_e(nom_cat(categorie))}</td><td>{_e(extrait)}</td>"
                              f"<td>{score:.0%}</td></tr>")
            lignes.append("</table>")
        else:
            lignes.append(f"<p class='vide'>{_e(T('Aucune.'))}</p>")

    mode_texte = (f"<p><strong>{_e(T('Pseudonymisation.'))}</strong> {_e(textes.texte('pseudonymisation', langue))}</p>" if lot.pseudonymisation
                  else f"<p><strong>{_e(T('Anonymisation.'))}</strong> {_e(textes.texte('anonymisation', langue))}</p>")
    lignes.append(f"<div class='legal'><p><strong>{_e(T('Propriété intellectuelle.'))}</strong> {_e(textes.texte('propriete', langue))}</p>"
                  f"<p><strong>{_e(T('Responsabilité.'))}</strong> {_e(textes.texte('responsabilite', langue))}</p>"
                  + mode_texte +
                  f"<p><strong>{_e(T('Confidentialité.'))}</strong> {_e(textes.texte('confidentialite', langue))}</p>"
                  f"<p><strong>{_e(T('Loi applicable.'))}</strong> {_e(textes.texte('loi', langue))}</p>"
                  f"<p>{_e(textes.texte('mention', langue))}</p>"
                  f"<p><strong>{_e(T('Contact.'))}</strong> {_e(textes.EDITEUR)} · "
                  f"<a href='mailto:{_e(textes.CONTACT_EMAIL)}'>{_e(textes.CONTACT_EMAIL)}</a> · "
                  f"{_e(textes.CONTACT_TELEPHONE)}</p></div></body></html>")
    chemin.write_text("\n".join(lignes), encoding="utf-8")


def _entete(feuille, colonnes):
    feuille.append(colonnes)
    for cellule in feuille[feuille.max_row]:
        cellule.font = Font(bold=True, color="FFFFFF")
        cellule.fill = PatternFill("solid", fgColor="2F3A56")
    feuille.freeze_panes = feuille.cell(row=feuille.max_row + 1, column=1)


def _largeurs(feuille, largeurs):
    for lettre, largeur in zip("ABCDEFGH", largeurs):
        feuille.column_dimensions[lettre].width = largeur


def ecrire_excel(chemin, lot, resultats, libelles, entites):
    langue = lot.langue
    T = traducteur(langue)
    categorie_par_id = {e.id: e.categorie for e in entites}
    classeur = Workbook()
    synthese = classeur.active
    synthese.title = T("Synthèse")
    synthese.append([T("Rapport d'anonymisation Sine Nomine"), ""])
    synthese["A1"].font = Font(bold=True, size=14)
    for ligne in ([T("Lot"), lot.id], [T("Mode"), textes.MODES_PAR_LANGUE[langue][lot.mode]],
                  [T("Date"), lot.date_traitement], [T("Avertissement accepté le"), lot.avertissement_accepte],
                  [T("Validé le"), lot.date_validation], [T("Fichiers traités"), len(resultats)],
                  [T("Images supprimées"), sum(r["journal"].images_supprimees for r in resultats)
                   if lot.supprimer_images else T("non (conservées)")], ["", ""],
                  [T("Fiabilité"), textes.texte("fiabilite", langue)], ["", ""],
                  [T("Éditeur"), textes.EDITEUR], ["Contact", f"{textes.CONTACT_EMAIL} · {textes.CONTACT_TELEPHONE}"]):
        synthese.append(ligne)
    synthese["B10"].alignment = Alignment(wrap_text=True)
    _largeurs(synthese, [26, 100])

    feuille = classeur.create_sheet(T("Entités remplacées"))
    _entete(feuille, [T("Fichier"), T("Identifiant"), T("Type"), T("Occurrences")])
    for r in resultats:
        for id_entite, n in sorted(r["journal"].entites.items(), key=lambda kv: libelles[kv[0]]):
            feuille.append([r["sortie_relative"], libelles[id_entite],
                            T(CATEGORIES_ENTITES[categorie_par_id[id_entite]]), n])
    _largeurs(feuille, [45, 18, 14, 12])
    feuille.auto_filter.ref = feuille.dimensions

    feuille = classeur.create_sheet(T("Sensibles remplacées"))
    _entete(feuille, [T("Fichier"), T("Catégorie"), T("Remplacements")])
    for r in resultats:
        for categorie, n in r["journal"].sensibles.items():
            feuille.append([r["sortie_relative"], T(sensibles.CATEGORIES[categorie]), n])
        if r["journal"].images_supprimees:
            feuille.append([r["sortie_relative"], T("Images (supprimées)"), r["journal"].images_supprimees])
    _largeurs(feuille, [45, 26, 14])
    feuille.auto_filter.ref = feuille.dimensions

    feuille = classeur.create_sheet(T("Sensibles conservées"))
    _entete(feuille, [T("Fichier"), T("Catégorie"), T("Extrait (texte anonymisé)"), T("Confiance")])
    for r in resultats:
        for categorie, score, extrait in r["journal"].conservees:
            feuille.append([r["sortie_relative"], T(sensibles.CATEGORIES[categorie]), extrait, round(score, 2)])
    _largeurs(feuille, [45, 24, 100, 11])
    feuille.auto_filter.ref = feuille.dimensions

    feuille = classeur.create_sheet(T("Avertissements"))
    _entete(feuille, [T("Fichier"), T("Message")])
    for r in resultats:
        for message in [traduire(m, langue) for m in r["avertissements"]] + ([T("Erreur : {x}", x=r["erreur"])] if r.get("erreur") else []):
            feuille.append([r["sortie_relative"], message])
    _largeurs(feuille, [45, 110])
    classeur.save(chemin)


def ecrire_correspondances(chemin, lot, libelles, entites, correspondances):
    langue = lot.langue
    T = traducteur(langue)
    classeur = Workbook()
    feuille = classeur.active
    feuille.title = T("Entités")
    feuille.append([T("DOCUMENT CONFIDENTIEL — permet de lever la pseudonymisation du lot {lot}", lot=lot.id)])
    feuille["A1"].font = Font(bold=True, color="B00020")
    feuille.append([textes.texte("pseudonymisation", langue)])
    feuille.append([])
    _entete(feuille, [T("Identifiant"), T("Type"), T("Nom d'origine"), T("Variantes recherchées"), T("Occurrences")])
    for e in sorted((e for e in entites if e.id in libelles), key=lambda e: e.premiere):
        feuille.append([libelles[e.id], T(CATEGORIES_ENTITES[e.categorie]), e.canonique, " | ".join(e.variantes),
                        e.occurrences])
    _largeurs(feuille, [16, 12, 34, 90, 12])

    feuille = classeur.create_sheet(T("Informations sensibles"))
    _entete(feuille, [T("Remplacé par"), T("Catégorie"), T("Valeur(s) d'origine")])
    valeurs = defaultdict(set)
    for reference, ensemble in correspondances.sensibles_valeurs.items():
        valeurs[reference] |= ensemble
    for reference, libelle in correspondances.sensibles_libelles.items():
        feuille.append([libelle, T(sensibles.CATEGORIES[reference[0]]), " | ".join(sorted(valeurs[reference]))])
    supprimees = [ref for ref in valeurs if ref not in correspondances.sensibles_libelles]
    for reference in supprimees:
        feuille.append([T("[supprimé]"), T(sensibles.CATEGORIES[reference[0]]), " | ".join(sorted(valeurs[reference]))])
    _largeurs(feuille, [22, 26, 80])
    classeur.save(chemin)
