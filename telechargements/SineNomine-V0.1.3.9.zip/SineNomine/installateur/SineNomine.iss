﻿; Installateur de Sine Nomine (Inno Setup 6). Construit par installateur/construire_installateur.py :
;   python installateur/construire_installateur.py
; Il copie les fichiers dans le dossier choisi par l'utilisateur (modifiable, ou à créer), propose les raccourcis,
; puis lance installer.bat qui prépare Python, les bibliothèques et les modèles (connexion Internet nécessaire).
; Signature de code : une fois le certificat acheté, décommentez SignTool et SignedUninstaller (voir installateur/LISEZMOI.md).

#ifndef Version
  #define Version "0.0.0"
#endif

[Setup]
AppId={{8B2F6A1E-3C47-4E5D-9A71-5D0C2B6E4F13}
AppName=Sine Nomine
AppVersion={#Version}
AppVerName=Sine Nomine {#Version}
AppPublisher=Habeas Corpus S.A.S.
AppPublisherURL=https://www.sinenomine.app
AppSupportURL=https://www.sinenomine.app
AppUpdatesURL=https://www.sinenomine.app/telecharger/
DefaultDirName={localappdata}\Programs\Sine Nomine
DisableProgramGroupPage=yes
DisableDirPage=no
; Les dossiers de travail (entree, sortie, correspondances) sont créés dans le dossier d'installation :
; une installation par utilisateur, sans droits d'administrateur, évite les problèmes d'écriture.
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
ExtraDiskSpaceRequired=6442450944
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=build\stage\anonymiseur\static\sine-nomine.ico
UninstallDisplayIcon={app}\anonymiseur\static\sine-nomine.ico
OutputDir=build\sortie
OutputBaseFilename=SineNomine-Setup-V{#Version}
; SignTool=signtool
; SignedUninstaller=yes

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"; LicenseFile: "build\stage\LICENCE.fr.txt"
Name: "english"; MessagesFile: "compiler:Default.isl"; LicenseFile: "build\stage\LICENCE.en.txt"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "menuicon"; Description: "{cm:AddToStartMenu}"; GroupDescription: "{cm:AdditionalIcons}"

[CustomMessages]
french.CreateDesktopIcon=Créer un raccourci sur le &Bureau
french.AddToStartMenu=Ajouter Sine Nomine au menu &Démarrer
french.AdditionalIcons=Raccourcis :
french.PreparingEnv=Préparation de Sine Nomine (Python, bibliothèques et modèles de détection)…
french.PreparingNote=Une fenêtre noire va s'ouvrir : elle installe Python si besoin, puis télécharge environ 2 Go de modèles. Laissez-la ouverte jusqu'à la fin ; cela peut prendre un temps assez long selon votre connexion Internet.
french.EnvFailed=La préparation de Sine Nomine n'a pas abouti (code %1). Vérifiez votre connexion Internet, puis double-cliquez sur « installer.bat » dans le dossier d'installation pour recommencer.
english.CreateDesktopIcon=Create a &Desktop shortcut
english.AddToStartMenu=Add Sine Nomine to the &Start menu
english.AdditionalIcons=Shortcuts:
english.PreparingEnv=Preparing Sine Nomine (Python, libraries and detection models)…
english.PreparingNote=A black window will open: it installs Python if needed, then downloads about 2 GB of models. Keep it open until it finishes; this can take a while depending on your Internet connection.
english.EnvFailed=Sine Nomine could not be prepared (code %1). Check your Internet connection, then double-click "installer.bat" in the installation folder to try again.

[Files]
Source: "build\stage\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion createallsubdirs

[Icons]
Name: "{autodesktop}\Sine Nomine"; Filename: "{app}\environnement\Scripts\pythonw.exe"; Parameters: "-B -m anonymiseur"; WorkingDir: "{app}"; IconFilename: "{app}\anonymiseur\static\sine-nomine.ico"; Comment: "Sine Nomine"; Tasks: desktopicon
Name: "{autoprograms}\Sine Nomine"; Filename: "{app}\environnement\Scripts\pythonw.exe"; Parameters: "-B -m anonymiseur"; WorkingDir: "{app}"; IconFilename: "{app}\anonymiseur\static\sine-nomine.ico"; Comment: "Sine Nomine"; Tasks: menuicon

[UninstallDelete]
; Seul l'environnement Python créé à l'installation est supprimé. Les dossiers entree, sortie, correspondances et
; dictionnaires (vos fichiers et l'archive des codes) ne sont jamais effacés par la désinstallation.
Type: filesandordirs; Name: "{app}\environnement"

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  Code: Integer;
begin
  // /SKIPENV=1 : copie des fichiers et raccourcis seulement (tests de l'installateur)
  if (CurStep = ssPostInstall) and (ExpandConstant('{param:SKIPENV|0}') <> '1') then
  begin
    WizardForm.StatusLabel.Caption := CustomMessage('PreparingEnv');
    if not WizardSilent then
      MsgBox(CustomMessage('PreparingNote'), mbInformation, MB_OK);
    if not Exec(ExpandConstant('{cmd}'), '/c ""' + ExpandConstant('{app}\installer.bat') + '""',
                ExpandConstant('{app}'), SW_SHOW, ewWaitUntilTerminated, Code) or (Code <> 0) then
      MsgBox(FmtMessage(CustomMessage('EnvFailed'), [IntToStr(Code)]), mbError, MB_OK);
  end;
end;
