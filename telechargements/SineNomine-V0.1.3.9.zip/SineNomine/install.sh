#!/usr/bin/env bash
# Sine Nomine - installation de l'environnement Python local (Linux et macOS)
set -e
VENV="${SINE_NOMINE_VENV:-$HOME/.venvs/sine-nomine}"
RACINE="$(cd "$(dirname "$0")" && pwd)"
SYSTEME="$(uname -s)"
export PYTHONDONTWRITEBYTECODE=1

echo
echo " Installation de Sine Nomine (bibliotheques et modeles, environ 2 Go)..."
echo

demander() {  # demander "question" -> 0 si oui
  read -r -p " $1 [O/n] " reponse
  case "$reponse" in [nN]*) return 1 ;; *) return 0 ;; esac
}

chercher_python() {
  for cmd in python3.12 python3; do
    if command -v "$cmd" >/dev/null 2>&1 && "$cmd" -c 'import sys; sys.exit(0 if sys.version_info[:2] == (3, 12) else 1)' 2>/dev/null; then
      PYEXE="$(command -v "$cmd")"; return 0
    fi
  done
  return 1
}

if ! chercher_python; then
  echo " Python 3.12 est introuvable. Sine Nomine en a besoin : les versions plus recentes ne sont pas compatibles avec spaCy."
  if [ "$SYSTEME" = "Darwin" ]; then
    command -v brew >/dev/null 2>&1 || { echo " Installez d'abord Homebrew (https://brew.sh), puis relancez ce script."; exit 1; }
    demander "Installer Python 3.12 avec Homebrew ?" || exit 1
    brew install python@3.12
  elif command -v apt-get >/dev/null 2>&1; then
    demander "Installer Python 3.12 avec apt (mot de passe administrateur demande) ?" || exit 1
    sudo apt-get update && sudo apt-get install -y python3.12 python3.12-venv
  else
    echo " Installez Python 3.12 avec le gestionnaire de paquets de votre distribution, puis relancez ce script."
    exit 1
  fi
  chercher_python || { echo " Python 3.12 reste introuvable apres l'installation."; exit 1; }
fi
echo " Python 3.12 utilise : $PYEXE"

if [ ! -x "$VENV/bin/python" ]; then
  mkdir -p "$(dirname "$VENV")"
  "$PYEXE" -m venv "$VENV" || { echo " La creation de l'environnement a echoue (sous Debian/Ubuntu : sudo apt install python3.12-venv)."; exit 1; }
fi
PIP="$VENV/bin/python -m pip"
$PIP install --upgrade pip
# Linux : la version de PyTorch par defaut embarque des bibliotheques graphiques (plusieurs Go) inutiles ici.
if [ "$SYSTEME" = "Linux" ]; then
  $PIP install torch --index-url https://download.pytorch.org/whl/cpu
fi
$PIP install -r "$RACINE/requirements.txt"
"$VENV/bin/python" -m spacy download fr_core_news_lg
"$VENV/bin/python" -m spacy download en_core_web_lg

# Reconnaissance de caracteres (OCR) pour les PDF scannes : facultative
if ! command -v tesseract >/dev/null 2>&1 && [ ! -x /opt/homebrew/bin/tesseract ]; then
  echo
  if [ "$SYSTEME" = "Darwin" ] && command -v brew >/dev/null 2>&1; then
    demander "Installer Tesseract (OCR des PDF scannes) avec Homebrew ?" && brew install tesseract tesseract-lang || true
  elif command -v apt-get >/dev/null 2>&1; then
    demander "Installer Tesseract (OCR des PDF scannes) avec apt ?" && \
      sudo apt-get install -y tesseract-ocr tesseract-ocr-fra tesseract-ocr-eng || true
  else
    echo " Tesseract (OCR des PDF scannes) n'est pas installe : installez-le avec votre gestionnaire de paquets si besoin."
  fi
fi

cd "$RACINE"
"$VENV/bin/python" -m anonymiseur --telecharger-modeles
echo
echo " Installation terminee."
