"""Lecture des fichiers PDF (texte, ou reconnaissance de caractères pour les pages scannées) et écriture du texte
anonymisé dans le format choisi (Word, PowerPoint, Markdown, texte, HTML, Excel).

Un PDF n'est pas modifié sur place : sa mise en page ne se prête pas au remplacement de texte. Sine Nomine en extrait le
texte, par page et par paragraphe, l'anonymise, puis l'écrit dans un nouveau fichier ; les images, tableaux et mises en
page ne sont pas repris, ce qui est signalé dans le rapport. Les métadonnées du PDF (auteur, titre…) ne sont pas copiées.

Tout se passe sur l'ordinateur : pypdf lit le texte, pypdfium2 dessine les pages scannées, Tesseract (installé à part,
voir installer.bat) les lit. Aucune connexion n'est faite.
"""

import html
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

FORMATS_SORTIE = ("docx", "pptx", "md", "txt", "html", "xlsx")
FORMAT_DEFAUT = "docx"
SEUIL_PAGE_SCANNEE = 25         # une page de moins de 25 caractères de texte est lue par OCR (si elle contient une image)
RACINE = Path(__file__).resolve().parent.parent
LANGUES_OCR_DEFAUT = "fra+eng"
RE_PONCTUATION_FINALE = re.compile(r"[.!?:;…»)\]]\s*$")


@dataclass
class ContenuPdf:
    pages: list = field(default_factory=list)          # [[paragraphe, …], …] : une liste de paragraphes par page
    avertissements: list = field(default_factory=list)
    pages_ocr: int = 0

    @property
    def texte(self):
        return "\n".join(p for page in self.pages for p in page)


class PdfIllisible(Exception):
    pass


# ---------------------------------------------------------------- reconnaissance de caractères (Tesseract)

def trouver_tesseract(config=None):
    """Chemin de tesseract.exe, ou None s'il n'est pas installé."""
    voulu = ((config or {}).get("ocr") or {}).get("tesseract") or ""
    candidats = [voulu, shutil.which("tesseract") or ""]
    for variable in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        base = os.environ.get(variable)
        if base:
            candidats += [str(Path(base) / "Tesseract-OCR" / "tesseract.exe"),
                          str(Path(base) / "Programs" / "Tesseract-OCR" / "tesseract.exe")]
    # macOS (Homebrew) et Linux : un programme lancé depuis le bureau n'a pas toujours le PATH du terminal
    candidats += ["/opt/homebrew/bin/tesseract", "/usr/local/bin/tesseract", "/usr/bin/tesseract"]
    return next((c for c in candidats if c and Path(c).is_file()), None)


def dossier_donnees_ocr():
    """Dossier des données de langue téléchargées par installer.bat (outils/tessdata), s'il existe."""
    dossier = RACINE / "outils" / "tessdata"
    return dossier if dossier.is_dir() and any(dossier.glob("*.traineddata")) else None


def langues_ocr(config, tesseract):
    """Langues demandées (réglage `ocr.langues`) qui sont réellement installées, jointes par « + »."""
    demandees = [l for l in (((config or {}).get("ocr") or {}).get("langues") or LANGUES_OCR_DEFAUT).split("+") if l]
    commande = [tesseract, "--list-langs"]
    donnees = dossier_donnees_ocr()
    if donnees:
        commande += ["--tessdata-dir", str(donnees)]
    try:
        sortie = subprocess.run(commande, capture_output=True, text=True, timeout=30, **_sans_fenetre()).stdout
    except (OSError, subprocess.SubprocessError):
        return ""
    installees = {l.strip() for l in sortie.splitlines()[1:] if l.strip()}
    return "+".join(l for l in demandees if l in installees)


def _sans_fenetre():
    """Sous Windows, évite qu'une fenêtre noire s'ouvre à chaque appel de Tesseract."""
    return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}


def etat_ocr(config=None):
    """{disponible, langues, message} : ce que l'utilisateur doit savoir pour les PDF scannés."""
    config = _CONFIG if config is None else config
    reglage = ((config or {}).get("ocr") or {})
    if reglage.get("actif", True) is False:
        return {"disponible": False, "langues": "", "message": "La reconnaissance de caractères est désactivée (config.json)."}
    exe = trouver_tesseract(config)
    if not exe:
        return {"disponible": False, "langues": "",
                "message": "Tesseract n'est pas installé : les PDF scannés (images sans texte) ne pourront pas être lus. "
                           "Relancez installer.bat pour l'installer."}
    langues = langues_ocr(config, exe)
    if not langues:
        return {"disponible": False, "langues": "",
                "message": "Tesseract est installé, mais sans données de langue (français, anglais) : relancez installer.bat."}
    return {"disponible": True, "langues": langues, "message": ""}


def _ocr_page(page_pdfium, exe, langues, echelle=300 / 72):
    """Texte d'une page dessinée en image et lue par Tesseract."""
    image = page_pdfium.render(scale=echelle).to_pil().convert("L")
    with tempfile.TemporaryDirectory(prefix="sn-ocr-") as dossier:
        fichier = Path(dossier) / "page.png"
        image.save(fichier)
        commande = [exe, str(fichier), "stdout", "-l", langues, "--psm", "3"]
        donnees = dossier_donnees_ocr()
        if donnees:
            commande += ["--tessdata-dir", str(donnees)]
        resultat = subprocess.run(commande, capture_output=True, timeout=300, **_sans_fenetre())
        if resultat.returncode != 0:
            raise PdfIllisible("Tesseract a échoué : " + resultat.stderr.decode("utf-8", "replace").strip()[:200])
        return resultat.stdout.decode("utf-8", "replace")


# ---------------------------------------------------------------- texte

def paragraphes(texte):
    """Découpe le texte d'une page en paragraphes : les lignes d'une même phrase sont recollées
    (« Jean\\nDupont » redevient « Jean Dupont »), les césures de fin de ligne sont supprimées."""
    resultat = []
    for bloc in re.split(r"\n\s*\n", texte.replace("\r", "")):
        courant = ""
        for ligne in (l.strip() for l in bloc.split("\n")):
            if not ligne:
                continue
            if not courant:
                courant = ligne
            elif courant.endswith("-") and ligne[:1].islower() and len(courant) > 1 and courant[-2].isalpha():
                courant = courant[:-1] + ligne                      # césure : « informa- tion »
            elif RE_PONCTUATION_FINALE.search(courant) and ligne[:1].isupper() and len(courant) < 60:
                resultat.append(courant)                             # ligne courte finie par un point : titre ou fin de paragraphe
                courant = ligne
            else:
                courant += " " + ligne
        if courant:
            resultat.append(courant)
    return [re.sub(r"[ \t ]+", " ", p).strip() for p in resultat if p.strip()]


_CACHE = {}
_CONFIG = {}


def configurer(config):
    """Réglages de config.json (section `ocr`) utilisés pour toutes les lectures de PDF."""
    _CONFIG.clear()
    _CONFIG.update(config or {})


def lire(chemin, config=None, progression=None):
    """Contenu du PDF, par page. Résultat mis en mémoire (la même lecture sert à la détection puis à l'écriture)."""
    chemin = Path(chemin)
    config = _CONFIG if config is None else config
    cle = (str(chemin), chemin.stat().st_mtime_ns)
    if cle in _CACHE:
        return _CACHE[cle]
    try:
        from pypdf import PdfReader
        from pypdf.errors import PdfReadError
    except ImportError as e:
        raise PdfIllisible("La lecture des PDF demande la bibliothèque pypdf : relancez installer.bat.") from e
    try:
        lecteur = PdfReader(str(chemin))
        if lecteur.is_encrypted and not lecteur.decrypt(""):
            raise PdfIllisible("PDF protégé par un mot de passe : retirez la protection avant de le traiter.")
        pages_pdf = list(lecteur.pages)
    except PdfReadError as e:
        raise PdfIllisible(f"PDF illisible ou endommagé ({e}).") from e

    contenu = ContenuPdf()
    ocr = etat_ocr(config)
    exe = trouver_tesseract(config) if ocr["disponible"] else None
    document = None
    sans_texte = 0
    total = len(pages_pdf)
    for numero, page in enumerate(pages_pdf, start=1):
        if progression:
            progression(numero, total)
        try:
            texte = page.extract_text() or ""
        except Exception:  # noqa: BLE001 — une page défectueuse ne doit pas arrêter tout le document
            texte = ""
        if len(texte.strip()) < SEUIL_PAGE_SCANNEE:
            try:
                a_une_image = bool(len(page.images))
            except Exception:  # noqa: BLE001
                a_une_image = True
            if a_une_image or not texte.strip():
                if exe:
                    try:
                        if document is None:
                            import pypdfium2
                            document = pypdfium2.PdfDocument(str(chemin))
                        texte = _ocr_page(document[numero - 1], exe, ocr["langues"])
                        contenu.pages_ocr += 1
                    except PdfIllisible:
                        raise
                    except Exception as e:  # noqa: BLE001
                        contenu.avertissements.append(f"Page {numero} : lecture par OCR impossible ({type(e).__name__}).")
                        texte = ""
                elif a_une_image and not texte.strip():
                    sans_texte += 1
        contenu.pages.append(paragraphes(texte))
    if document is not None:
        document.close()
    if sans_texte:
        contenu.avertissements.append(
            f"{sans_texte} page(s) sans texte (document scanné ?) non lue(s) : {ocr['message']}")
    if contenu.pages_ocr:
        contenu.avertissements.append(
            f"{contenu.pages_ocr} page(s) lue(s) par reconnaissance de caractères (OCR) : le texte peut contenir des "
            "erreurs, surtout sur les noms propres. Relisez attentivement la validation et le résultat.")
    if not contenu.texte.strip():
        contenu.avertissements.append("Aucun texte n'a pu être extrait de ce PDF.")
    contenu.avertissements.append(
        "PDF : le résultat est un nouveau fichier de texte seul. Les images, tableaux et la mise en page d'origine ne sont "
        "pas repris, et les métadonnées du PDF (auteur, titre…) ne sont pas copiées.")
    if len(_CACHE) >= 8:
        _CACHE.pop(next(iter(_CACHE)))
    _CACHE[cle] = contenu
    return contenu


def oublier():
    """Vide la mémoire des PDF lus (anonymisation irréversible : plus rien du texte d'origine ne doit rester)."""
    _CACHE.clear()


# ---------------------------------------------------------------- écriture

def ecrire(pages, destination):
    """Écrit les pages (listes de paragraphes déjà anonymisés) au format de l'extension de `destination`."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    format_ = destination.suffix.lower().lstrip(".")
    {"docx": _ecrire_docx, "pptx": _ecrire_pptx, "md": _ecrire_md, "txt": _ecrire_txt,
     "html": _ecrire_html, "xlsx": _ecrire_xlsx}[format_](pages, destination)


def _ecrire_txt(pages, destination):
    blocs = []
    for numero, page in enumerate(pages, start=1):
        blocs.append(f"--- Page {numero} ---\n\n" + "\n\n".join(page))
    destination.write_text("\n\n".join(blocs) + "\n", encoding="utf-8")


def _ecrire_md(pages, destination):
    blocs = []
    for numero, page in enumerate(pages, start=1):
        blocs.append(f"## Page {numero}\n\n" + "\n\n".join(p.replace("\\", "\\\\") for p in page))
    destination.write_text("\n\n".join(blocs) + "\n", encoding="utf-8")


def _ecrire_html(pages, destination):
    corps = []
    for numero, page in enumerate(pages, start=1):
        corps.append(f"<h2>Page {numero}</h2>\n" + "\n".join(f"<p>{html.escape(p)}</p>" for p in page))
    destination.write_text(
        "<!DOCTYPE html>\n<html lang=\"fr\"><head><meta charset=\"utf-8\"><title>Document anonymisé</title></head>\n<body>\n"
        + "\n".join(corps) + "\n</body></html>\n", encoding="utf-8")


def _texte_xml_valide(texte):
    """Retire les caractères de contrôle que XML (donc Word, PowerPoint, Excel) n'accepte pas."""
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]", "", texte)


def _ecrire_docx(pages, destination):
    from docx import Document
    document = Document()
    proprietes = document.core_properties
    proprietes.author = proprietes.last_modified_by = ""
    proprietes.title = proprietes.comments = ""
    proprietes.created = proprietes.modified = datetime.now()
    for numero, page in enumerate(pages, start=1):
        if numero > 1:
            document.add_page_break()
        document.add_heading(f"Page {numero}", level=2)
        for p in page:
            document.add_paragraph(_texte_xml_valide(p))
    document.save(str(destination))


def _ecrire_pptx(pages, destination, par_diapositive=1400):
    """Une diapositive par page du PDF ; une page longue est répartie sur plusieurs diapositives."""
    from pptx import Presentation
    from pptx.util import Emu, Pt
    presentation = Presentation()
    presentation.core_properties.author = presentation.core_properties.last_modified_by = ""
    presentation.core_properties.title = presentation.core_properties.comments = ""
    presentation.core_properties.created = presentation.core_properties.modified = datetime.now()
    gabarit = presentation.slide_layouts[5]                # titre seul
    largeur, hauteur = presentation.slide_width, presentation.slide_height
    for numero, page in enumerate(pages, start=1):
        groupes, courant, taille = [], [], 0
        for p in page or [""]:
            if courant and taille + len(p) > par_diapositive:
                groupes.append(courant)
                courant, taille = [], 0
            courant.append(p)
            taille += len(p)
        groupes.append(courant)
        for rang, groupe in enumerate(groupes, start=1):
            diapositive = presentation.slides.add_slide(gabarit)
            diapositive.shapes.title.text = f"Page {numero}" + (f" ({rang}/{len(groupes)})" if len(groupes) > 1 else "")
            zone = diapositive.shapes.add_textbox(Emu(int(largeur * 0.06)), Emu(int(hauteur * 0.24)),
                                                  Emu(int(largeur * 0.88)), Emu(int(hauteur * 0.68)))
            cadre = zone.text_frame
            cadre.word_wrap = True
            for i, p in enumerate(groupe):
                paragraphe = cadre.paragraphs[0] if i == 0 else cadre.add_paragraph()
                paragraphe.text = _texte_xml_valide(p)
                paragraphe.font.size = Pt(14)
    presentation.save(str(destination))


def _ecrire_xlsx(pages, destination):
    from openpyxl import Workbook
    classeur = Workbook()
    feuille = classeur.active
    feuille.title = "Texte"
    feuille.append(["Page", "Texte"])
    for numero, page in enumerate(pages, start=1):
        for p in page:
            feuille.append([numero, _texte_xml_valide(p)])
    feuille.column_dimensions["A"].width = 8
    feuille.column_dimensions["B"].width = 120
    classeur.properties.creator = classeur.properties.lastModifiedBy = ""
    classeur.save(str(destination))
