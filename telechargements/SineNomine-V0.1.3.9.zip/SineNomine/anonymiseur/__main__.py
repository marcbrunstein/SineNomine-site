"""Lancement : python -m anonymiseur [--port N] [--sans-navigateur] [--sans-gliner] [--telecharger-modeles]

Lancé avec pythonw.exe (raccourci du Bureau), il n'y a pas de console : les messages
vont dans %LOCALAPPDATA%\\SineNomine\\sine-nomine.log, et on arrête Sine Nomine avec
le bouton « Quitter » de l'interface.
"""

import argparse
import json
import os
import socket
import sys
import threading
import urllib.request
import warnings
import webbrowser
from pathlib import Path

# Avertissements des bibliothèques d'IA sans effet sur le résultat : ils ressemblent à des erreurs dans la console.
warnings.filterwarnings("ignore", message=".*torch.jit.script.*is deprecated")
warnings.filterwarnings("ignore", message=".*resume_download.*")

from . import VERSION, config as cfg
from .detection import Modeles

def _dossier_journal():
    """Windows : dossier LocalAppData de l'utilisateur ; macOS : ~/Library/Logs/SineNomine ; Linux : ~/.local/state/SineNomine."""
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SineNomine"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Logs" / "SineNomine"
    return Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / "SineNomine"


JOURNAL = _dossier_journal() / "sine-nomine.log"


def port_libre(depart):
    for port in range(depart, depart + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise RuntimeError("Aucun port libre trouvé.")


def instance_existante(port):
    """Vrai si Sine Nomine tourne déjà sur ce port."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/etat", timeout=2) as reponse:
            return "version" in json.load(reponse)
    except (OSError, ValueError):
        return False


def sans_console():
    """Sous pythonw.exe, sys.stdout est absent : on écrit dans un journal."""
    if sys.stdout is None or sys.stderr is None:
        JOURNAL.parent.mkdir(parents=True, exist_ok=True)
        # Ajout plutôt qu'écrasement (plusieurs lancements possibles), remis à zéro au-delà de 2 Mo.
        mode = "w" if JOURNAL.exists() and JOURNAL.stat().st_size > 2 * 1024**2 else "a"
        flux = open(JOURNAL, mode, encoding="utf-8", buffering=1)  # noqa: SIM115 — ouvert pour toute la session
        sys.stdout = sys.stderr = flux
        return True
    return False


def main():
    parser = argparse.ArgumentParser(prog="sine-nomine", description="Sine Nomine — anonymiseur local")
    parser.add_argument("--port", type=int)
    parser.add_argument("--sans-navigateur", action="store_true")
    parser.add_argument("--sans-gliner", action="store_true",
                        help="Démarrage plus rapide, sans le modèle GLiNER (produits par dictionnaire seulement).")
    parser.add_argument("--telecharger-modeles", action="store_true",
                        help="Télécharge et vérifie les modèles, puis quitte.")
    args = parser.parse_args()

    if not args.telecharger_modeles:
        # Hors ligne : les modèles installés se chargent sans contacter Hugging Face (vérifié), de sorte que
        # Sine Nomine n'établit aucune connexion Internet. Seul --telecharger-modeles (installer.bat) se connecte.
        os.environ.setdefault("HF_HUB_OFFLINE", "1")
        os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    config = cfg.charger()
    if args.sans_gliner:
        config["gliner"]["actif"] = False
    port_demande = args.port or config["port"]
    if not args.telecharger_modeles and instance_existante(port_demande):
        # Déjà lancé (double-clic répété sur le raccourci) : on rouvre simplement l'interface.
        if not args.sans_navigateur:
            webbrowser.open(f"http://127.0.0.1:{port_demande}/")
        return

    silencieux = sans_console()
    modeles = Modeles(config)
    if args.telecharger_modeles:
        modeles._charger()
        for erreur in modeles.erreurs:
            print("ERREUR :", erreur)
        print("Modèles :", modeles.etat)
        raise SystemExit(0 if modeles.nlp is not None else 1)

    modeles.charger_en_arriere_plan()
    from waitress import serve
    from .serveur import creer_application

    port = port_libre(port_demande)
    adresse = f"http://127.0.0.1:{port}/"
    print(f"Sine Nomine {VERSION} — interface : {adresse}")
    if silencieux:
        print("Lancé sans console : utilisez le bouton « Quitter » de l'interface pour arrêter Sine Nomine.")
    else:
        print("Laissez cette fenêtre ouverte pendant l'utilisation. Fermez-la pour arrêter Sine Nomine.")
    if not args.sans_navigateur:
        threading.Timer(1.5, webbrowser.open, args=(adresse,)).start()
    serve(creer_application(config, modeles), host="127.0.0.1", port=port, threads=8,
          max_request_body_size=2 * 1024**3)


if __name__ == "__main__":
    main()
