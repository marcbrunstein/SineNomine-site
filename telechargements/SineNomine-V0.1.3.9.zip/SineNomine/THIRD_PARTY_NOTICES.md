# Licences tierces

Sine Nomine (© 2026 Habeas Corpus Consulting, marque de Habeas Corpus S.A.S.) s'appuie sur des composants libres.
Ils **ne sont pas redistribués avec Sine Nomine** : `installer.bat` les télécharge depuis leurs sources officielles
(PyPI, spaCy, Hugging Face). Chacun reste soumis à sa propre licence, dont le texte accompagne son installation
(dossier `Lib\site-packages\<paquet>-<version>.dist-info\` de l'environnement `%USERPROFILE%\.venvs\sine-nomine`).

Relevé effectué le 5 novembre 2026 sur les versions installées, à partir des métadonnées des paquets et des fiches
officielles des modèles. À refaire après une mise à jour des composants.

## Bibliothèques

| Composant | Version | Licence | Usage dans Sine Nomine |
|---|---|---|---|
| spaCy | 3.8.18 | MIT | Détection des personnes, sociétés et lieux |
| GLiNER | 0.2.30 | Apache-2.0 | Détection des produits, marques, villes et pays |
| Flask | 3.1.3 | BSD-3-Clause | Interface web locale |
| waitress | 3.0.2 | ZPL-2.1 | Serveur local (127.0.0.1) |
| lxml | 6.1.3 | BSD-3-Clause | Lecture et écriture des fichiers Word, PowerPoint, Excel |
| openpyxl | 3.1.5 | MIT | Rapport et table de correspondance Excel |
| python-docx | 1.2.0 | MIT | Écriture des Word produits à partir d'un PDF ; tests |
| pypdf | 7.0.0 | BSD-3-Clause | Lecture du texte des PDF |
| pypdfium2 | 5.15.1 | BSD-3-Clause et Apache-2.0 (avec PDFium : BSD-3-Clause) | Dessin des pages de PDF scannés pour l'OCR |
| Tesseract OCR (programme séparé, installé par winget) | — | Apache-2.0 | Reconnaissance de caractères des PDF scannés. Données de langue `tessdata_fast` (fra, eng) : Apache-2.0, téléchargées par installer.bat dans `outils/tessdata` |
| python-pptx | 1.0.2 | MIT | Écriture des PowerPoint produits à partir d'un PDF ; tests |
| Pillow | 13.0.0 | MIT-CMU | Miniatures des images |
| protobuf | — | voir ses métadonnées d'installation | Dépendance de GLiNER |

Composants indirects installés avec GLiNER : PyTorch 2.15.0 (ensemble de licences BSD et Apache-2.0 : voir ses
métadonnées), Transformers 5.22.1 (Apache-2.0), huggingface_hub 2.4.0 (Apache-2.0), SentencePiece 0.2.3 (Apache-2.0).

## Modèles de détection

| Modèle | Licence | Remarque |
|---|---|---|
| `fr_core_news_lg` 3.8.0 (spaCy) | LGPL-LR | Licence copyleft propre à la ressource linguistique. Sources d'entraînement citées par spaCy : UD French Sequoia, WikiNER, données « lookups » de spaCy, vecteurs fastText d'Explosion. Voir la fiche du modèle et ses notes de version : <https://github.com/explosion/spacy-models/releases/tag/fr_core_news_lg-3.8.0> |
| `en_core_web_lg` 3.8.0 (spaCy) | MIT (métadonnées du paquet) | Modèle anglais. Les données d'entraînement (OntoNotes, GloVe, etc.) ont leurs propres conditions : voir la fiche <https://github.com/explosion/spacy-models/releases/tag/en_core_web_lg-3.8.0> |
| `urchade/gliner_multi-v2.1` | Apache-2.0 | Fiche : <https://huggingface.co/urchade/gliner_multi-v2.1>. Attention : la version antérieure `gliner_multi` est sous licence non commerciale (CC BY-NC 4.0) et ne doit pas être utilisée à sa place |
| `microsoft/mdeberta-v3-base` | MIT | Modèle de base utilisé par GLiNER. Fiche : <https://huggingface.co/microsoft/mdeberta-v3-base> |

## Remarque

Cette liste est fournie à titre d'information et ne modifie pas les licences de ces composants. Pour toute question :
contact@hcorpus.com.

## Mentions d'attribution et vérification des licences (14/11/2026)

Les licences ci-dessus ont été relevées dans les métadonnées des paquets installés et dans les fiches des modèles. Aucune
bibliothèque Python installée n'est sous licence GPL ou AGPL ; certifi et tqdm sont sous MPL-2.0 (copyleft limité aux
fichiers modifiés, non modifiés ici). Sine Nomine ne redistribue ni ces bibliothèques ni ces modèles : l'installation les
télécharge depuis leurs sources (PyPI, Hugging Face, spaCy). Si une version future les inclut dans l'installateur, leurs
textes de licence devront être joints.

- **fr_core_news_lg** (LGPL-LR) : entraîné sur UD French Sequoia (LGPL-LR), WikiNER (CC BY 4.0, Joel Nothman, Nicky
  Ringland, Will Radford, Tara Murphy, James R. Curran), les données « lookups » de spaCy (MIT) et des vecteurs
  fastText d'Explosion (CC0).
- **en_core_web_lg** (MIT) : entraîné sur OntoNotes 5 (licence commerciale détenue par Explosion), WordNet 3.0
  (licence WordNet, Princeton University) et des vecteurs d'Explosion (CC0).
- **urchade/gliner_multi-v2.1** (Apache-2.0) : entraîné sur le jeu de données synthétique `urchade/pile-mistral-v0.1`.
- **microsoft/mdeberta-v3-base** (MIT).

