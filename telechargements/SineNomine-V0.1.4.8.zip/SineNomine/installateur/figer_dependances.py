"""Fige les dépendances (directes ET transitives) et produit l'inventaire des composants (SBOM CycloneDX 1.5).

Lancement, depuis la racine, avec l'environnement Python qui contient les versions à figer :
    python installateur/figer_dependances.py

Écrit :
  requirements.lock       versions exactes de toutes les dépendances de requirements.txt (fermeture transitive) et des modèles spaCy
  docs/SBOM.cdx.json      inventaire CycloneDX : bibliothèques (version, licence déclarée), modèles (révision), composants externes

Ce qui n'est PAS fait ici (documenté dans docs/INSTALLATION.md) : empreintes (hash) des roues Python, empreinte des modèles téléchargés.
La licence de chaque composant est celle que son paquet DÉCLARE ; elle n'a pas fait l'objet d'une revue juridique.
"""

import json
import re
import sys
from importlib import metadata
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RACINE))
from anonymiseur import VERSION  # noqa: E402

MODELES_SPACY = {"fr_core_news_lg": "LGPL-LR", "en_core_web_lg": "MIT"}
URL_MODELE = "https://github.com/explosion/spacy-models/releases/download/{n}-{v}/{n}-{v}-py3-none-any.whl"


def nom_normalise(nom):
    return re.sub(r"[-_.]+", "-", nom).lower()


def exigences_directes():
    noms = []
    for ligne in (RACINE / "requirements.txt").read_text(encoding="utf-8").splitlines():
        ligne = ligne.split("#")[0].strip()
        if ligne:
            noms.append(nom_normalise(re.split(r"[<>=!~\[ ;]", ligne)[0]))
    return noms


def fermeture(racines):
    """Ensemble des distributions installées atteintes depuis `racines` (dépendances obligatoires, hors extras)."""
    installees = {nom_normalise(d.metadata["Name"]): d for d in metadata.distributions() if d.metadata["Name"]}
    vus, pile = {}, list(racines)
    while pile:
        nom = pile.pop()
        if nom in vus or nom not in installees:
            continue
        vus[nom] = installees[nom]
        for exigence in installees[nom].requires or []:
            if "extra ==" in exigence:
                continue
            marqueur = exigence.split(";", 1)[1] if ";" in exigence else ""
            if marqueur and "sys_platform" in marqueur and "win32" not in marqueur and "!= " not in marqueur.replace("!=", "!= "):
                pass
            pile.append(nom_normalise(re.split(r"[<>=!~\[ ;(]", exigence.strip())[0]))
    return vus


def licence(distribution):
    m = distribution.metadata
    expression = m.get("License-Expression")
    if expression:
        return expression
    texte = (m.get("License") or "").strip()
    if texte and len(texte) < 80 and "\n" not in texte:
        return texte
    classes = [c.split("::")[-1].strip() for c in (m.get_all("Classifier") or []) if c.startswith("License ::")]
    return " ; ".join(classes) or "non déclarée (voir les métadonnées du paquet)"


def main():
    modeles_installes = {n: metadata.version(n.replace("_", "-")) for n in MODELES_SPACY if _present(n)}
    vus = fermeture(exigences_directes())
    lignes = ["# Versions exactes (dépendances directes et transitives), générées par installateur/figer_dependances.py.",
              f"# Sine Nomine {VERSION}. À régénérer après toute mise à jour, puis à retester.", ""]
    for nom in sorted(vus):
        if nom in {nom_normalise(n) for n in MODELES_SPACY}:
            continue
        lignes.append(f"{vus[nom].metadata['Name']}=={vus[nom].version}")
    lignes += ["", "# Modèles spaCy (révisions figées ; aucune empreinte vérifiée automatiquement)"]
    for nom, version in sorted(modeles_installes.items()):
        lignes.append(f"{nom} @ {URL_MODELE.format(n=nom, v=version)}")
    (RACINE / "requirements.lock").write_text("\n".join(lignes) + "\n", encoding="utf-8")

    config = json.loads((RACINE / "config.json").read_text(encoding="utf-8"))
    composants = [{"type": "library", "name": vus[n].metadata["Name"], "version": vus[n].version,
                   "purl": f"pkg:pypi/{n}@{vus[n].version}", "licenses": [{"license": {"name": licence(vus[n])}}]} for n in sorted(vus)
                  if n not in {nom_normalise(m) for m in MODELES_SPACY}]
    for nom, version in sorted(modeles_installes.items()):
        composants.append({"type": "machine-learning-model", "name": nom, "version": version, "licenses": [{"license": {"name": MODELES_SPACY[nom]}}],
                           "externalReferences": [{"type": "distribution", "url": URL_MODELE.format(n=nom, v=version)}]})
    composants += [
        {"type": "machine-learning-model", "name": config["gliner"]["modele"], "version": config["gliner"].get("revision") or "non figée",
         "licenses": [{"license": {"id": "Apache-2.0"}}], "externalReferences": [{"type": "website", "url": "https://huggingface.co/" + config["gliner"]["modele"]}]},
        {"type": "machine-learning-model", "name": "microsoft/mdeberta-v3-base", "version": "voir GLiNER", "licenses": [{"license": {"id": "MIT"}}]},
        {"type": "application", "name": "Tesseract OCR (composant externe, installé par winget)", "licenses": [{"license": {"id": "Apache-2.0"}}],
         "description": "Facultatif. Données de langue tessdata_fast (fra, eng), Apache-2.0."},
        {"type": "application", "name": "LibreOffice (composant externe facultatif, non fourni)", "licenses": [{"license": {"id": "MPL-2.0"}}],
         "description": "Conversion PDF locale, détecté s'il est installé."},
        {"type": "data", "name": "Liste de mots latins des codes d'activation (serveur de licences)", "licenses": [{"license": {"name": "Rédigée par Habeas Corpus, sans licence tierce"}}]},
    ]
    sbom = {"bomFormat": "CycloneDX", "specVersion": "1.5", "version": 1,
            "metadata": {"component": {"type": "application", "name": "Sine Nomine", "version": VERSION,
                                       "supplier": {"name": "Habeas Corpus"}},
                         "properties": [{"name": "avertissement", "value": "Licences telles que déclarées par les paquets ; pas de revue juridique."}]},
            "components": composants}
    (RACINE / "docs").mkdir(exist_ok=True)
    (RACINE / "docs" / "SBOM.cdx.json").write_text(json.dumps(sbom, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"requirements.lock : {len(vus)} paquets ; docs/SBOM.cdx.json : {len(composants)} composants")


def _present(nom):
    try:
        metadata.version(nom.replace("_", "-"))
        return True
    except metadata.PackageNotFoundError:
        return False


if __name__ == "__main__":
    main()
