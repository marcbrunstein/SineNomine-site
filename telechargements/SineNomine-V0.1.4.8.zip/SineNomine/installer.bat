@echo off
rem Sine Nomine - installation de l environnement Python local
setlocal
rem Environnement Python : dans le dossier de Sine Nomine (nouvelles installations), ou celui des anciennes installations
set "VENV=%~dp0environnement"
if not exist "%~dp0environnement\Scripts\python.exe" if exist "%USERPROFILE%\.venvs\sine-nomine\Scripts\python.exe" set "VENV=%USERPROFILE%\.venvs\sine-nomine"
set PYTHONDONTWRITEBYTECODE=1
set "PYEXE="
echo.
echo  Installation de Sine Nomine (bibliotheques et modeles, environ 2 Go)...
echo.

call :chercher_python
if defined PYEXE goto python_trouve

echo  Python 3.12 est introuvable sur ce PC.
echo  Sine Nomine a besoin de Python 3.12 : les versions plus recentes ne sont pas compatibles avec spaCy.
echo.
choice /c ON /m " Installer Python 3.12 maintenant avec winget (O = oui, N = non)"
if errorlevel 2 (
  echo.
  echo  Installation annulee. Pour l installer plus tard : winget install Python.Python.3.12
  pause
  exit /b 1
)
winget install --id Python.Python.3.12 -e --accept-package-agreements --accept-source-agreements
call :chercher_python
if defined PYEXE goto python_trouve
echo.
echo  Python 3.12 est installe, mais pas encore detecte par cette fenetre.
echo  Fermez cette fenetre puis relancez installer.bat.
pause
exit /b 1

:python_trouve
echo  Python 3.12 utilise : %PYEXE%
echo.
if exist "%VENV%\Scripts\python.exe" goto venv_present
"%PYEXE%" -m venv "%VENV%"
if not exist "%VENV%\Scripts\python.exe" (
  echo  La creation de l environnement a echoue.
  pause
  exit /b 1
)
:venv_present
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip
rem Versions figees (requirements.lock : dependances directes et transitives, modeles spaCy a revision fixe) ; repli sur requirements.txt
if exist "%~dp0requirements.lock" (
  "%VENV%\Scripts\python.exe" -m pip install -r "%~dp0requirements.lock" || goto erreur
) else (
  "%VENV%\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt" || goto erreur
  "%VENV%\Scripts\python.exe" -m spacy download fr_core_news_lg || goto erreur
  "%VENV%\Scripts\python.exe" -m spacy download en_core_web_lg || goto erreur
)
call :ocr
pushd "%~dp0"
rem Telechargement explicite des modeles (seule etape avec acces reseau pour les modeles) ; code de sortie non nul si un composant manque (spaCy, GLiNER)
"%VENV%\Scripts\python.exe" -m anonymiseur --telecharger-modeles
if errorlevel 1 (
  popd
  goto erreur
)
popd
call :activation
echo.
echo  Installation terminee.
if not defined SN_INSTALLATEUR pause
exit /b 0

:ocr
rem Reconnaissance de caracteres (OCR) pour les PDF scannes : facultative, un echec ici n arrete pas l installation
echo.
echo  Reconnaissance de caracteres (OCR) pour les PDF scannes : installation de Tesseract...
set "TESS="
where tesseract >nul 2>nul && set "TESS=1"
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" set "TESS=1"
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESS=1"
if not defined TESS winget install --id UB-Mannheim.TesseractOCR -e --accept-package-agreements --accept-source-agreements
if not exist "%~dp0outils\tessdata" mkdir "%~dp0outils\tessdata"
for %%L in (fra eng) do if not exist "%~dp0outils\tessdata\%%L.traineddata" powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -Uri https://github.com/tesseract-ocr/tessdata_fast/raw/main/%%L.traineddata -OutFile '%~dp0outils\tessdata\%%L.traineddata' } catch { Write-Host 'Telechargement impossible : %%L' }"
if not exist "%~dp0outils\tessdata\fra.traineddata" echo  Attention : les donnees de langue francaise de l OCR n ont pas ete telechargees. Relancez installer.bat avec internet.
exit /b 0

:activation
rem Activation de la licence d evaluation : cle fournie par l installateur Windows (cle.tmp : cle et langue) ou saisie ici
if exist "%~dp0licence.json" exit /b 0
set "CLE="
set "LANGUE=fr"
if exist "%~dp0cle.tmp" (
  for /f "usebackq tokens=1,2" %%a in ("%~dp0cle.tmp") do (
    set "CLE=%%a"
    set "LANGUE=%%b"
  )
  del "%~dp0cle.tmp"
)
pushd "%~dp0"
echo.
echo  Activation de Sine Nomine (connexion Internet necessaire)...
if defined CLE (
  "%VENV%\Scripts\python.exe" -m anonymiseur --activer "%CLE%" --langue %LANGUE% --sortie "%~dp0activation.txt"
) else (
  "%VENV%\Scripts\python.exe" -m anonymiseur --activer --langue %LANGUE% --sortie "%~dp0activation.txt"
)
if errorlevel 1 echo  L activation n a pas abouti : relancez activer.bat avec votre cle d acces (contact@sinenomine.app).
popd
exit /b 0

:erreur
echo.
echo  L installation a echoue. Verifiez votre connexion internet puis relancez installer.bat.
pause
exit /b 1

:chercher_python
rem Renseigne PYEXE avec le chemin complet de python.exe 3.12, ou le laisse vide.
where py >nul 2>nul
if %errorlevel%==0 (
  for /f "delims=" %%i in ('py -3.12 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
)
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
exit /b 0
