# Évaluation de la détection (état réel et méthode)

**État : aucune mesure de précision ni de rappel n'a été réalisée ni publiée.** Les tests automatisés (`tests/`) sont **fonctionnels** : ils vérifient que le code se comporte comme documenté sur des
documents synthétiques ; ils ne mesurent **pas** la qualité de détection. Aucun score n'est donné ici, et il n'en sera pas inventé.

## Ce qui n'existe pas encore
Le corpus synthétique annoté de 200 documents (français et anglais d'abord) décidé avec l'éditeur n'est pas construit. Un corpus synthétique ne serait de toute façon pas représentatif de tous les clients.

## Méthode proposée
1. **Corpus** : documents synthétiques annotés (catégorie, empan, identité de regroupement), par langue et par format ; pour un corpus **métier**, uniquement s'il est légalement utilisable (accord, base légale, pseudonymisation préalable), jamais copié hors de la machine.
2. **Mesure** : précision et rappel **par catégorie, langue et format** ; erreurs de regroupement (identités fusionnées à tort, scindées à tort) ; **OCR séparément** (taux d'erreur de caractères) ; restauration (aller-retour exact) ;
   performances (temps, mémoire) sur des tailles croissantes.
3. **Reproductibilité** : versions figées (`requirements.lock`), révisions de modèles figées, jeu de données versionné, commande unique, rapport avec intervalle d'incertitude.
4. **Interprétation** : ne pas confondre rappel mesuré sur un corpus et garantie ; un oubli de détection reste possible : la relecture humaine demeure obligatoire.

Une fois le corpus disponible, ajouter `tests/evaluation/` (script de mesure, données, rapport) et publier les résultats **réellement obtenus** avec leurs limites.
