# Support, versions, vulnérabilités, partenaire de commercialisation

Ce document n'est pas une validation juridique : les conditions contractuelles sont à faire valider par un professionnel.

## Ce qu'achète une licence (à distinguer)
| | Contenu |
|---|---|
| **Droit d'utilisation** | licence perpétuelle ou d'évaluation (voir `serveur_activation/API_V2.md`). Une perpétuelle couvre **toutes les versions de la même série majeure** ; une nouvelle série majeure demande un nouveau code |
| **Nouvelles versions** | publiées sur le site ; mises à jour mineures de la série couverte incluses |
| **Assistance utilisateur** | **non incluse** ; peut être proposée à titre payant, séparément |
| **Signalement des défauts** | gratuit, à `contact@sinenomine.app` ; utiliser « Exporter les informations pour le support » (relu avant transmission, aucun document) |
| **Maintenance et correctifs de sécurité** | correctifs de sécurité fournis pendant **12 mois après la dernière version d'une série** |

## Signalement d'une vulnérabilité
Écrire à `contact@sinenomine.app` (objet « Vulnérabilité »), sans joindre de document réel. Accusé de réception sous 5 jours ouvrés ; divulgation coordonnée après correctif.
Aucun bug bounty n'est promis.

## Partenaire de commercialisation et d'assistance
La commercialisation et l'assistance peuvent être confiées à une société externe, qui utilise la documentation (installation, support, API de licences) et le rôle **distributeur** du service
(création de codes dans une enveloppe fixée par l'éditeur). Le partenaire n'a **jamais** accès aux coffres ni aux documents des utilisateurs : le service de licences ne les reçoit pas, et le coffre est chiffré
par un secret lié au compte Windows de l'utilisateur (récupération par la phrase de l'utilisateur seulement).

## Données traitées par le service de licences
Code, identifiant d'installation aléatoire, version, langue. Aucun document, nom, pseudonyme ou correspondance. Voir la politique de confidentialité du site.

## Documentation technique utile à une évaluation réglementaire
`docs/COFFRE.md` (chiffrement, transactions, migration), `docs/PERIMETRES.md`, `docs/VALIDATION.md`, `docs/CONTROLES.md`, `docs/PROFILS.md`, `docs/MATRICE_FORMATS.md` (limites par format),
`docs/INSTALLATION.md`, `docs/SBOM.cdx.json`, `THIRD_PARTY_NOTICES.md`. Sine Nomine ne garantit ni l'anonymat ni l'absence de données personnelles dans les résultats : l'utilisateur relit toujours.
