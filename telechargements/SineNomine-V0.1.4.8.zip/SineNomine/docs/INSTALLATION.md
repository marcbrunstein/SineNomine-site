# Installation, versions reproductibles, mise à jour, retour arrière (étape 8)

Ce document décrit ce que fait l'installation de Sine Nomine et ses limites. Il ne promet ni signature de code, ni conformité.

## 1. Quatre phases distinctes
| Phase | Réseau | Ce qui se passe |
|---|---|---|
| **Installation connectée** | oui | environnement Python, dépendances figées (`requirements.lock`), modèles spaCy à version fixe, Tesseract (winget) et données OCR |
| **Téléchargement des modèles** | oui, explicite | `python -m anonymiseur --telecharger-modeles` : télécharge GLiNER à **révision figée** (`config.json`, `gliner.revision`) ; code de sortie non nul si un composant manque |
| **Activation** | oui, une fois | `--activer` : seuls le code, un identifiant d'installation aléatoire, la version et la langue sont transmis |
| **Traitement** | **non** | hors ligne ; les variables `HF_HUB_OFFLINE`, `TRANSFORMERS_OFFLINE`, `HF_DATASETS_OFFLINE` sont **forcées à 1** (une valeur héritée de l'environnement ne rétablit pas le réseau) |

Défauts relevés dans `installer.bat` et corrigés en V0.1.4.8 : (1) GLiNER n'était pas validé : `--telecharger-modeles` réussissait même si GLiNER manquait → échec explicite
désormais ; (2) `setdefault` laissait une variable d'environnement préexistante désactiver silencieusement le mode hors ligne → réglage forcé ; (3) dépendances non figées →
`requirements.lock`. Le bloc OCR est présent (`:ocr`) et facultatif : un échec n'arrête pas l'installation.

## 2. Versions figées
`python installateur/figer_dependances.py` écrit `requirements.lock` (81 paquets : dépendances directes **et transitives**, plus les deux modèles spaCy par URL de version fixe) et
`docs/SBOM.cdx.json` (CycloneDX 1.5 : bibliothèques, modèles avec révision, Tesseract, LibreOffice facultatif, liste latine). À régénérer et retester après chaque mise à jour.
**Pas encore fait** : empreintes (hash) des roues Python (`--require-hashes`), empreintes des modèles téléchargés et des données OCR (téléchargées depuis leurs sources d'origine, sans
vérification d'empreinte automatique), figer Tesseract et LibreOffice (installés via winget / par l'utilisateur).

## 3. Prérequis, reprise, mise à jour, retour arrière, désinstallation
- **Prérequis** : Windows 10/11 64 bits, Python 3.12 (installé si absent), environ 6 Go d'espace (modèles compris), Internet pour l'installation seulement.
- **Reprise après erreur** : relancer `installer.bat` (idempotent : pip ne réinstalle pas ce qui est conforme) ; un échec de modèle ou de dépendance affiche un message et un code d'erreur.
- **Mise à jour** : installer la nouvelle version par-dessus. Le coffre est migré au besoin (`PRAGMA user_version`), jamais détruit ; faire **avant** une sauvegarde chiffrée du coffre
  (Outils → Coffre chiffré). Les données de l'utilisateur sont hors du dossier du programme (`%LOCALAPPDATA%\SineNomine`).
- **Retour arrière** : réinstaller la version précédente (l'installateur de chaque version est publié) et, si besoin, restaurer la sauvegarde du coffre faite avant la mise à jour.
  Une version ne sait pas toujours lire un coffre plus récent : ne pas revenir en arrière sans la sauvegarde.
- **Désinstallation** : retire le programme et **préserve les données** par défaut (coffre, profils, configuration). Les supprimer est une action distincte et explicite.

## 4. Signature
Le programme et l'installateur ne sont **pas signés** (aucun certificat de signature de code n'est disponible). Windows peut donc afficher un avertissement SmartScreen. Pour signer :
acquérir un certificat de signature de code (EV recommandé), puis signer `SineNomine-Setup-V<version>.exe` avec `signtool` et publier l'empreinte SHA-256 sur le site. Rien n'est annoncé comme signé tant que ce n'est pas fait.

## 5. Protocole de test sur Windows vierge (non exécuté dans cet environnement)
1. Machine virtuelle Windows 11 sans Python ni Tesseract, compte standard. 2. Exécuter `SineNomine-Setup-V<version>.exe` (connexion Internet). 3. Vérifier : raccourci, lancement, `Informations sur
l'installation de Sine Nomine` (modèles prêts, OCR, langues). 4. Couper le réseau, traiter un document synthétique (aucune connexion ne doit être tentée). 5. Activer avec un code d'essai.
6. Mettre à jour vers la version suivante, vérifier le coffre. 7. Désinstaller, vérifier que `%LOCALAPPDATA%\SineNomine` est conservé. Les tests automatisés couvrent le code, pas cette procédure.

## 6. Tests
`tests/test_installation.py` (versions figées, SBOM cohérente avec le verrou, mode hors ligne forcé, échec explicite), `tests/test_support.py` (informations pour le support).
Exécution de tous les tests avec `PYTHONUTF8=1`.
