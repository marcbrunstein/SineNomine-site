# Guide de l'utilisateur de Sine Nomine (FR)

*English version below.* Ce guide n'est pas une validation juridique ; relisez toujours les fichiers produits avant diffusion.

## Parcours
1. **Mode** : pseudonymiser (réversible, codes conservés dans le coffre chiffré) ou anonymiser (irréversible, rien n'est conservé).
2. **Profil** (facultatif) : un jeu de réglages ; vos ajustements ne valent que pour le lot.
3. **Fichiers, périmètre** (Document, Projet, Client) : un nom garde son pseudonyme **dans** un périmètre, jamais d'un périmètre à l'autre. Le client relie ses dossiers : à utiliser sciemment.
4. **Termes à faire disparaître** (facultatif) : leur absence est vérifiée dans les fichiers produits.
5. **Validation** : détections, rapprochements (fusions proposées, jamais appliquées sans vous), choix par occurrence, passages à masquer, informations sensibles, contenus non analysables, format de sortie.
6. **Résultats provisoires** : contrôles de cohérence, comparaison avant/après (texte), retour aux décisions, puis **Finaliser et exporter**.
7. **Dé-pseudonymisation** : aperçu des données réintroduites, écriture dans un dossier `restauration_CONFIDENTIEL_…`.

## À savoir
- Un PDF produit par conversion peut différer de la mise en page ; **conservez la version modifiable** pour les restaurations futures.
- Langues allemand, italien, espagnol : **version de test** (omissions possibles).
- Images, objets incorporés, formules, noms de feuilles : non analysés (voir `docs/MATRICE_FORMATS.md`).
- Licence : une activation en ligne, puis fonctionnement hors ligne. L'expiration bloque les nouveaux traitements ; vos traitements existants restent restaurables.
- Aide : Outils → « Informations sur l'installation de Sine Nomine », puis `contact@sinenomine.app`.

## Sauvegarde et récupération
- **Sauvegarde chiffrée** (Outils → Coffre chiffré) : fichier `.sncoffre` protégé par votre phrase de récupération. Faites-en une avant toute mise à jour.
- **Phrase de récupération** : créez-la et gardez-la dans un gestionnaire de mots de passe. Sans elle, perdre le compte Windows rend le coffre illisible : il n'existe pas de porte dérobée.
- **Restauration** : sur un autre ordinateur, restaurer le `.sncoffre` avec la phrase. **Migration** de l'ancienne archive : automatique, non destructive, relançable ; l'original reste intact (retour arrière possible avec l'ancienne version).

---

# Sine Nomine user guide (EN)

This guide is not legal advice; always proofread the files produced before sharing them.

**Flow:** choose the mode (pseudonymise = reversible, codes kept in the encrypted vault; anonymise = irreversible) → optionally a profile → files and scope (Document, Project, Client: a name keeps its pseudonym
*within* a scope, never across scopes) → optional terms to make disappear (their absence is checked in the files produced) → review (detections, suggested matches never applied without you, per-occurrence choices,
passages to hide, sensitive data, non-analysable content, output format) → provisional results (consistency checks, text before/after comparison, back to the decisions) → **Finalise and export** → de-pseudonymisation
(preview, then a folder marked CONFIDENTIAL).

**Good to know:** a converted PDF may differ in layout, **keep the editable version**; German, Italian and Spanish are a **test version**; images, embedded objects, formulas and sheet names are not analysed;
activation is online once, then offline; after expiry new processing is blocked but existing processing stays restorable; help: Tools → “Information about the Sine Nomine installation”, then contact@sinenomine.app.
**Backup:** create an encrypted backup (`.sncoffre`) before every update and keep your recovery phrase in a password manager; without it, losing the Windows account makes the vault unreadable.
