# Rapport final : version commercialisable (V0.1.4.8)

Ce rapport distingue ce qui est **réalisé et vérifié**, **réalisé mais non vérifié dans cet environnement**, **restant à faire** et les **décisions réellement nécessaires**.
Il ne constitue ni une validation juridique, ni une certification, ni une garantie d'anonymat.

## 1. Réalisé et vérifié (tests automatisés exécutés, données synthétiques)
| Étape | Contenu | Tests | Documentation |
|---|---|---|---|
| 1 V0.1.4.0 | sécurité du serveur local : session, CSRF, Host/Origin, CSP, confinement des chemins, formules neutralisées | `test_securite` | README, `FEUILLE_DE_ROUTE` |
| 2 V0.1.4.2 | coffre AES-256-GCM, transactions, publication récupérable, migration non destructive | `test_coffre` | `COFFRE.md` |
| 3 V0.1.4.3 | périmètres Document / Projet / Client, cloisonnement | `test_perimetres` | `PERIMETRES.md` |
| 4 V0.1.4.4 | termes imposés et vérification finale, rapprochements, occurrences, passages masqués | `test_validation` | `VALIDATION.md` |
| 5 V0.1.4.5 | résultats provisoires, contrôles de cohérence, comparaison, restauration confidentielle | `test_controles` | `CONTROLES.md` |
| 6 V0.1.4.6 | profils (20 max), dates à l'année, export PDF, contenus non analysables, langues, fichiers malformés | `test_profils_formats`, `test_formats_matrice`, `test_limites` | `PROFILS.md`, `MATRICE_FORMATS.md` |
| 7 V0.1.4.7 | licences : codes latins, expiration commune, quota cumulatif, idempotence, administration, client v2 | `test_licences_v2`, `test_licence_client_v2`, `test_activation` | `serveur_activation/API_V2.md` |
| 8 V0.1.4.8 | informations pour le support, versions figées, SBOM, mode hors ligne forcé, documentation | `test_support`, `test_installation` | `INSTALLATION.md`, `SUPPORT_ET_VERSIONS.md`, `GUIDE_UTILISATEUR.md`, `EVALUATION.md` |

Toute la suite est exécutée avec `PYTHONUTF8=1` (17 fichiers de tests). Les parcours d'interface ont été parcourus à la main dans un navigateur sur le serveur de démonstration (`tests/serveur_demo.py`).

## 2. Réalisé mais non vérifié dans cet environnement
- **Conversion PDF** : testée avec un faux LibreOffice ; jamais avec le vrai (non installé ici).
- **Installateur sur Windows vierge** : protocole fourni (`INSTALLATION.md`), non exécuté ; installation de Tesseract via winget non rejouée.
- **Service de licences** : testé en mémoire et sur HTTP local ; **non déployé** sur le VPS, jamais exposé à Internet (HTTPS, Caddy, limitation de débit au niveau du serveur web à valider).
- **DPAPI** : exercé sous Windows en test ; comportement après changement de mot de passe Windows non testé.
- **Interface en anglais** : texte vérifié par test automatique, pas relu à l'écran en entier.

## 3. Restant à faire
- Corpus synthétique annoté de 200 documents et **mesure de détection** (aucun score n'existe : `EVALUATION.md`).
- Empreintes des roues Python et des modèles ; figer Tesseract et LibreOffice ; téléchargement explicite des packs de langues dans l'application (allemand, italien, espagnol en version de test sans modèle spaCy).
- Sauvegarde et reprise de la validation en cours, détection des sources modifiées (étape 4) ; aperçu PDF natif des PDF d'entrée ; généralisation des lieux et des âges ; délai dur et isolation des analyses lourdes.
- Signature du programme et de l'installateur (certificat à acquérir) ; certificat et durcissement du VPS.
- Relecture de la liste de mots latins ; contenu des trois profils standards à faire valider par un professionnel du domaine.

## 4. Décisions réellement nécessaires (éditeur)
1. Acquérir un certificat de signature de code (SmartScreen).
2. Autoriser le déploiement du service de licences (OVH) et choisir la politique de limitation de débit en amont.
3. Confirmer la forme juridique exacte (SAS ou SASU) et faire valider conditions, politique de confidentialité et profils métier.
4. Décider de la fourniture de LibreOffice (composant facultatif) et des packs de langues supplémentaires.
5. Décider d'une éventuelle assistance payante et du partenaire de commercialisation.
