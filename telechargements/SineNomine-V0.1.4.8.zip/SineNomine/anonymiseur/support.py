"""Informations sur l'installation de Sine Nomine, exportables pour le support.

Le contenu est construit à partir d'une LISTE EXPLICITE d'informations autorisées (jamais en copiant des journaux) :
version, système, langues, modèles, OCR, moteur de conversion, état de la licence (sans code ni identifiant), état du coffre (sans chemin),
limites actives, anomalies techniques utiles (messages expurgés).

EXCLUS : documents, extraits, noms, correspondances, listes confidentielles, codes d'activation, secrets, chemins et identifiants d'installation.
Les messages d'erreur sont expurgés (chemins, adresses électroniques, URL, identifiants, codes) et tronqués. Rien n'est jamais envoyé
automatiquement : l'utilisateur consulte le contenu avant de l'enregistrer et de le transmettre à contact@sinenomine.app.
"""

import platform
import re
import sys

from . import VERSION, conversion, langues, limites, pdf

CONTACT = "contact@sinenomine.app"
MOTIFS = [
    (re.compile(r"https?://[^\s\"'<>]+"), "[url]"),
    # chemins : les noms de dossiers peuvent contenir des espaces (et des noms de personnes) : on couvre jusqu'à l'extension du fichier
    (re.compile(r"[A-Za-z]:[\\/][^:*?\"<>|\r\n]*?\.\w{1,5}\b(?:[\\/][^\s\"'<>|]*)?"), "[chemin]"),
    (re.compile(r"[A-Za-z]:[\\/][^\s\"'<>|]*"), "[chemin]"),
    (re.compile(r"\\\\[^\s\"'<>|]+"), "[chemin]"),
    (re.compile(r"(?:/Users|/home)/[^\s\"'<>|]*"), "[chemin]"),
    (re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+"), "[adresse]"),
    (re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"), "[identifiant]"),
    (re.compile(r"\b[0-9a-fA-F]{16,}\b"), "[identifiant]"),
    (re.compile(r"\b[a-z]{3,7}-[a-z]{3,7}-[a-z2-9]{5}\b"), "[code]"),
    (re.compile(r"\bSN-[A-Z2-9-]{10,}\b"), "[code]"),
    (re.compile(r"\[?\b(?:Personne|Société|Produit|Lieu|Email|Téléphone|IBAN|Passage|Date)_[A-Z0-9]+\]?"), "[pseudonyme]"),
]


def expurger(texte, longueur=240):
    """Message d'erreur sans donnée susceptible d'identifier : chemins, adresses, URL, identifiants, codes, pseudonymes."""
    texte = re.sub(r"\s+", " ", str(texte or "")).strip()
    for motif, remplacement in MOTIFS:
        texte = motif.sub(remplacement, texte)
    return texte[:longueur] + ("…" if len(texte) > longueur else "")


def informations(config, modeles=None, licence_etat=None, coffre_etat=None):
    """Dictionnaire d'informations AUTORISÉES uniquement (voir le module)."""
    ocr = pdf.etat_ocr(config)
    conv = conversion.etat(config)
    anomalies = []
    if modeles is not None:
        anomalies += [expurger(e) for e in getattr(modeles, "erreurs", [])]
    if coffre_etat and coffre_etat.get("erreur"):
        anomalies.append(expurger(coffre_etat["erreur"]))
    if ocr.get("message"):
        anomalies.append(expurger(ocr["message"]))
    licence_etat = licence_etat or {}
    return {
        "sine_nomine": {"version": VERSION, "contact": CONTACT},
        "systeme": {"windows": platform.platform(), "python": sys.version.split()[0], "architecture": platform.machine()},
        "langues_documents": [{"code": l["code"], "nom": l["nom"], "active": l["active"], "statut": l["statut"],
                               "experimental": bool(l["test"])} for l in langues.etat(config)],
        "modeles": {"etat": getattr(modeles, "etat", None), "spacy_fr": getattr(modeles, "nlp", None) is not None,
                    "spacy_en": getattr(modeles, "nlp_en", None) is not None, "gliner": getattr(modeles, "gliner", None) is not None},
        "ocr": {"disponible": bool(ocr.get("disponible")), "langues": ocr.get("langues")},
        "conversion_pdf": {"disponible": conv["disponible"], "moteur": conv["moteur"]},
        "licence": {"statut": licence_etat.get("statut"), "type": licence_etat.get("type"), "a_vie": licence_etat.get("a_vie"),
                    "valide_jusqu_au": licence_etat.get("valide_jusqu_au") or licence_etat.get("expire_le"),
                    "generation": licence_etat.get("v")},
        "coffre": {"existe": bool((coffre_etat or {}).get("dossier")), "phrase_de_recuperation": bool((coffre_etat or {}).get("phrase_definie")),
                   "migration_faite": bool((coffre_etat or {}).get("migration")), "erreur": bool((coffre_etat or {}).get("erreur"))},
        "limites": {nom: limites.limite(nom) for nom in limites.PAR_DEFAUT},
        "anomalies_techniques": anomalies,
        "exclu": ["documents", "extraits", "noms", "correspondances", "listes confidentielles", "codes d'activation", "secrets",
                  "chemins", "identifiant d'installation"],
    }
