"""Fonctionnement hors ligne des moteurs : réglage explicite, jamais laissé à une variable d'environnement préexistante.

En usage normal, les bibliothèques d'apprentissage (Hugging Face, Transformers) ne doivent établir AUCUNE connexion : les variables sont
FORCÉES à « 1 », même si l'environnement contenait déjà une autre valeur (un `HF_HUB_OFFLINE=0` hérité ne rétablit pas l'accès réseau).
Seul le téléchargement explicite des modèles (`--telecharger-modeles`, lancé par l'installation) les force à « 0 ».
"""

import os

VARIABLES = ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_DATASETS_OFFLINE")


def regler(telechargement=False):
    """Force le mode hors ligne (usage normal) ou en ligne (téléchargement explicite). Renvoie les valeurs qui ont été écrasées."""
    voulu = "0" if telechargement else "1"
    ecrasees = {v: os.environ[v] for v in VARIABLES if v in os.environ and os.environ[v] != voulu}
    for v in VARIABLES:
        os.environ[v] = voulu
    return ecrasees
