"""Serveur web local (127.0.0.1 uniquement) qui sert l'interface et pilote les lots."""

import os
from datetime import datetime
import subprocess
import sys
import threading
from pathlib import Path

from flask import Flask, Response, abort, jsonify, redirect, request, send_from_directory
from werkzeug.utils import safe_join

import shutil
import tempfile

from . import VERSION, chemins, conversion, langues, support, limites, profils, config as cfg, correction, formats, licence, migration, pdf, perimetres, publication, restauration, sensibles, textes, validation
from .coffre import PERIMETRE_HISTORIQUE, CoffreErreur
from .detection import CATEGORIES_ENTITES
from .securite import (CSP_APPLICATION, CSP_DOCUMENT_ISOLE, METHODES_ECRITURE, PUBLICS, Securite)
from .lots import LOTS, MODES, Lot, ajouter_au_dictionnaire, fichiers_du_dossier, maintenant

STATIQUE = Path(__file__).resolve().parent / "static"
RESTAURATIONS = {}   # identifiant -> dossier de sortie d'une désanonymisation
DICTIONNAIRES = {"personne": "personnes.txt", "societe": "societes.txt", "produit": "produits.txt",
                 "lieu": "lieux.txt"}
# Listes modifiables dans Outils : nom -> (fichier, libellé)
LISTES = {"exclusions": ("exclusions.txt", "Mots exclus (jamais détectés)"),
          "personnes": ("personnes.txt", "Personnes à toujours détecter"),
          "societes": ("societes.txt", "Sociétés à toujours détecter"),
          "produits": ("produits.txt", "Produits et marques à toujours détecter"),
          "lieux": ("lieux.txt", "Lieux à toujours détecter")}
ACTIONS_VALIDES = {"conserver", "pseudonymiser", "supprimer", "annee"}      # « annee » : dates et dates de naissance seulement


def ouvrir_dans_explorateur(chemin):
    """Ouvre le dossier dans l'Explorateur, puis amène sa fenêtre au premier plan.

    Windows laisse un programme en arrière-plan (le serveur) ouvrir une fenêtre, mais pas
    la placer devant le navigateur : elle s'ouvrirait cachée derrière.
    """
    if sys.platform == "win32":
        os.startfile(chemin)  # noqa: S606 — ouverture locale dans l'Explorateur
        threading.Thread(target=_premier_plan, args=(Path(chemin).name,), daemon=True).start()
        return
    # macOS : « open » ; Linux : le gestionnaire de fichiers du bureau, ou l'Explorateur de Windows sous WSL.
    if sys.platform == "darwin":
        commandes = [["open", str(chemin)]]
    else:
        commandes = [["xdg-open", str(chemin)], ["wslview", str(chemin)], ["explorer.exe", str(chemin)]]
    for commande in commandes:
        if shutil.which(commande[0]):
            subprocess.Popen(commande, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  # noqa: S603
            return


def _premier_plan(titre):
    import ctypes
    import time
    from ctypes import wintypes

    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    rappel_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    for _ in range(40):  # la fenêtre peut mettre un moment à apparaître (jusqu'à 4 s)
        time.sleep(0.1)
        trouvees = []

        def rappel(hwnd, _):
            classe = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(hwnd, classe, 64)
            if classe.value == "CabinetWClass":
                longueur = user32.GetWindowTextLengthW(hwnd)
                texte = ctypes.create_unicode_buffer(longueur + 1)
                user32.GetWindowTextW(hwnd, texte, longueur + 1)
                if titre in texte.value:
                    trouvees.append(hwnd)
            return True

        user32.EnumWindows(rappel_type(rappel), 0)
        if trouvees:
            fenetre = trouvees[0]  # la plus haute dans l'ordre d'affichage : celle qu'on vient d'ouvrir
            # S'attacher au fil de la fenêtre active permet de lui « passer la main ».
            active = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
            courant = kernel32.GetCurrentThreadId()
            user32.AttachThreadInput(courant, active, True)
            user32.ShowWindow(fenetre, 9)  # SW_RESTORE : la ressort si elle est réduite
            user32.BringWindowToTop(fenetre)
            user32.SetForegroundWindow(fenetre)
            user32.AttachThreadInput(courant, active, False)
            return


REFUS_LICENCE = {
    "absente": "Sine Nomine n'est pas activé. Saisissez votre clé d'accès. Pour en obtenir une : contact@sinenomine.app.",
    "invalide": "La licence est invalide. Saisissez à nouveau votre clé d'accès.",
    "horloge": "L'horloge de l'ordinateur est en retard sur la dernière utilisation : corrigez la date et l'heure.",
    "expiree": "Votre licence a expiré. Saisissez un nouveau code d'activation. La dé-pseudonymisation de vos fichiers "
               "reste possible.",
    "serie_non_couverte": "Votre licence ne couvre pas cette version majeure de Sine Nomine. Vos traitements existants restent accessibles et "
                          "dé-pseudonymisables ; saisissez un code d'activation couvrant cette version.",
}


def _resume_archive(config):
    """Totaux de tous les périmètres du coffre (l'archive n'est plus un fichier unique)."""
    try:
        coffre = migration.obtenir_coffre(config)
        migration.migrer_si_necessaire(config, coffre)
        liste = perimetres.lister(coffre)
        return {"entites": sum(p["comptes"]["identites"] for p in liste), "sensibles": sum(p["comptes"]["sensibles"] for p in liste),
                "chemin": str(coffre.dossier), "perimetres": len(liste)}
    except CoffreErreur as e:
        return {"entites": 0, "sensibles": 0, "chemin": None, "erreur": str(e)}


def _fichiers_sous_perimetre(fichiers):
    """Codes de pseudonymes présents dans des fichiers déjà pseudonymisés (contenu et nom)."""
    codes = set()
    for chemin, relatif in fichiers:
        codes |= perimetres.codes_dans(relatif)
        try:
            codes |= perimetres.codes_dans(formats.lire_texte(chemin))
        except Exception:  # noqa: BLE001 — un fichier illisible est signalé plus loin, il ne bloque pas la détection
            pass
    return codes


def _choisir_perimetre(config, fichiers, demande):
    """(identifiant, détection, réponse d'erreur) : le périmètre demandé, ou à défaut celui que les codes désignent sans doute.

    Jamais de choix silencieux en cas d'ambiguïté : une réponse 409 liste les périmètres possibles."""
    coffre = migration.obtenir_coffre(config)
    migration.migrer_si_necessaire(config, coffre)
    if demande:
        if demande != PERIMETRE_HISTORIQUE and coffre.lire_perimetre(demande) is None:
            return None, None, (jsonify({"erreur": "Périmètre inconnu."}), 400)
        return demande, None, None
    detection = perimetres.detecter(coffre, _fichiers_sous_perimetre(fichiers))
    if detection["perimetre_id"]:
        return detection["perimetre_id"], detection, None
    if detection["ambigu"]:
        return None, detection, (jsonify({"erreur": "Plusieurs périmètres connaissent ces codes : choisissez celui des fichiers.",
                                          "candidats": detection["candidats"]}), 409)
    return PERIMETRE_HISTORIQUE, detection, None


def _enregistrer_depots(envois, base, extensions):
    """Enregistre les fichiers reçus sous `base`, avec des noms validés et confinés (voir chemins.py).

    Renvoie ([(chemin, nom relatif)], [noms ignorés]). Un nom invalide ou une extension non prise en charge est ignoré ;
    deux fichiers de même nom (casse comprise) ne s'écrasent pas : le second reçoit « (2) ».
    """
    base = Path(base)
    base.mkdir(parents=True, exist_ok=True)
    fichiers, ignores = [], []
    for envoi in envois:
        try:
            relatif = chemins.nom_relatif_sur(envoi.filename)
            if Path(relatif).suffix.lower() not in extensions:
                ignores.append(relatif)
                continue
            destination = chemins.unique(chemins.confiner(base, relatif))
        except chemins.CheminInvalide:
            ignores.append("(nom de fichier invalide)")
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        envoi.save(destination)
        fichiers.append((destination, destination.relative_to(base.resolve()).as_posix()))
    return fichiers, ignores


def creer_application(config, modeles, securite=True):
    """`securite=False` : uniquement pour les tests unitaires de l'API (pas de session ni de jeton CSRF)."""
    app = Flask(__name__, static_folder=None)
    garde = Securite()
    app.extensions["securite"] = garde

    def refus_licence():
        """None si la licence permet de traiter des fichiers, sinon la réponse d'erreur (la dé-pseudonymisation reste libre)."""
        statut = licence.etat(config)["statut"]
        if statut in ("active", "non_requise"):
            return None
        return jsonify({"erreur": REFUS_LICENCE.get(statut, REFUS_LICENCE["invalide"]), "licence": statut}), 403

    app.config["MAX_CONTENT_LENGTH"] = None
    app.json.sort_keys = False  # garder l'ordre des catégories (Personnes, Sociétés, Produits…)

    # ------------------------------------------------------------------ sécurité du serveur local

    PAGE_REFUSEE = ("<!DOCTYPE html><meta charset=utf-8><title>Sine Nomine</title><body style='font-family:sans-serif;"
                    "padding:2rem'><h1>Sine Nomine</h1><p>Ouvrez Sine Nomine avec son raccourci ou « lancer.bat » : cette "
                    "adresse nécessite une session.</p><p>Open Sine Nomine with its shortcut or \"lancer.bat\": this "
                    "address requires a session.</p>")

    @app.before_request
    def controler_acces():
        if not securite:
            return None
        if not garde.hote_autorise(request.headers.get("Host")):
            return Response("Hôte non autorisé.", status=400, mimetype="text/plain")
        chemin = request.path
        if chemin == "/" and request.method == "GET":
            jeton = request.args.get("jeton")
            if jeton:
                if not garde.consommer_jeton(jeton):
                    return Response(PAGE_REFUSEE, status=403, mimetype="text/html")
                reponse = redirect("/", code=302)
                reponse.set_cookie("sn_session", garde.session, httponly=True, samesite="Strict", path="/")
                return reponse
        if chemin in PUBLICS or chemin.startswith("/static/"):
            return None
        if not garde.session_valide(request.cookies.get("sn_session")):
            if chemin == "/":
                return Response(PAGE_REFUSEE, status=403, mimetype="text/html")
            return jsonify({"erreur": "Session absente ou expirée : rouvrez Sine Nomine avec son raccourci."}), 401
        if request.method in METHODES_ECRITURE:
            if not garde.csrf_valide(request.headers.get("X-CSRF-Token")):
                return jsonify({"erreur": "Requête refusée (jeton de sécurité absent ou invalide)."}), 403
            if not garde.origine_valide(request.headers.get("Origin"), request.headers.get("Referer"),
                                        request.headers.get("Host"), request.headers.get("Sec-Fetch-Site")):
                return jsonify({"erreur": "Requête refusée (origine non autorisée)."}), 403
        return None

    @app.after_request
    def en_tetes(reponse):
        reponse.headers.setdefault("X-Content-Type-Options", "nosniff")
        reponse.headers.setdefault("Referrer-Policy", "no-referrer")
        reponse.headers.setdefault("X-Frame-Options", "DENY")
        reponse.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
        chemin = request.path
        if chemin.startswith("/api/") or chemin == "/":
            reponse.headers["Cache-Control"] = "no-store"
        if chemin == "/":
            reponse.headers["Content-Security-Policy"] = CSP_APPLICATION
        elif "/sortie/" in chemin or "/api/restaurations/" in chemin:
            # un document HTML produit (rapport) n'est jamais exécuté avec les droits de l'application
            reponse.headers["Content-Security-Policy"] = CSP_DOCUMENT_ISOLE
        return reponse

    @app.get("/api/ping")
    def ping():
        """Seule route sans session : permet à un second lancement de savoir qu'une instance tourne déjà."""
        return jsonify({"version": VERSION})

    @app.post("/api/instance/jeton")
    def jeton_instance():
        """Nouveau jeton d'ouverture pour un second lancement ; exige le secret écrit dans instance.json."""
        if not garde.secret_instance_valide(request.headers.get("X-Instance-Secret")):
            return jsonify({"erreur": "Secret invalide."}), 403
        return jsonify({"jeton": garde.nouveau_jeton()})

    @app.get("/")
    def accueil():
        page = (STATIQUE / "index.html").read_text(encoding="utf-8").replace("__CSRF__", garde.csrf)
        return Response(page, mimetype="text/html")

    @app.get("/licences")
    def licences():
        """Licences des composants tiers (fichier THIRD_PARTY_NOTICES.md), affichées en texte brut."""
        chemin = cfg.RACINE / "THIRD_PARTY_NOTICES.md"
        if not chemin.exists():
            abort(404)
        return Response(chemin.read_text(encoding="utf-8"), mimetype="text/plain; charset=utf-8")

    @app.get("/static/<path:nom>")
    def statique(nom):
        return send_from_directory(STATIQUE, nom)

    @app.get("/api/etat")
    def etat():
        return jsonify({
            "version": VERSION,
            "modeles": {"etat": modeles.etat, "pret": modeles.pret, "erreurs": modeles.erreurs,
                        "gliner": modeles.gliner is not None},
            "avertissement": textes.avertissement(),
            "avertissements": {langue: textes.avertissement(langue) for langue in textes.LANGUES},
            "categories_entites": CATEGORIES_ENTITES,
            "categories_sensibles": sensibles.CATEGORIES,
            "actions_par_defaut": config["actions_par_defaut"],
            "listes": {nom: libelle for nom, (_, libelle) in LISTES.items()},
            "images_par_defaut": config["images_par_defaut"],
            "mode_par_defaut": config["mode_par_defaut"],
            "seuil": config["seuil_preselection"],
            "dossiers": {nom: str(cfg.dossier(config, nom)) for nom in config["dossiers"]},
            "extensions": sorted(formats.EXTENSIONS),
            "extensions_entree": sorted(formats.EXTENSIONS_ENTREE),
            "pdf": {"formats": list(pdf.FORMATS_SORTIE), "format_defaut": config.get("pdf_format_sortie", pdf.FORMAT_DEFAUT),
                    "ocr": pdf.etat_ocr(config)},
            "archive": _resume_archive(config),
            "coffre": migration.etat_coffre(config),
            "licence": licence.etat(config),
            "conversion": conversion.etat(config),
        })

    def _lot(identifiant):
        lot = LOTS.get(identifiant)
        if lot is None:
            abort(404)
        return lot

    def _portee_demandee(mode):
        """Périmètre choisi dans le formulaire (jamais implicite pour pseudonymiser). (portée, réponse d'erreur)."""
        type_ = request.form.get("portee") or ""
        if mode != "pseudonymisation" and not (request.form.get("projet_id") or request.form.get("client_id")):
            return None, None            # sans conservation : pas de périmètre, sauf pour utiliser les listes d'un projet ou d'un client
        if mode != "pseudonymisation":
            type_ = type_ or ("client" if request.form.get("client_id") and not request.form.get("projet_id") else "projet")
        try:
            coffre = migration.obtenir_coffre(config)
            migration.migrer_si_necessaire(config, coffre)
            pseudonymiser = mode == "pseudonymisation"
            return perimetres.resoudre(
                coffre, type_, projet_id=request.form.get("projet_id") or None, client_id=request.form.get("client_id") or None,
                nouveau_projet=request.form.get("nouveau_projet") if pseudonymiser else None,
                nouveau_client=request.form.get("nouveau_client") if pseudonymiser else None), None
        except CoffreErreur as e:
            return None, (jsonify({"erreur": str(e)}), 400)

    @app.post("/api/lots")
    def creer_lot():
        if (refus := refus_licence()) is not None:
            return refus
        accepte = request.form.get("avertissement_accepte")
        if not accepte:
            return jsonify({"erreur": "L'avertissement doit être accepté avant tout traitement."}), 400
        dossier_sortie = request.form.get("dossier_sortie", "").strip() or None
        dossier = request.form.get("dossier", "").strip().strip('"')
        envois = request.files.getlist("fichiers")
        mode = request.form.get("mode") or config["mode_par_defaut"]
        langue = textes.langue_valide(request.form.get("langue"))
        format_pdf = request.form.get("format_pdf") or None
        if format_pdf is not None and format_pdf not in pdf.FORMATS_SORTIE:
            return jsonify({"erreur": f"Format de sortie inconnu : {format_pdf}"}), 400
        if mode not in MODES:
            return jsonify({"erreur": f"Mode inconnu : {mode}"}), 400
        portee, erreur = _portee_demandee(mode)
        if erreur:
            return erreur
        profil = None
        if request.form.get("profil_id"):
            profil = profils.obtenir(request.form["profil_id"])
            if profil is None:
                return jsonify({"erreur": "Profil inconnu."}), 400
        termes_imposes = [l for l in request.form.get("termes_imposes", "").splitlines() if l.strip()]
        if len(termes_imposes) > 5000:
            return jsonify({"erreur": "Liste de termes trop longue (5 000 lignes au plus)."}), 400

        try:
            limites.configurer(config)
            validation.nettoyer_termes(termes_imposes, {})
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 400

        if envois:
            lot = Lot(config, modeles, [], [], accepte, dossier_sortie, mode, langue, format_pdf, portee, termes_imposes, profil)
            depot = cfg.dossier(config, "entree") / lot.id
            lot.depot_copie = depot
            ignores = []
            lot.fichiers, lot.ignores = _enregistrer_depots(envois, depot, formats.EXTENSIONS_ENTREE)
        elif dossier:
            if not Path(dossier).is_dir():
                return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
            fichiers, ignores = fichiers_du_dossier(dossier)
            lot = Lot(config, modeles, fichiers, ignores, accepte, dossier_sortie, mode, langue, format_pdf, portee, termes_imposes, profil)
        else:
            return jsonify({"erreur": "Déposez des fichiers ou indiquez un dossier à traiter."}), 400

        if len(lot.fichiers) > limites.limite("fichiers_par_lot"):
            del LOTS[lot.id]
            return jsonify({"erreur": f"Trop de fichiers dans un lot ({len(lot.fichiers)} ; limite {limites.limite('fichiers_par_lot')}). "
                                      "Répartissez-les en plusieurs lots."}), 400
        if not lot.fichiers:
            del LOTS[lot.id]
            return jsonify({"erreur": "Aucun fichier à traiter (formats : " + ", ".join(sorted(formats.EXTENSIONS_ENTREE)) + ").",
                            "ignores": lot.ignores}), 400
        lot.avancement.total = len(lot.fichiers)
        lot.lancer_analyse()
        return jsonify({"id": lot.id, "portee": portee})

    @app.post("/api/licence/verifier")
    def verifier_licence():
        """Avant confirmation : quota, activations restantes, expiration commune ou prévue. Ne consomme aucune activation."""
        corps = request.get_json(silent=True) or {}
        langue = "en" if request.headers.get("X-Langue", "fr").lower().startswith("en") else "fr"
        serveur = (config.get("licence") or {}).get("serveur") or licence.SERVEUR_PAR_DEFAUT
        try:
            reponse = licence.verifier_cle(str(corps.get("cle", "")), langue, serveur)
        except licence.LicenceErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify(reponse)

    @app.post("/api/licence/activer")
    def activer_licence():
        """Active une clé d'accès saisie dans l'application (seule fonction qui se connecte à Internet en cours d'usage :
        elle n'envoie que la clé, l'identifiant d'installation, la version et la langue)."""
        corps = request.get_json(silent=True) or {}
        langue = "en" if request.headers.get("X-Langue", "fr").lower().startswith("en") else "fr"
        serveur = (config.get("licence") or {}).get("serveur") or licence.SERVEUR_PAR_DEFAUT
        try:
            reponse = licence.activer(str(corps.get("cle", "")), langue, serveur)
        except licence.LicenceErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"message": reponse["message"], "licence": licence.etat(config)})

    @app.get("/api/lots/<identifiant>")
    def lire_lot(identifiant):
        return jsonify(_lot(identifiant).vers_dict())

    @app.post("/api/lots/<identifiant>/valider")
    def valider(identifiant):
        if (refus := refus_licence()) is not None:
            return refus
        lot = _lot(identifiant)
        choix = request.get_json(force=True)
        if lot.etat != "a_valider":
            return jsonify({"erreur": "Ce lot n'est pas en attente de validation."}), 409
        if not choix.get("verification_confirmee"):
            return jsonify({"erreur": "Confirmez avoir vérifié les détections."}), 400
        try:
            lot.verifier_choix(choix)
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 400
        lot.valider(choix)
        return jsonify({"ok": True})

    def _lot_en_validation(identifiant):
        lot = _lot(identifiant)
        if lot.etat not in ("a_valider", "bloque"):
            abort(409)
        return lot

    @app.post("/api/lots/<identifiant>/fusions")
    def propositions_de_fusion(identifiant):
        """Rapprochements PROPOSÉS entre les entités en cours de validation (jamais appliqués par le serveur)."""
        lot = _lot_en_validation(identifiant)
        entites = (request.get_json(force=True) or {}).get("entites")
        if not isinstance(entites, list):
            entites = [e.vers_dict() for e in lot.entites]
        valides = [e for e in entites if isinstance(e, dict) and isinstance(e.get("id"), int) and e.get("categorie")
                   and isinstance(e.get("canonique"), str)]
        return jsonify({"propositions": validation.propositions_fusion(valides)})

    @app.post("/api/lots/<identifiant>/occurrences")
    def occurrences_d_un_terme(identifiant):
        lot = _lot_en_validation(identifiant)
        variantes = (request.get_json(force=True) or {}).get("variantes")
        if not isinstance(variantes, list):
            return jsonify({"erreur": "Indiquez les variantes à rechercher."}), 400
        return jsonify(lot.occurrences_de(variantes, mots=(request.get_json(force=True) or {}).get("mots", 10)))

    @app.get("/api/lots/<identifiant>/texte")
    def texte_d_un_fichier(identifiant):
        """Texte extrait d'un fichier, par tranches, pour sélectionner un passage à masquer."""
        lot = _lot_en_validation(identifiant)
        fichier = request.args.get("fichier", "")
        if fichier not in lot.textes:
            return jsonify({"erreur": "Fichier inconnu."}), 404
        debut = max(request.args.get("debut", 0, type=int), 0)
        taille = min(max(request.args.get("taille", 20000, type=int), 1000), 50000)
        texte = lot.textes[fichier].replace("\r\n", "\n")          # le navigateur normalise les fins de ligne
        return jsonify({"fichier": fichier, "debut": debut, "texte": texte[debut:debut + taille], "total": len(texte),
                        "fichiers": [r for r in lot.textes]})

    @app.post("/api/lots/<identifiant>/passage")
    def passage_a_masquer(identifiant):
        lot = _lot_en_validation(identifiant)
        corps = request.get_json(force=True) or {}
        try:
            return jsonify(lot.passage(corps.get("fichier"), corps.get("debut"), corps.get("fin")))
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 400

    @app.get("/api/lots/<identifiant>/comparaison")
    def comparaison(identifiant):
        """Comparaison avant/après (texte), sur les résultats provisoires, par pages de lignes."""
        lot = _lot(identifiant)
        try:
            return jsonify(lot.comparaison(request.args.get("fichier", ""), max(request.args.get("debut", 0, type=int), 0),
                                           min(max(request.args.get("nombre", 300, type=int), 1), 1000)))
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 409

    @app.get("/api/lots/<identifiant>/apercu-pdf/<path:chemin>")
    def apercu_pdf(identifiant, chemin):
        """Aperçu d'un PDF provisoire (avant l'export définitif) : uniquement les PDF produits par ce lot."""
        fichier = _lot(identifiant).apercu_pdf(chemin)
        if fichier is None or not fichier.is_file():
            abort(404)
        return send_from_directory(fichier.parent, fichier.name, mimetype="application/pdf")

    @app.post("/api/lots/<identifiant>/finaliser")
    def finaliser_lot(identifiant):
        """Export définitif des résultats provisoires. Pas de contrôle de licence : un résultat généré avant l'expiration peut toujours
        être finalisé et exporté (la licence ne conditionne que de NOUVEAUX traitements)."""
        try:
            _lot(identifiant).finaliser()
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 409
        return jsonify({"ok": True})

    @app.post("/api/lots/<identifiant>/abandonner")
    def abandonner_lot(identifiant):
        """Abandon des résultats provisoires : rien n'est publié, rien n'est conservé."""
        try:
            _lot(identifiant).abandonner_provisoire(definitivement=True)
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 409
        return jsonify({"ok": True})

    @app.post("/api/lots/<identifiant>/reprendre")
    def reprendre_lot(identifiant):
        """Retour à la validation après un blocage (un terme imposé subsiste dans un fichier produit)."""
        try:
            _lot(identifiant).reprendre()
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 409
        return jsonify({"ok": True})

    @app.post("/api/lots/<identifiant>/extraits")
    def extraits(identifiant):
        lot = _lot(identifiant)
        corps = request.get_json(force=True) or {}
        variantes = corps.get("variantes")
        if not isinstance(variantes, list):
            return jsonify({"erreur": "Indiquez les variantes à rechercher."}), 400
        return jsonify(lot.extraits(variantes, corps.get("mots", 15)))

    @app.get("/api/lots/<identifiant>/sortie/<path:chemin>")
    def fichier_sortie(identifiant, chemin):
        lot = _lot(identifiant)
        if safe_join(str(lot.dossier_sortie), chemin) is None:
            abort(404)
        return send_from_directory(lot.dossier_sortie, chemin)

    @app.get("/api/lots/<identifiant>/apercu/<int:index>")
    def apercu_image(identifiant, index):
        taille = min(max(request.args.get("taille", 320, type=int), 64), 2000)
        mini = _lot(identifiant).apercu(index, taille)
        if mini is None:
            abort(404)
        return Response(mini[0], mimetype=mini[1], headers={"Cache-Control": "private, max-age=3600"})

    @app.post("/api/lots/<identifiant>/ouvrir")
    def ouvrir(identifiant):
        lot = _lot(identifiant)
        cible = request.get_json(force=True).get("cible")
        if cible != "sortie" and not lot.fichier_correspondances:
            return jsonify({"erreur": "Aucune table de correspondance : ce lot a été anonymisé sans rien conserver."}), 400
        chemin = lot.dossier_sortie if cible == "sortie" else Path(lot.fichier_correspondances).parent
        ouvrir_dans_explorateur(chemin)
        return jsonify({"ok": True})

    @app.post("/api/lots/<identifiant>/exporter-correspondances")
    def exporter_correspondances(identifiant):
        """Export EN CLAIR de la table de correspondance : uniquement sur demande explicite et confirmée."""
        lot = _lot(identifiant)
        if not (request.get_json(silent=True) or {}).get("confirmation"):
            return jsonify({"erreur": "Confirmez l'export : le fichier contiendra les noms d'origine en clair."}), 400
        try:
            chemin = lot.exporter_correspondances()
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"fichier": str(chemin)})

    # ------------------------------------------------------------------ clients, projets, documents

    # ------------------------------------------------------------------ informations sur l'installation (support)

    @app.get("/api/support")
    def informations_support():
        """Informations autorisées pour le support, à CONSULTER avant tout enregistrement ; rien n'est envoyé."""
        return jsonify(support.informations(config, modeles, licence.etat(config), migration.etat_coffre(config)))

    # ------------------------------------------------------------------ langues des documents

    @app.get("/api/langues")
    def lire_langues():
        return jsonify({"langues": langues.etat(config)})

    @app.put("/api/langues")
    def ecrire_langues():
        """Active ou retire des langues de documents (prise en compte au prochain démarrage : les modèles sont chargés au lancement)."""
        choisies = (request.get_json(silent=True) or {}).get("actives")
        if not isinstance(choisies, list) or any(c not in langues.PACKS for c in choisies):
            return jsonify({"erreur": "Langues invalides."}), 400
        cfg.enregistrer_utilisateur(config, {"langues": langues.actives({"langues": choisies})})
        return jsonify({"langues": langues.etat(config), "redemarrage": True})

    # ------------------------------------------------------------------ profils de paramètres

    @app.get("/api/profils")
    def lister_profils():
        return jsonify({"profils": profils.lister(), "maximum": profils.MAX_PROFILS, "personnels_maximum": profils.MAX_PERSONNELS})

    @app.post("/api/profils")
    def creer_profil():
        """Enregistre un NOUVEAU profil personnel (aussi : « enregistrer sous » depuis un profil standard)."""
        corps = request.get_json(silent=True) or {}
        try:
            return jsonify(profils.creer(corps.get("nom"), corps.get("reglages")))
        except profils.ProfilErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.put("/api/profils/<identifiant>")
    def modifier_profil(identifiant):
        corps = request.get_json(silent=True) or {}
        try:
            return jsonify(profils.modifier(identifiant, corps.get("nom"), corps.get("reglages")))
        except profils.ProfilErreur as e:
            return jsonify({"erreur": str(e)}), 403 if identifiant.startswith("standard:") else 400

    @app.delete("/api/profils/<identifiant>")
    def supprimer_profil(identifiant):
        try:
            profils.supprimer(identifiant)
        except profils.ProfilErreur as e:
            return jsonify({"erreur": str(e)}), 403 if identifiant.startswith("standard:") else 400
        return jsonify({"ok": True})

    @app.get("/api/perimetres")
    def lister_perimetres():
        try:
            coffre = migration.obtenir_coffre(config)
            migration.migrer_si_necessaire(config, coffre)
            return jsonify({"perimetres": perimetres.lister(coffre), "nom_projet_par_defaut": perimetres.NOM_PROJET_PAR_DEFAUT})
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/perimetres")
    def creer_perimetre():
        corps = request.get_json(silent=True) or {}
        try:
            coffre = migration.obtenir_coffre(config)
            if corps.get("type") not in ("client", "projet"):
                return jsonify({"erreur": "Seuls un client ou un projet peuvent être créés ici."}), 400
            identifiant = coffre.creer_perimetre(corps["type"], corps.get("nom"), corps.get("client_id") or None)
            return jsonify(perimetres.libelle(coffre, identifiant))
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.put("/api/perimetres/<identifiant>")
    def modifier_perimetre(identifiant):
        """Renomme un client ou un projet, ou rattache / détache un projet (`client_id`). Aucun pseudonyme existant ne change."""
        corps = request.get_json(silent=True) or {}
        try:
            coffre = migration.obtenir_coffre(config)
            if "nom" in corps:
                coffre.renommer_perimetre(identifiant, corps["nom"])
            if "client_id" in corps:
                coffre.rattacher_projet(identifiant, corps["client_id"] or None)
            return jsonify(perimetres.libelle(coffre, identifiant))
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    # ------------------------------------------------------------------ coffre chiffré

    @app.get("/api/coffre")
    def etat_du_coffre():
        return jsonify(migration.etat_coffre(config))

    @app.post("/api/coffre/verifier")
    def verifier_le_coffre():
        try:
            return jsonify(migration.obtenir_coffre(config).verifier())
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/coffre/phrase")
    def phrase_de_recuperation():
        """Crée la phrase de récupération (affichée UNE SEULE fois). Remplacer une phrase existante demande une confirmation."""
        corps = request.get_json(silent=True) or {}
        try:
            coffre = migration.obtenir_coffre(config)
            if coffre.a_phrase() and not corps.get("remplacer"):
                return jsonify({"erreur": "Une phrase de récupération existe déjà. Confirmez pour la remplacer."}), 409
            return jsonify({"phrase": coffre.definir_phrase()})
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/coffre/sauvegarde")
    def sauvegarde_du_coffre():
        """Sauvegarde portable chiffrée par la phrase de récupération, dans le dossier de données de l'utilisateur."""
        corps = request.get_json(silent=True) or {}
        phrase = str(corps.get("phrase", ""))
        dossier = cfg.donnees_utilisateur() / "sauvegardes"
        fichier = dossier / f"coffre-{datetime.now():%Y%m%d-%H%M%S}.sncoffre"
        try:
            octets = migration.obtenir_coffre(config).sauvegarder(fichier, phrase)
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"fichier": str(fichier), "octets": octets})

    @app.post("/api/coffre/copies-en-clair/supprimer")
    def supprimer_copies_clair():
        """Supprime les anciens fichiers en clair (archive JSON, tables Excel) : accord explicite requis, migration vérifiée."""
        corps = request.get_json(silent=True) or {}
        try:
            supprimes = migration.supprimer_copies_en_clair(config, migration.obtenir_coffre(config),
                                                            accord_explicite=bool(corps.get("accord")))
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"supprimes": supprimes})

    @app.post("/api/restaurations/apercu")
    def apercu_restauration():
        """Avant dé-pseudonymisation : fichiers, périmètre, catégories de données réintroduites, codes inconnus. N'écrit rien."""
        envois = request.files.getlist("fichiers")
        dossier = request.form.get("dossier", "").strip().strip('"')
        with tempfile.TemporaryDirectory(prefix="sine-nomine-") as temporaire:
            fichiers, ignores = [], []
            if envois:
                fichiers, ignores = _enregistrer_depots(envois, Path(temporaire), formats.EXTENSIONS)
            elif dossier:
                if not Path(dossier).is_dir():
                    return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
                fichiers, ignores = fichiers_du_dossier(dossier)
            if not fichiers:
                return jsonify({"erreur": "Aucun fichier à désanonymiser.", "ignores": ignores}), 400
            perimetre, detection, refus = _choisir_perimetre(config, fichiers, request.form.get("perimetre_id") or None)
            if refus:
                return refus
            archive = restauration.charger_archive(config, perimetre)
            resume = restauration.resumer(archive, fichiers)
        return jsonify({"perimetre": perimetres.libelle(migration.obtenir_coffre(config), perimetre), "ignores": ignores,
                        "detecte": bool(detection and detection["perimetre_id"]) if not request.form.get("perimetre_id") else False,
                        **resume})

    @app.post("/api/restaurations")
    def desanonymiser():
        """Désanonymise des fichiers produits par Sine Nomine, à partir de l'archive des codes."""
        envois = request.files.getlist("fichiers")
        dossier = request.form.get("dossier", "").strip().strip('"')
        with tempfile.TemporaryDirectory(prefix="sine-nomine-") as temporaire:
            fichiers, ignores = [], []
            if envois:
                fichiers, ignores = _enregistrer_depots(envois, Path(temporaire), formats.EXTENSIONS)
            elif dossier:
                if not Path(dossier).is_dir():
                    return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
                fichiers, ignores = fichiers_du_dossier(dossier)
            if not fichiers:
                return jsonify({"erreur": "Aucun fichier à désanonymiser.", "ignores": ignores}), 400
            perimetre, detection, refus = _choisir_perimetre(config, fichiers, request.form.get("perimetre_id") or None)
            if refus:
                return refus
            archive = restauration.charger_archive(config, perimetre)
            if not archive.entites and not archive.sensibles:
                return jsonify({"erreur": "Ce périmètre ne contient aucune correspondance : aucun traitement n'y a encore été "
                                          "pseudonymisé."}), 400
            identifiant, dossier_sortie = restauration.nouveau_dossier(config, restauration.PREFIXE_CONFIDENTIEL)
            resultats = restauration.restaurer(archive, fichiers, dossier_sortie)
        RESTAURATIONS[identifiant] = dossier_sortie
        return jsonify({"id": identifiant, "dossier": str(dossier_sortie), "resultats": resultats, "ignores": ignores,
                        "perimetre": perimetres.libelle(migration.obtenir_coffre(config), perimetre),
                        "detecte": bool(detection and detection["perimetre_id"]) if not request.form.get("perimetre_id") else False})

    @app.get("/api/restaurations/<identifiant>/<path:chemin>")
    def fichier_restaure(identifiant, chemin):
        dossier = RESTAURATIONS.get(identifiant)
        if dossier is None or safe_join(str(dossier), chemin) is None:
            abort(404)
        return send_from_directory(dossier, chemin)

    @app.post("/api/restaurations/<identifiant>/ouvrir")
    def ouvrir_restauration(identifiant):
        dossier = RESTAURATIONS.get(identifiant)
        if dossier is None:
            abort(404)
        ouvrir_dans_explorateur(dossier)
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ menu : corriger des pseudonymes

    def _session(identifiant):
        session = correction.SESSIONS.get(identifiant)
        if session is None:
            abort(404)
        return session

    @app.post("/api/corrections")
    def creer_correction():
        if (refus := refus_licence()) is not None:
            return refus
        """Reçoit les fichiers déjà pseudonymisés à corriger (déposés ou indiqués par un dossier)."""
        envois = request.files.getlist("fichiers")
        dossier = request.form.get("dossier", "").strip().strip('"')
        fichiers, ignores, temporaire = [], [], None
        if envois:
            temporaire = Path(tempfile.mkdtemp(prefix="sine-nomine-correction-"))
            fichiers, ignores = _enregistrer_depots(envois, temporaire, formats.EXTENSIONS)
        elif dossier:
            if not Path(dossier).is_dir():
                return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
            fichiers, ignores = fichiers_du_dossier(dossier)
        if not fichiers:
            if temporaire:
                shutil.rmtree(temporaire, ignore_errors=True)
            return jsonify({"erreur": "Aucun fichier à corriger.", "ignores": ignores}), 400
        perimetre, detection, refus = _choisir_perimetre(config, fichiers, request.form.get("perimetre_id") or None)
        if refus:
            if temporaire:
                shutil.rmtree(temporaire, ignore_errors=True)
            return refus
        session = correction.creer_session(fichiers, temporaire, perimetre)
        return jsonify({"id": session.id, "fichiers": [r for _, r in fichiers], "ignores": ignores,
                        "perimetre": perimetres.libelle(migration.obtenir_coffre(config), perimetre)})

    def _parametres_correction():
        donnees = request.get_json(force=True)
        return (donnees.get("regles", []), bool(donnees.get("automatique", True)),
                bool(donnees.get("prenoms_seuls", False)))

    @app.post("/api/corrections/<identifiant>/apercu")
    def apercu_correction(identifiant):
        try:
            return jsonify(correction.apercu(config, _session(identifiant), *_parametres_correction()))
        except correction.ErreurRegle as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/corrections/<identifiant>/appliquer")
    def appliquer_correction(identifiant):
        if (refus := refus_licence()) is not None:
            return refus
        session = _session(identifiant)
        try:
            resultat = correction.appliquer(config, session, *_parametres_correction())
        except correction.ErreurRegle as e:
            return jsonify({"erreur": str(e)}), 400
        RESTAURATIONS[resultat["id"]] = Path(resultat["dossier"])      # mêmes liens de téléchargement que la restauration
        return jsonify(resultat)

    @app.delete("/api/corrections/<identifiant>")
    def annuler_correction(identifiant):
        _session(identifiant).nettoyer()
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ menu : consulter un pseudonyme

    @app.get("/api/pseudonymes")
    def consulter_pseudonymes():
        """Cherche dans l'archive un code (Personne_KQXMB) ou un nom d'origine. Affiche des données en clair."""
        coffre = migration.obtenir_coffre(config)
        migration.migrer_si_necessaire(config, coffre)
        trouvees, total = [], {"entites": 0, "sensibles": 0, "perimetres": 0}
        for p in perimetres.lister(coffre):
            if not (p["comptes"]["identites"] or p["comptes"]["sensibles"]):
                continue
            archive = restauration.charger_archive(config, p["id"])
            resultats, _ = archive.rechercher(request.args.get("q", ""), limite=100)
            for r in resultats:
                trouvees.append({**r, "perimetre": {"id": p["id"], "type": p["type"], "libelle": p["libelle"]}})
            total["entites"] += p["comptes"]["identites"]
            total["sensibles"] += p["comptes"]["sensibles"]
            total["perimetres"] += 1
        tronque = len(trouvees) > 100
        trouvees = trouvees[:100]
        return jsonify({"resultats": trouvees, "tronque": tronque, "total_archive": total})

    # ------------------------------------------------------------------ menu : outils

    def _chemin_liste(nom):
        if nom not in LISTES:
            abort(404)
        return cfg.dossier(config, "dictionnaires") / LISTES[nom][0]

    @app.get("/api/outils/listes")
    def listes():
        return jsonify({nom: libelle for nom, (_, libelle) in LISTES.items()})

    def _cible_liste(nom):
        """Liste GÉNÉRALE des mots exclus (fichier, règles communes) ou liste d'un périmètre (coffre) : (périmètre, erreur)."""
        _chemin_liste(nom)                                       # 404 si le nom est inconnu
        perimetre = request.args.get("perimetre") or "general"
        if perimetre == "general":
            if nom != "exclusions":
                return None, (jsonify({"erreur": "Cette liste est propre à un client ou à un projet : choisissez-en un."}), 400)
            return "general", None
        coffre = migration.obtenir_coffre(config)
        migration.migrer_si_necessaire(config, coffre)           # les anciennes listes sont copiées dans l'archive historique
        if coffre.lire_perimetre(perimetre) is None and perimetre != PERIMETRE_HISTORIQUE:
            return None, (jsonify({"erreur": "Périmètre inconnu."}), 404)
        return perimetre, None

    @app.get("/api/outils/listes/<nom>")
    def lire_liste(nom):
        perimetre, erreur = _cible_liste(nom)
        if erreur:
            return erreur
        if perimetre == "general":
            chemin = _chemin_liste(nom)
            lignes = chemin.read_text(encoding="utf-8-sig").splitlines() if chemin.exists() else []
            termes = [l.strip() for l in lignes if l.strip() and not l.lstrip().startswith("#")]
            commentaires = [l for l in lignes if l.lstrip().startswith("#")]
        else:
            contenu = migration.obtenir_coffre(config).lire_liste(perimetre, nom)
            termes, commentaires = contenu["termes"], contenu["commentaires"]
        return jsonify({"nom": nom, "libelle": LISTES[nom][1], "termes": termes, "commentaires": commentaires, "perimetre": perimetre})

    @app.put("/api/outils/listes/<nom>")
    def ecrire_liste(nom):
        perimetre, erreur = _cible_liste(nom)
        if erreur:
            return erreur
        termes = request.get_json(force=True).get("termes", [])
        if not isinstance(termes, list):
            return jsonify({"erreur": "Liste de termes attendue."}), 400
        propres = list(dict.fromkeys(t.strip() for t in termes
                                     if isinstance(t, str) and t.strip() and not t.strip().startswith("#")))
        if perimetre == "general":
            chemin = _chemin_liste(nom)
            existant = chemin.read_text(encoding="utf-8-sig").splitlines() if chemin.exists() else []
            commentaires = [l for l in existant if l.lstrip().startswith("#")]   # les consignes en tête de fichier restent
            chemin.write_text("\n".join(commentaires + propres) + "\n", encoding="utf-8")
        else:
            coffre = migration.obtenir_coffre(config)
            coffre.ecrire_liste(perimetre, nom, propres, coffre.lire_liste(perimetre, nom)["commentaires"])
        return jsonify({"ok": True, "nombre": len(propres)})

    def _options_courantes():
        actions = {c: config["actions_par_defaut"].get(c, "conserver") for c in sensibles.CATEGORIES}
        return {"actions_par_defaut": actions, "images_par_defaut": config["images_par_defaut"],
                "mode_par_defaut": config["mode_par_defaut"], "lieux_preselectionnes": bool(config["lieux_preselectionnes"]),
                "seuil_preselection": config["seuil_preselection"]}

    @app.get("/api/outils/options")
    def lire_options():
        return jsonify(_options_courantes())

    @app.put("/api/outils/options")
    def ecrire_options():
        """Enregistre les options par défaut dans config.utilisateur.json (config.json reste intact)."""
        donnees = request.get_json(force=True)
        options = {}
        if "actions_par_defaut" in donnees:
            actions = donnees["actions_par_defaut"]
            if not isinstance(actions, dict) or any(c not in sensibles.CATEGORIES or a not in ACTIONS_VALIDES
                                                    or (a == "annee" and c not in ("date", "date_naissance"))
                                                    for c, a in actions.items()):
                return jsonify({"erreur": "Actions invalides pour les informations sensibles."}), 400
            options["actions_par_defaut"] = actions
        if "images_par_defaut" in donnees:
            if donnees["images_par_defaut"] not in ("conserver", "supprimer"):
                return jsonify({"erreur": "Choix d'images invalide."}), 400
            options["images_par_defaut"] = donnees["images_par_defaut"]
        if "mode_par_defaut" in donnees:
            if donnees["mode_par_defaut"] not in MODES:
                return jsonify({"erreur": "Mode inconnu."}), 400
            options["mode_par_defaut"] = donnees["mode_par_defaut"]
        if "lieux_preselectionnes" in donnees:
            options["lieux_preselectionnes"] = bool(donnees["lieux_preselectionnes"])
        if "seuil_preselection" in donnees:
            try:
                seuil = float(donnees["seuil_preselection"])
            except (TypeError, ValueError):
                return jsonify({"erreur": "Seuil invalide."}), 400
            if not 0 <= seuil <= 1:
                return jsonify({"erreur": "Le seuil doit être compris entre 0 et 1."}), 400
            options["seuil_preselection"] = seuil
        cfg.enregistrer_utilisateur(config, options)
        return jsonify({"ok": True, **_options_courantes()})

    @app.post("/api/outils/archive/ouvrir")
    def ouvrir_archive():
        ouvrir_dans_explorateur(cfg.dossier(config, "correspondances"))
        return jsonify({"ok": True})

    @app.post("/api/quitter")
    def quitter():
        en_cours = [l.id for l in LOTS.values() if l.etat in ("analyse", "traitement")]
        if en_cours and not (request.get_json(silent=True) or {}).get("forcer"):
            return jsonify({"erreur": "Un traitement est en cours.", "en_cours": en_cours}), 409
        # Laisse le temps à la réponse de partir avant d'arrêter le processus.
        threading.Timer(0.5, os._exit, args=(0,)).start()
        return jsonify({"ok": True})

    @app.post("/api/dictionnaire")
    def dictionnaire():
        donnees = request.get_json(force=True)
        terme = (donnees.get("terme") or "").strip()
        if not terme:
            return jsonify({"erreur": "Terme vide."}), 400
        liste = {"personne": "personnes", "societe": "societes", "produit": "produits", "lieu": "lieux"}.get(donnees.get("liste"), donnees.get("liste"))
        if liste not in LISTES:
            return jsonify({"erreur": "Liste inconnue."}), 400
        # Le terme est ajouté aux listes du périmètre du lot (jamais aux listes générales ni à celles d'un autre client ou projet).
        lot = LOTS.get(donnees.get("lot"))
        portee = getattr(lot, "portee", None)
        if lot is None or not portee or portee["type"] == "document":
            return jsonify({"erreur": "Cette action est disponible pour un traitement rattaché à un projet ou à un client."}), 400
        migration.obtenir_coffre(config).ajouter_a_liste(portee["perimetre_id"], liste, terme)
        return jsonify({"ok": True, "date": maintenant()})

    return app
