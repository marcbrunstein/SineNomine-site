"""Détection des personnes, sociétés et produits (spaCy, GLiNER, dictionnaires, suggestions)."""

import re
import threading
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from . import langue as langues, sensibles
from .graphies import plier

CATEGORIES_ENTITES = {"personne": "Personne", "societe": "Société", "produit": "Produit", "lieu": "Lieu"}

LABELS_SPACY = {"PER": "personne", "ORG": "societe", "LOC": "lieu"}                     # modèle français
LABELS_SPACY_EN = {"PERSON": "personne", "ORG": "societe", "GPE": "lieu", "LOC": "lieu", "PRODUCT": "produit"}  # anglais
LABELS_GLINER = {"personne": "personne", "entreprise": "societe", "produit": "produit", "marque": "produit",
                 "ville": "lieu", "pays": "lieu"}

TITRES = {"m", "m.", "mr", "mr.", "mme", "mme.", "mlle", "mlle.", "me", "me.", "maitre", "maître",
          "dr", "dr.", "docteur", "pr", "pr.", "professeur", "monsieur", "madame", "mademoiselle",
          "messieurs", "mesdames",
          # anglais
          "mrs", "mrs.", "ms", "ms.", "miss", "prof", "prof.", "sir", "dame", "lord", "lady", "rev", "rev.",
          # allemand, espagnol, italien (utile dès qu'on y ajoutera une langue)
          "herr", "frau", "senor", "senora", "sr", "sr.", "sra", "sra.", "sig", "sig.", "sig.ra", "dott", "dott."}

# Mots souvent pris à tort pour des entités dans les documents juridiques et professionnels.
MOTS_IGNORES = {
    "article", "articles", "annexe", "annexes", "chapitre", "section", "titre", "page", "objet",
    "tribunal", "cour", "conseil", "juge", "société", "societe", "client", "clients", "contrat",
    "attendu", "considérant", "vu", "entre", "les", "soussignés", "soussignes", "ci-après",
    "madame", "monsieur", "mademoiselle", "maître", "maitre", "docteur", "bonjour", "cordialement",
    "date", "signature", "lieu", "fait", "pour", "par", "partie", "parties", "rgpd", "cnil",
    "tva", "ht", "ttc", "sas", "sarl", "sa", "eurl", "ceo", "cfo", "drh", "pdg", "dg", "ndlr",
    "nb", "ps", "ok", "faq", "pdf", "word", "excel", "url", "email", "e-mail", "tél", "tel",
    # sigles métier et institutions, pris à tort pour des sociétés ou des produits
    "dpa", "btob", "btoc", "esat", "ue", "union européenne", "nda", "codir", "copil", "sku", "erp", "crm",
    "cms", "bdd", "sirh", "rh", "daf", "dsi", "bu", "gwp", "fds", "adr", "geo",
    # anglais : mots de structure et sigles courants
    "company", "customer", "agreement", "table", "figure", "appendix", "annex", "chapter", "dear", "regards",
    "sincerely", "subject", "fyi", "cto", "coo", "hr", "it", "vat", "gdpr", "phone", "fax", "madam", "sir",
    "summary", "introduction", "conclusion", "contents", "note", "notes", "total", "name", "address",
}

ACRONYMES_COURANTS = {
    "RGPD", "CNIL", "TVA", "HT", "TTC", "SAS", "SARL", "SA", "EURL", "SCI", "CEO", "CFO", "DRH",
    "PDG", "DG", "UE", "EU", "USA", "UK", "PDF", "URL", "FAQ", "PME", "TPE", "ETI", "CDI", "CDD",
    "RH", "IT", "SI", "IA", "AI", "API", "RCS", "SIREN", "SIRET", "IBAN", "BIC", "NB", "PS", "OK",
    "CGV", "CGU", "KPI", "ROI", "B2B", "B2C", "CA", "ETP", "JO", "JORF", "CE", "CJUE", "CEDH",
    "OCDE", "ONU", "TGI", "TJ", "CPH", "URSSAF", "INSEE", "COVID", "ART", "CF", "ETC", "N°",
}


def normaliser(texte):
    """Minuscules, sans accents ni espaces superflus : sert de clé de regroupement."""
    texte = unicodedata.normalize("NFKD", texte)
    texte = "".join(c for c in texte if not unicodedata.combining(c))
    texte = texte.replace("’", "'")
    return re.sub(r"\s+", " ", texte).strip().lower()


MOTS_IGNORES = {normaliser(m) for m in MOTS_IGNORES}
TITRES = {normaliser(t) for t in TITRES}


@dataclass
class Candidat:
    surface: str
    categorie: str
    score: float
    source: str
    fichier: str
    langue: str = "fr"      # langue du paragraphe d'où vient le candidat ("fr" ou "en")


@dataclass
class Dictionnaires:
    personnes: list = field(default_factory=list)
    societes: list = field(default_factory=list)
    produits: list = field(default_factory=list)
    exclusions: set = field(default_factory=set)
    lieux: list = field(default_factory=list)

    @classmethod
    def charger(cls, dossier):
        def lire(nom):
            chemin = Path(dossier) / nom
            if not chemin.exists():
                return []
            lignes = chemin.read_text(encoding="utf-8-sig").splitlines()
            return [l.strip() for l in lignes if l.strip() and not l.lstrip().startswith("#")]

        return cls(lire("personnes.txt"), lire("societes.txt"), lire("produits.txt"),
                   {normaliser(t) for t in lire("exclusions.txt")}, lire("lieux.txt"))

    @classmethod
    def pour_perimetre(cls, dossier_general, coffre=None, perimetre_id=None):
        """Dictionnaires d'un périmètre (client, projet, archive historique) : les listes de CE périmètre, chiffrées dans le coffre,
        plus les seuls mots exclus GÉNÉRAUX du dossier de dictionnaires (règles linguistiques communes). Les anciennes listes de
        personnes, sociétés, produits et lieux en fichiers ne sont plus lues : elles ont été copiées dans l'archive historique."""
        chemin = Path(dossier_general) / "exclusions.txt"
        generales = chemin.read_text(encoding="utf-8-sig").splitlines() if chemin.exists() else []
        dico = cls(exclusions={normaliser(l.strip()) for l in generales if l.strip() and not l.lstrip().startswith("#")})
        if coffre is not None and perimetre_id:
            dico.personnes = list(coffre.lire_liste(perimetre_id, "personnes")["termes"])
            dico.societes = list(coffre.lire_liste(perimetre_id, "societes")["termes"])
            dico.produits = list(coffre.lire_liste(perimetre_id, "produits")["termes"])
            dico.lieux = list(coffre.lire_liste(perimetre_id, "lieux")["termes"])
            dico.exclusions |= {normaliser(t) for t in coffre.lire_liste(perimetre_id, "exclusions")["termes"]}
        return dico


class Modeles:
    """Chargement des modèles en arrière-plan, au démarrage du serveur."""

    def __init__(self, config):
        self.config = config
        self.nlp = None
        self.nlp_en = None          # modèle spaCy anglais (facultatif : réglage « langues »)
        self.gliner = None
        self.etat = "en attente"
        self.erreurs = []
        self._pret = threading.Event()

    def charger_en_arriere_plan(self):
        threading.Thread(target=self._charger, daemon=True).start()

    def _charger(self):
        try:
            self.etat = "chargement du modèle spaCy"
            import spacy
            self.nlp = spacy.load(self.config["spacy_modele"],
                                  disable=["parser", "lemmatizer", "morphologizer", "attribute_ruler"])
            self.nlp.max_length = 5_000_000
        except Exception as e:  # noqa: BLE001 — l'erreur est affichée dans l'interface
            self.erreurs.append(f"spaCy indisponible : {e}")
        if "en" in self.config.get("langues", ["fr"]):
            try:
                self.etat = "chargement du modèle spaCy anglais"
                import spacy
                self.nlp_en = spacy.load(self.config.get("spacy_modele_en", "en_core_web_lg"),
                                         disable=["parser", "lemmatizer", "attribute_ruler"])
                self.nlp_en.max_length = 5_000_000
            except Exception as e:  # noqa: BLE001
                self.erreurs.append("Modèle spaCy anglais indisponible : les textes anglais ne seront analysés que par "
                                    f"GLiNER. Relancez installer.bat pour l'installer. ({e})")
        if self.config["gliner"]["actif"]:
            try:
                self.etat = "chargement du modèle GLiNER"
                from gliner import GLiNER
                revision = self.config["gliner"].get("revision") or None          # révision figée du modèle (voir docs/INSTALLATION.md)
                self.gliner = GLiNER.from_pretrained(self.config["gliner"]["modele"], **({"revision": revision} if revision else {}))
            except Exception as e:  # noqa: BLE001
                self.erreurs.append(f"GLiNER indisponible (produits détectés par dictionnaire seulement) : {e}. "
                                    "Sine Nomine fonctionne hors ligne : relancez installer.bat pour (ré)installer les modèles.")
        self.etat = "prêt" if self.nlp is not None else "erreur"
        self._pret.set()

    def nlp_pour(self, code):
        """Modèle spaCy de la langue ('en' : anglais s'il est installé), sinon le modèle français."""
        return self.nlp_en if code == "en" and self.nlp_en is not None else self.nlp

    def attendre(self):
        self._pret.wait()

    @property
    def pret(self):
        return self._pret.is_set()


RE_ARTICLE_INITIAL = re.compile(r"^(?:(?:le|la|les|l'|l’|de|du|des|d'|d’)\s*)+", re.IGNORECASE)
RE_ARTICLE_MINUSCULE = re.compile(r"^(?:(?:le|la|les|l'|l’|de|du|des|d'|d’)\s+)+")


def _nettoyer_surface(surface, categorie=None):
    # Une détection peut déborder sur la syntaxe Markdown ou HTML (« Jean Dupont](photo.png ») : on coupe.
    surface = next((s for s in re.split(r"\]\(|[\[\]<>|`{}*]", surface) if s.strip()), "")
    surface = surface.strip(" \t\n\"'«»“”‘’()[]{},;:.!?-–—*_#|")
    if categorie != "personne":
        surface = RE_ARTICLE_INITIAL.sub("", surface)
    else:
        # Pour une personne, la particule fait partie du nom (« de Gaulle », « DE GAULLE », « Le Pen ») :
        # on ne retire qu'un article en minuscules, et s'il reste au moins deux mots
        # (« de Marie Donnet » → « Marie Donnet »).
        sans_article = RE_ARTICLE_MINUSCULE.sub("", surface)
        if len(sans_article.split()) >= 2:
            surface = sans_article
    return re.sub(r"\s+", " ", surface).strip()


PARTICULES = {"de", "du", "des", "la", "le", "les", "d'", "l'", "d", "l", "van", "von", "der", "den", "ben", "bin",
              "el", "al", "di", "da", "dos", "del", "et", "&", "y"}
# Particules qui commencent un nom de famille (« Charles de Gaulle », « Ludwig van Beethoven »).
PARTICULES_NOM = PARTICULES - {"et", "&", "y"}
RE_ELISION = re.compile(r"^[dDlL]['’]")
RE_MOT_MINUSCULE = re.compile(r"(?<![\w'’-])[a-zà-ÿ][a-zà-ÿ'’-]{2,}(?![\w])")
FILTRES_DEFAUT = {"min_minuscules": 3, "min_minuscules_spacy": 1, "motifs_exclus": [r"^[A-Za-z]\d{1,3}$"]}


RE_ADRESSES = re.compile(r"\S+@\S+|(?:https?://|www\.)\S+", re.IGNORECASE)

# Intitulés de fonction (français et anglais) : jamais des noms de personnes, même écrits avec une majuscule.
FONCTIONS = {normaliser(m) for m in (
    "manager", "managers", "director", "officer", "advisor", "adviser", "assistant", "associate", "executive",
    "head", "lead", "store", "stores", "sales", "retail", "owner", "consultant", "consultante", "supervisor",
    "directeur", "directrice", "responsable", "chef", "gérant", "gérante", "conseiller", "conseillère",
    "vendeur", "vendeuse", "stagiaire", "alternant", "alternante", "collaborateur", "collaboratrice",
    "assistante", "comptable", "juriste", "avocat", "avocate", "associé", "associée", "président", "présidente",
    "boutique", "agence", "service", "équipe", "equipe", "pilote", "vague", "solution", "agent", "book",
    "analyst", "analyste", "developer", "développeur", "engineer", "ingénieur", "designer", "specialist",
    "spécialiste", "coordinator", "coordinateur", "coordinatrice", "controller", "contrôleur", "buyer", "acheteur",
    "acheteuse", "merchandiser", "intern", "dsi", "daf", "drh", "dg", "pdg", "ceo", "cfo", "cto", "coo", "cio",
    "client", "clients", "fournisseur", "utilisateur", "administrateur")}
# Intitulés qui, dans un nom de société, signalent une fonction (« Store Managers », « Sales Advisor »).
FONCTIONS_SOCIETE = {normaliser(m) for m in (
    "manager", "managers", "advisor", "advisors", "director", "officer", "supervisor", "directeur", "responsable")}
RE_NOM_FICHIER = re.compile(r"\.(?:xlsx?|docx?|pptx?|pdf|jpe?g|png|csv|txt|zip|msg)\b|_", re.IGNORECASE)


def lexique(textes):
    """Mots du lot écrits au moins une fois en minuscules : ce sont des mots courants, pas des noms propres."""
    compteur = Counter()
    for texte in textes:
        compteur.update(normaliser(m) for m in RE_MOT_MINUSCULE.findall(RE_ADRESSES.sub(" ", texte)))
    return compteur


def _mots_nom(surface):
    """Mots d'un nom, sans particules ni titres, découpés aussi sur les traits d'union et apostrophes.

    Les chiffres et les lettres isolées sont écartés (« Vague 2 », « Architecture A » → « Vague », « Architecture »).
    """
    mots = re.split(r"[\s\-'’]+", surface)
    return [m for m in mots if len(m) > 1 and not m.isdigit() and m.lower() not in PARTICULES
            and normaliser(m) not in TITRES]


def _mot_courant(mot, mots_courants, minimum):
    """Vrai si le mot (ou son singulier : « Transports » → « transport ») est écrit en minuscules dans le lot."""
    cle = normaliser(mot)
    nombre = mots_courants.get(cle, 0)
    if len(cle) > 4 and cle[-1] in "sx":
        nombre = max(nombre, mots_courants.get(cle[:-1], 0))
    return nombre >= minimum


def _forme_de_nom_propre(surface, categorie):
    """Chaque mot commence par une majuscule ou un chiffre (hors particules) ; pas de chiffre dans un nom de personne."""
    if categorie == "personne" and re.search(r"\d", surface):
        return False
    for mot in surface.split():
        if mot.lower() in PARTICULES:
            continue
        premier = RE_ELISION.sub("", mot.lstrip("'’(\"«"))[:1]    # « d'Orléans » : la majuscule suit l'apostrophe
        if premier and not (premier.isupper() or premier.isdigit()):
            return False
    return True


def _acceptable(surface, categorie, nlp, dictionnaires, mots_courants=None, filtres=None):
    filtres = {**FILTRES_DEFAUT, **(filtres or {})}
    if len(surface) < 2 or len(surface) > 80 or "\n" in surface:
        return False
    if not any(c.isupper() for c in surface) or not any(c.isalpha() for c in surface):
        return False
    mots = surface.split()
    if len(mots) > 6:
        return False
    cle = normaliser(surface)
    if cle in dictionnaires.exclusions or cle in MOTS_IGNORES:
        return False
    if any(re.search(motif, surface) for motif in filtres["motifs_exclus"]):
        return False
    if RE_NOM_FICHIER.search(surface):        # « Q16_Alertes.xlsx » : un nom de fichier, pas une entité
        return False
    if sensibles.detecter(surface):
        return False
    if categorie in ("personne", "produit", "lieu") and not _forme_de_nom_propre(surface, categorie):
        return False
    if categorie == "personne" and any(normaliser(m) in FONCTIONS for m in _mots_nom(surface)):
        return False
    if categorie == "societe" and any(normaliser(m) in FONCTIONS_SOCIETE for m in _mots_nom(surface)):
        return False
    if mots_courants:
        significatifs = _mots_nom(surface)
        if significatifs and all(_mot_courant(m, mots_courants, filtres["min_minuscules"]) for m in significatifs):
            return False
    if len(mots) == 1:
        if cle in TITRES:
            return False
        if nlp is not None and nlp.vocab[cle].is_stop:
            return False
    elif categorie == "personne" and all(normaliser(m) in TITRES for m in mots):
        return False
    return True


RE_COORDINATION = re.compile(r"\s+(?:et|&)\s+")


def _separer_coordinations(candidats):
    """Les modèles renvoient parfois deux personnes d'un coup (« Maude et Stanislas ») : on les sépare."""
    resultat = []
    for c in candidats:
        if c.categorie == "personne" and c.source != "dictionnaire" and RE_COORDINATION.search(c.surface):
            resultat += [Candidat(p, c.categorie, c.score, c.source, c.fichier)
                         for p in RE_COORDINATION.split(c.surface) if p.strip()]
        else:
            resultat.append(c)
    return resultat


def _morceaux(texte, taille=200):
    """Découpe le texte en morceaux d'environ `taille` mots (limite du modèle GLiNER)."""
    morceaux, courant, n = [], [], 0
    for paragraphe in texte.split("\n"):
        mots = paragraphe.split()
        if n + len(mots) > taille and courant:
            morceaux.append("\n".join(courant))
            courant, n = [], 0
        if len(mots) > taille:
            morceaux += [m.group() for m in re.finditer(r"(?:\S+\s*){1,%d}" % taille, paragraphe)]
        else:
            courant.append(paragraphe)
            n += len(mots)
    if courant:
        morceaux.append("\n".join(courant))
    return morceaux


RE_SUGGESTION = re.compile(
    r"(?<![\w'’-])(?:[A-Z][a-z]+[A-Z][\w]*|[a-z]+[A-Z][\w]*|[A-Z]{3,}[0-9]*|[A-Za-z]+[0-9]+[A-Za-z0-9]*)(?![\w'’-])")


def _suggestions(texte, nlp, deja, fichier, mots_courants=None, filtres=None, nlp_en=None):
    """Termes atypiques (CamelCase, sigles, alphanumériques) : produits possibles, non cochés par défaut."""
    filtres = {**FILTRES_DEFAUT, **(filtres or {})}
    minuscules = set(re.findall(r"\b[a-zà-ÿ]{3,}\b", texte))
    zones_sensibles = [(t.debut, t.fin) for t in sensibles.detecter(texte)]
    candidats = []
    for m in RE_SUGGESTION.finditer(texte):
        mot = m.group()
        if any(m.start() < fin and m.end() > debut for debut, fin in zones_sensibles):
            continue
        if any(re.search(motif, mot) for motif in filtres["motifs_exclus"]):
            continue
        if mots_courants and _mot_courant(mot, mots_courants, filtres["min_minuscules"]):
            continue
        if mot in ACRONYMES_COURANTS or normaliser(mot) in deja or normaliser(mot) in MOTS_IGNORES:
            continue
        if mot.isupper():
            if mot.lower() in minuscules or re.fullmatch(r"[IVXLCDM]+", mot):
                continue
            if any(n is not None and n.vocab[mot.lower()].is_stop for n in (nlp, nlp_en)):
                continue
        if mot.isdigit():
            continue
        candidats.append(Candidat(mot, "produit", 0.3, "suggestion", fichier))
    return candidats


def _dictionnaire(texte, termes, categorie, fichier):
    """Termes du dictionnaire retrouvés avec ou sans accents (« Inès » = « Ines »), quelle que soit la casse."""
    candidats = []
    plie = plier(texte)
    for terme in termes:
        motif = r"(?<![^\W_])" + re.escape(plier(terme)) + r"(?![^\W_])"
        for m in re.finditer(motif, plie, flags=re.IGNORECASE):
            candidats.append(Candidat(texte[m.start():m.end()], categorie, 1.0, "dictionnaire", fichier))
    return candidats


SOURCES_SURES = {"dictionnaire", "nom de fichier", "intitulé"}     # candidats que les filtres de vraisemblance n'écartent pas

RE_INTITULE_PERSONNE = re.compile(
    r"(?im)^[ \t]*(?:collaborateur|collaboratrice|auteur|autrice|salarié|salariée|employé|employée|candidat|candidate|"
    r"interlocuteur|interlocutrice|nom et prénom|prénom et nom|name|employee|author|candidate|prepared by|"
    r"interviewee|participant)[ \t]*:[ \t]*([^\n:|]{3,80})$")


def _suite_de_noms(mots, mots_courants=None):
    """Plus longue suite de mots qui ressemble à un nom (majuscule initiale ; particules et petits mots permis
    à l'intérieur), avec au moins deux mots de nom."""
    suites, courante = [], []
    for m in mots:
        nom = re.fullmatch(r"[A-ZÀ-Ý][\w'’-]*", m) is not None and not m.isdigit() and not (m.isupper() and len(m) < 3) \
            and not (mots_courants and _mot_courant(m, mots_courants, 1))
        petit = courante and m.islower() and len(m) <= 3
        if nom or petit:
            courante.append(m)
        else:
            if courante:
                suites.append(courante)
            courante = []
    if courante:
        suites.append(courante)
    resultat = []
    for s in suites:
        while s and s[-1].islower():
            s = s[:-1]
        if sum(1 for m in s if not m.islower()) >= 2:
            resultat.append(s)
    return resultat


def _noms_dans_intitules(texte, fichier):
    """Personnes introduites par un intitulé (« Collaborateur : Mila Lin an Park ») : très fiable, jamais écartées."""
    candidats = []
    for m in RE_INTITULE_PERSONNE.finditer(texte):
        for suite in _suite_de_noms(m.group(1).split()):
            if len(suite) <= 6:
                candidats.append(Candidat(" ".join(suite), "personne", 0.9, "intitulé", fichier))
    return candidats


def _noms_du_fichier(texte, fichier, mots_courants=None):
    """Personne dont le nom figure dans le nom du fichier (« Rapport_Individuel_Mila_Lin_an_Park.docx ») et dans le texte."""
    mots = [m for m in re.split(r"[_\s]+", Path(str(fichier)).stem) if m]
    candidats = []
    for suite in _suite_de_noms(mots, mots_courants):
        for debut in range(len(suite)):                  # on essaie la suite entière, puis ses fins plus courtes
            morceau = suite[debut:]
            if sum(1 for m in morceau if not m.islower()) < 2 or morceau[0].islower():
                continue
            motif = r"(?<![^\W_])" + r"[\s_\-]+".join(re.escape(m) for m in morceau) + r"(?![^\W_])"
            trouves = {x.group() for x in re.finditer(motif, texte)}
            if trouves:
                candidats += [Candidat(t, "personne", 0.9, "nom de fichier", fichier) for t in trouves]
                break
    return candidats


TAILLE_LOT_GLINER = 4     # morceaux de ~200 mots traités par appel : un point d'avancement toutes les quelques secondes


def _filtres_source(filtres, source):
    """spaCy est moins précis que GLiNER sur les noms propres : un seul emploi en minuscules dans le lot
    (« impact », « transport ») suffit à écarter ce qu'il propose seul."""
    filtres = {**FILTRES_DEFAUT, **filtres}
    if source == "spaCy":
        filtres["min_minuscules"] = filtres["min_minuscules_spacy"]
    return filtres


def analyser(texte, fichier, modeles, dictionnaires, mots_courants=None, rappel=None):
    """Candidats entités (personnes, sociétés, produits, lieux) trouvés dans le texte d'un fichier.

    `mots_courants` : lexique du lot (mots vus en minuscules), qui écarte « Manager », « Solution »…
    `rappel(modele, fait, total)` : appelé régulièrement pour afficher l'avancement au sein du fichier.
    """
    candidats = []
    nlp = modeles.nlp
    filtres = modeles.config.get("filtres", {})
    seuils = modeles.config["gliner"].get("seuils", {})
    seuil_global = modeles.config["gliner"]["seuil"]

    candidats += _dictionnaire(texte, dictionnaires.personnes, "personne", fichier)
    candidats += _dictionnaire(texte, dictionnaires.societes, "societe", fichier)
    candidats += _dictionnaire(texte, dictionnaires.produits, "produit", fichier)
    candidats += _dictionnaire(texte, dictionnaires.lieux, "lieu", fichier)
    candidats += _noms_dans_intitules(texte, fichier)
    candidats += _noms_du_fichier(texte, fichier, mots_courants)

    # Chaque paragraphe est analysé par le modèle spaCy de sa langue (français ou anglais). Un texte anglais n'est jamais
    # confié au modèle français, qui y ajoute du bruit ; sans modèle anglais installé, GLiNER (multilingue) s'en charge seul.
    langue_fichier = langues.detecter(texte)
    paragraphes = [p for p in texte.split("\n") if p.strip()]
    par_langue = {"fr": [], "en": []}
    fait = 0                    # paragraphes traités ou écartés ; ceux d'une autre langue (de, es, it) : GLiNER seul
    for p in paragraphes:
        code = langues.detecter(p, langue_fichier)
        if code in par_langue:
            par_langue[code].append(p)
        else:
            fait += 1
    for code, modele_spacy, etiquettes in (("fr", nlp, LABELS_SPACY), ("en", modeles.nlp_en, LABELS_SPACY_EN)):
        if modele_spacy is None:
            fait += len(par_langue[code])
            continue
        for doc in modele_spacy.pipe(par_langue[code], batch_size=64):
            fait += 1
            for ent in doc.ents:
                categorie = etiquettes.get(ent.label_)
                if categorie:
                    candidats.append(Candidat(ent.text, categorie, 0.7, "spaCy", fichier, code))
            if rappel and (fait % 20 == 0 or fait == len(paragraphes)):
                rappel("spaCy", fait, len(paragraphes))

    if modeles.gliner is not None:
        morceaux = [m for m in _morceaux(texte) if m.strip()]
        plancher = min([seuil_global, *seuils.values()])
        # Par petits lots, pour que l'avancement soit mis à jour même sur un long document.
        for debut in range(0, len(morceaux), TAILLE_LOT_GLINER):
            lot_morceaux = morceaux[debut:debut + TAILLE_LOT_GLINER]
            resultats = modeles.gliner.inference(lot_morceaux, list(LABELS_GLINER),
                                                 threshold=plancher, batch_size=TAILLE_LOT_GLINER)
            for morceau, entites_morceau in zip(lot_morceaux, resultats):
                code = langues.detecter(morceau, langue_fichier)
                for ent in entites_morceau:
                    if float(ent["score"]) < seuils.get(ent["label"], seuil_global):
                        continue
                    candidats.append(Candidat(ent["text"], LABELS_GLINER[ent["label"]],
                                              round(float(ent["score"]), 2), "GLiNER", fichier, code))
            if rappel:
                rappel("GLiNER", min(debut + TAILLE_LOT_GLINER, len(morceaux)), len(morceaux))

    propres = []
    candidats = _separer_coordinations(candidats)
    for c in candidats:
        c.surface = _nettoyer_surface(c.surface, c.categorie)
    # Les mots d'un nom complet accepté (« Mila Lin-an Park ») restent acceptés seuls (« Mila »),
    # même si le mot est aussi un nom commun.
    composants = set()
    for c in candidats:
        if c.categorie == "personne" and len(c.surface.split()) >= 2 and (
                c.source in SOURCES_SURES
                or _acceptable(c.surface, c.categorie, modeles.nlp_pour(c.langue), dictionnaires, mots_courants,
                               _filtres_source(filtres, c.source))):
            composants.update(m.lower() for m in _mots_nom(c.surface))
    for c in candidats:
        if c.source in SOURCES_SURES or _acceptable(c.surface, c.categorie, modeles.nlp_pour(c.langue), dictionnaires, mots_courants,
                                                     _filtres_source(filtres, c.source)):
            propres.append(c)
        elif (c.categorie == "personne" and c.surface.lower() in composants
              and _acceptable(c.surface, c.categorie, modeles.nlp_pour(c.langue), dictionnaires, None, filtres)):
            propres.append(c)

    deja = {normaliser(c.surface) for c in propres}
    for c in propres:
        deja.update(normaliser(m) for m in c.surface.split())
    propres += _suggestions(texte, nlp, deja, fichier, mots_courants, filtres, modeles.nlp_en)
    return propres
