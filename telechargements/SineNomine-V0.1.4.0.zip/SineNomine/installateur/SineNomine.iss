﻿; Installateur de Sine Nomine (Inno Setup 6). Construit par installateur/construire_installateur.py :
;   python installateur/construire_installateur.py
; Il copie les fichiers dans le dossier choisi par l'utilisateur (modifiable, ou à créer), propose les raccourcis,
; puis lance installer.bat qui prépare Python, les bibliothèques et les modèles (connexion Internet nécessaire).
; Signature de code : une fois le certificat acheté, décommentez SignTool et SignedUninstaller (voir installateur/LISEZMOI.md).

#ifndef Version
  #define Version "0.0.0"
#endif

[Setup]
AppId={{8B2F6A1E-3C47-4E5D-9A71-5D0C2B6E4F13}
AppName=Sine Nomine
AppVersion={#Version}
AppVerName=Sine Nomine {#Version}
AppPublisher=Habeas Corpus S.A.S.
AppPublisherURL=https://www.sinenomine.app
AppSupportURL=https://www.sinenomine.app
AppUpdatesURL=https://www.sinenomine.app/telecharger/
DefaultDirName={localappdata}\Programs\Sine Nomine
DisableProgramGroupPage=yes
DisableDirPage=no
; Les dossiers de travail (entree, sortie, correspondances) sont créés dans le dossier d'installation :
; une installation par utilisateur, sans droits d'administrateur, évite les problèmes d'écriture.
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
ExtraDiskSpaceRequired=6442450944
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=build\stage\anonymiseur\static\sine-nomine.ico
UninstallDisplayIcon={app}\anonymiseur\static\sine-nomine.ico
OutputDir=build\sortie
OutputBaseFilename=SineNomine-Setup-V{#Version}
; SignTool=signtool
; SignedUninstaller=yes

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"; LicenseFile: "build\stage\LICENCE.fr.txt"
Name: "english"; MessagesFile: "compiler:Default.isl"; LicenseFile: "build\stage\LICENCE.en.txt"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "menuicon"; Description: "{cm:AddToStartMenu}"; GroupDescription: "{cm:AdditionalIcons}"

[CustomMessages]
french.CreateDesktopIcon=Créer un raccourci sur le &Bureau
french.AddToStartMenu=Ajouter Sine Nomine au menu &Démarrer
french.AdditionalIcons=Raccourcis :
french.PreparingEnv=Préparation de Sine Nomine (Python, bibliothèques et modèles de détection)…
french.PreparingNote=Une fenêtre noire va s'ouvrir : elle installe Python si besoin, puis télécharge environ 2 Go de modèles. Laissez-la ouverte jusqu'à la fin ; cela peut prendre un temps assez long selon votre connexion Internet.
french.EnvFailed=La préparation de Sine Nomine n'a pas abouti (code %1). Vérifiez votre connexion Internet, puis double-cliquez sur « installer.bat » dans le dossier d'installation pour recommencer.
english.CreateDesktopIcon=Create a &Desktop shortcut
english.AddToStartMenu=Add Sine Nomine to the &Start menu
english.AdditionalIcons=Shortcuts:
english.PreparingEnv=Preparing Sine Nomine (Python, libraries and detection models)…
english.PreparingNote=A black window will open: it installs Python if needed, then downloads about 2 GB of models. Keep it open until it finishes; this can take a while depending on your Internet connection.
english.EnvFailed=Sine Nomine could not be prepared (code %1). Check your Internet connection, then double-click "installer.bat" in the installation folder to try again.

french.KeyTitle=Clé d'accès
french.KeyDesc=Saisissez la clé d'accès de votre version d'évaluation.
french.KeyLabel=Clé d'accès (SN-XXXXX-XXXXX-XXXXX-XXXXX) :
french.KeyEmpty=Saisissez votre clé d'accès. Pour en obtenir une : contact@sinenomine.app.
french.KeyOk=Cette clé est valable : elle peut encore être utilisée %1 fois. L'installation va la consommer une fois.
french.KeyFormat=Cette clé n'a pas le bon format. Elle ressemble à SN-XXXXX-XXXXX-XXXXX-XXXXX.
french.KeyUnknown=Cette clé est inconnue. Vérifiez-la ou contactez contact@sinenomine.app.
french.KeyRevoked=Cette clé a été désactivée. Contactez contact@sinenomine.app.
french.KeyExhausted=Cette clé a déjà été utilisée pour toutes les installations prévues. Contactez contact@sinenomine.app.
french.KeyLimit=Trop de tentatives. Réessayez dans quelques minutes.
french.KeyNoServer=Le serveur d'activation est injoignable (vérifiez votre connexion Internet). Voulez-vous installer quand même ? Vous activerez ensuite avec « activer.bat ».
french.KeyOther=La clé n'a pas pu être vérifiée. Réessayez, ou contactez contact@sinenomine.app.
english.KeyTitle=Access key
english.KeyDesc=Enter the access key of your evaluation version.
english.KeyLabel=Access key (SN-XXXXX-XXXXX-XXXXX-XXXXX):
english.KeyEmpty=Enter your access key. To get one: contact@sinenomine.app.
english.KeyOk=This key is valid: it can still be used %1 time(s). The installation will use it once.
english.KeyFormat=This key does not have the right format. It looks like SN-XXXXX-XXXXX-XXXXX-XXXXX.
english.KeyUnknown=This key is unknown. Check it or contact contact@sinenomine.app.
english.KeyRevoked=This key has been deactivated. Contact contact@sinenomine.app.
english.KeyExhausted=This key has already been used for all the installations it allows. Contact contact@sinenomine.app.
english.KeyLimit=Too many attempts. Try again in a few minutes.
english.KeyNoServer=The activation server cannot be reached (check your Internet connection). Install anyway? You can then activate with "activer.bat".
english.KeyOther=The key could not be checked. Try again, or contact contact@sinenomine.app.

[Files]
Source: "build\stage\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion createallsubdirs

[Icons]
Name: "{autodesktop}\Sine Nomine"; Filename: "{app}\environnement\Scripts\pythonw.exe"; Parameters: "-B -m anonymiseur"; WorkingDir: "{app}"; IconFilename: "{app}\anonymiseur\static\sine-nomine.ico"; Comment: "Sine Nomine"; Tasks: desktopicon
Name: "{autoprograms}\Sine Nomine"; Filename: "{app}\environnement\Scripts\pythonw.exe"; Parameters: "-B -m anonymiseur"; WorkingDir: "{app}"; IconFilename: "{app}\anonymiseur\static\sine-nomine.ico"; Comment: "Sine Nomine"; Tasks: menuicon

[UninstallDelete]
; Seul l'environnement Python créé à l'installation est supprimé. Les dossiers entree, sortie, correspondances et
; dictionnaires (vos fichiers et l'archive des codes) ne sont jamais effacés par la désinstallation.
Type: filesandordirs; Name: "{app}\environnement"

[Code]
const
  ServeurActivation = 'https://activation.sinenomine.app';

var
  PageCle: TInputQueryWizardPage;
  CleSaisie: String;

function CodeLangue: String;
begin
  if ActiveLanguage = 'english' then Result := 'en' else Result := 'fr';
end;

// Ne garde que les caractères d'une clé (lettres, chiffres, tirets) : rien d'autre ne part vers le serveur.
function NettoyerCle(Texte: String): String;
var
  I: Integer;
  C: Char;
begin
  Result := '';
  for I := 1 to Length(Texte) do
  begin
    C := Texte[I];
    if ((C >= 'A') and (C <= 'Z')) or ((C >= 'a') and (C <= 'z')) or ((C >= '0') and (C <= '9')) or (C = '-') then
      Result := Result + C;
  end;
end;

// Interroge le serveur sans consommer d'installation. Renvoie True si la clé est valable ; Message : à afficher.
// Serveur injoignable : Injoignable = True (on propose de continuer et d'activer plus tard).
function VerifierCle(Cle: String; var Message: String; var Injoignable: Boolean): Boolean;
var
  Http: Variant;
  Reponse, Restantes: String;
  P: Integer;
begin
  Result := False;
  Injoignable := False;
  try
    Http := CreateOleObject('WinHttp.WinHttpRequest.5.1');
    Http.Open('POST', ServeurActivation + '/api/v1/verifier', False);
    Http.SetRequestHeader('Content-Type', 'application/json');
    Http.SetTimeouts(10000, 10000, 15000, 15000);
    Http.Send('{"cle":"' + Cle + '","langue":"' + CodeLangue + '"}');
    Reponse := Http.ResponseText;
    case Http.Status of
      200:
        begin
          Restantes := '?';
          P := Pos('"restantes":', Reponse);
          if P > 0 then
          begin
            Restantes := '';
            P := P + Length('"restantes":');
            while (P <= Length(Reponse)) and (Reponse[P] = ' ') do P := P + 1;
            while (P <= Length(Reponse)) and (Reponse[P] >= '0') and (Reponse[P] <= '9') do
            begin
              Restantes := Restantes + Reponse[P];
              P := P + 1;
            end;
          end;
          Message := FmtMessage(CustomMessage('KeyOk'), [Restantes]);
          Result := True;
        end;
      400: Message := CustomMessage('KeyFormat');
      404: Message := CustomMessage('KeyUnknown');
      429: Message := CustomMessage('KeyLimit');
      403:
        if Pos('revoquee', Reponse) > 0 then Message := CustomMessage('KeyRevoked')
        else Message := CustomMessage('KeyExhausted');
    else
      Message := CustomMessage('KeyOther');
    end;
  except
    Injoignable := True;
    Message := CustomMessage('KeyNoServer');
  end;
end;

procedure InitializeWizard;
begin
  PageCle := CreateInputQueryPage(wpLicense, CustomMessage('KeyTitle'), CustomMessage('KeyDesc'), '');
  PageCle.Add(CustomMessage('KeyLabel'), False);
  PageCle.Values[0] := ExpandConstant('{param:CLE|}');
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Message: String;
  Injoignable: Boolean;
begin
  Result := True;
  if CurPageID = PageCle.ID then
  begin
    CleSaisie := NettoyerCle(PageCle.Values[0]);
    if CleSaisie = '' then
    begin
      MsgBox(CustomMessage('KeyEmpty'), mbError, MB_OK);
      Result := False;
    end
    else if VerifierCle(CleSaisie, Message, Injoignable) then
      MsgBox(Message, mbInformation, MB_OK)
    else if Injoignable then
      Result := MsgBox(Message, mbConfirmation, MB_YESNO) = IDYES
    else
    begin
      MsgBox(Message, mbError, MB_OK);
      Result := False;
    end;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Code: Integer;
  Texte: AnsiString;
begin
  // /SKIPENV=1 : copie des fichiers et raccourcis seulement (tests de l'installateur)
  if (CurStep = ssPostInstall) and (ExpandConstant('{param:SKIPENV|0}') <> '1') then
  begin
    WizardForm.StatusLabel.Caption := CustomMessage('PreparingEnv');
    if WizardSilent then
      CleSaisie := NettoyerCle(ExpandConstant('{param:CLE|}'));
    if not WizardSilent then
      MsgBox(CustomMessage('PreparingNote'), mbInformation, MB_OK);
    if CleSaisie <> '' then
      SaveStringToFile(ExpandConstant('{app}\cle.tmp'), CleSaisie + ' ' + CodeLangue + #13#10, False);
    if not Exec(ExpandConstant('{cmd}'), '/c "set SN_INSTALLATEUR=1&& "' + ExpandConstant('{app}\installer.bat') + '""',
                ExpandConstant('{app}'), SW_SHOW, ewWaitUntilTerminated, Code) or (Code <> 0) then
      MsgBox(FmtMessage(CustomMessage('EnvFailed'), [IntToStr(Code)]), mbError, MB_OK)
    else if (not WizardSilent) and LoadStringFromFile(ExpandConstant('{app}\activation.txt'), Texte) then
      MsgBox(String(Texte), mbInformation, MB_OK);
    DeleteFile(ExpandConstant('{app}\activation.txt'));
    DeleteFile(ExpandConstant('{app}\cle.tmp'));
  end;
end;
