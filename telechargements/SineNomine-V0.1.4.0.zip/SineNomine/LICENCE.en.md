# Sine Nomine terms of use (English)

© 2026 Habeas Corpus Consulting, a trademark of Habeas Corpus S.A.S. — contact@sinenomine.app — +33 1 89 16 73 22

*Courtesy translation of [LICENCE.md](LICENCE.md), identical to the text shown in the English interface (`anonymiseur/textes.py`). In the event of any discrepancy, the French version prevails. To be reviewed by a lawyer before any distribution.*

## Intellectual property and use

Sine Nomine is the exclusive intellectual property of Habeas Corpus S.A.S. (Habeas Corpus Consulting is a trademark of Habeas Corpus S.A.S.). An access key, entered at installation or in the application, grants a personal, non-exclusive, non-transferable right of use for the period attached to the key (counted from activation, or with no time limit for a lifetime licence) and for the number of installations it allows. An evaluation-version key limits use to evaluating the software: it may cover your own documents, provided you are entitled to process their data, but it is not production use. A commercial-version key allows professional use on the terms of the contract concluded with Habeas Corpus S.A.S. You may not circumvent or disable the activation mechanism, redistribute the software or make it available to third parties. When the period attached to the key ends, any continued use requires a new key or the prior written consent of Habeas Corpus S.A.S., to be requested from contact@sinenomine.app or on +33 1 89 16 73 22.

Sine Nomine relies on open-source components which remain subject to their own licences (see `THIRD_PARTY_NOTICES.md`). They are not redistributed with Sine Nomine.

## Warranty and liability

Sine Nomine is provided “as is”, without warranty of any kind, express or implied, including as to the completeness of detection, fitness for a particular purpose or freedom from errors. To the fullest extent permitted by law, Habeas Corpus S.A.S. is not liable for any direct or indirect damage that may result from the use of the tool, its operation or its malfunctions, including where information is not detected, wrongly replaced or disclosed. This exclusion does not apply in cases of gross negligence or wilful misconduct, nor where the law prohibits excluding liability. The user remains solely responsible for checking the files produced and for how they are used.

## Detection reliability

No automatic detection is 100% reliable. Names, companies, products, places or sensitive information may go undetected, or be detected wrongly. Human review of each processing run is essential, and the files produced must be proofread before any distribution.

## Confidentiality and file locations

Sine Nomine processes your files only on your computer and sends none of your documents and no names over the Internet. The Internet is used only during installation: to download the components and the detection models, and (at installation or when you enter a new key in the application) to activate your access key with Habeas Corpus S.A.S.'s activation server, which receives only the key, a random installation identifier, the version and the language (see the privacy policy at https://www.sinenomine.app). Once installed, Sine Nomine works offline. If you place Sine Nomine's folders or your files in a synchronisation or archiving service (Google Drive, OneDrive or any other), it is that service that transmits and stores the files, under its own terms and at your own responsibility. With files kept only on the local disk, no document leaves the computer.

## Pseudonymisation and anonymisation

*Pseudonymisation.* Each name is replaced by a random code (for example Personne_KQXMB). The correspondence table and the code archive (archive_codes.json) make it possible to recover the original information and to de-pseudonymise files: under the GDPR this is pseudonymisation, not anonymisation. These files contain the original information in clear: keep them separately and securely, or delete them if you do not need them.

*Anonymisation.* Names are replaced by numbers (Personne_1, Société_1…) and no correspondence table or archive is kept: Sine Nomine keeps no means of recovering the original names from the files produced. This mode does not guarantee that the result is anonymous within the meaning of the GDPR: a text may remain identifiable by cross-referencing (role, place, event, combination of information). Proofread it before sharing.

## Governing law

These terms are governed by French law. Failing an amicable agreement, any dispute falls within the jurisdiction of the courts of Paris, subject to mandatory rules of jurisdiction, in particular in favour of consumers. In the event of any discrepancy between the French and English versions, the French version prevails.
