# Historique des versions de Sine Nomine

Chaque version est publiée sur GitHub avec une étiquette `V<numéro>` (V0.1.3.5, V0.1.3.6…).

## V0.1.4.0
Étape 1 de la version commercialisable (voir docs/FEUILLE_DE_ROUTE.md) : sécurité du serveur local (session par jeton d'ouverture à
usage unique, protection CSRF, validation de l'hôte et de l'origine contre le DNS rebinding, politique de sécurité de contenu,
en-têtes sans cache, rapports HTML isolés), validation et confinement centralisés des chemins et noms de fichiers (lecteurs, chemins
réseau, flux NTFS, noms réservés, jonctions, collisions), neutralisation des formules dans les tableurs produits. Contact unique :
contact@sinenomine.app ; mentions légales complétées.

## V0.1.3.11
Types de licence (évaluation ou commerciale) et licences à vie : le bandeau de l'application indique le type et la date de fin, ou
« valable à vie » ; à l'expiration, le message précise depuis combien de jours et le bouton « Saisir une clé » permet de saisir un
nouveau code d'activation directement dans l'application. Textes juridiques, politique de confidentialité et site mis à jour.

## V0.1.3.10
Version d'évaluation sur clé d'accès : serveur d'activation (clés avec nombre d'installations et durée, licence signée Ed25519,
vérification hors ligne), page de clé dans l'installateur Windows (vérification avant installation, nombre d'utilisations restantes),
bandeau de licence, blocage du traitement sans licence valable (la dé-pseudonymisation reste libre), textes juridiques et politique
de confidentialité mis à jour. Correction : installer.bat sautait le téléchargement des modèles de détection depuis la V0.1.3.7.

## V0.1.3.9
Préparation de Linux et macOS (install.sh, lancer.sh, Sine Nomine.command, creer-raccourci.sh ; ouverture des dossiers, journal et
Tesseract selon le système). Installateur Windows (Inno Setup) : dossier d'installation au choix, raccourcis en option,
environnement Python dans le dossier de Sine Nomine. Vérification des licences des composants et des modèles.

## V0.1.3.8
Console : les avertissements sans effet de torch et huggingface_hub ne s'affichent plus au démarrage.

## V0.1.3.7
Lecture des fichiers PDF en entrée : le texte est extrait (pypdf), anonymisé, puis écrit dans le format choisi (Word, PowerPoint,
Markdown, texte, HTML ou Excel). Les PDF scannés sont lus par reconnaissance de caractères (Tesseract, installé par installer.bat).

## V0.1.3.6
Correction de l'erreur « ValueError : not enough values to unpack (expected 2, got 1) » à la confirmation d'un lot quand une
exception « Conserver » était cochée dans l'onglet des informations sensibles : le séparateur invisible de la clé était
effacé par le navigateur. Le serveur ignore désormais une exception mal formée au lieu de s'arrêter.

## V0.1.3.5
Première version enregistrée dans le dépôt. Fonctions : anonymisation et pseudonymisation (docx, pptx, xlsx, csv, html, txt, md),
archive des codes et dé-pseudonymisation, correction de pseudonymes, validation guidée par onglets avec examen du contexte,
indicateur d'avancement, interface bilingue français / anglais, documents en français et en anglais (UK et US),
détection des URL, noms de domaine, chemins de fichiers, IPv6/MAC, coordonnées GPS, BIC et numéros de châssis.
