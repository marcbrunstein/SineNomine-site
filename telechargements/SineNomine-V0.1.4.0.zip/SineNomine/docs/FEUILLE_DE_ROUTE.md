# Feuille de route : version commercialisable de Sine Nomine

Ce fichier garde l'état du chantier d'une session à l'autre. Il est mis à jour à la fin de chaque étape. Cahier des charges d'origine :
transmis par l'éditeur (novembre 2026). Chaque étape est testée, fusionnée dans `main` et publiée sous une étiquette `V0.1.4.x`.

## Décisions prises (réponses de l'éditeur et défauts retenus)

| Sujet | Décision |
|---|---|
| Contact | `contact@sinenomine.app` partout. Éditeur dans les mentions légales : HABEAS CORPUS (SASU), capital 2 000 €, siège 5 route du Bosc André, 27230 Saint-Germain-la-Campagne, RCS Bernay 898 734 231, Président : Marc Brunstein. |
| Plateforme | Windows uniquement pour la version commerciale ; scripts Linux et macOS conservés mais non maintenus. |
| Évaluation | 12 mois par défaut (6 mois possible) ; quota d'activations par défaut : 1 ; licence perpétuelle : quota 1. |
| Expiration | Commune au code : fin du mois de première activation + durée en mois calendaires ; instant technique = 1er jour suivant à 00 h 00, Europe/Paris. Calculée côté serveur, incluse dans le justificatif signé. |
| Quota | Cumulatif, transactionnel, idempotent ; aucune activation rendue automatiquement. |
| Codes | Deux mots latins (7 lettres au plus) + suffixe de contrôle ; liste issue de sources libres (Wiktionnaire latin CC BY-SA, dictionnaires du domaine public), attribution conservée. |
| Droits couverts | Une licence perpétuelle couvre toutes les versions de la même série majeure ; correctifs de sécurité 12 mois après la dernière version ; aucun support inclus. |
| Poste | Identifiant d'installation aléatoire + justificatif protégé par le compte Windows (DPAPI) ; aucune empreinte matérielle. |
| Administration | Application web sur le VPS (mot de passe + TOTP) + ligne de commande ; rôles éditeur et distributeur (le distributeur crée des codes dans une enveloppe fixée par l'éditeur). |
| Coffre | Chiffrement de champs AES-256-GCM (bibliothèque `cryptography`), index chiffrés par HMAC ; clé protégée par DPAPI + phrase de récupération ; sauvegarde portable chiffrée. |
| Périmètres | Document, Projet (défaut), Client ; identifiants internes aléatoires ; noms de clients et de projets dans le coffre ; restauration : périmètre choisi par l'utilisateur et vérifié par recoupement des codes. |
| Identifiant de document | Dans le coffre, lié à l'empreinte du fichier source ; rien d'ajouté dans les fichiers produits. |
| Recherche | Exacte, puis équivalence normalisée, puis approximative à valider : distance 1 pour les mots de 5 à 8 lettres, 2 au-delà, jamais sous 5 lettres. |
| Profils | 20 profils au maximum au total : 3 standards en lecture seule (Préparation pour une IA, Juridique, Recrutement) + 17 personnels. Contenu des standards rédigé par nos soins, à faire valider. |
| Généralisation | Version 1 : dates (code ou année) et âges (tranches). Lieux : plus tard (base géographique à choisir). |
| PDF | Conversion locale par LibreOffice (MPL-2.0, composant facultatif) ; Office utilisable si choisi explicitement. PDF préservant la présentation : hors version 1. |
| Langues | Anglais inclus ; français, allemand, italien, espagnol en packs (allemand, italien, espagnol : « version de test »). Licences des modèles à vérifier avant inclusion ; repli : GLiNER seul + règles. |
| Composants | Téléchargés depuis leurs sources d'origine, révisions figées, empreintes vérifiées. |
| Rapports | Rapport partageable minimal (sans noms ni miniatures) ; informations de travail dans le coffre. |
| Conservation | Aperçus et journaux 12 mois (réglable) ; lots jamais supprimés automatiquement. |
| Tests | Données synthétiques uniquement (corpus de 200 documents, FR/EN d'abord). La migration des archives réelles est validée sur des copies synthétiques ; l'éditeur la lance lui-même après sauvegarde. |

## État d'avancement

| Étape | Contenu | État |
|---|---|---|
| 1 | Sécurité du serveur local : session, jeton d'ouverture, CSRF, Host/Origin, CSP, confinement des chemins, formules | **Réalisée et testée** (V0.1.4.0) |
| 2 | Coffre chiffré transactionnel, concurrence des archives, publication récupérable, migration | À faire |
| 3 | Périmètres (client, projet, document) | À faire |
| 4 | Validation : termes imposés, fusion, choix par occurrence, masquage, historique | À faire |
| 5 | Contrôles finaux, comparaison avant/après, publication | À faire |
| 6 | Profils, langues, exports PDF, limites des fichiers malformés | À faire |
| 7 | Licences : serveur, administration, expiration commune, quota | À faire (une première version existe : V0.1.3.11, à faire évoluer) |
| 8 | Installation reproductible, informations pour le support, SBOM, documentation | À faire |

## Étape 1 : écarts constatés avant correction, et résultat

Constats vérifiés dans le code de V0.1.3.11 :

- Aucune session, aucun jeton CSRF, aucune validation de l'hôte : n'importe quelle page web ouverte dans le navigateur pouvait appeler
  l'API locale (fichiers, archive, arrêt du serveur). **Corrigé.**
- Validation des noms déposés limitée à la recherche de « .. » : lettres de lecteur, chemins réseau, flux NTFS, noms réservés Windows,
  collisions de casse (« A.txt » écrasant « a.txt ») non traités. **Corrigé** (`anonymiseur/chemins.py`, utilisé par les trois routes de dépôt).
- Rapport HTML servi avec les mêmes droits que l'application. **Corrigé** : politique de sécurité isolant (`sandbox`).
- Cellules Excel des rapports interprétables comme formules (`=`, `+`, `-`, `@`). **Corrigé** (`anonymiseur/tableur.py`).
- Un gestionnaire d'événement `onerror` dans le code de l'interface empêchait une politique de sécurité stricte. **Corrigé.**

Constats confirmés, **non encore corrigés** (étape 2) : plusieurs lots chargent chacun l'archive des codes puis l'écrasent à l'enregistrement
(risque de perte de correspondances) ; l'archive des codes est en JSON clair ; table Excel de correspondances en clair à chaque lot.

Limites connues de l'étape 1 : le serveur local écoute sur 127.0.0.1 ; un programme malveillant exécuté sous le même compte Windows peut lire
`instance.json` (secret de réouverture) comme n'importe quel fichier du profil. La protection vise les pages web et les autres comptes.
