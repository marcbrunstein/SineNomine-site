# Conditions d'utilisation de Sine Nomine

© 2026 Habeas Corpus Consulting, marque de Habeas Corpus S.A.S. — contact@sinenomine.app — +33 1 89 16 73 22

*Ce texte reprend celui qui s'affiche dans l'interface (`anonymiseur/textes.py`). À faire valider par un juriste avant toute diffusion.*

## Propriété intellectuelle et usage

Sine Nomine est la propriété intellectuelle exclusive de Habeas Corpus S.A.S. (Habeas Corpus Consulting est une marque de Habeas Corpus S.A.S.). Une clé d'accès, saisie à l'installation ou dans l'application, concède un droit d'utilisation personnel, non exclusif et non cessible, pour la durée attachée à la clé (comptée à partir de l'activation, ou sans limite de durée pour une licence à vie) et pour le nombre d'installations qu'elle autorise. Une clé de version d'évaluation limite l'usage à l'évaluation du logiciel : elle peut porter sur vos propres documents, dans la mesure où vous avez le droit d'en traiter les données, mais ne constitue pas un usage en production. Une clé de version commerciale permet l'usage professionnel dans les conditions du contrat conclu avec Habeas Corpus S.A.S. Il est interdit de contourner ou de désactiver le mécanisme d'activation, de redistribuer le logiciel ou de le mettre à disposition de tiers. À l'issue de la durée attachée à la clé, toute poursuite de l'utilisation nécessite une nouvelle clé ou l'accord préalable et écrit de Habeas Corpus S.A.S., à demander à contact@sinenomine.app ou au +33 1 89 16 73 22.

Sine Nomine s'appuie sur des composants libres qui restent soumis à leurs propres licences (voir `THIRD_PARTY_NOTICES.md`). Ils ne sont pas redistribués avec Sine Nomine.

## Garantie et responsabilité

Sine Nomine est fourni « en l'état », sans garantie d'aucune sorte, expresse ou implicite, notamment quant à l'exhaustivité de la détection, à l'adéquation à un usage particulier ou à l'absence d'erreur. Dans toute la mesure permise par la loi, Habeas Corpus S.A.S. n'est pas responsable des dommages directs ou indirects pouvant résulter de l'utilisation de l'outil, de son fonctionnement ou de ses dysfonctionnements, y compris en cas d'information non détectée, mal remplacée ou divulguée. Cette exclusion ne s'applique ni en cas de faute lourde ou de dol, ni dans les cas où la loi interdit de l'écarter. L'utilisateur reste seul responsable de la vérification des fichiers produits et de l'usage qu'il en fait.

## Fiabilité de la détection

Aucune détection automatique n'est fiable à 100 %. Des noms, sociétés, produits, lieux ou informations sensibles peuvent ne pas être détectés, ou être détectés à tort. La validation humaine de chaque traitement est indispensable, et les fichiers produits doivent être relus avant toute diffusion.

## Confidentialité et emplacement des fichiers

Sine Nomine traite vos fichiers uniquement sur votre ordinateur et n'envoie aucun de vos documents ni aucun nom sur Internet. Internet n'est utilisé qu'à l'installation : pour télécharger les composants et les modèles de détection, et (à l'installation ou lorsque vous saisissez une nouvelle clé dans l'application) pour activer votre clé d'accès auprès du serveur d'activation de Habeas Corpus S.A.S., qui ne reçoit que la clé, un identifiant d'installation aléatoire, la version et la langue (voir la politique de confidentialité sur https://www.sinenomine.app). Une fois installé, Sine Nomine fonctionne hors ligne. Si vous placez les dossiers de Sine Nomine ou vos fichiers dans un service de synchronisation ou d'archivage (Google Drive, OneDrive ou tout autre), c'est ce service qui transmet et conserve les fichiers, selon ses propres conditions et sous votre responsabilité. Avec des fichiers uniquement sur le disque local, aucun document ne quitte l'ordinateur.

## Pseudonymisation et anonymisation

*Pseudonymisation.* Chaque nom est remplacé par un code aléatoire (par exemple Personne_KQXMB). La table de correspondance et l'archive des codes (archive_codes.json) permettent de retrouver les informations d'origine et de désanonymiser les fichiers : au sens du RGPD, il s'agit d'une pseudonymisation et non d'une anonymisation. Ces fichiers contiennent les informations d'origine en clair : conservez-les à part, de manière sécurisée, ou supprimez-les si vous n'en avez pas besoin.

*Anonymisation.* Les noms sont remplacés par des numéros (Personne_1, Société_1…) et aucune table de correspondance ni archive n'est conservée : Sine Nomine ne garde aucun moyen de retrouver les noms d'origine à partir des fichiers produits. Ce mode ne garantit pas que le résultat soit anonyme au sens du RGPD : un texte peut rester identifiable par recoupement (fonction, lieu, événement, combinaison d'informations). Relisez-le avant diffusion.

## Loi applicable

Les présentes conditions sont soumises au droit français. À défaut d'accord amiable, tout litige relève des tribunaux de Paris, sous réserve des règles de compétence impératives, notamment en faveur des consommateurs.
