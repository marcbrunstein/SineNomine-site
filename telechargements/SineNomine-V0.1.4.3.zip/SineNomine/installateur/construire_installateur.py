"""Construit l'installateur Windows de Sine Nomine (installateur/build/sortie/SineNomine-Setup-V<version>.exe).

Prérequis : Inno Setup 6 (winget install JRSoftware.InnoSetup). Lancement, depuis la racine de Sine Nomine :
    python installateur/construire_installateur.py
L'installateur est construit depuis l'étiquette Git V<VERSION> (rien d'autre que les fichiers suivis par Git).
"""

import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
BUILD = Path(__file__).resolve().parent / "build"
sys.path.insert(0, str(RACINE))
from anonymiseur import VERSION  # noqa: E402

COMPILATEURS = [Path.home() / "AppData/Local/Programs/Inno Setup 6/ISCC.exe",
                Path("C:/Program Files (x86)/Inno Setup 6/ISCC.exe"), Path("C:/Program Files/Inno Setup 6/ISCC.exe")]


def texte_brut(markdown):
    """LICENCE.md -> texte lisible dans la page de licence de l'installateur."""
    t = re.sub(r"^#+\s*", "", markdown, flags=re.M)
    t = re.sub(r"\*\*([^*]+)\*\*", r"\1", t)
    t = re.sub(r"\*([^*]+)\*", r"\1", t)
    t = re.sub(r"`([^`]+)`", r"\1", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", t)
    return t.replace("\r\n", "\n").replace("\n", "\r\n")


def main():
    etiquette = f"V{VERSION}"
    if subprocess.run(["git", "rev-parse", "--verify", "--quiet", f"refs/tags/{etiquette}"], cwd=RACINE,
                      capture_output=True).returncode != 0:
        raise SystemExit(f"L'étiquette Git {etiquette} n'existe pas : publiez d'abord la version.")
    iscc = next((c for c in COMPILATEURS if c.is_file()), None)
    if iscc is None:
        raise SystemExit("Inno Setup 6 est introuvable : winget install JRSoftware.InnoSetup")
    shutil.rmtree(BUILD, ignore_errors=True)
    stage = BUILD / "stage"
    BUILD.mkdir(parents=True)
    archive = Path(tempfile.gettempdir()) / "sine-nomine-source.zip"
    subprocess.run(["git", "archive", "--format=zip", "--prefix=stage/", "-o", str(archive), etiquette,
                    "--", ".", ":(exclude)tests", ":(exclude)site_src", ":(exclude)installateur", ":(exclude)serveur_activation", ":(exclude)sauvegarde"], cwd=RACINE, check=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(BUILD)
    archive.unlink()
    for nom, cible in (("LICENCE.md", "LICENCE.fr.txt"), ("LICENCE.en.md", "LICENCE.en.txt")):
        (stage / cible).write_bytes(("\ufeff" + texte_brut((stage / nom).read_text(encoding="utf-8"))).encode("utf-8"))
    for script in stage.glob("*.sh"):         # inutiles sous Windows
        script.unlink()
    (stage / "Sine Nomine.command").unlink(missing_ok=True)
    resultat = subprocess.run([str(iscc), f"/DVersion={VERSION}", str(Path(__file__).with_name("SineNomine.iss"))],
                              cwd=Path(__file__).parent)
    if resultat.returncode:
        raise SystemExit("La compilation de l'installateur a échoué.")
    exe = next((BUILD / "sortie").glob("*.exe"))
    print(f"Installateur construit : {exe} ({exe.stat().st_size / 1024**2:.1f} Mo)")


if __name__ == "__main__":
    main()
