#!/usr/bin/env bash
# Sine Nomine - lancement de l'interface locale (Linux et macOS)
VENV="${SINE_NOMINE_VENV:-$HOME/.venvs/sine-nomine}"
RACINE="$(cd "$(dirname "$0")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1 PYTHONUTF8=1
if [ ! -x "$VENV/bin/python" ]; then
  bash "$RACINE/install.sh" || exit 1
fi
cd "$RACINE"
exec "$VENV/bin/python" -m anonymiseur "$@"
