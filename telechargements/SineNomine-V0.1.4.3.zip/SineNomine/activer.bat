@echo off
rem Sine Nomine - active cette installation avec une cle d acces (connexion Internet necessaire)
setlocal
set "VENV=%~dp0environnement"
if not exist "%~dp0environnement\Scripts\python.exe" if exist "%USERPROFILE%\.venvs\sine-nomine\Scripts\python.exe" set "VENV=%USERPROFILE%\.venvs\sine-nomine"
set PYTHONUTF8=1
if not exist "%VENV%\Scripts\python.exe" (
  echo L environnement n est pas installe : lancez d abord installer.bat.
  pause
  exit /b 1
)
cd /d "%~dp0"
"%VENV%\Scripts\python.exe" -m anonymiseur --activer
pause
