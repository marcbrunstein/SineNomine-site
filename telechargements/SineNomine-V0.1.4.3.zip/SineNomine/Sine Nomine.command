#!/usr/bin/env bash
# Double-clic sous macOS : ouvre un terminal qui lance Sine Nomine (la fenetre doit rester ouverte pendant l'utilisation).
cd "$(dirname "$0")" && exec bash ./lancer.sh
