#!/usr/bin/env bash
# Sine Nomine - cree un raccourci : lanceur du menu des applications (Linux) ou fichier .command sur le Bureau (macOS)
set -e
RACINE="$(cd "$(dirname "$0")" && pwd)"
if [ "$(uname -s)" = "Darwin" ]; then
  cible="$HOME/Desktop/Sine Nomine.command"
  printf '#!/usr/bin/env bash\ncd "%s" && exec bash ./lancer.sh\n' "$RACINE" > "$cible"
  chmod +x "$cible"
  echo "Raccourci cree : $cible"
else
  dossier="$HOME/.local/share/applications"
  mkdir -p "$dossier"
  cat > "$dossier/sine-nomine.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Sine Nomine
Comment=Anonymiseur de fichiers local (Habeas Corpus Consulting)
Exec=bash "$RACINE/lancer.sh"
Path=$RACINE
Icon=$RACINE/anonymiseur/static/sine-nomine.png
Terminal=true
Categories=Office;Utility;
DESKTOP
  chmod +x "$dossier/sine-nomine.desktop"
  echo "Raccourci cree : $dossier/sine-nomine.desktop (menu des applications)"
  if [ -d "$HOME/Desktop" ]; then
    cp "$dossier/sine-nomine.desktop" "$HOME/Desktop/Sine Nomine.desktop" && chmod +x "$HOME/Desktop/Sine Nomine.desktop"
    echo "Raccourci cree : $HOME/Desktop/Sine Nomine.desktop"
  fi
fi
