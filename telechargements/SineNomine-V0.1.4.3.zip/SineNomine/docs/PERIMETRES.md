# Périmètres de stabilité des pseudonymes (étape 3)

Ce document décrit ce que fait Sine Nomine depuis la V0.1.4.3, et ses limites. Il ne promet ni certification ni garantie d'anonymat.

## 1. Principe

Un **périmètre** est l'espace dans lequel une même personne, société ou valeur sensible garde le **même pseudonyme**. Avant chaque
pseudonymisation, l'utilisateur choisit explicitement un périmètre ; rien n'est deviné ni réutilisé en silence.

| Périmètre | Les pseudonymes sont communs à… | Usage typique |
|---|---|---|
| **Document** | un seul document logique | documents à ne jamais recouper |
| **Projet** (choix par défaut) | tous les documents et traitements du projet | un dossier, une affaire |
| **Client** | tous les projets et documents rattachés au client | recoupements voulus entre dossiers d'un client |
| **Historique** | l'ancienne archive migrée (V0.1.4.2) | restauration des fichiers déjà produits |

- Un nouveau projet s'appelle **« Nouveau projet »** par défaut ; son nom est **modifiable** (à la création et ensuite, onglet
  « Clients et projets »). Renommer ne change aucun pseudonyme (les identifiants internes sont aléatoires et stables).
- Le périmètre **Client** affiche un avertissement : il relie entre eux tous les dossiers du client, ce qui facilite les recoupements.
- Le périmètre choisi est rappelé avant le lancement de l'analyse et en tête de l'écran de validation.

## 2. Règles garanties

1. **Un pseudonyme ne désigne jamais deux valeurs dans un même périmètre** (contrainte d'unicité du coffre sur le code, par périmètre).
2. **Aucune fusion automatique entre périmètres** : deux projets d'un même client restent indépendants ; le client ne reprend pas
   les pseudonymes de ses projets. Un même nom a donc des pseudonymes différents dans deux périmètres.
3. **Pas d'archive globale implicite** : ni les variantes apprises, ni les refus de détection, ni les listes de noms d'un périmètre
   ne sont lus par un autre. Seule la liste des mots exclus **générale** (règles linguistiques communes) est partagée.
4. **Document** : l'identité d'un document est l'empreinte (SHA-256) du fichier source, pas son nom ni son chemin. Le même contenu
   retraité retrouve ses pseudonymes ; deux documents distincts d'un même lot ont des pseudonymes indépendants.
5. **L'ancienne archive n'est jamais réinterprétée** : elle reste le périmètre « historique », intact, non rattaché à un client.
   Ses anciennes listes en fichiers (personnes, sociétés, produits, lieux) y ont été copiées (chiffrées).
6. Rattacher un projet à un client est une action explicite (annoncée à l'écran) ; un projet ne passe pas d'un client à un autre
   sans action explicite.

## 3. Dé-pseudonymisation, correction, consultation

- **Dé-pseudonymisation et correction** : le périmètre est reconnu d'après les codes présents dans les fichiers (contenu et nom). Il est
  retenu s'il est le seul à connaître tous les codes. Si plusieurs périmètres connaissent les mêmes codes (collision aléatoire rare mais
  possible entre périmètres), **le serveur refuse de choisir** (réponse 409) et l'interface demande le périmètre ; il peut aussi être
  choisi à l'avance. Un code inconnu est laissé tel quel et signalé.
- **Consultation d'un pseudonyme** : recherche dans tous les périmètres ; chaque résultat indique le sien.
- **Listes** (Outils) : chaque liste de noms est propre à un périmètre ; les mots exclus existent en version générale et par périmètre.

## 4. Anonymisation irréversible

Sans conservation des correspondances, aucun périmètre n'est créé. L'utilisateur peut seulement choisir les **listes** d'un projet
ou d'un client à appliquer (lecture seule).

## 5. Limites connues

- Le périmètre **Document** n'applique pas de liste de noms (il n'a pas de liste propre) : seuls les modèles de détection, les valeurs
  sensibles (e-mails, téléphones, IBAN…) et les mots exclus généraux y travaillent.
- Les noms de clients et de projets sont chiffrés dans le coffre ; les identifiants internes, types et dates restent visibles dans
  le fichier de base (voir COFFRE.md).
- Un document modifié (contenu différent) est un autre document logique : il n'hérite pas des pseudonymes de l'ancienne version.
- Avec le périmètre Client, une personne présente dans deux dossiers du client reçoit le même pseudonyme : c'est voulu, mais cela
  permet de rapprocher ces dossiers.
