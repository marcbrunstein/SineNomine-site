"""Validation centralisée des chemins et des noms de fichiers venant de l'extérieur (fichiers déposés, URL, formulaires).

Règles (Windows, mais aussi Linux et macOS) : jamais de chemin absolu, de lettre de lecteur, de chemin réseau (UNC), de
remontée (« .. »), de flux alternatif NTFS (« nom:flux »), de nom réservé Windows (CON, NUL, COM1…), de caractère de contrôle
ni de nom finissant par un point ou une espace. Un chemin résolu doit rester dans son dossier de base, sans passer par un
lien symbolique ou une jonction qui en sortirait.
"""

import os
import re
from pathlib import Path

LONGUEUR_MAX_TOTALE = 240
LONGUEUR_MAX_PARTIE = 120
RESERVES = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10)),
            "COM¹", "COM²", "COM³", "LPT¹", "LPT²", "LPT³", "CONIN$", "CONOUT$"}
RE_CARACTERES_INTERDITS = re.compile(r'[\x00-\x1f<>"|?*]')
RE_LECTEUR = re.compile(r"^[A-Za-z]:")
FILE_ATTRIBUTE_REPARSE_POINT = 0x400        # liens symboliques et jonctions Windows


class CheminInvalide(ValueError):
    """Le chemin ou le nom proposé n'est pas acceptable (la raison est dans le message, sans donnée confidentielle)."""


def _partie_valide(partie):
    if not partie or partie in (".", ".."):
        raise CheminInvalide("composant vide ou relatif")
    if ":" in partie:
        raise CheminInvalide("lecteur ou flux alternatif (« : »)")
    if RE_CARACTERES_INTERDITS.search(partie):
        raise CheminInvalide("caractère interdit")
    if partie != partie.rstrip(" ."):
        raise CheminInvalide("nom finissant par un point ou une espace")
    if len(partie) > LONGUEUR_MAX_PARTIE:
        raise CheminInvalide("nom trop long")
    if partie.split(".")[0].strip().upper() in RESERVES:
        raise CheminInvalide("nom réservé par Windows")


def nom_relatif_sur(brut):
    """Chemin relatif propre, avec « / » comme séparateur (ex. « dossier/note.docx »), ou CheminInvalide."""
    texte = str(brut or "").replace("\\", "/")
    if not texte.strip():
        raise CheminInvalide("nom vide")
    if texte.startswith("/") or RE_LECTEUR.match(texte):
        raise CheminInvalide("chemin absolu, lecteur ou chemin réseau")
    parties = [p for p in texte.split("/") if p not in ("", ".")]
    if not parties:
        raise CheminInvalide("nom vide")
    for partie in parties:
        _partie_valide(partie)
    resultat = "/".join(parties)
    if len(resultat) > LONGUEUR_MAX_TOTALE:
        raise CheminInvalide("chemin trop long")
    return resultat


def nom_fichier_sur(brut):
    """Nom d'un seul fichier (pas de dossier) ou CheminInvalide."""
    relatif = nom_relatif_sur(brut)
    if "/" in relatif:
        raise CheminInvalide("un nom de fichier ne contient pas de dossier")
    return relatif


def est_lien(chemin):
    """Vrai pour un lien symbolique ou une jonction (point de reparse Windows)."""
    chemin = Path(chemin)
    if chemin.is_symlink():
        return True
    try:
        attributs = getattr(os.lstat(chemin), "st_file_attributes", 0)
    except OSError:
        return False
    return bool(attributs & FILE_ATTRIBUTE_REPARSE_POINT)


def confiner(base, relatif):
    """Chemin absolu de `relatif` sous `base`, ou CheminInvalide s'il en sortirait (lien, jonction, remontée).

    `relatif` est d'abord validé par nom_relatif_sur. Le résultat peut ne pas exister encore.
    """
    base = Path(base).resolve()
    propre = nom_relatif_sur(relatif)
    courant = base
    for partie in propre.split("/"):
        courant = courant / partie
        if courant.exists() and est_lien(courant):
            raise CheminInvalide("lien symbolique ou jonction")
    cible = courant.resolve()
    try:
        cible.relative_to(base)
    except ValueError:
        raise CheminInvalide("sortie du dossier autorisé") from None
    return cible


def unique(chemin):
    """Chemin libre : « nom (2).ext » si `chemin` existe déjà (comparaison insensible à la casse sous Windows)."""
    chemin = Path(chemin)
    if not chemin.exists():
        return chemin
    n = 2
    while True:
        candidat = chemin.with_name(f"{chemin.stem} ({n}){chemin.suffix}")
        if not candidat.exists():
            return candidat
        n += 1
