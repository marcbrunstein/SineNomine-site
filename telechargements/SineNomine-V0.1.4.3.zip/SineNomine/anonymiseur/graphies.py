"""Équivalences de graphie pour retrouver un même nom écrit de plusieurs façons.

- accents : « Inès » = « Ines », « Stéphan » = « Stephan », « Gülhan » = « Gulhan » ;
- graphies étrangères : « Kärscher » = « Kaerscher » = « Karscher », « Straße » = « Strasse » ;
- séparateurs : « Lin-an », « Lin_an » et « Lin an » ; apostrophes droites et typographiques.

`plier` conserve la longueur du texte (un caractère donne toujours un caractère) : une recherche faite sur le texte
« plié » donne donc des positions valables dans le texte d'origine.
"""

import re
import unicodedata
from functools import lru_cache

_SPECIAUX = {"ß": "s", "æ": "a", "Æ": "A", "œ": "o", "Œ": "O", "ø": "o", "Ø": "O", "đ": "d", "Đ": "D",
             "ð": "d", "Ð": "D", "ł": "l", "Ł": "L", "þ": "t", "Þ": "T", "ı": "i", "İ": "I"}
_SEPARATEURS = {"_": " ", "-": " ", "‐": " ", "‑": " ", "–": " ", "—": " ",
                " ": " ", " ": " ", "’": "'", "‘": "'", "`": "'", "´": "'"}

# Graphie « avec digraphes » des lettres étrangères.
_VERS_DIGRAPHES = {"ä": "ae", "ö": "oe", "ü": "ue", "Ä": "Ae", "Ö": "Oe", "Ü": "Ue", "ß": "ss", "æ": "ae",
                   "Æ": "Ae", "œ": "oe", "Œ": "Oe", "ø": "oe", "Ø": "Oe", "å": "aa", "Å": "Aa"}
_VERS_TREMAS = (("ae", "ä"), ("oe", "ö"), ("ue", "ü"), ("Ae", "Ä"), ("Oe", "Ö"), ("Ue", "Ü"), ("ss", "ß"))


@lru_cache(maxsize=None)
def _plier_caractere(c):
    if c in _SEPARATEURS:
        return _SEPARATEURS[c]
    if c in _SPECIAUX:
        return _SPECIAUX[c]
    if c.isascii():
        return c
    decompose = unicodedata.normalize("NFD", c)
    return decompose[0] if decompose and decompose[0].isalpha() else c


def plier(texte):
    """Texte sans accents, avec des séparateurs uniformes, de même longueur que l'original."""
    return "".join(_plier_caractere(c) for c in texte)


def graphies_etrangeres(variante):
    """Autres écritures usuelles d'un nom : « Kärscher » → « Kaerscher », et inversement.

    Ne renvoie que des écritures différentes de l'original ; `plier` couvre déjà les simples accents.
    """
    autres = set()
    avec_digraphes = "".join(_VERS_DIGRAPHES.get(c, c) for c in variante)
    if avec_digraphes != variante:
        autres.add(avec_digraphes)
    avec_tremas = variante
    for digraphe, lettre in _VERS_TREMAS:
        avec_tremas = avec_tremas.replace(digraphe, lettre)
    if avec_tremas != variante:
        autres.add(avec_tremas)
    return autres


def cle_nom(texte):
    """Clé de comparaison d'un nom, insensible à la casse, aux accents et aux séparateurs."""
    return re.sub(r"[^0-9a-z]+", " ", plier(texte).lower()).strip()
