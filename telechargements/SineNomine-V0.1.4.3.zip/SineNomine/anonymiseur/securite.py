"""Sécurité du serveur local (127.0.0.1) : session, jeton d'ouverture, CSRF, Host/Origin, en-têtes.

Principe : le navigateur est ouvert avec une adresse contenant un jeton à usage unique et de courte durée ; le serveur
l'échange contre un cookie de session (HttpOnly, SameSite=Strict) et redirige vers « / » (le jeton ne reste pas dans
l'adresse). Ensuite, toute route sensible exige ce cookie ; toute écriture exige aussi un jeton CSRF (en-tête X-CSRF-Token,
fourni dans la page) et une origine identique. Le nom d'hôte doit être local : cela bloque le « DNS rebinding ». Aucun CORS.

Un second lancement de Sine Nomine (double-clic sur le raccourci) obtient un nouveau jeton d'ouverture auprès de l'instance
en cours grâce à un secret placé dans un fichier réservé à l'utilisateur (instance.json).
"""

import hmac
import json
import os
import secrets
import time
from pathlib import Path
from urllib.parse import urlsplit

DUREE_JETON = 120                      # secondes
HOTES_LOCAUX = {"127.0.0.1", "localhost", "[::1]"}
METHODES_ECRITURE = {"POST", "PUT", "DELETE", "PATCH"}
PUBLICS = ("/api/ping", "/api/instance/jeton")          # sans session (le second exige un secret propre)
CSP_APPLICATION = ("default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; "
                   "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'")
CSP_DOCUMENT_ISOLE = "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:"


def _egaux(a, b):
    return bool(a) and bool(b) and hmac.compare_digest(str(a), str(b))


class Securite:
    def __init__(self):
        self.session = secrets.token_urlsafe(32)
        self.csrf = secrets.token_urlsafe(32)
        self.secret_instance = secrets.token_urlsafe(32)
        self._jetons = {}              # jeton -> instant d'expiration

    # ---------------------------------------------------------------- jetons d'ouverture
    def nouveau_jeton(self):
        maintenant = time.monotonic()
        self._jetons = {j: t for j, t in self._jetons.items() if t > maintenant}
        jeton = secrets.token_urlsafe(24)
        self._jetons[jeton] = maintenant + DUREE_JETON
        return jeton

    def consommer_jeton(self, jeton):
        """Vrai une seule fois pour un jeton valable."""
        expire = self._jetons.pop(jeton or "", None)
        return expire is not None and expire > time.monotonic()

    # ---------------------------------------------------------------- contrôles
    def hote_autorise(self, host):
        nom = (host or "").strip().lower()
        if nom.startswith("["):                       # [::1]:8765
            nom = nom.split("]")[0] + "]"
        else:
            nom = nom.split(":")[0]
        return nom in HOTES_LOCAUX

    def session_valide(self, cookie):
        return _egaux(cookie, self.session)

    def csrf_valide(self, en_tete):
        return _egaux(en_tete, self.csrf)

    def origine_valide(self, origin, referer, host, sec_fetch_site):
        """Pour une écriture : l'origine doit être celle du serveur lui-même."""
        attendu = {f"http://{host}"}
        if origin:
            return origin in attendu
        if sec_fetch_site:
            return sec_fetch_site in ("same-origin", "none")
        if referer:
            parties = urlsplit(referer)
            return f"{parties.scheme}://{parties.netloc}" in attendu
        return True                                  # client non navigateur : le jeton CSRF reste exigé

    def secret_instance_valide(self, valeur):
        return _egaux(valeur, self.secret_instance)


# ---------------------------------------------------------------- fichier de l'instance en cours
def fichier_instance(dossier):
    return Path(dossier) / "instance.json"


def ecrire_instance(dossier, port, secret):
    """Mémorise port et secret pour les lancements suivants (fichier dans le profil de l'utilisateur)."""
    chemin = fichier_instance(dossier)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_text(json.dumps({"port": port, "secret": secret, "pid": os.getpid()}), encoding="utf-8")
    try:
        os.chmod(chemin, 0o600)
    except OSError:
        pass
    return chemin


def lire_instance(dossier):
    try:
        donnees = json.loads(fichier_instance(dossier).read_text(encoding="utf-8"))
        return int(donnees["port"]), str(donnees["secret"])
    except (OSError, ValueError, KeyError, TypeError):
        return None


def effacer_instance(dossier):
    try:
        fichier_instance(dossier).unlink()
    except OSError:
        pass
