"""Détection de la langue d'un texte, hors ligne et sans dépendance.

On compte les mots-outils propres à chaque langue (« le, des, est… » contre « the, of, and… »). Les mots ambigus
(« a », « on », « son », « plus », « an », « or »…) sont exclus des listes. Un paragraphe trop court ou équivoque
reprend la langue du fichier, ce qui convient aux documents français contenant des mots ou des citations en anglais.

Français et anglais sont analysés par leur modèle spaCy ; allemand, espagnol et italien sont seulement reconnus, pour
ne pas confier leurs textes au modèle français (GLiNER, multilingue, s'en charge seul).
"""

import re

MOTS = {
    # Seulement des mots propres au français : « de, en, la, le, un, il, si, y » sont aussi de l'espagnol ou de l'italien.
    "fr": set("""les des du une et est sont pas ne que qui dans pour avec sur au aux ce cette ces par mais ou où comme aussi
        très tout tous leur leurs sa ses elle ils elles nous vous être avoir été fait peut sans sous entre chez dont donc
        car alors cela ceci celui à""".split()),
    "en": set("""the of and to in is that it for was are with his they be at have this from by not but what all were when we
        there can your which their if will about would been has more her you our these than also she him them who being
        those into over after because while should could must may might shall each every other some such only own same
        both few most any mr mrs ms miss ltd inc plc llc address number dear regards thanks please meeting company
        customer customers""".split()),
    "de": set("""der die das und ist nicht mit von zu den dem des ein eine auf für sich auch bei werden sind wird oder als wie
        nach aus über herr frau""".split()),
    "es": set("""el los las del que por con para una es son está pero como más también muy ya sido entre cuando sobre sus este
        esta señor señora""".split()),
    "it": set("""il lo gli della delle degli che per con una sono è non anche come più questo questa tra fra nel nella sul
        sulla signor signora""".split()),
}
LANGUES_ANALYSEES = ("fr", "en")      # celles qui ont un modèle spaCy
RE_MOT = re.compile(r"[a-zà-ÿ]+")
RAPPORT_MIN = 1.5      # une langue l'emporte si elle a au moins 1,5 fois plus de mots-outils que la suivante
HITS_MIN = 3           # en dessous, on ne tranche pas


def compter(texte):
    mots = RE_MOT.findall(texte.lower())
    return {code: sum(1 for m in mots if m in liste) for code, liste in MOTS.items()}


def detecter(texte, defaut="fr"):
    """Code de la langue ('fr', 'en', 'de', 'es' ou 'it') ; `defaut` si le texte est trop court ou équivoque."""
    classement = sorted(compter(texte).items(), key=lambda kv: kv[1], reverse=True)
    (premiere, n1), (_, n2) = classement[0], classement[1]
    if n1 < HITS_MIN:
        return defaut
    return premiere if n1 >= RAPPORT_MIN * n2 else defaut
