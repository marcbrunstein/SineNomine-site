"""Publication des résultats d'un lot, récupérable après une panne.

Une transaction de base de données ne couvre pas les fichiers : la publication suit donc un protocole en étapes, dont chacune
est reprise ou annulée proprement au démarrage suivant.

    1. Les codes sont réservés durablement dans le coffre (état du lot : « en_cours »).
    2. Les résultats sont écrits dans un dossier provisoire voisin de la destination (même disque : le renommage final est
       atomique), jamais dans la destination elle-même.
    3. Contrôle : chaque fichier attendu existe, n'est pas vide, et son empreinte SHA-256 est enregistrée (manifeste).
    4. Les correspondances définitives sont enregistrées dans le coffre ; le lot passe à « pret » avec son manifeste.
    5. Publication : un seul renommage du dossier provisoire (destination nouvelle) ou un déplacement fichier par fichier
       (destination existante, noms déjà garantis uniques).
    6. Le lot passe à « publie ».

Reprise (`recuperer`), au démarrage :
    - « en_cours » : dossier provisoire supprimé, lot « abandonne » (les codes réservés restent sans effet) ;
    - « pret » : si le dossier provisoire est intact (manifeste vérifié), la publication est terminée ; sinon, abandon.
Un résultat incomplet n'est donc jamais présenté comme réussi, et les codes d'un fichier publié sont toujours dans le coffre.
"""

import hashlib
import json
import os
import shutil
from pathlib import Path

PREFIXE = ".sn-en-cours-"


class PublicationErreur(Exception):
    """Contrôle ou publication impossible ; le message est destiné à l'utilisateur."""


def dossier_provisoire(destination, lot_id):
    destination = Path(destination).resolve()
    return destination.parent / f"{PREFIXE}{lot_id}"


def preparer(provisoire):
    provisoire = Path(provisoire)
    shutil.rmtree(provisoire, ignore_errors=True)
    provisoire.mkdir(parents=True)
    return provisoire


def nettoyer(provisoire):
    shutil.rmtree(provisoire, ignore_errors=True)


def _empreinte(chemin):
    h = hashlib.sha256()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloc)
    return h.hexdigest()


def _forcer_ecriture(chemin):
    """Demande au système d'écrire réellement le fichier sur le disque (au mieux : certains systèmes l'interdisent)."""
    try:
        with open(chemin, "r+b") as f:
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass


def fichiers_de(provisoire):
    provisoire = Path(provisoire)
    return sorted(p for p in provisoire.rglob("*") if p.is_file())


def manifeste(provisoire, attendus=()):
    """Contrôle les fichiers produits et renvoie {chemin relatif: {taille, sha256}}.

    `attendus` : chemins relatifs qui DOIVENT exister et ne pas être vides (résultats sans erreur, rapports)."""
    provisoire = Path(provisoire)
    for relatif in attendus:
        chemin = provisoire / relatif
        if not chemin.is_file() or chemin.stat().st_size == 0:
            raise PublicationErreur(f"Contrôle échoué : le fichier produit « {relatif} » est absent ou vide.")
    resultat = {}
    for chemin in fichiers_de(provisoire):
        _forcer_ecriture(chemin)
        resultat[chemin.relative_to(provisoire).as_posix()] = {"taille": chemin.stat().st_size, "sha256": _empreinte(chemin)}
    return resultat


def verifier(provisoire, manifeste_attendu):
    """Vrai si le dossier provisoire correspond exactement au manifeste (aucun fichier absent, modifié ou ajouté)."""
    provisoire = Path(provisoire)
    if not provisoire.is_dir():
        return False
    reel = {p.relative_to(provisoire).as_posix(): p for p in fichiers_de(provisoire)}
    if set(reel) != set(manifeste_attendu):
        return False
    return all(reel[r].stat().st_size == m["taille"] and _empreinte(reel[r]) == m["sha256"] for r, m in manifeste_attendu.items())


def publier(provisoire, destination, manifeste_attendu=None):
    """Déplace les résultats vers la destination. Reprenable : relancée après une interruption, elle termine le travail."""
    provisoire, destination = Path(provisoire), Path(destination)
    if not destination.exists() and provisoire.is_dir():
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.replace(provisoire, destination)                       # un seul renommage : tout ou rien
        return
    destination.mkdir(parents=True, exist_ok=True)
    if provisoire.is_dir():
        for chemin in fichiers_de(provisoire):
            cible = destination / chemin.relative_to(provisoire)
            if cible.exists():
                raise PublicationErreur(f"Publication impossible : « {cible.name} » existe déjà dans la destination.")
            cible.parent.mkdir(parents=True, exist_ok=True)
            os.replace(chemin, cible)
        shutil.rmtree(provisoire, ignore_errors=True)
    if manifeste_attendu is not None:
        manquants = [r for r in manifeste_attendu if not (destination / r).is_file()]
        if manquants:
            raise PublicationErreur(f"Publication incomplète : {len(manquants)} fichier(s) manquant(s) dans la destination.")


def recuperer(coffre):
    """Reprise après panne, au démarrage : traite les lots restés « en_cours » ou « pret ». Renvoie un compte rendu."""
    actions = []
    for lot_id, etat in coffre.lots_en_cours():
        donnees = coffre.donnees_lot(lot_id)
        provisoire, destination = donnees.get("provisoire"), donnees.get("destination")
        if etat == "pret" and provisoire and destination and donnees.get("manifeste") is not None:
            attendu = donnees["manifeste"]
            if Path(provisoire).is_dir() and verifier(provisoire, attendu):
                try:
                    publier(provisoire, destination, attendu)
                    coffre.changer_etat_lot(lot_id, "publie", {})
                    actions.append((lot_id, "publication terminée"))
                    continue
                except (PublicationErreur, OSError):
                    pass
            elif all((Path(destination) / r).is_file() for r in attendu):
                coffre.changer_etat_lot(lot_id, "publie", {})
                actions.append((lot_id, "déjà publié"))
                continue
        if provisoire:
            nettoyer(provisoire)
        coffre.changer_etat_lot(lot_id, "abandonne", {})
        actions.append((lot_id, "abandonné et nettoyé"))
    return actions
