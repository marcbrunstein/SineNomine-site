"""Traductions français -> anglais des textes produits par le serveur (rapports, avertissements, libellés).

Le français reste la langue d'écriture du code : `traduire` et `traducteur` renvoient le texte tel quel pour le
français. Les clés peuvent contenir des variables `{n}` ; `traduire` reconnaît aussi un texte déjà formaté
(« 3 image(s) conservée(s)… ») grâce à ces modèles. tests/generer_i18n.py reprend ce dictionnaire pour l'interface.
"""

import re

EN = {
    # ---- rapport HTML et Excel
    "Rapport d'anonymisation": "Anonymisation report",
    "Rapport d'anonymisation Sine Nomine": "Sine Nomine anonymisation report",
    "Rapport Sine Nomine — {lot}": "Sine Nomine report — {lot}",
    "Lot": "Batch", "Mode : {mode}": "Mode: {mode}", "Mode": "Mode", "Date": "Date",
    "Avertissement accepté le {a}. Détections validées par l'utilisateur le {v}.":
        "Notice accepted on {a}. Detections reviewed by the user on {v}.",
    "Avertissement accepté le": "Notice accepted on", "Validé le": "Reviewed on",
    "Synthèse": "Summary", "Fichiers traités": "Files processed", "Entités remplacées": "Entities replaced",
    "Informations sensibles remplacées": "Sensitive items replaced", "Informations sensibles conservées": "Sensitive items kept",
    "Choix appliqués aux informations sensibles": "Choices applied to sensitive information",
    "Catégorie": "Category", "Action": "Action", "Éléments exclus (conservés)": "Excluded items (kept)",
    "conserver": "keep", "pseudonymiser": "pseudonymise", "supprimer": "delete",
    "Images": "Images", "Images supprimées": "Images removed", "non (conservées)": "no (kept)",
    "Images (supprimées)": "Images (removed)",
    "{n} image(s) supprimée(s), remplacée(s) par « [image supprimée] ».": "{n} image(s) removed, replaced by “[image supprimée]”.",
    "{n} image(s) supprimée(s).": "{n} image(s) removed.",
    "Erreur : {x}": "Error: {x}", "Identifiant": "Identifier", "Type": "Type", "Occurrences": "Occurrences",
    "Aucune.": "None.", "Remplacements": "Replacements",
    "Informations potentiellement sensibles conservées": "Potentially sensitive information kept",
    "Extrait (texte anonymisé)": "Excerpt (anonymised text)", "Confiance": "Confidence",
    "Image {n}": "Image {n}", "Aperçu impossible pour ce format.": "Preview not available for this format.",
    "Propriété intellectuelle.": "Intellectual property.", "Responsabilité.": "Liability.",
    "Pseudonymisation.": "Pseudonymisation.", "Anonymisation.": "Anonymisation.", "Confidentialité.": "Confidentiality.",
    "Loi applicable.": "Governing law.", "Contact.": "Contact.", "Fiabilité": "Reliability", "Éditeur": "Publisher",
    "Fichier": "File", "Message": "Message", "Avertissements": "Warnings",
    "Sensibles remplacées": "Sensitive items replaced", "Sensibles conservées": "Sensitive items kept",
    "DOCUMENT CONFIDENTIEL — permet de lever la pseudonymisation du lot {lot}":
        "CONFIDENTIAL DOCUMENT — makes it possible to reverse the pseudonymisation of batch {lot}",
    "Entités": "Entities", "Nom d'origine": "Original name", "Variantes recherchées": "Searched variants",
    "Informations sensibles": "Sensitive information", "Remplacé par": "Replaced by", "Valeur(s) d'origine": "Original value(s)",
    "[supprimé]": "[deleted]",
    # ---- libellés de catégories
    "Personne": "Person", "Société": "Company", "Produit": "Product", "Lieu": "Place",
    "E-mails": "Emails", "Téléphones": "Phone numbers", "IBAN et BIC": "IBAN and BIC", "N° de sécurité sociale": "Social security number (France)",
    "SIRET / SIREN": "SIRET / SIREN", "Adresses": "Addresses", "Dates de naissance": "Dates of birth", "Montants": "Amounts",
    "URL et noms de domaine": "URLs and domain names", "Dates": "Dates", "Adresses IP et MAC": "IP and MAC addresses", "Cartes bancaires": "Bank cards", "N° de TVA": "VAT numbers",
    "Plaques d'immatriculation et n° de châssis": "Number plates and chassis numbers", "Comptes et pseudos (@nom)": "Accounts and handles (@name)",
    "Passeports et cartes d'identité": "Passports and ID cards",
    "Références internes (motifs configurés)": "Internal references (configured patterns)",
    "Identifiants nationaux étrangers (NINO, SSN, NHS…)": "Foreign national identifiers (NINO, SSN, NHS…)",
    "Chemins de fichiers et de réseau": "File and network paths", "Coordonnées GPS": "GPS coordinates",
    # ---- notes d'images et avertissements produits par le serveur
    "Image distante : non affichée (aucune connexion n'est faite).": "Remote image: not shown (no connection is made).",
    "Fichier image introuvable à côté du document. Pour le voir, indiquez le chemin du dossier plutôt que de déposer le seul fichier Markdown.":
        "Image file not found next to the document. To see it, enter the folder path rather than dropping the Markdown file alone.",
    "Image introuvable dans le document.": "Image not found in the document.",
    "Image liée (hors du document) : non affichée.": "Linked image (outside the document): not shown.",
    "{n} image(s) conservée(s) et non analysée(s) : vérifiez qu'elles ne contiennent pas d'informations identifiantes (logos, signatures, captures d'écran).":
        "{n} image(s) kept and not analysed: check that they contain no identifying information (logos, signatures, screenshots).",
    "PDF : le résultat est un nouveau fichier de texte seul. Les images, tableaux et la mise en page d'origine ne sont pas repris, et les métadonnées du PDF (auteur, titre…) ne sont pas copiées.":
        "PDF: the result is a new plain-text file. Images, tables and the original layout are not carried over, and the PDF metadata (author, title…) is not copied.",
    "Aucun texte n'a pu être extrait de ce PDF.": "No text could be extracted from this PDF.",
    "La reconnaissance de caractères est désactivée (config.json).": "Optical character recognition is disabled (config.json).",
    "Tesseract n'est pas installé : les PDF scannés (images sans texte) ne pourront pas être lus. Relancez installer.bat pour l'installer.":
        "Tesseract is not installed: scanned PDFs (images without text) cannot be read. Run installer.bat again to install it.",
    "Tesseract est installé, mais sans données de langue (français, anglais) : relancez installer.bat.":
        "Tesseract is installed, but without language data (French, English): run installer.bat again.",
    "PDF protégé par un mot de passe : retirez la protection avant de le traiter.": "PDF protected by a password: remove the protection before processing it.",
    "{n} page(s) sans texte (document scanné ?) non lue(s) : {m}": "{n} page(s) without text (scanned document?) not read: {m}",
    "{n} page(s) lue(s) par reconnaissance de caractères (OCR) : le texte peut contenir des erreurs, surtout sur les noms propres. Relisez attentivement la validation et le résultat.":
        "{n} page(s) read by optical character recognition (OCR): the text may contain errors, especially on proper names. Review the validation and the result carefully.",
    "Objets incorporés (tableaux Excel, autres documents) non analysés, y compris leur image d'aperçu.":
        "Embedded objects (Excel tables, other documents) were not analysed, including their preview image.",
    "La miniature d'aperçu intégrée au fichier (image de la première page) a été supprimée.":
        "The preview thumbnail embedded in the file (image of the first page) was removed.",
    "Excel : les textes des cellules et des commentaires sont traités ; les noms des feuilles, les formules, les nombres, les tableaux croisés dynamiques et les liens externes ne le sont pas.":
        "Excel: cell and comment texts are processed; sheet names, formulas, numbers, pivot tables and external links are not.",
    "PowerPoint : les images d'arrière-plan et les objets incorporés ne sont pas analysés.":
        "PowerPoint: background images and embedded objects are not analysed.",
    "Fichier d'origine endommagé, réparé dans la version anonymisée : {n} élément(s) sans type déclaré (Word proposait de « récupérer le contenu » de l'original).":
        "Damaged original file, repaired in the anonymised version: {n} element(s) with no declared type (Word offered to “recover the contents” of the original).",
}

_PATRONS = []
for _fr, _en in EN.items():
    if "{" in _fr:
        _noms = []
        _source = re.sub(r"([.*+?^$()|\[\]\\])", r"\\\1", _fr)
        _source = re.sub(r"\{(\w+)\}", lambda m: (_noms.append(m.group(1)), "(.+?)")[1], _source)
        _PATRONS.append((re.compile("^" + _source + "$", re.S), _noms, _en))


def traduire(fr, langue):
    """Anglais d'un texte français, qu'il soit une clé du dictionnaire ou un texte déjà formaté ; sinon le texte tel quel."""
    if langue != "en":
        return fr
    if fr in EN:
        return EN[fr]
    for regex, noms, en in _PATRONS:
        m = regex.match(fr)
        if m:
            return re.sub(r"\{(\w+)\}", lambda v: m.group(noms.index(v.group(1)) + 1), en)
    return fr


def traducteur(langue):
    """T(« Texte {x} », x=3) : le modèle dans la langue demandée, puis ses variables remplies."""
    def T(fr, **variables):
        modele = EN.get(fr, fr) if langue == "en" else fr
        return modele.format(**variables) if variables else modele
    return T
