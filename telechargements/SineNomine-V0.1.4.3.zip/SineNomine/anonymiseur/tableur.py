"""Écriture de lignes dans une feuille Excel sans exécution possible de formule (injection de formules).

Une valeur venant d'un document (nom, extrait…) peut commencer par =, +, - ou @ : Excel l'interpréterait comme une formule.
`ajouter` écrit ces valeurs comme du texte (type chaîne explicite, préfixe de citation) : elles s'affichent telles quelles.
"""

PREFIXES_FORMULE = ("=", "+", "-", "@", "\t", "\r", "\n")


def neutre(valeur):
    """Vrai si la valeur serait prise pour une formule par un tableur."""
    return isinstance(valeur, str) and valeur.startswith(PREFIXES_FORMULE)


def ajouter(feuille, valeurs):
    feuille.append(list(valeurs))
    for cellule in feuille[feuille.max_row]:
        if neutre(cellule.value):
            cellule.data_type = "s"
            cellule.quotePrefix = True
