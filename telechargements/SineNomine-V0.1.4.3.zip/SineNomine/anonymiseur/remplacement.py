"""Calcul des remplacements à appliquer à un texte (entités validées et informations sensibles)."""

import re
from collections import Counter, defaultdict
from dataclasses import dataclass

from . import sensibles
from .archive import Archive
from .entites import formes_de_casse
from .graphies import graphies_etrangeres, plier

SUPPRIME = "[supprimé]"

# Un nom ne doit pas être collé à une lettre ou un chiffre ; un tiret bas, en revanche, sert de séparateur.
LIMITE_AVANT = r"(?<![^\W_])"
LIMITE_APRES = r"(?![^\W_])"


@dataclass
class Remplacement:
    debut: int
    fin: int
    texte: str
    nature: str      # "entite" ou "sensible"
    reference: object  # id d'entité, ou (catégorie, clé)


class Correspondances:
    """Recherche les variantes des entités et les informations sensibles, puis décide du remplacement.

    Les informations sensibles pseudonymisées reçoivent un code aléatoire ([Email_ZTRPA]…),
    repris de l'archive s'il existe déjà : la même valeur garde le même code partout.
    """

    def __init__(self, entites, libelles, actions, exclusions, archive=None, numerote=False, graphies=True):
        self.archive = archive if archive is not None else Archive()
        self.numerote = numerote                  # anonymisation : [Email_1], [Email_2]… sans archive
        self.libelles = libelles                  # id d'entité -> « Personne_KQXMB »
        self.actions = actions                    # catégorie sensible -> conserver / pseudonymiser / supprimer
        self.exclusions = set(exclusions)         # {(catégorie, clé)} à conserver malgré l'action
        self.sensibles_libelles = {}              # (catégorie, clé) -> « [Email 1] »
        self.sensibles_valeurs = defaultdict(set)  # (catégorie, clé) -> valeurs d'origine rencontrées
        self._compteurs = Counter()

        # La recherche se fait sur le texte « plié » (sans accents, séparateurs uniformes) : « Inès Marchand » retrouve
        # « Ines Marchand », « Ines_Marchand » (nom de fichier) et « INÈS MARCHAND » ; « Lin-an » retrouve « Lin_an ».
        # Avec `graphies`, « Kärscher » et « Kaerscher » sont aussi tenus pour équivalents.
        self.forme_vers_id = {}
        for e in sorted(entites, key=lambda e: e.id):
            if e.id not in libelles:
                continue
            for v in e.variantes:
                v = v.strip()
                for ecriture in {v, *(graphies_etrangeres(v) if graphies else ())}:
                    for forme in formes_de_casse(ecriture):
                        f = plier(forme)
                        if len(f) >= 2:
                            self.forme_vers_id.setdefault(f, e.id)
        formes = sorted(self.forme_vers_id, key=len, reverse=True)
        self.motif = (re.compile(LIMITE_AVANT + "(?:" + "|".join(re.escape(f) for f in formes) + ")" + LIMITE_APRES)
                      if formes else None)

    def libelle_sensible(self, categorie, cle):
        reference = (categorie, cle)
        if reference not in self.sensibles_libelles:
            if self.numerote:
                self._compteurs[categorie] += 1
                etiquette = sensibles.ETIQUETTES[categorie].replace(" ", "_")
                self.sensibles_libelles[reference] = f"[{etiquette}_{self._compteurs[categorie]}]"
            else:
                self.sensibles_libelles[reference] = self.archive.code_sensible(categorie, cle)
        return self.sensibles_libelles[reference]

    def occurrences(self, texte):
        """(début, fin, id d'entité) de chaque nom trouvé, positions rapportées au texte d'origine."""
        if self.motif is None:
            return
        for m in self.motif.finditer(plier(texte)):
            yield m.start(), m.end(), self.forme_vers_id[m.group()]

    def analyser(self, texte):
        """(remplacements à faire, informations sensibles conservées), sans chevauchement."""
        remplacements, conservees = [], []
        for t in sensibles.detecter(texte):
            action = self.actions.get(t.categorie, "conserver")
            if action == "conserver" or (t.categorie, t.cle) in self.exclusions:
                conservees.append(t)
                continue
            self.sensibles_valeurs[(t.categorie, t.cle)].add(t.valeur)
            nouveau = SUPPRIME if action == "supprimer" else self.libelle_sensible(t.categorie, t.cle)
            remplacements.append(Remplacement(t.debut, t.fin, nouveau, "sensible", (t.categorie, t.cle)))

        for debut, fin, id_entite in self.occurrences(texte):
            if any(debut < r.fin and fin > r.debut for r in remplacements):
                continue
            remplacements.append(Remplacement(debut, fin, self.libelles[id_entite], "entite", id_entite))

        remplacements.sort(key=lambda r: r.debut)
        conservees = [t for t in conservees if not any(t.debut < r.fin and t.fin > r.debut for r in remplacements)]
        return remplacements, conservees

    def remplacer(self, texte):
        """Texte remplacé, remplacements faits, et informations conservées repositionnées dans le nouveau texte."""
        remplacements, conservees = self.analyser(texte)
        morceaux, position, decalages = [], 0, []
        for r in remplacements:
            morceaux.append(texte[position:r.debut])
            morceaux.append(r.texte)
            decalages.append((r.fin, len(r.texte) - (r.fin - r.debut)))
            position = r.fin
        morceaux.append(texte[position:])
        nouveau = "".join(morceaux)
        repositionnees = []
        for t in conservees:
            decalage = sum(d for fin, d in decalages if fin <= t.debut)
            repositionnees.append((t, t.debut + decalage, t.fin + decalage))
        return nouveau, remplacements, repositionnees


def contexte_mots(texte, debut, fin, mots=15):
    """Extrait en texte brut : `mots` mots avant et après l'occurrence, qui est entourée de ⟦ ⟧."""
    mots_avant = list(re.finditer(r"\S+", texte[:debut]))
    mots_apres = list(re.finditer(r"\S+", texte[fin:]))
    # Les mots collés à l'occurrence (« l'⟦Acme⟧ », « ⟦Acme⟧, ») restent collés : on coupe sur les positions d'origine.
    depart = mots_avant[-mots].start() if mots and len(mots_avant) > mots else 0
    arrivee = fin + mots_apres[mots - 1].end() if mots and len(mots_apres) >= mots else len(texte)
    if not mots:
        depart, arrivee = debut, fin
    coupe_avant = depart > 0 and bool(texte[:depart].strip())
    coupe_apres = arrivee < len(texte) and bool(texte[arrivee:].strip())
    extrait = f"{texte[depart:debut]}⟦{texte[debut:fin]}⟧{texte[fin:arrivee]}"
    return re.sub(r"\s+", " ", ("… " if coupe_avant else "") + extrait.strip() + (" …" if coupe_apres else "")).strip()


def contexte(texte, debut, fin, largeur=60):
    avant = texte[max(0, debut - largeur):debut]
    apres = texte[fin:fin + largeur]
    prefixe = "…" if debut > largeur else ""
    suffixe = "…" if fin + largeur < len(texte) else ""
    return re.sub(r"\s+", " ", f"{prefixe}{avant}⟦{texte[debut:fin]}⟧{apres}{suffixe}").strip()
