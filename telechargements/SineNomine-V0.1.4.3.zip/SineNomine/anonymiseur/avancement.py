"""Suivi d'avancement d'un lot, lu par l'interface une fois par seconde.

Deux groupes d'étapes : l'analyse (avant la validation) et le traitement (après). Chaque étape fait avancer une
fraction globale du groupe ; les compteurs (détections, substitutions) et les durées s'y ajoutent.
Aucun nom d'origine n'est conservé ici : seulement des nombres.
"""

import threading
import time
from collections import Counter

PHASES = {
    "analyse": [("modeles", "Chargement des modèles"), ("lecture", "Lecture des fichiers"),
                ("detection", "Détection des noms"), ("regroupement", "Regroupement et calculs")],
    "traitement": [("preparation", "Préparation"), ("remplacement", "Remplacement dans les fichiers"),
                   ("rapport", "Rapport et archive")],
}


class Avancement:
    def __init__(self, total_fichiers=0):
        self.verrou = threading.RLock()
        self.total = total_fichiers
        self.groupe = "analyse"
        self.phase = "modeles"
        self.etape = "En attente"
        self.detail = ""
        self.fichier = None
        self.courant = 0
        self.fraction = 0.0
        self.mots = 0                         # mots du texte traités jusqu'ici
        self.mots_total = 0                   # mots du texte de tous les fichiers lus
        self.decouverts = {}                  # catégorie -> nombre de formes distinctes détectées jusqu'ici
        self.substitutions = Counter()        # catégorie -> remplacements effectués
        self.durees = {}                      # groupe -> secondes, une fois terminé
        self._t_groupe = time.monotonic()
        self._t_maj = time.monotonic()
        self._actif = True

    def demarrer(self, groupe):
        with self.verrou:
            self.groupe, self.fraction, self.courant, self.mots = groupe, 0.0, 0, 0
            self.phase = PHASES[groupe][0][0]
            self.fichier, self.detail = None, ""
            self._t_groupe = self._t_maj = time.monotonic()
            self._actif = True

    def maj(self, phase, etape, fraction, courant=None, fichier=None, detail=""):
        with self.verrou:
            self.phase, self.etape, self.detail = phase, etape, detail
            self.fraction = max(self.fraction, min(float(fraction), 1.0))   # ne recule jamais
            if courant is not None:
                self.courant = courant
            self.fichier = fichier
            self._t_maj = time.monotonic()

    def terminer(self):
        with self.verrou:
            self.durees[self.groupe] = round(time.monotonic() - self._t_groupe, 1)
            self.fraction = 1.0
            self._actif = False

    def vers_dict(self):
        with self.verrou:
            maintenant = time.monotonic()
            ecoule = (maintenant - self._t_groupe) if self._actif else self.durees.get(self.groupe, 0.0)
            restant = None
            if self._actif and self.fraction >= 0.03 and ecoule >= 3:
                restant = round(ecoule * (1 - self.fraction) / self.fraction)
            phases = PHASES[self.groupe]
            rang = next((i for i, (cle, _) in enumerate(phases) if cle == self.phase), 0)
            return {
                "groupe": self.groupe, "phase": self.phase, "etape": self.etape, "detail": self.detail,
                "fichier": self.fichier, "courant": self.courant, "total": self.total,
                "fraction": round(self.fraction, 4), "mots": self.mots, "mots_total": self.mots_total,
                "phases": [{"cle": cle, "libelle": libelle,
                            "etat": "faite" if (i < rang or not self._actif) else ("active" if i == rang else "a_venir")}
                           for i, (cle, libelle) in enumerate(phases)],
                "ecoule": round(ecoule, 1), "restant": restant,
                "derniere_maj": round(maintenant - self._t_maj, 1),
                "decouverts": dict(self.decouverts), "substitutions": dict(self.substitutions),
                "durees": dict(self.durees),
            }
