"""Périmètres de stabilité des pseudonymes : Document, Projet, Client.

Un PÉRIMÈTRE est l'espace dans lequel une identité garde le même pseudonyme :

- DOCUMENT : un document logique (identifié par l'empreinte de son contenu, pas par son nom ni son chemin). Deux documents
  distincts ont des correspondances indépendantes, même dans un même lot.
- PROJET (choix initial) : tous les documents et traitements du projet. Deux projets restent indépendants, même s'ils
  appartiennent au même client.
- CLIENT : tous les documents, projets et traitements explicitement rattachés au client. Ce périmètre facilite les recoupements
  entre dossiers : l'interface l'indique.
- HISTORIQUE : l'ancienne archive migrée (jamais rattachée automatiquement à un client).

Règles : identifiants internes aléatoires et stables ; noms de clients et de projets chiffrés dans le coffre ; aucune recherche ni
fusion automatique d'identités entre périmètres ; variantes apprises, refus de détection et dictionnaires propres à un périmètre ne
sont jamais lus par un autre. Seules les règles linguistiques générales (liste des mots exclus « généraux », titres, particules)
sont partagées.
"""

import re

from .coffre import PERIMETRE_HISTORIQUE, CoffreErreur

NOM_PROJET_PAR_DEFAUT = "Nouveau projet"
TYPES_PORTEE = ("document", "projet", "client")
LISTES_PAR_PERIMETRE = ("personnes", "societes", "produits", "lieux", "exclusions")


class PorteeInvalide(CoffreErreur):
    """Le choix de périmètre est incomplet ou incohérent (le message le dit)."""


def resoudre(coffre, type_, projet_id=None, client_id=None, nouveau_projet=None, nouveau_client=None):
    """Transforme le choix de l'utilisateur en portée : un dictionnaire sérialisable, avec les identifiants internes.

    Les nouveaux projets et clients sont créés ici (leur nom est modifiable ensuite). Aucune réutilisation implicite :
    sans `projet_id` ni `client_id`, un NOUVEAU projet (« Nouveau projet » par défaut) est créé."""
    if type_ not in TYPES_PORTEE:
        raise PorteeInvalide("Choisissez le périmètre des pseudonymes : document, projet ou client.")
    if type_ == "document":
        return {"type": "document", "perimetre_id": None, "projet_id": None, "client_id": None, "projet_nom": None, "client_nom": None}

    client = coffre.lire_perimetre(client_id) if client_id else None
    if client_id and (client is None or client["type"] != "client"):
        raise PorteeInvalide("Client inconnu.")
    projet = coffre.lire_perimetre(projet_id) if projet_id else None
    if projet_id and (projet is None or projet["type"] != "projet"):
        raise PorteeInvalide("Projet inconnu.")

    if type_ == "client":
        if client is None:
            nom = (nouveau_client or "").strip()
            if not nom:
                raise PorteeInvalide("Indiquez le nom du nouveau client, ou choisissez un client existant.")
            client = coffre.lire_perimetre(coffre.creer_perimetre("client", nom))
        if projet is not None and projet["parent_id"] not in (None, client["id"]):
            raise PorteeInvalide("Ce projet est déjà rattaché à un autre client.")
        if projet is not None and projet["parent_id"] is None:
            coffre.rattacher_projet(projet["id"], client["id"])        # rattachement explicite, annoncé à l'écran avant validation
            projet = coffre.lire_perimetre(projet["id"])
        return _portee("client", client, projet, client)

    # type_ == "projet"
    if projet is None:
        nom = (nouveau_projet or "").strip() or NOM_PROJET_PAR_DEFAUT
        projet = coffre.lire_perimetre(coffre.creer_perimetre("projet", nom, parent_id=client["id"] if client else None))
    elif client is not None and projet["parent_id"] not in (None, client["id"]):
        raise PorteeInvalide("Ce projet est déjà rattaché à un autre client.")
    elif client is not None and projet["parent_id"] is None:
        coffre.rattacher_projet(projet["id"], client["id"])
        projet = coffre.lire_perimetre(projet["id"])
    rattache = coffre.lire_perimetre(projet["parent_id"]) if projet["parent_id"] else None
    return _portee("projet", projet, projet, rattache)


def _portee(type_, perimetre, projet, client):
    return {"type": type_, "perimetre_id": perimetre["id"], "projet_id": projet["id"] if projet else None,
            "client_id": client["id"] if client else None, "projet_nom": projet["nom"] if projet else None,
            "client_nom": client["nom"] if client else None}


def valider_portee(coffre, portee):
    """Une portée reçue de l'extérieur doit désigner des périmètres existants du bon type."""
    if not isinstance(portee, dict) or portee.get("type") not in TYPES_PORTEE:
        raise PorteeInvalide("Périmètre invalide.")
    if portee["type"] != "document":
        perimetre = coffre.lire_perimetre(portee.get("perimetre_id"))
        if perimetre is None or perimetre["type"] != portee["type"]:
            raise PorteeInvalide("Le périmètre choisi n'existe plus.")
    return portee


def libelle(coffre, perimetre_id):
    """Nom lisible d'un périmètre pour l'interface (noms de clients et de projets : données de l'utilisateur)."""
    if perimetre_id == PERIMETRE_HISTORIQUE:
        return {"id": perimetre_id, "type": "historique", "nom": None, "parent_id": None, "libelle": "Archive historique"}
    p = coffre.lire_perimetre(perimetre_id)
    if p is None:
        return None
    if p["type"] == "document":
        p["libelle"] = coffre.nom_document(perimetre_id) or "Document"
    else:
        p["libelle"] = p["nom"]
    return p


def lister(coffre):
    """Clients, projets (avec leur client), archive historique et nombre d'identités de chacun ; les documents ensuite."""
    resultat = []
    for p in coffre.lister_perimetres():
        if p["id"] == PERIMETRE_HISTORIQUE:
            continue                       # ajouté une seule fois, en tête
        etiquette = libelle(coffre, p["id"])
        etiquette["comptes"] = coffre.compter_perimetre(p["id"])
        resultat.append(etiquette)
    historique = libelle(coffre, PERIMETRE_HISTORIQUE)
    historique["comptes"] = coffre.compter_perimetre(PERIMETRE_HISTORIQUE)
    ordre = {"historique": 0, "client": 1, "projet": 2, "document": 3}
    return sorted([historique, *resultat], key=lambda p: (ordre[p["type"]], p.get("libelle") or ""))


RE_CODES = None


def codes_dans(texte):
    """Codes de pseudonymes (Personne_KQXMB, [Email_ZTRPA]…) présents dans un texte."""
    global RE_CODES
    if RE_CODES is None:
        from .archive import RE_CODE
        RE_CODES = RE_CODE
    return {m.group() for m in RE_CODES.finditer(texte)}


def detecter(coffre, codes):
    """Retrouve le périmètre d'un ensemble de fichiers pseudonymisés d'après les codes qu'ils contiennent.

    Renvoie {perimetre_id, ambigu, candidats[], codes}. Un périmètre n'est choisi seul que s'il est le seul à connaître TOUS
    les codes (ou, à défaut, le seul à en connaître). Sinon `ambigu` est vrai et l'utilisateur choisit parmi `candidats`.
    Un même code aléatoire peut exister dans deux périmètres : ce n'est jamais résolu silencieusement."""
    codes = sorted(codes)
    if not codes:
        return {"perimetre_id": None, "ambigu": False, "candidats": [], "codes": 0}
    connus = coffre.perimetres_des_codes(codes)
    candidats = []
    for identifiant, n in sorted(connus.items(), key=lambda kv: -kv[1]):
        etiquette = libelle(coffre, identifiant)
        if etiquette:
            candidats.append({**etiquette, "codes_connus": n})
    complets = [c for c in candidats if c["codes_connus"] == len(codes)]
    if len(complets) == 1:
        choix = complets[0]["id"]
    elif not complets and len(candidats) == 1:
        choix = candidats[0]["id"]
    else:
        choix = None
    return {"perimetre_id": choix, "ambigu": choix is None and len(candidats) > 1, "candidats": candidats, "codes": len(codes)}


def dictionnaire_collectif(coffre, perimetre_id):
    """Contenu des listes d'un périmètre : {personnes, societes, produits, lieux, exclusions} (listes de termes)."""
    return {nom: coffre.lire_liste(perimetre_id, nom)["termes"] for nom in LISTES_PAR_PERIMETRE}


def nom_valide(nom):
    return bool(re.sub(r"\s+", "", nom or ""))
