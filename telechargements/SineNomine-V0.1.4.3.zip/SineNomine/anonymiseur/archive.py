"""Archive des codes de remplacement (Personne_KQXMB, [Email_ZTRPA]…) et désanonymisation.

Chaque nom d'origine reçoit un code de 5 lettres tirées au hasard. L'archive conserve, pour
tous les lots, le lien code → valeur d'origine : elle permet de désanonymiser n'importe quel
fichier produit par Sine Nomine, à tout moment. Un même nom garde le même code d'un lot à l'autre.

Le fichier d'archive contient des données identifiantes en clair : il est à garder privé.
"""

import json
import re
import secrets
import string
import threading
from collections import Counter
from pathlib import Path

from .coffre import PERIMETRE_HISTORIQUE
from .detection import CATEGORIES_ENTITES
from .graphies import cle_nom
from . import sensibles

NOM_FICHIER = "archive_codes.json"
LETTRES = string.ascii_uppercase
LONGUEUR_CODE = 5

ETIQUETTES_ENTITES = list(CATEGORIES_ENTITES.values())
ETIQUETTES_SENSIBLES = [e.replace(" ", "_") for e in sensibles.ETIQUETTES.values()]
# Date_de_naissance doit passer avant Date : on trie par longueur décroissante.
_ALTERNATIVES_SENSIBLES = "|".join(re.escape(e) for e in sorted(ETIQUETTES_SENSIBLES, key=len, reverse=True))
MOTIF_ENTITE = r"(?<![A-Za-z0-9])(?:%s)_[A-Z]{%d}(?![A-Za-z0-9])" % (
    "|".join(re.escape(e) for e in ETIQUETTES_ENTITES), LONGUEUR_CODE)
MOTIF_SENSIBLE = r"\[(?:%s)_[A-Z]{%d}\]" % (_ALTERNATIVES_SENSIBLES, LONGUEUR_CODE)
RE_CODE = re.compile(f"{MOTIF_SENSIBLE}|{MOTIF_ENTITE}")
# Le même code deux fois de suite, séparé par des séparateurs : « Personne_KQXMB_Personne_KQXMB » (nom de fichier).
RE_CODE_REPETE = re.compile(f"({MOTIF_SENSIBLE}|{MOTIF_ENTITE})(?:[ _\\-]+\\1)+")


def _union(*listes):
    return list(dict.fromkeys(x for liste in listes for x in liste))


def _fusion_identite(courante, locale):
    """Deux lots qui ont modifié la même identité : on réunit leurs variantes et leurs lots, sans rien perdre."""
    resultat = dict(courante)
    resultat["canonique"] = locale.get("canonique") or courante.get("canonique")
    resultat["variantes"] = _union(courante.get("variantes", []), locale.get("variantes", []))
    resultat["lots"] = _union(courante.get("lots", []), locale.get("lots", []))
    resultat["cree"] = courante.get("cree") or locale.get("cree")
    return resultat


def _fusion_sensible(courante, locale):
    resultat = dict(courante)
    resultat["valeurs"] = sorted({*courante.get("valeurs", []), *locale.get("valeurs", [])})
    resultat["lots"] = _union(courante.get("lots", []), locale.get("lots", []))
    return resultat


class Archive:
    """Table persistante code → valeur d'origine.

    Trois modes : `Archive.ouvrir(config)` (application) lit et écrit dans le COFFRE CHIFFRÉ, de façon transactionnelle ;
    `Archive.charger(chemin)` lit l'ancien fichier JSON en clair (migration, retour arrière) ; `Archive()` : en mémoire (tests).
    """

    def __init__(self, chemin=None, coffre=None, perimetre=None):
        self.chemin = Path(chemin) if chemin else None
        self.coffre = coffre
        self.perimetre = perimetre or (PERIMETRE_HISTORIQUE if coffre is not None else None)
        self._instantane = {"identites": {}, "sensibles": {}}      # état au dernier chargement / enregistrement
        self.verrou = threading.RLock()
        self.entites = {}     # "Personne_KQXMB" -> {categorie, canonique, variantes, lots, cree}
        self.sensibles = {}   # "[Email_ZTRPA]"  -> {categorie, cle, valeurs, lots}
        self.refuses = {}     # catégorie -> [forme normalisée] : décochés lors d'une validation précédente
        self._par_nom = {}    # (catégorie, forme normalisée) -> code
        self._par_cle = {}    # (catégorie sensible, clé) -> code
        self._suffixes = set()

    # ------------------------------------------------------------------ chargement et sauvegarde

    @classmethod
    def ouvrir(cls, config, perimetre=None):
        """Archive de l'application, dans le coffre chiffré (créé, et alimenté depuis l'ancien fichier JSON, au besoin)."""
        from . import migration
        coffre = migration.obtenir_coffre(config)
        migration.migrer_si_necessaire(config, coffre)
        archive = cls(chemin=coffre.dossier, coffre=coffre, perimetre=perimetre)
        archive.recharger()
        return archive

    def recharger(self):
        """Relit le coffre (les modifications d'un autre lot deviennent visibles)."""
        with self.verrou:
            self.entites = self.coffre.lire_table("identites", self.perimetre)
            self.sensibles = self.coffre.lire_table("sensibles", self.perimetre)
            self.refuses = self.coffre.lire_refus(self.perimetre)
            self._indexer()
            self._prendre_instantane()

    @staticmethod
    def _empreinte_fiche(fiche):
        return json.dumps(fiche, sort_keys=True, ensure_ascii=False)

    def _prendre_instantane(self):
        self._instantane = {"identites": {c: self._empreinte_fiche(f) for c, f in self.entites.items()},
                            "sensibles": {c: self._empreinte_fiche(f) for c, f in self.sensibles.items()}}

    def _modifiees(self, table, fiches):
        """Fiches changées depuis le dernier chargement (y compris par modification directe de `entites` / `sensibles`)."""
        return {c: f for c, f in fiches.items() if self._instantane[table].get(c) != self._empreinte_fiche(f)}

    @classmethod
    def charger(cls, chemin):
        archive = cls(chemin)
        if archive.chemin.exists():
            donnees = json.loads(archive.chemin.read_text(encoding="utf-8"))
            archive.entites = donnees.get("entites", {})
            archive.sensibles = donnees.get("sensibles", {})
            archive.refuses = donnees.get("refuses", {})
            archive._indexer()
        return archive

    def _indexer(self):
        self._par_nom = {(v["categorie"], cle_nom(v["canonique"])): code for code, v in self.entites.items()}
        self._par_cle = {(v["categorie"], v["cle"]): code for code, v in self.sensibles.items()}
        self._suffixes = {code.rstrip("]")[-LONGUEUR_CODE:] for code in [*self.entites, *self.sensibles]}

    def sauver(self):
        """Dans le coffre : une transaction qui FUSIONNE les modifications avec l'état courant (jamais d'écrasement d'un lot
        par un autre). Hors coffre : écriture atomique du fichier JSON, avec une copie de la version précédente."""
        if self.coffre is not None:
            with self.verrou:
                self.coffre.fusionner("identites", self.perimetre, self._modifiees("identites", self.entites), _fusion_identite)
                self.coffre.fusionner("sensibles", self.perimetre, self._modifiees("sensibles", self.sensibles), _fusion_sensible)
                self._prendre_instantane()
            return
        if self.chemin is None:
            return
        with self.verrou:
            self.chemin.parent.mkdir(parents=True, exist_ok=True)
            contenu = json.dumps({"version": 1, "entites": self.entites, "sensibles": self.sensibles,
                                  "refuses": self.refuses}, ensure_ascii=False, indent=1)
            temporaire = self.chemin.with_suffix(".tmp")
            temporaire.write_text(contenu, encoding="utf-8")
            if self.chemin.exists():
                self.chemin.replace(self.chemin.with_suffix(".bak"))
            temporaire.replace(self.chemin)

    # ------------------------------------------------------------------ codes

    def _suffixe_libre(self):
        while True:
            suffixe = "".join(secrets.choice(LETTRES) for _ in range(LONGUEUR_CODE))
            if suffixe not in self._suffixes:
                self._suffixes.add(suffixe)
                return suffixe

    def chercher_entite(self, categorie, canonique):
        return self._par_nom.get((categorie, cle_nom(canonique)))

    def code_entite(self, categorie, canonique):
        """Code déjà attribué à ce nom (même catégorie), sinon un nouveau code aléatoire."""
        with self.verrou:
            code = self.chercher_entite(categorie, canonique)
            if code is None and self.coffre is not None:
                code, _ = self.coffre.obtenir_ou_creer(
                    "identites", self.perimetre, categorie, cle_nom(canonique), CATEGORIES_ENTITES[categorie],
                    {"canonique": canonique, "variantes": [], "lots": [], "cree": None})
                fiche = self.coffre.lire_fiche("identites", self.perimetre, code)      # peut venir d'un autre lot
                self.entites[code] = fiche
                self._instantane["identites"][code] = self._empreinte_fiche(fiche)
                self._par_nom[(categorie, cle_nom(fiche["canonique"]))] = code
                self._par_nom[(categorie, cle_nom(canonique))] = code
                self._suffixes.add(code[-LONGUEUR_CODE:])
            elif code is None:
                code = f"{CATEGORIES_ENTITES[categorie]}_{self._suffixe_libre()}"
                self._par_nom[(categorie, cle_nom(canonique))] = code
                self.entites[code] = {"categorie": categorie, "canonique": canonique, "variantes": [],
                                      "lots": [], "cree": None}
            return code

    def code_sensible(self, categorie, cle):
        with self.verrou:
            code = self._par_cle.get((categorie, cle))
            if code is None and self.coffre is not None:
                etiquette = sensibles.ETIQUETTES[categorie].replace(" ", "_")
                code, _ = self.coffre.obtenir_ou_creer("sensibles", self.perimetre, categorie, cle, etiquette,
                                                       {"cle": cle, "valeurs": [], "lots": []}, entourer=True)
                fiche = self.coffre.lire_fiche("sensibles", self.perimetre, code)
                self.sensibles[code] = fiche
                self._instantane["sensibles"][code] = self._empreinte_fiche(fiche)
                self._par_cle[(categorie, cle)] = code
                self._suffixes.add(code.rstrip("]")[-LONGUEUR_CODE:])
            elif code is None:
                etiquette = sensibles.ETIQUETTES[categorie].replace(" ", "_")
                code = f"[{etiquette}_{self._suffixe_libre()}]"
                self._par_cle[(categorie, cle)] = code
                self.sensibles[code] = {"categorie": categorie, "cle": cle, "valeurs": [], "lots": []}
            return code

    # ------------------------------------------------------------------ enregistrement d'un lot

    def enregistrer_lot(self, lot_id, date, entites, libelles, sensibles_libelles, sensibles_valeurs):
        """Complète l'archive avec ce que le lot a réellement utilisé (variantes, valeurs d'origine)."""
        with self.verrou:
            for e in entites:
                code = libelles.get(e.id)
                if code is None:
                    continue
                fiche = self.entites[code]
                fiche["canonique"] = e.canonique
                fiche["variantes"] = list(dict.fromkeys([*fiche["variantes"], *e.variantes]))
                fiche["cree"] = fiche["cree"] or date
                if lot_id not in fiche["lots"]:
                    fiche["lots"].append(lot_id)
            for (categorie, cle), code in sensibles_libelles.items():
                fiche = self.sensibles[code]
                fiche["valeurs"] = sorted({*fiche["valeurs"], *sensibles_valeurs.get((categorie, cle), ())})
                if lot_id not in fiche["lots"]:
                    fiche["lots"].append(lot_id)

    def refuser(self, categorie, canonique):
        with self.verrou:
            formes = self.refuses.setdefault(categorie, [])
            forme = cle_nom(canonique)
            if forme not in formes:
                formes.append(forme)
            if self.coffre is not None:
                self.coffre.refuser(self.perimetre, categorie, forme)

    def accepter(self, categorie, canonique):
        with self.verrou:
            forme = cle_nom(canonique)
            if forme in self.refuses.get(categorie, []):
                self.refuses[categorie].remove(forme)
            if self.coffre is not None:
                self.coffre.accepter(self.perimetre, categorie, forme)

    def est_refuse(self, categorie, canonique):
        return cle_nom(canonique) in self.refuses.get(categorie, [])

    # ------------------------------------------------------------------ désanonymisation

    def valeur_d_origine(self, code):
        """Valeur d'origine d'un code, ou None s'il est inconnu (ou si la valeur n'a pas été archivée)."""
        fiche = self.entites.get(code)
        if fiche:
            return fiche["canonique"]
        fiche = self.sensibles.get(code)
        if fiche and fiche["valeurs"]:
            return fiche["valeurs"][0]
        return None

    def rechercher(self, requete, limite=100):
        """Entrées de l'archive dont le code, le nom d'origine, une variante ou une valeur correspond à la requête.

        Sans requête : les premières entrées. Renvoie (liste, tronque).
        """
        requete = (requete or "").strip()
        cle = cle_nom(requete)
        trouvees = []
        for code, fiche in self.entites.items():
            textes = [fiche["canonique"], *fiche["variantes"]]
            if not requete or cle in cle_nom(code) or any(cle in cle_nom(t) for t in textes):
                trouvees.append({"code": code, "type": "entite", "categorie": fiche["categorie"],
                                 "valeur": fiche["canonique"], "variantes": fiche["variantes"],
                                 "lots": fiche["lots"], "cree": fiche["cree"]})
        for code, fiche in self.sensibles.items():
            if not requete or cle in cle_nom(code) or any(cle in cle_nom(v) for v in fiche["valeurs"]):
                trouvees.append({"code": code, "type": "sensible", "categorie": fiche["categorie"],
                                 "valeur": " | ".join(fiche["valeurs"]), "variantes": [], "lots": fiche["lots"],
                                 "cree": None})
        trouvees.sort(key=lambda t: (t["type"], t["categorie"], t["code"]))
        return trouvees[:limite], len(trouvees) > limite

    def resume(self):
        return {"entites": len(self.entites), "sensibles": len(self.sensibles),
                "chemin": str(self.chemin) if self.chemin else None}


class Restaurateur:
    """Même interface que `remplacement.Correspondances`, mais remplace les codes par les valeurs d'origine."""

    def __init__(self, archive):
        self.archive = archive
        self.inconnus = Counter()   # codes retrouvés dans les fichiers mais absents de l'archive

    def remplacer(self, texte):
        from .remplacement import Remplacement  # import tardif : évite une dépendance circulaire
        remplacements = []
        for m in RE_CODE.finditer(texte):
            origine = self.archive.valeur_d_origine(m.group())
            if origine is None:
                self.inconnus[m.group()] += 1
                continue
            remplacements.append(Remplacement(m.start(), m.end(), origine, "entite", m.group()))
        morceaux, position = [], 0
        for r in remplacements:
            morceaux += [texte[position:r.debut], r.texte]
            position = r.fin
        morceaux.append(texte[position:])
        return "".join(morceaux), remplacements, []
