"""Lancement : python -m anonymiseur [--port N] [--sans-navigateur] [--sans-gliner] [--telecharger-modeles]

Lancé avec pythonw.exe (raccourci du Bureau), il n'y a pas de console : les messages
vont dans %LOCALAPPDATA%\\SineNomine\\sine-nomine.log, et on arrête Sine Nomine avec
le bouton « Quitter » de l'interface.
"""

import argparse
import atexit
import json
import os
import socket
import sys
import threading
import urllib.request
import warnings
import webbrowser
from pathlib import Path

# Avertissements des bibliothèques d'IA sans effet sur le résultat : ils ressemblent à des erreurs dans la console.
warnings.filterwarnings("ignore", message=".*torch.jit.script.*is deprecated")
warnings.filterwarnings("ignore", message=".*resume_download.*")

from . import VERSION, config as cfg
from .detection import Modeles

def _dossier_journal():
    """Windows : dossier LocalAppData de l'utilisateur ; macOS : ~/Library/Logs/SineNomine ; Linux : ~/.local/state/SineNomine."""
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SineNomine"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Logs" / "SineNomine"
    return Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / "SineNomine"


JOURNAL = _dossier_journal() / "sine-nomine.log"


def port_libre(depart):
    for port in range(depart, depart + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise RuntimeError("Aucun port libre trouvé.")


def instance_existante(port):
    """Vrai si Sine Nomine tourne déjà sur ce port (route publique /api/ping : aucune donnée n'y figure)."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=2) as reponse:
            return "version" in json.load(reponse)
    except (OSError, ValueError):
        return False


def rouvrir_instance(port_demande, ouvrir=True):
    """Second lancement : demande à l'instance en cours un jeton d'ouverture (grâce au secret de instance.json), puis ouvre le
    navigateur. Renvoie True si une instance a été trouvée."""
    from . import securite
    connue = securite.lire_instance(JOURNAL.parent)
    port = connue[0] if connue else port_demande
    if not instance_existante(port):
        return False
    if connue and ouvrir:
        requete = urllib.request.Request(f"http://127.0.0.1:{port}/api/instance/jeton", data=b"{}", method="POST",
                                         headers={"X-Instance-Secret": connue[1], "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(requete, timeout=5) as reponse:
                jeton = json.load(reponse)["jeton"]
            webbrowser.open(f"http://127.0.0.1:{port}/?jeton={jeton}")
        except (OSError, ValueError, KeyError):
            print("Sine Nomine est déjà lancé, mais l'ouverture automatique a échoué : utilisez la fenêtre déjà ouverte.")
    elif ouvrir:
        print("Sine Nomine est déjà lancé : utilisez la fenêtre déjà ouverte du navigateur.")
    return True


def sans_console():
    """Sous pythonw.exe, sys.stdout est absent : on écrit dans un journal."""
    if sys.stdout is None or sys.stderr is None:
        JOURNAL.parent.mkdir(parents=True, exist_ok=True)
        # Ajout plutôt qu'écrasement (plusieurs lancements possibles), remis à zéro au-delà de 2 Mo.
        mode = "w" if JOURNAL.exists() and JOURNAL.stat().st_size > 2 * 1024**2 else "a"
        flux = open(JOURNAL, mode, encoding="utf-8", buffering=1)  # noqa: SIM115 — ouvert pour toute la session
        sys.stdout = sys.stderr = flux
        return True
    return False


def commande_licence(args):
    """--licence, --verifier-cle, --activer : seules commandes qui peuvent se connecter à Internet (à l'installation)."""
    from . import licence
    config = cfg.charger()
    serveur = (config.get("licence") or {}).get("serveur") or licence.SERVEUR_PAR_DEFAUT
    sortie = []

    def dire(texte):
        print(texte)
        sortie.append(texte)

    code = 0
    try:
        if args.licence:
            print(json.dumps(licence.etat(config), ensure_ascii=False))
            return 0
        cle = args.verifier_cle or args.activer
        if not cle:
            cle = input("Clé d'accès (SN-XXXXX-XXXXX-XXXXX-XXXXX) : ").strip()
        if args.verifier_cle:
            dire(licence.verifier_cle(cle, args.langue, serveur)["message"])
        else:
            dire(licence.activer(cle, args.langue, serveur)["message"])
    except licence.LicenceErreur as e:
        dire(str(e))
        code = 1
    if args.sortie:
        Path(args.sortie).write_text(chr(10).join(sortie), encoding="utf-8")
    return code


def main():
    parser = argparse.ArgumentParser(prog="sine-nomine", description="Sine Nomine — anonymiseur local")
    parser.add_argument("--port", type=int)
    parser.add_argument("--sans-navigateur", action="store_true")
    parser.add_argument("--sans-gliner", action="store_true",
                        help="Démarrage plus rapide, sans le modèle GLiNER (produits par dictionnaire seulement).")
    parser.add_argument("--telecharger-modeles", action="store_true",
                        help="Télécharge et vérifie les modèles, puis quitte.")
    parser.add_argument("--activer", nargs="?", const="", metavar="CLE",
                        help="Active cette installation avec une clé d'accès (connexion Internet), puis quitte.")
    parser.add_argument("--verifier-cle", metavar="CLE", help="Vérifie une clé sans l'utiliser, puis quitte.")
    parser.add_argument("--licence", action="store_true", help="Affiche l'état de la licence, puis quitte.")
    parser.add_argument("--langue", default="fr", choices=["fr", "en"], help="Langue des messages d'activation.")
    parser.add_argument("--sortie", metavar="FICHIER", help="Écrit aussi le message d'activation dans ce fichier.")
    args = parser.parse_args()

    if args.licence or args.verifier_cle or args.activer is not None:
        raise SystemExit(commande_licence(args))

    if not args.telecharger_modeles:
        # Hors ligne : les modèles installés se chargent sans contacter Hugging Face (vérifié), de sorte que
        # Sine Nomine n'établit aucune connexion Internet. Seul --telecharger-modeles (installer.bat) se connecte.
        os.environ.setdefault("HF_HUB_OFFLINE", "1")
        os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    config = cfg.charger()
    if args.sans_gliner:
        config["gliner"]["actif"] = False
    port_demande = args.port or config["port"]
    if not args.telecharger_modeles and (instance_existante(port_demande) or rouvrir_instance(port_demande, ouvrir=False)):
        # Déjà lancé (double-clic répété sur le raccourci) : on rouvre l'interface avec un nouveau jeton d'ouverture.
        rouvrir_instance(port_demande, ouvrir=not args.sans_navigateur)
        return

    silencieux = sans_console()
    modeles = Modeles(config)
    if args.telecharger_modeles:
        modeles._charger()
        for erreur in modeles.erreurs:
            print("ERREUR :", erreur)
        print("Modèles :", modeles.etat)
        raise SystemExit(0 if modeles.nlp is not None else 1)

    modeles.charger_en_arriere_plan()
    from waitress import serve
    from .serveur import creer_application

    port = port_libre(port_demande)
    adresse = f"http://127.0.0.1:{port}/"
    print(f"Sine Nomine {VERSION} — interface : {adresse}")
    if silencieux:
        print("Lancé sans console : utilisez le bouton « Quitter » de l'interface pour arrêter Sine Nomine.")
    else:
        print("Laissez cette fenêtre ouverte pendant l'utilisation. Fermez-la pour arrêter Sine Nomine.")
    from . import migration, publication, securite
    try:        # reprise après une panne : publications interrompues terminées ou abandonnées proprement
        for lot_id, action in publication.recuperer(migration.obtenir_coffre(config)):
            print(f"Reprise du lot {lot_id} : {action}")
    except Exception as e:  # noqa: BLE001 — le coffre inutilisable est signalé dans l'interface, pas ici
        print(f"Reprise des publications impossible : {type(e).__name__}")
    application = creer_application(config, modeles)
    garde = application.extensions["securite"]
    securite.ecrire_instance(JOURNAL.parent, port, garde.secret_instance)
    atexit.register(securite.effacer_instance, JOURNAL.parent)
    if not args.sans_navigateur:
        threading.Timer(1.5, webbrowser.open, args=(f"{adresse}?jeton={garde.nouveau_jeton()}",)).start()
    serve(application, host="127.0.0.1", port=port, threads=8, max_request_body_size=2 * 1024**3)


if __name__ == "__main__":
    main()
