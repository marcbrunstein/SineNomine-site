"""Textes juridiques affichés dans l'interface et repris dans les rapports.

Ces textes sont à faire valider par un juriste avant toute diffusion de Sine Nomine.
Le fichier LICENCE.md reprend les mêmes conditions : à garder cohérent avec ce module.
"""

ANNEE = 2026
TITULAIRE = "Habeas Corpus"
EDITEUR = "Habeas Corpus Consulting"
MARQUE = f"{EDITEUR} est une marque de {TITULAIRE}"
CONTACT_EMAIL = "contact@sinenomine.app"
CONTACT_TELEPHONE = "+33 1 89 16 73 22"

PROPRIETE = (
    f"Sine Nomine est la propriété intellectuelle exclusive de {TITULAIRE} ({MARQUE}). "
    "Une clé d'accès, saisie à l'installation ou dans l'application, concède un droit d'utilisation personnel, non exclusif et non cessible, pour la durée attachée à la clé (comptée à partir de l'activation, ou sans limite de durée pour une licence à vie) et pour le nombre d'installations qu'elle autorise. Une clé de version d'évaluation limite l'usage à l'évaluation du logiciel : elle peut porter sur vos propres documents, dans la mesure où vous avez le droit d'en traiter les données, mais ne constitue pas un usage en production. Une clé de version commerciale permet l'usage professionnel dans les conditions du contrat conclu avec Habeas Corpus Il est interdit de contourner ou de désactiver le mécanisme d'activation, de redistribuer le logiciel ou de le mettre à disposition de tiers. À l'issue de la durée attachée à la clé, toute poursuite de l'utilisation nécessite une nouvelle clé ou l'accord préalable et écrit de Habeas Corpus, à demander à contact@sinenomine.app ou au +33 1 89 16 73 22."
)

COMPOSANTS_TIERS = (
    "Sine Nomine s'appuie sur des composants libres (spaCy, GLiNER, Flask, python-docx, python-pptx, "
    "openpyxl…) qui restent soumis à leurs propres licences. Ils ne sont pas redistribués avec Sine Nomine : "
    "ils sont téléchargés à l'installation depuis leurs sources officielles. La liste figure sous "
    "« Licences tierces » et dans le fichier THIRD_PARTY_NOTICES.md."
)

RESPONSABILITE = (
    "Sine Nomine est fourni « en l'état », sans garantie d'aucune sorte, expresse ou implicite, notamment "
    "quant à l'exhaustivité de la détection, à l'adéquation à un usage particulier ou à l'absence d'erreur. "
    f"Dans toute la mesure permise par la loi, {TITULAIRE} n'est pas responsable des dommages directs ou "
    "indirects pouvant résulter de l'utilisation de l'outil, de son fonctionnement ou de ses "
    "dysfonctionnements, y compris en cas d'information non détectée, mal remplacée ou divulguée. "
    "Cette exclusion ne s'applique ni en cas de faute lourde ou de dol, ni dans les cas où la loi interdit "
    "de l'écarter. L'utilisateur reste seul responsable de la vérification des fichiers produits et de "
    "l'usage qu'il en fait."
)

FIABILITE = (
    "Aucune détection automatique n'est fiable à 100 %. Des noms, sociétés, produits, lieux ou "
    "informations sensibles peuvent ne pas être détectés, ou être détectés à tort. "
    "La validation humaine de chaque traitement est indispensable, et les fichiers "
    "produits doivent être relus avant toute diffusion."
)

CONFIDENTIALITE = (
    "Sine Nomine traite vos fichiers uniquement sur votre ordinateur et n'envoie aucun de vos documents ni aucun nom "
    "sur Internet. Internet n'est utilisé qu'à l'installation : pour télécharger les composants et les modèles de "
    "détection, et (à l'installation ou lorsque vous saisissez une nouvelle clé dans l'application) pour activer votre clé d'accès auprès du serveur d'activation de Habeas Corpus, qui ne reçoit "
    "que la clé, un identifiant d'installation aléatoire, la version et la langue (voir la politique de confidentialité "
    "sur https://www.sinenomine.app). Une fois installé, Sine Nomine fonctionne hors ligne. Si vous placez les dossiers "
    "de Sine Nomine ou vos fichiers dans un service de synchronisation ou d'archivage (Google Drive, OneDrive ou tout "
    "autre), c'est ce service qui transmet et conserve les fichiers, selon ses propres conditions et sous votre "
    "responsabilité. Avec des fichiers uniquement sur le disque local, aucun document ne quitte l'ordinateur."
)

PSEUDONYMISATION = (
    "Chaque nom est remplacé par un code aléatoire (par exemple Personne_KQXMB). La table de "
    "correspondance et l'archive des codes (archive_codes.json) permettent de retrouver les "
    "informations d'origine et de dé-pseudonymiser les fichiers : au sens du RGPD, il s'agit d'une "
    "pseudonymisation et non d'une anonymisation. Ces fichiers contiennent les informations d'origine en clair : "
    "conservez-les à part, de manière sécurisée, ou supprimez-les si vous n'en avez pas besoin."
)

ANONYMISATION = (
    "Mode anonymisation : les noms sont remplacés par des numéros (Personne_1, Société_1…) et aucune "
    "table de correspondance ni archive n'est conservée : Sine Nomine ne garde aucun moyen de retrouver les "
    "noms d'origine à partir des fichiers produits. Ce mode ne garantit pas que le résultat soit anonyme au "
    "sens du RGPD : un texte peut rester identifiable par recoupement (fonction, lieu, événement, combinaison "
    "d'informations). Relisez-le avant diffusion."
)

LOI_APPLICABLE = (
    "Les présentes conditions sont soumises au droit français. À défaut d'accord amiable, tout litige relève "
    "des tribunaux de Paris, sous réserve des règles de compétence impératives, notamment en faveur des "
    "consommateurs."
)

MODES = {"pseudonymisation": "Pseudonymisation (réversible)",
         "anonymisation": "Anonymisation (sans table de correspondance)"}

MENTION_COURTE = (
    f"© {ANNEE} {EDITEUR}, marque de {TITULAIRE} — Sine Nomine. Utilisation soumise à une licence (clé d'accès) de {TITULAIRE}"
)


# ---------------------------------------------------------------- English version
# Traduction de courtoisie : la version française prévaut (voir LOI_APPLICABLE_EN). À faire relire par un juriste.
PROPRIETE_EN = (
    f"Sine Nomine is the exclusive intellectual property of {TITULAIRE} ({EDITEUR} is a trademark of {TITULAIRE}). "
    'An access key, entered at installation or in the application, grants a personal, non-exclusive, non-transferable right of use for the period attached to the key (counted from activation, or with no time limit for a lifetime licence) and for the number of installations it allows. An evaluation-version key limits use to evaluating the software: it may cover your own documents, provided you are entitled to process their data, but it is not production use. A commercial-version key allows professional use on the terms of the contract concluded with Habeas Corpus You may not circumvent or disable the activation mechanism, redistribute the software or make it available to third parties. When the period attached to the key ends, any continued use requires a new key or the prior written consent of Habeas Corpus, to be requested from contact@sinenomine.app or on +33 1 89 16 73 22.'
)
COMPOSANTS_TIERS_EN = (
    "Sine Nomine relies on open-source components (spaCy, GLiNER, Flask, python-docx, python-pptx, openpyxl…) which "
    "remain subject to their own licences. They are not redistributed with Sine Nomine: they are downloaded at "
    "installation from their official sources. The list appears under “Third-party licences” and in the "
    "THIRD_PARTY_NOTICES.md file."
)
RESPONSABILITE_EN = (
    "Sine Nomine is provided “as is”, without warranty of any kind, express or implied, including as to the "
    "completeness of detection, fitness for a particular purpose or freedom from errors. "
    f"To the fullest extent permitted by law, {TITULAIRE} is not liable for any direct or indirect damage that may result "
    "from the use of the tool, its operation or its malfunctions, including where information is not detected, wrongly "
    "replaced or disclosed. This exclusion does not apply in cases of gross negligence or wilful misconduct, nor where "
    "the law prohibits excluding liability. The user remains solely responsible for checking the files produced and "
    "for how they are used."
)
FIABILITE_EN = (
    "No automatic detection is 100% reliable. Names, companies, products, places or sensitive information may go "
    "undetected, or be detected wrongly. Human review of each processing run is essential, and the files produced must "
    "be proofread before any distribution."
)
CONFIDENTIALITE_EN = (
    "Sine Nomine processes your files only on your computer and sends none of your documents and no names over the "
    "Internet. The Internet is used only during installation: to download the components and the detection models, "
    "and (at installation or when you enter a new key in the application) to activate your access key with Habeas Corpus's activation server, which receives only the key, a "
    "random installation identifier, the version and the language (see the privacy policy at "
    "https://www.sinenomine.app). Once installed, Sine Nomine works offline. If you place Sine Nomine's folders or "
    "your files in a synchronisation or archiving service (Google Drive, OneDrive or any other), it is that service "
    "that transmits and stores the files, under its own terms and at your own responsibility. With files kept only on "
    "the local disk, no document leaves the computer."
)
PSEUDONYMISATION_EN = (
    "Each name is replaced by a random code (for example Personne_KQXMB). The correspondence table and the code archive "
    "(archive_codes.json) make it possible to recover the original information and to de-pseudonymise files: under the "
    "GDPR this is pseudonymisation, not anonymisation. These files contain the original information in clear: keep them "
    "separately and securely, or delete them if you do not need them."
)
ANONYMISATION_EN = (
    "Anonymisation mode: names are replaced by numbers (Personne_1, Société_1…) and no correspondence table or archive "
    "is kept: Sine Nomine keeps no means of recovering the original names from the files produced. This mode does not "
    "guarantee that the result is anonymous within the meaning of the GDPR: a text may remain identifiable by "
    "cross-referencing (role, place, event, combination of information). Proofread it before sharing."
)
LOI_APPLICABLE_EN = (
    "These terms are governed by French law. Failing an amicable agreement, any dispute falls within the jurisdiction "
    "of the courts of Paris, subject to mandatory rules of jurisdiction, in particular in favour of consumers. In the "
    "event of any discrepancy between the French and English versions, the French version prevails."
)
MODES_EN = {"pseudonymisation": "Pseudonymisation (reversible)", "anonymisation": "Anonymisation (no correspondence table)"}
MENTION_COURTE_EN = (
    f"© {ANNEE} {EDITEUR}, a trademark of {TITULAIRE} — Sine Nomine. Use subject to a licence (access key) from {TITULAIRE}"
)

LANGUES = ("fr", "en")
TEXTES = {
    "fr": {"propriete": PROPRIETE, "composants": COMPOSANTS_TIERS, "responsabilite": RESPONSABILITE, "fiabilite": FIABILITE,
           "confidentialite": CONFIDENTIALITE, "pseudonymisation": PSEUDONYMISATION, "anonymisation": ANONYMISATION,
           "loi": LOI_APPLICABLE, "mention": MENTION_COURTE},
    "en": {"propriete": PROPRIETE_EN, "composants": COMPOSANTS_TIERS_EN, "responsabilite": RESPONSABILITE_EN,
           "fiabilite": FIABILITE_EN, "confidentialite": CONFIDENTIALITE_EN, "pseudonymisation": PSEUDONYMISATION_EN,
           "anonymisation": ANONYMISATION_EN, "loi": LOI_APPLICABLE_EN, "mention": MENTION_COURTE_EN},
}
MODES_PAR_LANGUE = {"fr": MODES, "en": MODES_EN}


def langue_valide(langue):
    return langue if langue in LANGUES else "fr"


def texte(cle, langue="fr"):
    """Texte légal `cle` (« propriete », « loi »…) dans la langue demandée (français par défaut)."""
    return TEXTES[langue_valide(langue)][cle]


def avertissement(langue="fr"):
    langue = langue_valide(langue)
    return {**TEXTES[langue], "editeur": EDITEUR, "titulaire": TITULAIRE, "email": CONTACT_EMAIL,
            "telephone": CONTACT_TELEPHONE}
