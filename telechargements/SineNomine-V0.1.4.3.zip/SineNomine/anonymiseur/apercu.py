"""Miniatures des images conservées, pour les vérifier à l'écran et dans le rapport."""

import io
from pathlib import Path

AFFICHABLES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
               ".bmp": "image/bmp", ".webp": "image/webp"}


def miniature(donnees, nom, taille):
    """(octets, type MIME, (largeur, hauteur) d'origine) réduits à `taille` px au plus, ou None si illisible.

    Les petites images ne sont pas agrandies. Les formats que le navigateur ne sait pas
    afficher (EMF, WMF, TIFF…) sont convertis en PNG.
    """
    extension = Path(nom).suffix.lower()
    if extension == ".svg":
        return donnees, "image/svg+xml", None
    try:
        from PIL import Image
        with Image.open(io.BytesIO(donnees)) as image:
            image.load()
            dimensions = image.size
            image.thumbnail((taille, taille))
            transparente = image.mode in ("RGBA", "LA", "P") or "transparency" in image.info
            image = image.convert("RGBA" if transparente else "RGB")
            sortie = io.BytesIO()
            if transparente:
                image.save(sortie, "PNG", optimize=True)
                return sortie.getvalue(), "image/png", dimensions
            image.save(sortie, "JPEG", quality=85)
            return sortie.getvalue(), "image/jpeg", dimensions
    except Exception:  # noqa: BLE001 — format non pris en charge : on tente l'affichage direct
        if extension in AFFICHABLES:
            return donnees, AFFICHABLES[extension], None
        return None
