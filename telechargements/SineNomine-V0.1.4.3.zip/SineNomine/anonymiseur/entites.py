"""Regroupement des candidats en entités, et variantes à rechercher dans les textes.

« Jean Dupont », « M. Dupont », « J. Dupont » et « DUPONT » deviennent une seule
entité (Personne 1), remplacée de la même façon dans tous les fichiers du lot.
"""

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from .detection import CATEGORIES_ENTITES, PARTICULES_NOM, RE_ELISION, TITRES, normaliser

FORMES_JURIDIQUES = re.compile(
    r"[\s,]+(?:SA|SAS|SASU|SARL|EURL|SCI|SNC|SCP|SCM|SELARL|SELAS|SELAFA|GIE|SEM|"
    r"S\.A\.S?\.?|S\.A\.R\.L\.?|Inc\.?|Ltd\.?|LLC|LLP|PLC|GmbH|AG|BV|NV|SpA|S\.p\.A\.|Corp\.?|Co\.?)$",
    re.IGNORECASE)

TITRES_VARIANTES = ["M.", "Mme", "Mlle", "Me", "Maître", "Monsieur", "Madame", "Dr", "Docteur",
                    "Mr", "Mrs", "Ms", "Miss", "Prof", "Sir"]


@dataclass
class Entite:
    id: int
    categorie: str
    canonique: str
    variantes: list
    score: float
    sources: list
    selection: bool = True
    code: str = None            # code déjà attribué dans l'archive (lots précédents), sinon None
    occurrences: int = 0
    fichiers: dict = field(default_factory=dict)
    contextes: list = field(default_factory=list)
    premiere: tuple = (10**9, 10**9)

    def vers_dict(self):
        return {
            "id": self.id, "categorie": self.categorie, "canonique": self.canonique,
            "variantes": self.variantes, "score": self.score, "sources": self.sources,
            "selection": self.selection, "code": self.code, "occurrences": self.occurrences,
            "fichiers": self.fichiers, "contextes": self.contextes,
        }


def _est_particule(mot):
    return mot.lower() in PARTICULES_NOM or RE_ELISION.match(mot) is not None


def _en_capitales(mot):
    """Un vrai mot en capitales : au moins deux lettres (« J. » est une initiale, pas un nom)."""
    return mot.isupper() and len(re.sub(r"\W", "", mot)) >= 2


def _decouper_nom(surface):
    """(titre présent, prénom ou None, nom de famille ou None).

    Le nom de famille garde sa particule : « Charles de Gaulle » → ("Charles", "de Gaulle").
    """
    mots = surface.replace("’", "'").split()
    titre = False
    while mots and normaliser(mots[0]) in TITRES:
        mots, titre = mots[1:], True
    if not mots:
        return titre, None, None
    if len(mots) == 1:
        return (titre, None, mots[0]) if titre else (titre, mots[0], None)
    # « DUPONT Jean », « DE GAULLE Charles » : nom en capitales d'abord, suivi du prénom
    capitales = 0
    while capitales < len(mots) and _en_capitales(mots[capitales]):
        capitales += 1
    if 0 < capitales < len(mots):
        return titre, " ".join(mots[capitales:]), " ".join(mots[:capitales])
    # Particule : le nom de famille commence à la première particule (« Martina de Dilectis »).
    rang = next((i for i, m in enumerate(mots) if _est_particule(m)), None)
    if rang == 0:
        return titre, None, " ".join(mots)                  # « de Gaulle », « Le Pen »
    if rang is not None:
        return titre, " ".join(mots[:rang]), " ".join(mots[rang:])
    return titre, mots[0], " ".join(mots[1:])


def _prenoms_compatibles(a, b):
    if a is None or b is None:
        return True
    na, nb = normaliser(a).rstrip("."), normaliser(b).rstrip(".")
    if na == nb:
        return True
    if len(na) == 1 or len(nb) == 1:
        return na[0] == nb[0]
    return False


def _choisir_categories(candidats):
    """Une seule catégorie par forme : celle au meilleur score, puis la plus fréquente."""
    par_forme = defaultdict(lambda: defaultdict(list))
    for c in candidats:
        par_forme[normaliser(c.surface)][c.categorie].append(c.score)
    choix = {}
    for forme, categories in par_forme.items():
        choix[forme] = max(categories, key=lambda cat: (max(categories[cat]), len(categories[cat])))
    return choix


def regrouper(candidats):
    choix = _choisir_categories(candidats)
    retenus = [c for c in candidats if choix[normaliser(c.surface)] == c.categorie]

    groupes = []  # chaque groupe : dict(categorie, surfaces Counter, scores, sources, cle…)

    def nouveau(categorie, **cles):
        g = {"categorie": categorie, "surfaces": Counter(), "score": 0.0, "sources": set(), **cles}
        groupes.append(g)
        return g

    def ajouter(g, c):
        g["surfaces"][c.surface] += 1
        g["score"] = max(g["score"], c.score)
        g["sources"].add(c.source)

    # Personnes : d'abord les noms complets, puis les formes courtes rattachées si sans ambiguïté.
    personnes = [c for c in retenus if c.categorie == "personne"]
    complets, courts = [], []
    for c in personnes:
        titre, prenom, nom = _decouper_nom(c.surface)
        if prenom is None and nom is None:
            continue
        (complets if prenom and nom else courts).append((c, titre, prenom, nom))

    for c, _, prenom, nom in complets:
        cible = None
        for g in groupes:
            if (g["categorie"] == "personne" and g.get("nom") and normaliser(g["nom"]) == normaliser(nom)
                    and _prenoms_compatibles(g.get("prenom"), prenom)):
                cible = g
                break
        if cible is None:
            cible = nouveau("personne", nom=nom, prenom=prenom)
        elif cible.get("prenom") and len(prenom.rstrip(".")) > len(cible["prenom"].rstrip(".")):
            cible["prenom"] = prenom
        ajouter(cible, c)

    for c, titre, prenom, nom in courts:
        pers = [g for g in groupes if g["categorie"] == "personne" and g.get("nom")]
        if nom:  # « M. Dupont » ou nom seul
            liste = [g for g in pers if normaliser(g["nom"]) == normaliser(nom)]
        else:    # prénom seul, ou nom seul sans titre
            liste = [g for g in pers if normaliser(g["nom"]) == normaliser(prenom)]
            if not liste:
                liste = [g for g in pers if g.get("prenom") and normaliser(g["prenom"]) == normaliser(prenom)]
        if len(liste) == 1:
            ajouter(liste[0], c)
            continue
        cle = normaliser(nom or prenom)
        seul = next((g for g in groupes if g["categorie"] == "personne" and g.get("seul") == cle), None)
        if seul is None:
            seul = nouveau("personne", seul=cle, ambigu=len(liste) > 1)
        ajouter(seul, c)

    # Sociétés : même nom une fois retirée la forme juridique.
    for c in retenus:
        if c.categorie != "societe":
            continue
        cle = normaliser(FORMES_JURIDIQUES.sub("", c.surface))
        g = next((g for g in groupes if g["categorie"] == "societe" and g["cle"] == cle), None)
        ajouter(g or nouveau("societe", cle=cle, base=FORMES_JURIDIQUES.sub("", c.surface)), c)

    # Produits et lieux : même nom à la casse près.
    for c in retenus:
        if c.categorie not in ("produit", "lieu"):
            continue
        cle = normaliser(c.surface)
        g = next((g for g in groupes if g["categorie"] == c.categorie and g["cle"] == cle), None)
        ajouter(g or nouveau(c.categorie, cle=cle), c)

    noms_partages = Counter(normaliser(g["nom"]) for g in groupes if g.get("nom"))
    # Formes détectées comme société, produit ou lieu : une personne ne doit pas se les approprier par une
    # variante générée (« Marques Jovoy » ne doit pas capter « Jovoy », le nom de la société).
    formes_autres = set()
    for g in groupes:
        if g["categorie"] != "personne":
            formes_autres |= {normaliser(s) for s in g["surfaces"]}
            if g.get("base"):
                formes_autres.add(normaliser(g["base"]))
    entites = []
    for i, g in enumerate(groupes, start=1):
        surfaces = [s for s, _ in g["surfaces"].most_common()]
        variantes = list(dict.fromkeys(surfaces))
        if g["categorie"] == "personne" and g.get("nom"):
            variantes += variantes_personne(g.get("prenom"), g["nom"], noms_partages[normaliser(g["nom"])] == 1)
        elif g["categorie"] == "societe" and len(g["base"]) >= 3:
            variantes.append(g["base"])
        variantes = list(dict.fromkeys(v for v in variantes if len(v) >= 2))
        if g["categorie"] == "personne":
            variantes = [v for v in variantes if v in surfaces or normaliser(v) not in formes_autres]
        canonique = max(surfaces, key=len)
        entites.append(Entite(id=i, categorie=g["categorie"], canonique=canonique, variantes=variantes,
                              score=affiner_score(g), sources=sorted(g["sources"])))
    return entites


def affiner_score(g):
    """Score de confiance d'un groupe : le meilleur score des détecteurs, ajusté par des indices de fiabilité.

    + l'accord de spaCy et de GLiNER ; − un nom de personne isolé (ni prénom ni titre), souvent un mot courant.
    Un terme du dictionnaire garde sa confiance maximale.
    """
    score = g["score"]
    if "dictionnaire" in g["sources"]:
        return round(score, 2)
    if {"spaCy", "GLiNER"} <= g["sources"]:
        score += 0.15
    elif g["categorie"] == "personne":
        score -= 0.15          # un vrai nom de personne est presque toujours vu par les deux modèles
    elif g["categorie"] == "societe" and g["sources"] == {"spaCy"} and not _nom_propre_net(g):
        score -= 0.2           # spaCy seul : sigles, intitulés et titres d'onglets pris pour des sociétés
    if g["categorie"] == "personne" and g.get("seul") is not None:
        score -= 0.25
    return round(min(max(score, 0.0), 0.99), 2)


def _nom_propre_net(g):
    """Vrai si la forme la plus fréquente ressemble à un nom propre : mots en majuscule initiale, ni sigle ni chiffre."""
    surface = g["surfaces"].most_common(1)[0][0]
    for mot in surface.split():
        if mot.lower() in PARTICULES_NOM:
            continue
        if not mot[:1].isupper() or re.search(r"\d", mot) or (mot.isupper() and len(mot) <= 6):
            return False
    return True


def variantes_personne(prenom, nom, nom_seul_autorise):
    """Formes usuelles d'un nom de personne, pour attraper les mentions non détectées."""
    v = []
    if prenom:
        initiale = prenom[0] + "."
        v += [f"{prenom} {nom}", f"{initiale} {nom}", f"{nom} {prenom}", f"{prenom} {nom.upper()}",
              f"{nom.upper()} {prenom}", f"{initiale} {nom.upper()}"]
    if nom_seul_autorise and len(nom) >= 3:
        v.append(nom)
        v += [f"{t} {nom}" for t in TITRES_VARIANTES]
        if prenom:
            v += [f"{t} {prenom} {nom}" for t in TITRES_VARIANTES]
        # « Gaulle » sans la particule : plus rare, mais on la rencontre (« le général Gaulle »)
        mots = nom.split()
        while len(mots) > 1 and _est_particule(mots[0]):
            mots = mots[1:]
        nu = " ".join(mots)
        if nu != nom and len(nu) >= 4:
            v += [nu] + [f"{t} {nu}" for t in TITRES_VARIANTES]
    return v


def formes_de_casse(variante):
    """La variante telle quelle, en capitales et avec une majuscule à chaque mot."""
    formes = {variante, variante.upper()}
    if not any(c.isupper() for c in variante[1:]):
        formes.add(" ".join(m[:1].upper() + m[1:] for m in variante.split(" ")))
    elif variante.isupper() and len(variante) >= 4:
        # « JOVOY » détecté en capitales : « Jovoy » désigne la même chose dans le texte courant.
        formes.add(" ".join(m.capitalize() for m in variante.split(" ")))
    return formes


def libelles_numerotes(entites):
    """Mode anonymisation : Personne_1, Société_2… dans l'ordre d'apparition. Rien n'est conservé :
    le numéro ne permet pas de retrouver le nom, il garde seulement la cohérence du texte."""
    compteurs = Counter()
    resultat = {}
    for e in sorted((e for e in entites if e.selection), key=lambda e: e.premiere):
        compteurs[e.categorie] += 1
        resultat[e.id] = f"{CATEGORIES_ENTITES[e.categorie]}_{compteurs[e.categorie]}"
    return resultat


def libelles(entites, archive):
    """Code de remplacement de chaque entité retenue : « Personne_KQXMB », « Société_ZTRPA »…

    Le code est tiré au hasard la première fois, puis retrouvé dans l'archive : un même nom
    garde le même code d'un lot à l'autre.
    """
    return {e.id: archive.code_entite(e.categorie, e.canonique)
            for e in sorted((e for e in entites if e.selection), key=lambda e: e.premiere)}
