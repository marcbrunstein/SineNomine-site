# Sine Nomine — Anonymiseur de fichiers local

Spécification reprise de la session « Anonymiseur de fichiers local » (ouverte par erreur dans le dossier ingridbrunstein.fr, le 3 novembre 2026).

## Demande initiale

Une application **locale** qui anonymise des fichiers, y compris **Word** et **Markdown** :

- tous les noms et prénoms remplacés par **Personne 1, Personne 2…** ;
- tous les noms de sociétés remplacés par **Société 1, Société 2…** ;
- tous les noms de produits remplacés par **Produit 1, Produit 2…** ;
- un **rapport** identifiant les informations potentiellement sensibles ;
- traitement de **plusieurs fichiers à la fois**.

Tout tourne en local, sans envoi de données dans le cloud.

## Architecture technique convenue

**Langage : Python 3.12** (les versions plus récentes posent parfois problème avec spaCy).

| Brique | Outil | Rôle |
|---|---|---|
| Personnes et sociétés | spaCy, modèle `fr_core_news_lg` | Détection PER et ORG |
| Produits | GLiNER (modèle multilingue, local) + dictionnaire fourni par l'utilisateur | Catégories libres « produit », « marque » |
| Données sensibles | Presidio (Microsoft) + expressions régulières pour les formats français | E-mails, téléphones, IBAN, n° de sécurité sociale, SIRET, adresses, dates de naissance |
| Word | python-docx | Corps du texte, tableaux, en-têtes et pieds de page, métadonnées |
| Markdown | Texte brut | En préservant les liens et les blocs de code |
| Rapport | Excel (openpyxl) ou HTML | Lisible et filtrable |

### Fonctionnement en 3 passes

1. **Détection** sur l'ensemble des fichiers du lot, avec une **table de correspondance unique** : « Jean Dupont » devient Personne 1 dans *tous* les fichiers. Les variantes sont regroupées (« M. Dupont », « J. Dupont », « Jean »).
2. **Validation systématique** (obligatoire, pas facultative) dans l'interface HTML : correction des faux positifs, ajout des oublis et des produits manquants.
3. **Remplacement et rapport.** Les fichiers anonymisés vont dans un dossier de sortie, **les originaux ne sont jamais modifiés**. Le rapport est généré à la fin.

### Pièges à traiter

- **Runs Word** : un nom peut être coupé entre plusieurs morceaux de mise en forme. Il faut reconstruire chaque paragraphe pour remplacer sans casser la mise en forme.
- **Métadonnées Word** (auteur, dernière modification), commentaires et révisions suivies : à nettoyer aussi.
- **Aucune détection automatique n'est fiable à 100 %**, surtout pour les produits. Le dictionnaire et la validation rendent l'outil utilisable.
- **RGPD** : garder la table de correspondance relève de la *pseudonymisation*, pas de l'anonymisation. La stocker à part, voire la chiffrer, ou la supprimer si on n'a pas besoin de revenir en arrière.

## Interface HTML locale

Interface dans le navigateur, servie en local :

- **glisser-déposer** de fichiers ;
- possibilité d'**indiquer l'emplacement des données à traiter** (dossier) ;
- **page d'avertissement à accepter avant de lancer un traitement** (voir ci-dessous) ;
- **écran de validation** de toutes les détections (table de correspondance éditable) ;
- téléchargement / accès au résultat et au rapport.

### Informations sensibles : choix par catégorie

Dans l'écran de validation, une ligne par catégorie : **e-mails, téléphones, IBAN, n° de sécurité sociale, adresses, montants, URL, dates**. Pour chacune, trois choix :

- **Conserver** : l'information est seulement signalée dans le rapport ;
- **Pseudonymiser** : remplacée, par exemple par `[Email 1]` ou `[Téléphone 2]` ;
- **Supprimer** : remplacée par `[supprimé]`.

En plus, on peut **exclure un élément précis** (par exemple garder le numéro du standard d'un tribunal).

### Page d'avertissement (à valider avant confirmation)

Rédaction initiale, remplacée depuis par les textes de `LICENCE.md` et `anonymiseur/textes.py` (propriétaire : Habeas Corpus, marque Habeas Corpus Consulting ; usage personnel non commercial ; garantie « en l'état » avec réserve de la loi ; droit français, tribunaux de Paris) :

1. **Propriété intellectuelle** : l'outil est la propriété de Habeas Corpus **Usage personnel non commercial** autorisé. Tout autre usage nécessite l'**accord de Habeas Corpus**
2. **Note juridique** : outil fourni « en l'état » ; responsabilité exclue dans la mesure permise par la loi (hors faute lourde et dol).
3. **Aucune détection automatique n'est fiable à 100 %.**

## Rapport

Un rapport et une table de correspondance par lot. Pour chaque fichier :

- les entités remplacées, avec leur type, leur nombre d'occurrences et l'identifiant attribué ;
- les informations sensibles **détectées mais non remplacées** (e-mails, téléphones, IBAN, n° de sécurité sociale, adresses, montants, URL, dates) ;
- pour chacune, un **extrait du contexte** et un **score de confiance**.

## Emplacements

| Élément | Emplacement | Pourquoi |
|---|---|---|
| Code, dictionnaires, configuration | `G:\Mon Drive\Travail\Habeas Corpus\Admin\IT\Sine Nomine` | Fichiers légers, sauvegardés et accessibles depuis d'autres postes |
| Environnement Python | `C:\Users\MARC\.venvs\sine-nomine` | Des milliers de fichiers que Drive synchroniserait sans fin, avec un risque de fichiers verrouillés |
| Modèles de détection (spaCy, GLiNER, environ 1 Go) | Cache local Windows (emplacement par défaut) | Même raison |

Un script **`lancer.bat`** dans le dossier Drive active l'environnement local et ouvre l'interface.

Organisation du dossier :

```
Sine Nomine\
├── anonymiseur\        ← le code de l'application
├── dictionnaires\      ← listes de produits / sociétés à forcer
├── entree\             ← fichiers à traiter (configurable)
├── sortie\             ← fichiers anonymisés + rapport (configurable)
├── correspondances\    ← tables « vrai nom → Personne 1 », à garder privées (configurable)
└── lancer.bat
```

Les dossiers `entree`, `sortie` et `correspondances` sont **configurables** dans un fichier de réglages. Par défaut, ils sont dans le dossier Sine Nomine. Si les originaux ne sont pas dans Drive, il est conseillé de sortir au moins `correspondances` de Drive : c'est le fichier qui permet de lever l'anonymisation.

## Prérequis

- **Python 3.12** installé et dans le PATH (`winget install Python.Python.3.12`, ou installeur python.org en cochant « Add python.exe to PATH »).
