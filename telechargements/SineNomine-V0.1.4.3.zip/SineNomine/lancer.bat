@echo off
rem Sine Nomine - lancement de l interface locale
setlocal
rem Environnement Python : dans le dossier de Sine Nomine (nouvelles installations), ou celui des anciennes installations
set "VENV=%~dp0environnement"
if not exist "%~dp0environnement\Scripts\python.exe" if exist "%USERPROFILE%\.venvs\sine-nomine\Scripts\python.exe" set "VENV=%USERPROFILE%\.venvs\sine-nomine"
set PYTHONDONTWRITEBYTECODE=1
set PYTHONUTF8=1
title Sine Nomine
if not exist "%VENV%\Scripts\python.exe" (
  call "%~dp0installer.bat" || exit /b 1
)
cd /d "%~dp0"
"%VENV%\Scripts\python.exe" -m anonymiseur %*
if errorlevel 1 pause
