# Sine Nomine

Anonymiseur de fichiers local d'Habeas Corpus. Il remplace les noms de personnes, de sociétés et de produits par des codes aléatoires (`Personne_KQXMB`, `Société_ZTRPA`, `Produit_HWDNC`…, et `[Email_QMVRT]`, `[Téléphone_BXLDA]`… pour les informations sensibles), traite les informations sensibles et produit un rapport. Une archive des codes permet de **désanonymiser** n'importe quel fichier produit. Tout tourne sur votre ordinateur : Sine Nomine n'envoie aucune donnée sur Internet. Si vous placez vos dossiers dans Google Drive, OneDrive ou un autre service de synchronisation, c'est ce service qui transmet les fichiers (voir « Confidentialité » plus bas).

La spécification complète est dans [SPEC.md](SPEC.md).

## Lancer

Double-cliquez sur le raccourci **Sine Nomine** du Bureau ou du menu Démarrer. L'interface s'ouvre dans le navigateur (adresse `http://127.0.0.1:8765/`), sans fenêtre noire. Pour arrêter Sine Nomine, cliquez sur **Quitter** en haut à droite de l'interface. Un nouveau double-clic alors que Sine Nomine tourne déjà rouvre simplement l'interface.

Pour créer les raccourcis sur un autre PC, ou les recréer, double-cliquez sur **`creer-raccourcis.bat`**. Le journal du lancement sans console est dans `%LOCALAPPDATA%\SineNomine\sine-nomine.log`.

`lancer.bat` reste disponible pour un lancement avec fenêtre noire, qui affiche les messages en direct. On l'arrête en fermant cette fenêtre.

Au premier lancement sur un PC, `lancer.bat` installe d'abord l'environnement : il faut Python 3.12 (`winget install Python.Python.3.12`) et une connexion internet. Le téléchargement fait environ 2 Go.

Le chargement des modèles de détection prend 20 à 60 secondes à chaque démarrage. Son état est affiché en haut à droite de l'interface.

## Langues

**Interface bilingue français / anglais.** Deux drapeaux en haut à droite de l'écran changent la langue à tout moment, sans recharger la page ni perdre le travail en cours ; le choix est mémorisé (au premier lancement, la langue du navigateur est utilisée). Les textes légaux, le rapport HTML, le rapport Excel et la table de correspondance sont rédigés dans la langue de l'interface au moment où l'on lance le lot. Les codes de remplacement gardent leurs étiquettes françaises (`Personne_KQXMB`, `Société_1`) dans les deux langues, pour que la dé-pseudonymisation reconnaisse tous les fichiers. La version anglaise des conditions d'utilisation est une traduction de courtoisie ([LICENCE.en.md](LICENCE.en.md)) : la version française prévaut, et les deux sont à faire relire par un juriste.

**Documents en français et en anglais (UK et US).** La langue de chaque paragraphe est reconnue automatiquement (par les mots-outils, hors ligne). Le modèle spaCy de la langue est alors utilisé : `fr_core_news_lg` pour le français, `en_core_web_lg` pour l'anglais, dont `installer.bat` télécharge environ 400 Mo. GLiNER, multilingue, complète les deux. Formats anglais reconnus : dates (`5th March 2024`, `March 5, 2024`), téléphones UK et US, adresses UK et US avec code postal ou ZIP, montants (`£2,500`, `$2,500.00`), numéro d'assurance nationale britannique (NINO), numéro NHS (clé de contrôle), SSN américain, titres (Mr, Mrs, Ms, Dr, Prof, Sir…). Réglage `langues` dans `config.json` : `["fr"]` pour ne charger que le modèle français. Sans le modèle anglais, les textes anglais ne sont analysés que par GLiNER et l'interface le signale.

**Allemand, espagnol, italien : reconnus, pas encore pris en charge.** Ces langues sont détectées pour ne pas confier leurs textes au modèle français, qui y ajoute du bruit ; seul GLiNER les analyse, avec une détection un peu moins complète (certains lieux ou sociétés peuvent manquer), et leurs formats locaux (dates, identifiants nationaux, adresses) ne sont pas reconnus. Les autres alphabets (cyrillique, grec, arabe, caractères chinois…) ne sont pas pris en charge.

## Clé d'accès et activation

Cette version est une **version d'évaluation** : une clé d'accès (`SN-XXXXX-XXXXX-XXXXX-XXXXX`, à demander à contact@sinenomine.app) est
activée pendant l'installation, avec une connexion Internet. L'installateur vérifie la clé avant d'installer et indique combien de fois
elle peut encore être utilisée ; l'activation consomme une installation. La durée d'utilisation court à partir de l'activation.
Ensuite Sine Nomine fonctionne hors ligne : la licence signée (`licence.json`) est vérifiée sur l'ordinateur.

- Une clé a un **type** (évaluation ou commerciale), un **nombre d'installations** et une **durée** (jours, ou à vie). Le bandeau en haut de
  l'application affiche le type et la date de fin (« licence valable jusqu'au … » ou « valable à vie »). Quand la licence expire, un message
  indique depuis combien de jours et invite à saisir un nouveau code d'activation, avec le bouton « Saisir une clé » (connexion Internet).
- Le serveur d'activation ne reçoit que la clé, un identifiant d'installation aléatoire, la version et la langue (jamais un document ni un nom).
- Sans licence valable, l'anonymisation, la pseudonymisation et la correction sont bloquées ; **la dé-pseudonymisation reste possible**.
- Pour (ré)activer : `activer.bat` (Windows) ou `bash activer.sh` ; `python -m anonymiseur --licence` affiche l'état.
- Côté éditeur : `serveur_activation/` (création des clés, serveur) et `serveur_activation/DEPLOIEMENT.md`. Ce dossier n'est pas distribué.

## Windows, Linux et macOS

- **Windows 10 ou 11** : l'installateur `SineNomine-Setup-V….exe` demande le dossier d'installation (modifiable ou à créer), propose
  les raccourcis du Bureau et du menu Démarrer, puis prépare Python, les bibliothèques et les modèles. Sans l'installateur :
  décompressez l'archive et lancez `lancer.bat`. L'environnement Python est créé dans le dossier de Sine Nomine
  (`environnement`) ; les anciennes installations (`%USERPROFILE%\.venvs\sine-nomine`) continuent de fonctionner.
- **Linux** (Ubuntu 24.04 ; préparé, test sous WSL en cours) : `bash install.sh`, puis `bash lancer.sh` ; `bash creer-raccourci.sh` ajoute un lanceur au menu
  des applications. Prépare Python 3.12, PyTorch pour processeur seul, les modèles et Tesseract (avec `apt`, mot de passe demandé).
- **macOS** : `bash install.sh` (Homebrew requis pour Python 3.12 et Tesseract), puis double-clic sur `Sine Nomine.command`. Préparé,
  **non testé** sur un Mac.

## Fichiers PDF

Un PDF peut être déposé comme les autres fichiers. Il n'est pas modifié sur place (sa mise en page ne s'y prête pas) : Sine Nomine en **extrait le texte**, l'anonymise, puis l'écrit dans un **nouveau fichier du format de votre choix** : Word (.docx, par défaut), PowerPoint (.pptx), Markdown (.md), texte (.txt), HTML (.html) ou Excel (.xlsx). Le choix se fait dans l'écran « Fichiers » (réglage `pdf_format_sortie` dans `config.json`). Le nom du fichier est anonymisé comme le reste.

- **Ce qui n'est pas repris** : images, tableaux, mise en page et métadonnées du PDF (auteur, titre…). Le rapport le rappelle.
- **PDF scannés** (pages qui ne sont que des images) : lus par reconnaissance de caractères avec **Tesseract**, installé par `installer.bat` (via winget, avec les données de langue française et anglaise téléchargées dans `outils/tessdata`). C'est plus lent et moins fiable, surtout sur les noms propres : relisez avec soin la validation et le résultat. Sans Tesseract, une page scannée est signalée comme non lue. Réglage `ocr` dans `config.json` (`actif`, `langues` : `fra+eng`, `tesseract` : chemin de tesseract.exe si besoin).
- **PDF protégés par un mot de passe** : à déprotéger avant. Tout se passe sur l'ordinateur ; aucune connexion n'est faite.

## Menu principal

Sine Nomine s'ouvre sur un menu :

| Entrée | Effet |
|---|---|
| **Remplacer les noms par des numéros (anonymisation)** | Remplace les noms par des numéros (`Personne_1`…) dans l'ordre d'apparition. Sans retour possible : aucune table ni archive n'est conservée |
| **Remplacer les noms par des pseudonymes (pseudonymisation)** | Remplace les noms par des codes aléatoires (`Personne_KQXMB`). Réversible grâce à l'archive des codes |
| **Corriger des pseudonymes (re-pseudonymisation)** | Complète des fichiers déjà pseudonymisés dans lesquels des noms sont restés (voir plus bas) |
| **Remplacer les pseudonymes par des noms (dé-pseudonymisation)** | Remet les noms d'origine dans des fichiers pseudonymisés par Sine Nomine |
| **Consulter un pseudonyme** | Cherche un code (`Personne_KQXMB`, `[Email_ZTRPA]` ou seulement `KQXMB`) ou un nom d'origine dans l'archive, et affiche la correspondance, les variantes et les lots. Affiche des données en clair |
| **Configurer Sine Nomine** | Mots exclus et dictionnaires (modifiables, avec suppression), options par défaut (téléphones, IBAN, images, lieux, seuil), archive des codes |
| **Quitter** | Arrête Sine Nomine |

Les options de l'écran **Outils** sont enregistrées dans `config.utilisateur.json`, à côté de `config.json` qui n'est jamais modifié ; elles sont appliquées au prochain lot et restent modifiables lot par lot à l'écran de validation. Le bouton **Menu** en haut de l'écran ramène au menu (hors traitement en cours).

## Corriger des pseudonymes

Pour des fichiers **déjà pseudonymisés** par Sine Nomine dans lesquels des noms sont restés : par exemple « Ines » à côté d'un code (`Ines_Personne_PRLWV`), ou « Elise_Wu » et « Mila_Lin_an_Park » dans des noms de fichiers. Déposez les fichiers (ou indiquez un dossier), puis choisissez :

- **Les noms connus de l'archive** (coché par défaut) : tous les noms et variantes déjà archivés sont recherchés et remplacés par leur code, avec ou sans accents, avec les graphies étrangères et dans les noms de fichiers ;
- **Les prénoms seuls** des personnes connues (décoché par défaut : risque de remplacer un mot courant) ;
- **Des règles à la main** : « ce texte est une variante du pseudonyme X » (on saisit le code ou le nom, avec suggestions) ou « ce texte est une nouvelle personne, société, produit ou lieu ».

**Aperçu** avant toute écriture : nombre de corrections par règle, par pseudonyme connu et par fichier, avec le contexte, et nouveau nom de chaque fichier. **Appliquer** n'est possible qu'après l'aperçu. Les fichiers déposés ne sont pas modifiés : les versions corrigées vont dans `sortie\correction_<date>\`. Un nom de fichier qui contiendrait deux fois le même code à la suite (`Ines_Marchand` remplacé en deux morceaux) est réduit à un seul. Les variantes et nouveaux noms saisis sont ajoutés à l'archive : ils servent aux lots suivants et à la dé-pseudonymisation.

La correction s'appuie sur l'archive des codes : elle concerne des fichiers pseudonymisés, pas des fichiers anonymisés (numérotés, sans archive).

## Accents, séparateurs et graphies étrangères

Un même nom est retrouvé quelle que soit son écriture : avec ou sans accents (« Inès » = « Ines », « Stéphan » = « Stephan », « Gülhan » = « Gulhan »), avec les graphies étrangères (« Kärscher » = « Kaerscher » = « Karscher », « Straße » = « Strasse »), et avec des séparateurs différents (« Lin-an », « Lin_an », « Lin an » : utile pour les noms de fichiers). Cela vaut pour l'anonymisation, la pseudonymisation, la correction, les dictionnaires et la recherche dans l'archive. Réglable : `filtres.graphies_etrangeres` dans `config.json` (`false` pour ne garder que l'insensibilité aux accents et aux séparateurs). Limite : cette équivalence peut rapprocher deux noms réellement distincts qui ne diffèrent que par l'accent ou la graphie (« Michael » et « Michal ») ; la validation reste nécessaire.

## Indicateur d'avancement

Pendant l'analyse et le remplacement, l'écran de progression se rafraîchit chaque seconde (la durée écoulée avance en continu) et affiche : les étapes (chargement des modèles, lecture, détection, regroupement, puis préparation, remplacement, rapport) avec l'étape en cours, le pourcentage, le fichier en cours et l'avancement du modèle au sein du fichier (par exemple « GLiNER : 12 / 40 »), le nombre de fichiers, la durée écoulée et une estimation du temps restant. Pendant l'analyse, il compte ce qui est détecté jusqu'ici (personnes, sociétés, produits et marques, lieux, informations sensibles) ; pendant le traitement, il compte les substitutions effectuées par catégorie. L'écran de résultat rappelle le total et les durées de l'analyse et du traitement. Ces compteurs ne contiennent que des nombres, jamais de noms.

## Utilisation

1. **Avertissement** : à accepter avant chaque lot.
2. **Fichiers** : glissez-déposez des fichiers ou des dossiers, ou indiquez le chemin d'un dossier. Formats pris en charge : Word (`.docx`), PowerPoint (`.pptx`), Excel (`.xlsx`), Markdown (`.md`), texte (`.txt`), CSV (`.csv`, `.tsv`) et HTML (`.html`). Les PDF ne sont pas pris en charge : un PDF ne se réécrit pas proprement, exportez-le d'abord en Word.
3. **Validation** (obligatoire), en parcours guidé : cinq onglets (Personnes, Sociétés, Produits, Lieux, Informations sensibles et images) que l'on parcourt avec **Passer à l'onglet suivant** (et **Onglet précédent**). La confirmation n'est possible que sur le dernier onglet, une fois tous les onglets ouverts ; en confirmant, vous attestez avoir vérifié les détections de tous les onglets. Dans ces onglets :
   - cochez ou décochez chaque entité, corrigez son type, ajoutez ou retirez des variantes ;
   - fusionnez les doublons et ajoutez les noms oubliés ;
   - pour chaque catégorie d'informations sensibles, choisissez entre conserver, pseudonymiser ou supprimer, et excluez les éléments précis à garder ;
   - choisissez de conserver ou de supprimer les images.
4. **Résultat** : les fichiers anonymisés, le rapport et la table de correspondance.

## Deux modes : pseudonymiser ou anonymiser

À l'écran **Fichiers**, choisissez le mode de traitement (réglage par défaut : `mode_par_defaut` dans `config.json`).

| | Pseudonymiser (réversible) | Anonymiser (irréversible) |
|---|---|---|
| Remplacement | Codes aléatoires : `Personne_KQXMB`, `[Email_QMVRT]` | Numéros : `Personne_1`, `Société_1`, `[Email_1]`, dans l'ordre d'apparition dans le lot |
| Archive des codes | Écrite, et relue aux lots suivants | Ni lue ni écrite |
| Table de correspondance | `correspondances\<lot>_correspondances.xlsx` | Aucune |
| Copies des fichiers déposés dans l'interface | Conservées dans `entree\` | Effacées à la fin (un dossier indiqué par son chemin n'est jamais touché) |
| Noms d'origine en mémoire | — | Effacés à la fin du traitement |
| Désanonymisation | Possible | Impossible avec Sine Nomine |

En anonymisation, « Toujours détecter » est désactivé à l'écran de validation, car il écrirait des noms réels dans les dictionnaires. Le texte peut rester identifiable par son contexte (fonction, lieu, événement) : relisez-le toujours.

## Codes et désanonymisation

Chaque nom reçoit un code de 5 lettres tirées au hasard (`Personne_KQXMB`). Les codes sont conservés dans **`correspondances\archive_codes.json`**, pour tous les lots : un même nom garde le même code d'un lot à l'autre, et un nom déjà anonymisé est coché d'office aux lots suivants. Un terme décoché à une validation précédente le reste (la colonne des sources indique « refusé précédemment »).

Pour retrouver les noms d'origine, choisissez **Dé-pseudonymiser** dans le menu, puis déposez des fichiers produits par Sine Nomine (même modifiés, par exemple après un passage dans une IA). Les codes sont remplacés par la valeur d'origine ; un code absent de l'archive est laissé tel quel et signalé. Les versions restaurées vont dans un dossier `restauration_<date>` du dossier de sortie.

Limites : le nom restauré est la forme de référence de l'entité (« M. Dupont » redevient « Jean Dupont »), et ce qui a été **supprimé** (`[supprimé]`) ou masqué dans les métadonnées (auteur, société) ne peut pas être restauré.

**L'archive contient les noms d'origine en clair : gardez-la privée.** Si vous la perdez, les fichiers déjà anonymisés ne peuvent plus être restaurés. Une copie de la version précédente est conservée à côté (`archive_codes.bak`).

## Coffre chiffré

Les correspondances (noms d'origine, valeurs sensibles) sont conservées dans un **coffre chiffré** du profil de l'utilisateur, plus dans un fichier
JSON en clair. La clé est protégée par votre compte Windows : **créez une phrase de récupération** et une **sauvegarde chiffrée** (Outils, Coffre
chiffré) ; sans l'un des deux, la perte du compte Windows rend les fichiers pseudonymisés irrécupérables. La première ouverture migre l'ancienne
archive sans rien supprimer. Détails, limites et récupération : [docs/COFFRE.md](docs/COFFRE.md).

## Sécurité du serveur local

L'interface n'est accessible qu'en local (127.0.0.1) et seulement avec la session ouverte par Sine Nomine : le navigateur est lancé avec
un jeton à usage unique, échangé contre un cookie de session ; les écritures exigent en plus un jeton de sécurité et une origine
identique. Un autre site web ouvert dans votre navigateur ne peut donc pas appeler Sine Nomine. Les rapports HTML s'ouvrent isolés.
Si vous obtenez « Ouvrez Sine Nomine avec son raccourci », relancez-le avec le raccourci ou `lancer.bat`.

## Confidentialité

Sine Nomine traite vos fichiers uniquement sur votre ordinateur et n'envoie aucune donnée sur Internet. Internet n'est utilisé qu'à l'installation (`installer.bat` télécharge les composants et les modèles) ; au lancement, Sine Nomine fonctionne **hors ligne** (variables `HF_HUB_OFFLINE` et `TRANSFORMERS_OFFLINE` activées) et n'établit aucune connexion. Si les modèles manquent, l'interface le signale : relancez `installer.bat`.

Les dossiers de Sine Nomine (`entree`, `sortie`, `correspondances`) peuvent être sur le disque local ou dans un service de synchronisation (Google Drive, OneDrive…). Dans ce second cas, c'est ce service qui transmet et conserve les fichiers, selon ses propres conditions : `correspondances\` contient les noms d'origine en clair. Pour un fonctionnement strictement local, gardez le projet et ses dossiers sur le disque local, ou indiquez des dossiers locaux dans `config.json`.

## Où vont les fichiers

| Dossier | Contenu |
|---|---|
| `entree\` | Copies des fichiers déposés dans l'interface, un sous-dossier par lot |
| `sortie\<lot>\` | Fichiers anonymisés, `rapport.html` et `rapport.xlsx`. Le rapport ne contient aucune valeur d'origine |
| `correspondances\` | `<lot>_correspondances.xlsx` : la table du lot, et `archive_codes.json` : l'archive de tous les codes, utilisée pour désanonymiser. **À garder privés** |
| `dictionnaires\` | Listes de personnes, sociétés et produits à toujours détecter, et `exclusions.txt` pour les termes à ne jamais anonymiser |

Les emplacements se changent dans **`config.json`**, où un chemin absolu est accepté. Si vos fichiers d'origine ne sont pas dans Google Drive, sortez au moins `correspondances` de Drive.

L'environnement Python est dans `%USERPROFILE%\.venvs\sine-nomine`, et les modèles dans le cache local de Windows. Les deux restent hors de Drive.

## Ce qui est traité dans un fichier Word

Sont traités : le corps du texte, les tableaux, les en-têtes et pieds de page, les notes, les commentaires et leurs auteurs, les révisions suivies, les zones de texte, les textes des graphiques, les liens, les métadonnées (auteur, société, titre) et les données XML personnalisées. Le nom du fichier est lui aussi anonymisé.

**Images** : elles ne sont pas analysées. À l'écran de validation, vous pouvez les **supprimer**, y compris les logos des en-têtes et les filigranes : chacune est alors remplacée par le texte « [image supprimée] » et le fichier image est retiré du document. Les graphiques, zones de texte et SmartArt sont conservés. Dans les fichiers Markdown, les balises d'image (`![…](…)` et `<img>`) sont remplacées de la même façon. Les miniatures des images sont affichées à l'écran de validation, dans l'écran de résultat et dans le rapport si elles sont conservées. Un clic sur une miniature l'agrandit.

**Fichiers d'origine endommagés** : certains générateurs produisent des .docx que Word doit « réparer » à l'ouverture (par exemple une image sans type déclaré). Sine Nomine corrige ce défaut dans la version anonymisée et le signale dans le rapport.

**Non traités** (signalés dans le rapport) : les images conservées et les objets incorporés, y compris leur image d'aperçu.

**PowerPoint et Excel** : sont traités les textes des diapositives (titres, zones de texte, tableaux, graphiques), les notes, les masques et dispositions, les commentaires et leurs auteurs, et les cellules texte d'Excel. Les nombres, formules, noms de feuilles, tableaux croisés dynamiques et liens externes d'Excel ne sont pas analysés (signalé dans le rapport). La miniature d'aperçu intégrée aux fichiers Office (une image de la première page) est supprimée de la version anonymisée.

## Détection

| Élément | Méthode |
|---|---|
| Personnes et sociétés | spaCy `fr_core_news_lg` et GLiNER multilingue |
| Produits | GLiNER, dictionnaire `produits.txt`, et suggestions (termes en CamelCase, sigles, alphanumériques) décochées par défaut |
| Lieux (villes, pays) | spaCy (`LOC`), GLiNER (« ville », « pays ») et dictionnaire `lieux.txt`. **Décochés par défaut** : « Paris » ou « Londres » reviennent dans presque tout document. Cochez ceux à remplacer, ou mettez-les dans `lieux.txt` pour qu'ils soient toujours cochés. Remplacés par `Lieu_KQXMB` (ou `Lieu_1` en anonymisation) |
| Informations sensibles | Expressions régulières pour les formats français, avec contrôle des clés : IBAN (mod 97), n° de sécurité sociale (clé), SIRET/SIREN (Luhn), cartes bancaires (Luhn), n° de TVA français (clé). Détectés aussi : adresses IP (IPv4), plaques d'immatriculation SIV, comptes `@pseudo`, n° de passeport ou de carte d'identité (seulement après le mot « passeport » ou « carte d'identité »), et vos propres références internes (voir `references_motifs`) |

**Limiter les faux positifs** (noms de personnes et de produits à tort) :

- un mot que le lot écrit aussi en minuscules (« manager », « solution ») n'est pas pris pour un nom propre ;
- un nom de personne ou de produit de plusieurs mots doit avoir une majuscule à chaque mot (« Agent IA assistant » est écarté) ;
- les intitulés de fonction (Manager, Store, Sales, Directeur…) ne sont jamais des personnes ;
- les codes du type `Q9` (numéros de questions) sont ignorés, et une « personne » présente dans la plupart des fichiers du lot (vocabulaire de gabarit) est décochée ;
- les seuils de GLiNER sont plus élevés pour les produits que pour les personnes, et la confiance monte quand spaCy et GLiNER s'accordent ;
- **Toujours ignorer** dans l'écran de validation ajoute le terme à `dictionnaires\exclusions.txt`.

Un même nom est remplacé par le même identifiant dans tous les fichiers du lot. Ses variantes (« M. Dupont », « J. Dupont », « DUPONT Jean ») sont regroupées automatiquement.

## Réglages utiles (`config.json`)

| Réglage | Effet |
|---|---|
| `seuil_preselection` | Confiance en dessous de laquelle une entité est décochée par défaut |
| `references_motifs` | Expressions régulières de vos références internes à masquer (numéros de dossier, de contrat, de client…), par exemple `["\\bDOS-\\d{6}\\b"]`. Un motif invalide est ignoré |
| `lieux_preselectionnes` | `true` pour que les villes et pays détectés par les modèles soient cochés d'office (`false` par défaut) |
| `gliner.seuils` | Seuil de confiance de GLiNER par type (`personne`, `entreprise`, `produit`, `marque`). Monter un seuil réduit les faux positifs de ce type |
| `filtres.min_minuscules` | Nombre d'apparitions en minuscules à partir duquel un mot est jugé courant (3 par défaut). Plus bas : plus de faux positifs écartés, au risque d'écarter un vrai nom |
| `filtres.graphies_etrangeres` | `true` par défaut : « Kärscher » = « Kaerscher » = « Karscher ». `false` : seuls les accents et les séparateurs sont tenus pour équivalents |
| `filtres.motifs_exclus` | Expressions régulières des termes jamais détectés (par défaut `^[A-Za-z]\d{1,3}$` : `Q9`, `Y2`…) |
| `gliner.actif` | `false` pour un démarrage plus rapide. Les produits ne sont alors détectés que par le dictionnaire et les suggestions |
| `actions_par_defaut` | Action proposée par défaut pour chaque catégorie d'informations sensibles |
| `images_par_defaut` | `"conserver"` ou `"supprimer"` : choix proposé par défaut pour les images |

---

© 2026 Habeas Corpus Consulting, marque de Habeas Corpus — contact@sinenomine.app — +33 1 89 16 73 22. Version d'évaluation : toute poursuite de l'utilisation est soumise à l'accord de Habeas Corpus
