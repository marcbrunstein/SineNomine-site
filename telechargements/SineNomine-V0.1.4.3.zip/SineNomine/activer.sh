#!/usr/bin/env bash
# Sine Nomine - active cette installation avec une cle d'acces (connexion Internet necessaire)
VENV="${SINE_NOMINE_VENV:-$HOME/.venvs/sine-nomine}"
RACINE="$(cd "$(dirname "$0")" && pwd)"
[ -x "$VENV/bin/python" ] || { echo "L'environnement n'est pas installe : lancez d'abord install.sh."; exit 1; }
cd "$RACINE" && exec "$VENV/bin/python" -m anonymiseur --activer "$@"
