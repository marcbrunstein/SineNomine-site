"""Inventaire des contenus que Sine Nomine n'analyse pas (ou analyse en partie), par fichier, et politique de confidentialité.

Chaque élément : {cle, libelle, nombre, traite, supprimable}
- `traite` : "oui" (texte analysé et remplacé), "partiel" (une partie seulement) ou "non" (conservé tel quel, non analysé) ;
- `supprimable` : peut être retiré du fichier produit par la politique « confidentialité renforcée ».

DEUX POLITIQUES
- PRÉSERVATION (par défaut) : les éléments non traités sont conservés ; leurs limites sont affichées avant confirmation et dans le rapport.
- CONFIDENTIALITÉ RENFORCÉE : ce qui peut être supprimé l'est (images) ; si un élément NON traité et NON supprimable est présent,
  la publication est BLOQUÉE avec l'explication (jamais de publication silencieuse d'un contenu non analysé).

La matrice par format (ce qui est traité, partiellement traité ou ignoré) est documentée dans docs/MATRICE_FORMATS.md et vérifiée par
tests/test_formats_matrice.py.
"""

import re
import zipfile
from pathlib import Path

from . import formats, limites

POLITIQUES = ("preservation", "renforcee")
RE_FEUILLE_GENERIQUE = re.compile(r"^(feuil|sheet|tabelle|hoja|foglio|blad)\s*\d*$", re.IGNORECASE)
RE_NOM_FEUILLE = re.compile(rb'<(?:\w+:)?sheet\b[^>]*\bname="([^"]*)"')
RE_FORMULE = re.compile(rb"<(?:\w+:)?f[\s>/]")


def _element(cle, libelle, nombre, traite, supprimable=False):
    return {"cle": cle, "libelle": libelle, "nombre": nombre, "traite": traite, "supprimable": supprimable}


def inventaire(chemin):
    """Éléments non analysés (ou analysés en partie) présents dans un fichier. Liste vide : rien à signaler pour ce format."""
    chemin = Path(chemin)
    extension = chemin.suffix.lower()
    elements = []
    if extension == ".pdf":
        from . import pdf
        contenu = pdf.lire(chemin)
        if contenu.pages_ocr:
            elements.append(_element("pdf_ocr", "Pages lues par reconnaissance de caractères (moins fiable)", contenu.pages_ocr, "partiel"))
        for avertissement in contenu.avertissements:
            elements.append(_element("pdf_avertissement", avertissement, 1, "partiel"))
        elements.append(_element("pdf_structure", "Mise en page, images et tableaux du PDF non repris", 1, "non"))
        return elements
    if extension in formats.OOXML:
        limites.verifier_fichier(chemin)
        with zipfile.ZipFile(chemin) as z:
            noms = z.namelist()
            n_images = formats.compter_images(chemin)
            if n_images:
                elements.append(_element("images", "Images (non analysées : logos, signatures, captures d'écran)", n_images, "non", True))
            n = sum(1 for x in noms if "/embeddings/" in x)
            if n:
                elements.append(_element("objets_incorpores", "Objets incorporés (tableaux, documents) et leur aperçu", n, "non"))
            n = sum(1 for x in noms if x.startswith("customXml/") and x.endswith(".xml"))
            if n:
                elements.append(_element("xml_personnalise", "Parties XML personnalisées (métadonnées d'application)", n, "non", True))
            n = sum(1 for x in noms if "/externalLinks/" in x and x.endswith(".xml"))
            if n:
                elements.append(_element("liens_externes", "Liaisons vers des classeurs externes", n, "partiel"))
            n = sum(1 for x in noms if "/charts/" in x and x.endswith(".xml"))
            if n:
                elements.append(_element("graphiques", "Graphiques (titres et valeurs en cache traités ; mise en forme non vérifiée)", n, "partiel"))
            n = sum(1 for x in noms if "/pivotCache/" in x or "/pivotTables/" in x)
            if n:
                elements.append(_element("tableaux_croises", "Tableaux croisés dynamiques et leurs caches", n, "non"))
            if extension == ".xlsx":
                formules = 0
                for x in noms:
                    if x.startswith("xl/worksheets/") and x.endswith(".xml"):
                        formules += len(RE_FORMULE.findall(z.read(x)))
                if formules:
                    elements.append(_element("formules", "Formules (texte littéral des formules non analysé)", formules, "non"))
                if "xl/workbook.xml" in noms:
                    feuilles = [f.decode("utf-8", "replace") for f in RE_NOM_FEUILLE.findall(z.read("xl/workbook.xml"))]
                    specifiques = [f for f in feuilles if not RE_FEUILLE_GENERIQUE.match(f)]
                    if specifiques:
                        elements.append(_element("noms_feuilles", "Noms des feuilles (non analysés)", len(specifiques), "non"))
        return elements
    if extension in (".html", ".htm", ".md", ".markdown"):
        texte = formats._lire_brut(chemin)[0]
        n = len(formats.RE_IMAGE_HTML.findall(texte)) + len(formats.RE_IMAGE_MD.findall(texte))
        if n:
            elements.append(_element("images", "Images référencées (non analysées)", n, "non", True))
    return elements


def blocages(elements, politique):
    """Éléments qui empêchent la publication en CONFIDENTIALITÉ RENFORCÉE : non traités et non supprimables."""
    if politique != "renforcee":
        return []
    return [e for e in elements if e["traite"] == "non" and not e["supprimable"]]
