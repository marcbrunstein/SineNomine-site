"""Lecture et écriture des fichiers Word (.docx), Markdown et texte.

Pour Word, on travaille directement sur le XML de chaque partie du document
(corps, en-têtes, pieds de page, notes, commentaires, zones de texte, graphiques).
Un nom peut être découpé entre plusieurs « runs » de mise en forme : on reconstitue
le texte du paragraphe, on calcule les remplacements, puis on les reporte dans les
nœuds d'origine, ce qui conserve la mise en forme du premier morceau.
"""

import posixpath
import re
import urllib.parse
import zipfile
from pathlib import Path

from lxml import etree

from . import limites, pdf

OOXML = {".docx", ".pptx", ".xlsx"}          # Word, PowerPoint, Excel : archives zip de parties XML
EXTENSIONS = OOXML | {".md", ".markdown", ".txt", ".csv", ".tsv", ".html", ".htm"}
EXTENSIONS_ENTREE = EXTENSIONS | {".pdf"}   # à analyser : le PDF n'est qu'une source, jamais un fichier produit ni restauré

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
C = "http://schemas.openxmlformats.org/drawingml/2006/chart"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
XDR = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
TC = "http://schemas.microsoft.com/office/spreadsheetml/2018/threadedcomments"
XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"

W_P, W_T, W_DEL, W_INSTR = f"{{{W}}}p", f"{{{W}}}t", f"{{{W}}}delText", f"{{{W}}}instrText"
A_P, A_T = f"{{{A}}}p", f"{{{A}}}t"
SEPARATEURS = {f"{{{W}}}tab": "\t", f"{{{W}}}br": "\n", f"{{{W}}}cr": "\n",
               f"{{{W}}}noBreakHyphen": "-", f"{{{A}}}br": "\n"}
C_V = f"{{{C}}}v"
S_SI, S_IS, S_TEXT, S_T, S_RPH, S_AUTHOR = (f"{{{S}}}{n}" for n in ("si", "is", "text", "t", "rPh", "author"))
P_TEXT, TC_TEXT = f"{{{P}}}text", f"{{{TC}}}text"      # commentaires PowerPoint et Excel (texte brut)
P_PIC, XDR_PIC = f"{{{P}}}pic", f"{{{XDR}}}pic"

R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"a": A, "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
      "v": "urn:schemas-microsoft-com:vml"}
W_R, W_DRAWING, W_PICT = f"{{{W}}}r", f"{{{W}}}drawing", f"{{{W}}}pict"
MC_ALT = "{http://schemas.openxmlformats.org/markup-compatibility/2006}AlternateContent"
IMAGE_SUPPRIMEE = "[image supprimée]"
RE_IMAGE_MD = re.compile(r"!\[([^\]\n]*)\]\(\s*(<[^>\n]*>|[^)\s\n]*)(?:\s+[\"'][^)\n]*[\"'])?\s*\)")
RE_IMAGE_HTML = re.compile(r"<img\b[^>]*>", re.IGNORECASE)

PARTIES_IGNOREES = {"word/styles.xml", "word/stylesWithEffects.xml", "word/fontTable.xml",
                    "word/webSettings.xml", "word/numbering.xml", "word/settings.xml",
                    "ppt/presProps.xml", "ppt/viewProps.xml", "ppt/tableStyles.xml",
                    "xl/styles.xml", "xl/workbook.xml", "xl/calcChain.xml"}
PREFIXES_IGNORES = ("word/theme/", "ppt/theme/", "xl/theme/")
RACINES = ("word/", "ppt/", "xl/")
RE_MEDIA = re.compile(r"(?:word|ppt|xl)/media/")
RE_MINIATURE = re.compile(r"docProps/thumbnail\.\w+")
ANONYME = "Anonyme"


def _est_ooxml(chemin):
    return Path(chemin).suffix.lower() in OOXML


def _parties_texte(noms):
    for nom in noms:
        if nom.endswith(".xml") and nom.startswith(RACINES) and nom not in PARTIES_IGNOREES \
                and not nom.startswith(PREFIXES_IGNORES):
            yield nom


def _lire_racine(zip_, nom):
    """Arbre XML d'une partie, ou None pour une feuille Excel sans texte en ligne (parcours inutile, parfois énorme)."""
    donnees = zip_.read(nom)
    if nom.startswith("xl/worksheets/") and b"<is>" not in donnees:
        return None
    return limites.xml(donnees)


def _segments(paragraphe, balise_texte):
    """Nœuds de texte et séparateurs du paragraphe, dans l'ordre, sans descendre dans les paragraphes imbriqués."""
    resultat = []

    def parcourir(element):
        for enfant in element:
            if enfant.tag in (W_P, A_P, S_RPH):
                continue
            if enfant.tag == balise_texte or enfant.tag in SEPARATEURS:
                resultat.append(enfant)
            else:
                parcourir(enfant)

    parcourir(paragraphe)
    return resultat


def _texte_segment(noeud):
    return SEPARATEURS.get(noeud.tag, noeud.text or "")


def _paragraphes(racine):
    """(paragraphe, balise de texte) pour les textes visibles et les textes supprimés (révisions)."""
    for p in racine.iter(W_P):
        yield p, W_T
        yield p, W_DEL
    for p in racine.iter(A_P):
        yield p, A_T
    for p in racine.iter(S_SI, S_IS, S_TEXT):      # chaînes d'Excel : partagées, en ligne, commentaires
        yield p, S_T


def _textes_xml(racine):
    for p, balise in _paragraphes(racine):
        texte = "".join(_texte_segment(n) for n in _segments(p, balise))
        if texte.strip():
            yield texte
    for noeud in racine.iter(C_V):
        if noeud.text and not re.fullmatch(r"[\d.,\-E+ ]*", noeud.text):
            yield noeud.text
    for noeud in racine.iter(P_TEXT, TC_TEXT):
        if noeud.text and noeud.text.strip():
            yield noeud.text


def _reporter(segments, remplacements):
    """Reporte les remplacements calculés sur le texte concaténé dans les nœuds d'origine."""
    bornes, position = [], 0
    for n in segments:
        longueur = len(_texte_segment(n))
        bornes.append((n, position, position + longueur, n.tag not in SEPARATEURS))
        position += longueur

    # Le texte de remplacement est placé dans le premier nœud de texte touché par la zone remplacée.
    porteurs = {}
    for r in remplacements:
        for n, debut, fin, modifiable in bornes:
            if modifiable and fin > r.debut and debut < r.fin:
                porteurs[id(r)] = (n, max(debut, r.debut))
                break

    for n, debut, fin, modifiable in bornes:
        if not modifiable:
            continue
        ancien = n.text or ""
        morceaux = []
        for i, caractere in enumerate(ancien):
            p = debut + i
            couvrant = next((r for r in remplacements if r.debut <= p < r.fin), None)
            if couvrant is None:
                morceaux.append(caractere)
            elif porteurs.get(id(couvrant)) == (n, p):
                morceaux.append(couvrant.texte)
        nouveau = "".join(morceaux)
        if nouveau != ancien:
            n.text = nouveau
            if n.tag != A_T:
                n.set(XML_SPACE, "preserve")


def _anonymiser_xml(racine, correspondances, journal, masquer=True):
    for p, balise in _paragraphes(racine):
        segments = _segments(p, balise)
        texte = "".join(_texte_segment(n) for n in segments)
        if not texte.strip():
            continue
        nouveau, remplacements, conservees = correspondances.remplacer(texte)
        journal.noter(nouveau, remplacements, conservees)
        if remplacements:
            _reporter(segments, remplacements)

    for balise in (W_INSTR, C_V, P_TEXT, TC_TEXT):
        for noeud in racine.iter(balise):
            if noeud.text:
                nouveau, remplacements, conservees = correspondances.remplacer(noeud.text)
                journal.noter(nouveau, remplacements, conservees)
                noeud.text = nouveau

    if not masquer:
        return
    # Auteurs des commentaires et des révisions, identifiants des participants (Word, PowerPoint, Excel).
    for element in racine.iter():
        if not isinstance(element.tag, str):
            continue
        local_element = element.tag.split("}")[-1]
        if element.tag == S_AUTHOR and element.text:
            element.text = ANONYME
        for attribut in list(element.attrib):
            local = attribut.split("}")[-1]
            if local == "author" or local == "displayName" \
                    or (local == "name" and local_element in ("cmAuthor", "author")):
                element.set(attribut, ANONYME)
            elif local == "initials":
                element.set(attribut, "A")
            elif local in ("userId", "providerId") and element.attrib[attribut]:
                element.set(attribut, "")


def _anonymiser_proprietes(nom, racine, correspondances, journal, masquer=True):
    for element in racine.iter():
        if not isinstance(element.tag, str) or element.text is None:
            continue
        local = element.tag.split("}")[-1]
        if nom == "docProps/core.xml" and local in ("creator", "lastModifiedBy"):
            if masquer:
                element.text = ANONYME
        elif nom == "docProps/app.xml" and local in ("Company", "Manager"):
            if masquer:
                element.text = ""
        elif nom == "docProps/app.xml" and local == "lpstr":   # titres des diapositives, noms des feuilles
            nouveau, remplacements, conservees = correspondances.remplacer(element.text)
            journal.noter(nouveau, remplacements, conservees)
            element.text = nouveau
        elif nom == "docProps/core.xml" and local in ("title", "subject", "description", "keywords", "category") \
                or nom != "docProps/core.xml" and nom != "docProps/app.xml" and len(element) == 0:
            nouveau, remplacements, conservees = correspondances.remplacer(element.text)
            journal.noter(nouveau, remplacements, conservees)
            element.text = nouveau


def _anonymiser_relations(racine, correspondances, journal):
    for rel in racine:
        if rel.get("TargetMode") == "External" and rel.get("Target"):
            nouveau, remplacements, conservees = correspondances.remplacer(rel.get("Target"))
            if remplacements:
                rel.set("Target", "#")


# ---------------------------------------------------------------- interface commune

def _est_pdf(chemin):
    return Path(chemin).suffix.lower() == ".pdf"


def lire_texte(chemin, progression=None):
    """Texte du fichier (un paragraphe par ligne), pour la détection. `progression(page, total)` : PDF seulement."""
    chemin = Path(chemin)
    limites.verifier_fichier(chemin)
    if _est_pdf(chemin):
        return pdf.lire(chemin, progression=progression).texte
    if _est_ooxml(chemin):
        lignes = []
        with zipfile.ZipFile(chemin) as z:
            for nom in sorted(_parties_texte(z.namelist()), key=_ordre_parties):
                racine = _lire_racine(z, nom)
                if racine is not None:
                    lignes.extend(_textes_xml(racine))
        return "\n".join(lignes)
    return _lire_brut(chemin)[0]


def _ordre_parties(nom):
    """Diapositives dans l'ordre numérique (slide2 avant slide10), le reste dans l'ordre alphabétique."""
    return [(0, int(t)) if t.isdigit() else (1, t) for t in re.split(r"(\d+)", nom) if t]


def _lire_brut(chemin):
    donnees = Path(chemin).read_bytes()
    for encodage in ("utf-8-sig", "cp1252"):
        try:
            texte = donnees.decode(encodage)
            if encodage == "utf-8-sig" and not donnees.startswith(b"\xef\xbb\xbf"):
                encodage = "utf-8"
            return texte, encodage
        except UnicodeDecodeError:
            continue
    return donnees.decode("latin-1"), "latin-1"


# ---------------------------------------------------------------- images

def _images_xml(racine):
    """Images du document : dessins contenant directement une image, et images VML (filigranes…).

    Les zones de texte, graphiques, SmartArt et groupes de formes sont conservés.
    Une image enveloppée dans un mc:AlternateContent est supprimée avec son enveloppe.
    """
    cibles = []
    for dessin in racine.iter(W_DRAWING):
        if dessin.xpath("./*/a:graphic/a:graphicData/pic:pic", namespaces=NS):
            cibles.append(dessin)
    for pict in racine.iter(W_PICT):
        if pict.xpath("./v:shape/v:imagedata", namespaces=NS):
            cibles.append(pict)
    cibles += list(racine.iter(P_PIC, XDR_PIC))        # images de PowerPoint et d'Excel
    resultat = []
    for cible in cibles:
        enveloppe = next((a for a in cible.iterancestors() if a.tag == MC_ALT), None)
        cible = enveloppe if enveloppe is not None else cible
        if cible not in resultat:
            resultat.append(cible)
    return resultat


def _supprimer_images_xml(racine):
    """Remplace chaque image par le texte « [image supprimée] », dans le même run."""
    images = _images_xml(racine)
    for image in images:
        parent = image.getparent()
        if parent.tag == W_R:
            texte = etree.Element(W_T)
            texte.text = IMAGE_SUPPRIMEE
            texte.set(XML_SPACE, "preserve")
            parent.replace(image, texte)
        else:
            parent.remove(image)
    return len(images)


def _references(racine):
    """Identifiants de relations encore utilisés dans une partie (r:embed, r:id, o:relid…)."""
    return {valeur for element in racine.iter() if isinstance(element.tag, str)
            for attribut, valeur in element.attrib.items()
            if attribut.startswith(f"{{{R}}}") or attribut.endswith("}relid")}


def _partie_des_relations(nom_rels):
    """word/_rels/document.xml.rels → word/document.xml"""
    dossier, fichier = posixpath.split(nom_rels)
    return posixpath.join(posixpath.dirname(dossier), fichier[:-len(".rels")])


def _nettoyer_medias(parties, contenus):
    """Retire les relations d'image devenues inutiles, puis les fichiers de word/media/ plus référencés."""
    references = {nom: _references(racine) for nom, racine in parties.items()}
    for nom, racine in contenus.items():
        if not nom.endswith(".rels"):
            continue
        partie = _partie_des_relations(nom)
        if partie not in references:
            continue
        for rel in list(racine):
            if rel.get("Type", "").endswith("/image") and rel.get("TargetMode") != "External" \
                    and rel.get("Id") not in references[partie]:
                racine.remove(rel)

    utilises = set()
    for nom, racine in contenus.items():
        if nom.endswith(".rels"):
            base = posixpath.dirname(_partie_des_relations(nom))
            for rel in racine:
                if rel.get("TargetMode") != "External" and rel.get("Target"):
                    cible = rel.get("Target")
                    cible = cible.lstrip("/") if cible.startswith("/") else posixpath.join(base, cible)
                    utilises.add(posixpath.normpath(cible))
    return utilises


def _relations_de(nom_partie):
    """word/document.xml → word/_rels/document.xml.rels"""
    dossier, fichier = posixpath.split(nom_partie)
    return posixpath.join(dossier, "_rels", fichier + ".rels")


def _cible_relation(rel, nom_partie):
    cible = rel.get("Target")
    if cible.startswith("/"):
        return cible.lstrip("/")
    return posixpath.normpath(posixpath.join(posixpath.dirname(nom_partie), cible))


def _image_md(source, adresse, alt):
    adresse = urllib.parse.unquote(adresse.strip().strip("<>"))
    image = {"nom": Path(adresse).name or adresse, "membre": None, "chemin": None, "note": None,
             "occurrences": 1, "alt": alt}
    if re.match(r"(?i)(https?:|data:|//)", adresse):
        image["nom"] = adresse[:80]
        image["note"] = "Image distante : non affichée (aucune connexion n'est faite)."
    else:
        chemin = (Path(source).parent / adresse).resolve()
        if chemin.is_file():
            image["chemin"] = str(chemin)
        else:
            image["note"] = ("Fichier image introuvable à côté du document. Pour le voir, indiquez le chemin "
                             "du dossier plutôt que de déposer le seul fichier Markdown.")
    return image


def images_du_fichier(chemin):
    """Images présentes dans le fichier, avec de quoi les retrouver (membre du .docx ou fichier sur disque)."""
    chemin = Path(chemin)
    if _est_pdf(chemin):
        return []
    if not _est_ooxml(chemin):
        texte = _lire_brut(chemin)[0]
        images = [_image_md(chemin, m.group(2), m.group(1)) for m in RE_IMAGE_MD.finditer(texte)]
        for m in RE_IMAGE_HTML.finditer(texte):
            src = re.search(r"""\bsrc\s*=\s*["']([^"']+)["']""", m.group(), re.IGNORECASE)
            alt = re.search(r"""\balt\s*=\s*["']([^"']*)["']""", m.group(), re.IGNORECASE)
            if src:
                images.append(_image_md(chemin, src.group(1), alt.group(1) if alt else ""))
        return images

    trouvees = {}
    with zipfile.ZipFile(chemin) as z:
        noms = set(z.namelist())
        for partie in _parties_texte(sorted(noms)):
            racine = _lire_racine(z, partie)
            elements = _images_xml(racine) if racine is not None else []
            if not elements:
                continue
            fichier_rels = _relations_de(partie)
            rels = {r.get("Id"): r for r in limites.xml(z.read(fichier_rels))} if fichier_rels in noms else {}
            for element in elements:
                ids = element.xpath(".//a:blip/@r:embed | .//a:blip/@r:link | .//v:imagedata/@r:id",
                                    namespaces={**NS, "r": R})
                rel = rels.get(ids[0]) if ids else None
                if rel is None:
                    cle, image = id(element), {"nom": "image", "note": "Image introuvable dans le document."}
                elif rel.get("TargetMode") == "External":
                    cle, image = rel.get("Target"), {"nom": rel.get("Target")[:80],
                                                     "note": "Image liée (hors du document) : non affichée."}
                else:
                    cle = _cible_relation(rel, partie)
                    image = {"nom": posixpath.basename(cle), "membre": cle if cle in noms else None,
                             "note": None if cle in noms else "Image introuvable dans le document."}
                if cle in trouvees:
                    trouvees[cle]["occurrences"] += 1
                else:
                    trouvees[cle] = {"membre": None, "chemin": None, "alt": "", "occurrences": 1, **image}
    return list(trouvees.values())


def lire_image(source, image):
    """Octets de l'image, ou None si elle n'est pas accessible."""
    if image.get("membre"):
        with zipfile.ZipFile(source) as z:
            return z.read(image["membre"])
    if image.get("chemin"):
        return Path(image["chemin"]).read_bytes()
    return None


def compter_images(chemin):
    chemin = Path(chemin)
    if _est_pdf(chemin):
        return 0              # les images d'un PDF ne sont jamais reprises dans le fichier produit
    if not _est_ooxml(chemin):
        texte = _lire_brut(chemin)[0]
        return len(RE_IMAGE_MD.findall(texte)) + len(RE_IMAGE_HTML.findall(texte))
    with zipfile.ZipFile(chemin) as z:
        total = 0
        for nom in _parties_texte(z.namelist()):
            racine = _lire_racine(z, nom)
            total += len(_images_xml(racine)) if racine is not None else 0
        return total


def avertissements(chemin, images_supprimees):
    """Éléments du fichier que l'outil n'analyse pas, à signaler dans le rapport."""
    chemin = Path(chemin)
    if _est_pdf(chemin):
        return list(pdf.lire(chemin).avertissements)
    messages = []
    if not images_supprimees:
        n = compter_images(chemin)
        if n:
            messages.append(f"{n} image(s) conservée(s) et non analysée(s) : vérifiez qu'elles ne contiennent "
                            "pas d'informations identifiantes (logos, signatures, captures d'écran).")
    if _est_ooxml(chemin):
        with zipfile.ZipFile(chemin) as z:
            noms = z.namelist()
            if any("/embeddings/" in n for n in noms):
                messages.append("Objets incorporés (tableaux Excel, autres documents) non analysés, "
                                "y compris leur image d'aperçu.")
            if any(RE_MINIATURE.fullmatch(n) for n in noms):
                messages.append("La miniature d'aperçu intégrée au fichier (image de la première page) "
                                "a été supprimée.")
        if chemin.suffix.lower() == ".xlsx":
            messages.append("Excel : les textes des cellules et des commentaires sont traités ; les noms des "
                            "feuilles, les formules, les nombres, les tableaux croisés dynamiques et les liens "
                            "externes ne le sont pas.")
        if chemin.suffix.lower() == ".pptx":
            messages.append("PowerPoint : les images d'arrière-plan et les objets incorporés ne sont pas analysés.")
    return messages


CT = "{http://schemas.openxmlformats.org/package/2006/content-types}"
SIGNATURES = [(b"\x89PNG", "image/png"), (b"\xff\xd8", "image/jpeg"), (b"GIF8", "image/gif"), (b"BM", "image/bmp"),
              (b"II*\x00", "image/tiff"), (b"MM\x00*", "image/tiff"), (b"\xd7\xcd\xc6\x9a", "image/x-wmf"),
              (b"\x01\x00\x00\x00", "image/x-emf"), (b"<svg", "image/svg+xml"), (b"<?xml", "application/xml")]


def _reparer_types(types, membres, lire):
    """Déclare un type de contenu pour les parties qui n'en ont pas (ex. une image « .undefined »).

    Sans type déclaré, Word juge le fichier endommagé et propose de le réparer.
    Renvoie le nombre de parties réparées.
    """
    defauts = {(e.get("Extension") or "").lower() for e in types if e.tag == CT + "Default"}
    surcharges = {(e.get("PartName") or "").lstrip("/") for e in types if e.tag == CT + "Override"}
    reparees = 0
    for nom in membres:
        extension = nom.rsplit(".", 1)[-1].lower() if "." in posixpath.basename(nom) else ""
        if nom.endswith("/") or nom == "[Content_Types].xml" or nom in surcharges or extension in defauts:
            continue
        debut = lire(nom)[:16].lstrip()
        type_ = next((t for signature, t in SIGNATURES if debut.startswith(signature)), "application/octet-stream")
        surcharge = etree.SubElement(types, CT + "Override")
        surcharge.set("PartName", "/" + nom)
        surcharge.set("ContentType", type_)
        reparees += 1
    return reparees


def _proprietes(nom):
    """Parties de propriétés traitées comme du texte libre (métadonnées, données XML personnalisées)."""
    return nom in ("docProps/core.xml", "docProps/app.xml", "docProps/custom.xml") \
        or re.fullmatch(r"customXml/item\d+\.xml", nom) is not None


def ecrire_anonymise(source, destination, correspondances, journal, supprimer_images=False, restaurer=False,
                     supprimer_xml_personnalise=False):
    """Écrit la version anonymisée de `source`. `restaurer=True` : `correspondances` remet les valeurs d'origine,
    et les métadonnées (auteurs, société, miniature) ne sont pas touchées."""
    source, destination = Path(source), Path(destination)
    limites.verifier_fichier(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    masquer = not restaurer
    if _est_pdf(source):
        pages = []
        for page in pdf.lire(source).pages:
            nouvelle = []
            for paragraphe in page:
                nouveau, remplacements, conservees = correspondances.remplacer(paragraphe)
                journal.noter(nouveau, remplacements, conservees)
                nouvelle.append(nouveau)
            pages.append(nouvelle)
        pdf.ecrire(pages, destination)
        return
    if not _est_ooxml(source):
        texte, encodage = _lire_brut(source)
        if supprimer_images:
            for motif in (RE_IMAGE_MD, RE_IMAGE_HTML):
                texte, n = motif.subn(IMAGE_SUPPRIMEE, texte)
                journal.images_supprimees += n
        nouveau, remplacements, conservees = correspondances.remplacer(texte)
        journal.noter(nouveau, remplacements, conservees)
        destination.write_text(nouveau, encoding="utf-8-sig" if encodage == "utf-8-sig" else encodage,
                               newline="")
        return

    with zipfile.ZipFile(source) as entree:
        infos = entree.infolist()
        a_traiter = set(_parties_texte(entree.namelist()))
        contenus = {}  # parties XML modifiées : nom -> racine
        for info in infos:
            nom = info.filename
            if nom in a_traiter or _proprietes(nom) or nom.endswith(".rels") or nom == "[Content_Types].xml":
                racine = _lire_racine(entree, nom) if nom in a_traiter else limites.xml(entree.read(nom))
                if racine is None:
                    a_traiter.discard(nom)
                    continue
                if nom in a_traiter:
                    if supprimer_images:
                        journal.images_supprimees += _supprimer_images_xml(racine)
                    _anonymiser_xml(racine, correspondances, journal, masquer)
                elif nom.endswith(".rels"):
                    if masquer:
                        _anonymiser_relations(racine, correspondances, journal)
                    if supprimer_xml_personnalise:        # confidentialité renforcée : parties XML personnalisées retirées
                        for rel in list(racine):
                            if "customXml" in (rel.get("Target") or "") or (rel.get("Type") or "").endswith("/customXml"):
                                racine.remove(rel)
                elif _proprietes(nom):
                    _anonymiser_proprietes(nom, racine, correspondances, journal, masquer)
                contenus[nom] = racine

        # Les entrées de dossier du zip (« word/ ») ne servent à rien dans un .docx : on ne les recopie pas.
        retires = {i.filename for i in infos if i.filename.endswith("/")}
        if supprimer_xml_personnalise:
            retires |= {i.filename for i in infos if i.filename.startswith("customXml/")}
        types = contenus["[Content_Types].xml"]
        if masquer:
            # La miniature d'aperçu est une image de la première page : elle montrerait les noms que l'on masque.
            retires |= {i.filename for i in infos if RE_MINIATURE.fullmatch(i.filename)}
            racine_rels = contenus.get("_rels/.rels")
            if racine_rels is not None:
                for rel in list(racine_rels):
                    if rel.get("Type", "").endswith("/thumbnail"):
                        racine_rels.remove(rel)
        if supprimer_images:
            utilises = _nettoyer_medias({n: r for n, r in contenus.items() if n in a_traiter}, contenus)
            retires |= {i.filename for i in infos if RE_MEDIA.match(i.filename) and i.filename not in utilises}
        for override in list(types):
            if (override.get("PartName") or "").lstrip("/") in retires:
                types.remove(override)
        journal.parties_reparees += _reparer_types(
            types, [i.filename for i in infos if i.filename not in retires], entree.read)

        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as sortie:
            for info in infos:
                if info.filename in retires:
                    continue
                if info.filename in contenus:
                    donnees = etree.tostring(contenus[info.filename], xml_declaration=True,
                                             encoding="UTF-8", standalone=True)
                else:
                    donnees = entree.read(info.filename)
                sortie.writestr(info, donnees, compress_type=info.compress_type)
