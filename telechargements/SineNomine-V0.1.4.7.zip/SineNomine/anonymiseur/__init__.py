"""Sine Nomine — anonymiseur de fichiers local. © Habeas Corpus Consulting, marque de Habeas Corpus"""

VERSION = "0.1.4.7"
