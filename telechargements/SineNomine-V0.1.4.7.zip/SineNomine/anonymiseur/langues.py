"""Langues des documents : état des packs, couverture réelle, avertissements.

Distinct de la langue de l'INTERFACE. Couverture exacte, telle qu'elle est implémentée aujourd'hui :

| Langue | Statut | Noms de personnes, sociétés, lieux | Formats locaux (téléphones, dates, adresses) |
|---|---|---|---|
| Anglais | inclus | modèle spaCy anglais + GLiNER | téléphones US/UK, dates anglaises |
| Français | facultatif (précoché si Windows est en français) | modèle spaCy français + GLiNER | téléphones, dates, adresses, NIR, SIRET… |
| Allemand | VERSION DE TEST | GLiNER (multilingue) seulement | aucun format local ; règles génériques (e-mail, IBAN, URL, IP, cartes) |
| Italien | VERSION DE TEST | GLiNER seulement | idem |
| Espagnol | VERSION DE TEST | GLiNER seulement | idem |

Les langues en test : prise en charge EXPÉRIMENTALE, omissions ou interprétations erronées possibles, vérification attentive nécessaire.
Ce message est affiché avant lancement, à la validation et dans les rapports. Les modèles ne sont pas téléchargés par l'application
dans cette version (le téléchargement explicite, distinct du traitement et sans contenu documentaire, relève de l'installation).
"""

from collections import Counter

from . import langue as detecteur

PACKS = {
    "en": {"nom": "Anglais", "statut": "inclus", "test": False, "modeles": "spaCy anglais, GLiNER", "formats_locaux": True},
    "fr": {"nom": "Français", "statut": "facultatif", "test": False, "modeles": "spaCy français, GLiNER", "formats_locaux": True},
    "de": {"nom": "Allemand", "statut": "version de test", "test": True, "modeles": "GLiNER seulement", "formats_locaux": False},
    "it": {"nom": "Italien", "statut": "version de test", "test": True, "modeles": "GLiNER seulement", "formats_locaux": False},
    "es": {"nom": "Espagnol", "statut": "version de test", "test": True, "modeles": "GLiNER seulement", "formats_locaux": False},
}
MESSAGE_TEST = ("Prise en charge expérimentale ({langue}) : des omissions ou des interprétations erronées sont possibles ; "
                "une vérification attentive est nécessaire.")
MESSAGE_NON_ACTIVEE = ("Passages en {langue} détectés alors que cette langue n'est pas activée : l'analyse de ces passages est partielle "
                       "(modèle de cette langue non utilisé).")


def actives(config):
    """Langues activées (l'anglais est toujours inclus)."""
    choisies = [c for c in (config or {}).get("langues", ["fr", "en"]) if c in PACKS]
    return sorted({*choisies, "en"}, key=list(PACKS).index)


def etat(config):
    activees = actives(config)
    return [{"code": code, **pack, "active": code in activees,
             "avertissement": MESSAGE_TEST.format(langue=pack["nom"]) if pack["test"] else None}
            for code, pack in PACKS.items()]


def detecter_passages(textes, config, minimum_mots=8):
    """Langues détectées par passage (paragraphe) : {"detectees": {code: nombre de passages}, "avertissements": [...]}.

    L'analyse partielle n'est jamais présentée comme complète : une langue détectée mais non activée, ou en version de test,
    est signalée."""
    compte = Counter()
    for texte in textes.values():
        defaut = detecteur.detecter(texte)
        for paragraphe in texte.split("\n"):
            if len(paragraphe.split()) >= minimum_mots:
                compte[detecteur.detecter(paragraphe, defaut)] += 1
    activees = actives(config)
    avertissements = []
    for code, n in compte.items():
        pack = PACKS.get(code)
        if pack is None:
            continue
        if pack["test"]:
            avertissements.append(MESSAGE_TEST.format(langue=pack["nom"]))
        if code not in activees:
            avertissements.append(MESSAGE_NON_ACTIVEE.format(langue=pack["nom"]))
    return {"detectees": dict(compte), "avertissements": list(dict.fromkeys(avertissements))}
