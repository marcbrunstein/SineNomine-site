"""Conversion locale des fichiers produits en PDF, par LibreOffice (composant FACULTATIF).

LibreOffice (licence MPL-2.0 ; https://www.libreoffice.org) n'est pas fourni avec Sine Nomine : il est détecté s'il est installé
(`soffice.exe`), ou indiqué dans `config.json` (rubrique `conversion.libreoffice`). La conversion est LOCALE : aucun service distant,
aucun contenu transmis. Elle intervient APRÈS le traitement (remplacement des noms) et tous les livrables finaux, PDF compris,
sont ensuite contrôlés (termes imposés, cohérence).

Formats convertibles (les seuls proposés) : Word (.docx), PowerPoint (.pptx), Excel (.xlsx), HTML et texte. Les autres formats
(Markdown, CSV) n'ont pas de conversion opérationnelle et ne sont pas proposés.

Un PDF produit par conversion automatique peut différer de la mise en page du fichier modifiable (sauts de page, polices, feuilles
Excel larges, animations PowerPoint). Il ne permet pas une restauration fidèle : CONSERVEZ la version modifiable pour les
dé-pseudonymisations futures.
"""

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from . import limites

FORMATS_CONVERTIBLES = {".docx", ".pptx", ".xlsx", ".html", ".htm", ".txt"}
CHEMINS_USUELS = (r"C:\Program Files\LibreOffice\program\soffice.exe", r"C:\Program Files (x86)\LibreOffice\program\soffice.exe")
AVERTISSEMENTS_PDF = [
    "PDF produit par conversion automatique (LibreOffice) : la mise en page peut différer du fichier modifiable (sauts de page, polices, "
    "feuilles Excel larges, animations PowerPoint). Relisez-le.",
    "Un PDF ne permet pas une restauration fidèle : conservez la version modifiable pour les dé-pseudonymisations futures.",
]


class ConversionErreur(Exception):
    """La conversion a échoué (le message dit pourquoi)."""


def trouver_libreoffice(config=None):
    voulu = ((config or {}).get("conversion") or {}).get("libreoffice") or ""
    candidats = [voulu, shutil.which("soffice") or "", *CHEMINS_USUELS]
    return next((c for c in candidats if c and Path(c).is_file()), None)


def etat(config=None):
    exe = trouver_libreoffice(config)
    return {"disponible": exe is not None, "moteur": "LibreOffice (MPL-2.0)", "chemin": exe,
            "formats": sorted(FORMATS_CONVERTIBLES),
            "message": None if exe else "LibreOffice n'est pas installé : l'export PDF n'est pas disponible. "
                                         "Installez-le (composant facultatif) puis relancez Sine Nomine."}


def convertir_en_pdf(source, destination, config=None):
    """Convertit `source` en PDF et l'écrit à `destination`. Lève ConversionErreur (message clair) en cas d'échec."""
    exe = trouver_libreoffice(config)
    if exe is None:
        raise ConversionErreur("LibreOffice n'est pas installé : conversion PDF impossible.")
    source, destination = Path(source), Path(destination)
    if source.suffix.lower() not in FORMATS_CONVERTIBLES:
        raise ConversionErreur(f"Pas de conversion PDF pour le format {source.suffix}.")
    delai = limites.limite("duree_conversion")
    with tempfile.TemporaryDirectory(prefix="sine-nomine-conv-") as temporaire:
        profil = Path(temporaire) / "profil"
        sortie = Path(temporaire) / "sortie"
        sortie.mkdir()
        commande = [exe, "--headless", "--norestore", "--nolockcheck", "--nodefault", "--nofirststartwizard",
                    f"-env:UserInstallation={profil.as_uri()}", "--convert-to", "pdf", "--outdir", str(sortie), str(source)]
        try:
            processus = subprocess.Popen(commande, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError as e:
            raise ConversionErreur(f"LibreOffice n'a pas pu démarrer : {e}") from e
        try:
            _, erreur = processus.communicate(timeout=delai)
        except subprocess.TimeoutExpired:
            _arreter(processus)
            raise ConversionErreur(f"Conversion interrompue : délai de {delai} s dépassé.") from None
        produit = sortie / (source.stem + ".pdf")
        if processus.returncode != 0 or not produit.is_file():
            detail = (erreur or b"").decode("utf-8", "replace").strip()[:200]
            raise ConversionErreur("Échec de la conversion PDF" + (f" : {detail}" if detail else "."))
        if produit.stat().st_size == 0 or not produit.read_bytes()[:5] == b"%PDF-":
            raise ConversionErreur("Le fichier PDF produit est vide ou invalide.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(produit), str(destination))
    return destination


def _arreter(processus):
    """Arrête LibreOffice et ses processus fils (sous Windows, soffice.exe lance soffice.bin)."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(processus.pid)], capture_output=True, timeout=15)
        else:
            processus.kill()
        processus.communicate(timeout=15)
    except Exception:  # noqa: BLE001 — au pire, le processus sera arrêté à la fermeture
        pass
