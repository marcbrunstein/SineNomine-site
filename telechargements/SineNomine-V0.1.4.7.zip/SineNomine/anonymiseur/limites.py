"""Limites documentées contre les fichiers démesurés ou malformés, et lecture XML durcie.

LIMITES PAR DÉFAUT (réglables dans `config.json`, rubrique `limites`) :

| Limite | Valeur | Effet |
|---|---|---|
| taille d'un fichier | 200 Mo | fichier refusé, signalé |
| fichiers par lot | 2 000 | lot refusé |
| membres d'une archive Office (zip) | 5 000 | fichier refusé |
| taille décompressée d'un fichier Office | 1 Go | fichier refusé |
| taux de compression d'un membre | 200 | fichier refusé (bombe de décompression) |
| taille d'une partie XML | 100 Mo | fichier refusé |
| pages d'un PDF | 2 000 | PDF refusé |
| pixels d'une image | 100 millions | miniature non produite |
| durée de conversion PDF d'un fichier | 300 s | conversion interrompue |
| termes imposés | 5 000, 200 caractères chacun | liste refusée |

Un fichier refusé n'arrête pas le lot : il est signalé comme non lu, et ce qui n'a pas été analysé n'est jamais présenté comme vérifié.
Les expressions régulières de recherche sont construites à partir de formes littérales échappées (aucune expression fournie par l'utilisateur).
La lecture XML interdit les déclarations de type de document (DTD) et d'entités, le réseau et les très grands arbres.
"""

import zipfile
from pathlib import Path

from lxml import etree

PAR_DEFAUT = {
    "taille_fichier": 200 * 2**20,
    "fichiers_par_lot": 2000,
    "membres_zip": 5000,
    "taille_decompressee": 2**30,
    "ratio_compression": 200,
    "taille_partie_xml": 100 * 2**20,
    "pages_pdf": 2000,
    "pixels_image": 100_000_000,
    "duree_conversion": 300,
    "termes_imposes": 5000,
    "longueur_terme": 200,
}
_ACTIVES = dict(PAR_DEFAUT)
EXTENSIONS_ZIP = {".docx", ".docm", ".dotx", ".pptx", ".pptm", ".potx", ".xlsx", ".xlsm", ".xltx"}


class FichierRefuse(Exception):
    """Fichier trop gros, trop imbriqué ou dangereux : il n'est pas lu."""


def configurer(config):
    _ACTIVES.clear()
    _ACTIVES.update(PAR_DEFAUT)
    for cle, valeur in ((config or {}).get("limites") or {}).items():
        if cle in PAR_DEFAUT and isinstance(valeur, int) and valeur > 0:
            _ACTIVES[cle] = valeur


def limite(nom):
    return _ACTIVES[nom]


def verifier_fichier(chemin):
    """Refuse (FichierRefuse) un fichier dont la taille, ou celle de son contenu décompressé, dépasse les limites."""
    chemin = Path(chemin)
    taille = chemin.stat().st_size
    if taille > limite("taille_fichier"):
        raise FichierRefuse(f"Fichier trop volumineux ({taille // 2**20} Mo ; limite {limite('taille_fichier') // 2**20} Mo).")
    if chemin.suffix.lower() not in EXTENSIONS_ZIP:
        return
    try:
        with zipfile.ZipFile(chemin) as z:
            infos = z.infolist()
    except zipfile.BadZipFile as e:
        raise FichierRefuse(f"Archive Office endommagée ({e}).") from e
    if len(infos) > limite("membres_zip"):
        raise FichierRefuse(f"Archive anormale : {len(infos)} éléments (limite {limite('membres_zip')}).")
    total = 0
    for info in infos:
        total += info.file_size
        if info.compress_size and info.file_size / info.compress_size > limite("ratio_compression") and info.file_size > 1_000_000:
            raise FichierRefuse(f"Archive anormale : taux de compression excessif ({info.filename}).")
        if info.file_size > limite("taille_partie_xml") and info.filename.endswith((".xml", ".rels")):
            raise FichierRefuse(f"Partie XML trop volumineuse ({info.filename}).")
    if total > limite("taille_decompressee"):
        raise FichierRefuse(f"Contenu décompressé trop volumineux ({total // 2**20} Mo ; limite {limite('taille_decompressee') // 2**20} Mo).")


def parseur_xml():
    """Parseur XML durci : ni entités, ni DTD, ni réseau, ni arbre démesuré."""
    return etree.XMLParser(resolve_entities=False, no_network=True, load_dtd=False, dtd_validation=False, huge_tree=False,
                           remove_comments=False, remove_pis=False)


def xml(donnees):
    """Racine d'un document XML, après refus de toute déclaration DTD ou d'entité (XXE, « milliard de rires »)."""
    if isinstance(donnees, str):
        donnees = donnees.encode("utf-8")
    entete = donnees[:4096].lower()
    if b"<!doctype" in entete or b"<!entity" in donnees[:65536].lower():
        raise FichierRefuse("Document XML refusé : déclaration de type de document ou d'entité (non autorisée).")
    return etree.fromstring(donnees, parseur_xml())
