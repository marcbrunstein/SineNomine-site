"""Détection des informations sensibles par expressions régulières (formats français).

Chaque détecteur renvoie des Trouvaille(debut, fin, categorie, valeur, cle, score).
`cle` est la forme normalisée qui permet de reconnaître la même valeur écrite
de plusieurs façons (par exemple un téléphone avec ou sans espaces).
"""

import re
from dataclasses import dataclass

CATEGORIES = {
    "email": "E-mails",
    "telephone": "Téléphones",
    "iban": "IBAN et BIC",
    "nir": "N° de sécurité sociale",
    "siret": "SIRET / SIREN",
    "adresse": "Adresses",
    "date_naissance": "Dates de naissance",
    "montant": "Montants",
    "url": "URL et noms de domaine",
    "date": "Dates",
    "ip": "Adresses IP et MAC",
    "carte": "Cartes bancaires",
    "tva": "N° de TVA",
    "plaque": "Plaques d'immatriculation et n° de châssis",
    "pseudo": "Comptes et pseudos (@nom)",
    "piece_identite": "Passeports et cartes d'identité",
    "reference": "Références internes (motifs configurés)",
    "id_national": "Identifiants nationaux étrangers (NINO, SSN, NHS…)",
    "chemin": "Chemins de fichiers et de réseau",
    "coordonnees": "Coordonnées GPS",
}

# Étiquette utilisée dans le texte remplacé : [Email 1], [Téléphone 2]…
ETIQUETTES = {
    "email": "Email",
    "telephone": "Téléphone",
    "iban": "IBAN",
    "nir": "N° sécu",
    "siret": "SIRET",
    "adresse": "Adresse",
    "date_naissance": "Date de naissance",
    "montant": "Montant",
    "url": "URL",
    "date": "Date",
    "ip": "IP",
    "carte": "Carte",
    "tva": "TVA",
    "plaque": "Plaque",
    "pseudo": "Pseudo",
    "piece_identite": "Pièce identité",
    "reference": "Référence",
    "id_national": "Identifiant",
    "chemin": "Chemin",
    "coordonnees": "Coordonnées",
    "passage": "Passage",           # passage masqué à la main (pas une catégorie détectée : absente de CATEGORIES)
}

# En cas de chevauchement, la catégorie la plus haute dans cette liste l'emporte.
PRIORITE = ["email", "url", "iban", "carte", "nir", "id_national", "siret", "tva", "telephone", "ip", "plaque", "pseudo",
            "piece_identite", "reference", "chemin", "coordonnees", "adresse", "date_naissance", "montant", "date"]

# Motifs de références internes (numéros de dossier, de contrat, de client…), définis dans config.json.
MOTIFS_REFERENCES = []
MOTIFS_INVALIDES = []


@dataclass
class Trouvaille:
    debut: int
    fin: int
    categorie: str
    valeur: str
    cle: str
    score: float


def _chiffres(texte):
    return re.sub(r"\D", "", texte)


def _luhn(nombre):
    total = 0
    for i, c in enumerate(reversed(nombre)):
        n = int(c)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def _iban_valide(iban):
    iban = iban.replace(" ", "").upper()
    if not 15 <= len(iban) <= 34:
        return False
    deplace = iban[4:] + iban[:4]
    numerique = "".join(str(int(c, 36)) for c in deplace)
    return int(numerique) % 97 == 1


def _nir_cle_valide(nir):
    nir = nir.replace(" ", "").upper()
    if len(nir) != 15:
        return None
    corps = nir[:13].replace("2A", "19").replace("2B", "18")
    if not corps.isdigit():
        return False
    return 97 - int(corps) % 97 == int(nir[13:])


ESP = r"[   ]"  # espaces, y compris insécables
MOIS = (r"(?:janvier|f[ée]vrier|mars|avril|mai|juin|juillet|ao[uû]t|septembre|"
        r"octobre|novembre|d[ée]cembre|janv\.?|f[ée]vr?\.?|avr\.?|juil\.?|sept\.?|oct\.?|nov\.?|d[ée]c\.?)")

RE_EMAIL = re.compile(r"(?<![\w.+-])[\w.+-]+@[\w-]+(?:\.[\w-]+)*\.[A-Za-z]{2,}(?![\w-])")
RE_URL = re.compile(r"(?<![\w@/])(?:https?://|www\.)[^\s<>\"'«»()\[\]]+", re.IGNORECASE)
# Noms de domaine écrits sans « http » (acme.fr, linkedin.com/in/jean-dupont) : seules les extensions courantes comptent,
# pour ne pas prendre pour un site un nom de fichier (rapport.docx) ou une abréviation.
EXTENSIONS_WEB = (r"(?:com|net|org|info|biz|eu|fr|de|es|it|be|ch|nl|lu|pt|ie|uk|us|ca|io|ai|co|app|dev|tech|online|site|shop|"
                  r"store|cloud|pro|agency|group|consulting|paris|gov|edu|local|internal|lan|intranet|corp|home)")
RE_DOMAINE = re.compile(
    rf"(?<![\w@./:-])(?:[a-z0-9](?:[a-z0-9-]{{0,61}}[a-z0-9])?\.)+{EXTENSIONS_WEB}(?::\d{{2,5}})?"
    rf"(?:/[^\s<>\"'«»()\[\]]*)?(?![\w@-])", re.IGNORECASE)
RE_TEL_FR = re.compile(
    rf"(?<![\d+])(?:(?:\+|00)33{ESP}?(?:\(0\){ESP}?)?|0)[1-9](?:[{ESP[1:-1]}.\-]?\d{{2}}){{4}}(?!\d)")
RE_TEL_INTL = re.compile(rf"(?<![\d+])(?:\+|00)(?!33)\d{{1,3}}(?:[{ESP[1:-1]}.\-]?\(?\d{{1,4}}\)?){{2,5}}(?!\d)")
RE_IBAN = re.compile(rf"(?<![A-Z0-9])[A-Z]{{2}}\d{{2}}(?:{ESP}?[A-Z0-9]{{4}}){{2,7}}(?:{ESP}?[A-Z0-9]{{1,3}})?(?![A-Z0-9])")
RE_NIR = re.compile(
    rf"(?<!\d)[12]{ESP}?\d{{2}}{ESP}?(?:0[1-9]|1[0-2]|[2-9]\d){ESP}?(?:\d{{2}}|2[ABab])"
    rf"{ESP}?\d{{3}}{ESP}?\d{{3}}(?:{ESP}?\d{{2}})?(?!\d)")
RE_SIRET = re.compile(rf"(?<!\d)\d{{3}}{ESP}?\d{{3}}{ESP}?\d{{3}}{ESP}?\d{{5}}(?!\d)")
RE_SIREN = re.compile(rf"(?i:siren|rcs|immatricul\w*|siret)[^\d\n]{{0,25}}(?<!\d)(\d{{3}}{ESP}?\d{{3}}{ESP}?\d{{3}})(?!\d)")
NOMBRE = rf"(?:\d{{1,3}}(?:[{ESP[1:-1]}.]\d{{3}})+|\d+)(?:,\d{{1,2}})?"
# Nombres à l'anglaise (2,500.00) : exigés avec une virgule de milliers ou une décimale pour ne pas gêner « 2 500,50 ».
NOMBRE_EN = r"(?:\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+\.\d{1,2})"
RE_MONTANT = re.compile(
    rf"(?<![\w,.])(?:(?:€|\$|£){ESP}?{NOMBRE_EN}|{NOMBRE_EN}{ESP}?(?i:USD|GBP|EUR|dollars?|pounds?)\b"
    rf"|{NOMBRE}{ESP}?(?:k€|M€|Md€|€|(?i:euros?|EUR|USD|dollars?|CHF|GBP)\b|\$|£)"
    rf"|(?:€|\$|£){ESP}?{NOMBRE})")
RE_DATE = re.compile(
    rf"(?<!\d)(?:\d{{1,2}}[/.\-]\d{{1,2}}[/.\-](?:\d{{4}}|\d{{2}})|\d{{4}}-\d{{2}}-\d{{2}}"
    rf"|(?:1er|\d{{1,2}}){ESP}+(?i:{MOIS}){ESP}+\d{{4}})(?!\d)")
RE_NAISSANCE = re.compile(r"(?i:\bn[ée]e?\s+le|\bdate\s+de\s+naissance\s*:?|\bnaissance\s*:"
                          r"|\bborn(?:\s+on)?|\bdate\s+of\s+birth\s*:?|\bD\.?O\.?B\.?\s*:?)\s*$")

# ---------------------------------------------------------------- formats anglais (UK et US)
MOIS_EN = (r"(?:January|February|March|April|May|June|July|August|September|October|November|December|"
           r"Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sept?|Oct|Nov|Dec)\.?")
RE_DATE_EN = re.compile(
    rf"(?<![\w])(?:\d{{1,2}}(?:st|nd|rd|th)?{ESP}+(?:of{ESP}+)?{MOIS_EN},?{ESP}+\d{{4}}"
    rf"|{MOIS_EN}{ESP}+\d{{1,2}}(?:st|nd|rd|th)?,?{ESP}+\d{{4}})(?!\d)")
RE_TEL_US = re.compile(rf"(?<![\d+])(?:\+?1{ESP}?)?\(?[2-9]\d{{2}}\)?[{ESP[1:-1]}.\-]\d{{3}}[{ESP[1:-1]}.\-]\d{{4}}(?!\d)")
RE_TEL_UK = re.compile(rf"(?<![\d+])0[1-378]\d{{1,3}}{ESP}\d{{3,4}}{ESP}?\d{{3,4}}(?!\d)")
SUFFIXES_EN = (r"(?:Street|St\.?|Road|Rd\.?|Avenue|Ave\.?|Lane|Ln\.?|Drive|Dr\.?|Close|Way|Square|Sq\.?|Place|Pl\.?|"
               r"Court|Ct\.?|Boulevard|Blvd\.?|Terrace|Crescent|Gardens|Hill|Row|Walk|Mews|Parade|Highway|Hwy|"
               r"Parkway|Pkwy|Circle|Trail)")
MOT_CAP = r"[A-Z][\w'’\-]*"
CP_UK = r"[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}"
ZIP_US = r"[A-Z]{2}\s\d{5}(?:-\d{4})?"
RE_ADRESSE_EN = re.compile(
    rf"(?<![\w])\d{{1,5}}[A-Z]?{ESP}+(?:{MOT_CAP}{ESP}+){{1,4}}{SUFFIXES_EN}(?![\w])"
    rf"(?:,{ESP}*{MOT_CAP}(?:{ESP}(?!{CP_UK}(?!\w)){MOT_CAP}){{0,2}})?"
    rf"(?:,?{ESP}+(?:{ZIP_US}|{CP_UK})(?![\w]))?")
RE_CP_EN = re.compile(rf"(?<![\w-])(?:{ZIP_US}|{CP_UK})(?![\w-])")
RE_NINO = re.compile(rf"(?<![\w])[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]{ESP}?\d{{2}}{ESP}?\d{{2}}{ESP}?\d{{2}}{ESP}?[A-D](?![\w])")
RE_SSN = re.compile(r"(?<![\w-])(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}(?![\w-])")
RE_NHS = re.compile(rf"(?<![\d-])\d{{3}}{ESP}\d{{3}}{ESP}\d{{4}}(?!\d)")
NINO_PREFIXES_INVALIDES = {"BG", "GB", "NK", "KN", "TN", "NT", "ZZ"}


def _nhs_valide(chiffres):
    """Numéro NHS : clé modulo 11 sur les neuf premiers chiffres (poids 10 à 2)."""
    if len(chiffres) != 10:
        return False
    cle = 11 - sum(int(c) * (10 - i) for i, c in enumerate(chiffres[:9])) % 11
    cle = 0 if cle == 11 else cle
    return cle != 10 and cle == int(chiffres[9])

TYPES_VOIE = (r"(?i:rue|avenue|av\.|boulevard|bd|bld|place|pl\.|chemin|ch\.|all[ée]e|impasse|imp\.|quai|cours|"
              r"route|rte|square|passage|voie|faubourg|fbg|rond-point|esplanade|parvis|cit[ée]|hameau|"
              r"lieu-dit|r[ée]sidence|sentier|villa|mail|promenade|traverse|mont[ée]e)")
MOT_VOIE = r"[A-ZÀ-Ý0-9][\w'’\-.]*"
LIAISON = r"(?:de|du|des|la|le|les|l['’]|d['’]|et|sur|sous|en|aux?)"
RE_ADRESSE = re.compile(
    rf"(?<![\w])\d{{1,4}}{ESP}?(?:(?i:bis|ter|quater)|[A-D])?,?{ESP}+{TYPES_VOIE}{ESP}+"
    rf"(?:{LIAISON}{ESP}*)*{MOT_VOIE}(?:{ESP}+(?:{LIAISON}{ESP}*)*{MOT_VOIE}){{0,5}}"
    rf"(?:,?{ESP}+(?:\d{{5}}|\d{{2}}{ESP}\d{{3}}){ESP}+[A-ZÀ-Ý][\w'’\-]*(?:[{ESP[1:-1]}\-][A-ZÀ-Ý][\w'’\-]*){{0,3}}"
    rf"(?:{ESP}+(?i:cedex)(?:{ESP}\d{{1,2}})?)?)?")
RE_CP_VILLE = re.compile(
    rf"(?<![\w])(?:\d{{5}}){ESP}+[A-ZÀ-Ý][\w'’\-]*(?:[{ESP[1:-1]}\-](?:{LIAISON}[{ESP[1:-1]}\-])?[A-ZÀ-Ý][\w'’\-]*){{0,3}}"
    rf"(?:{ESP}+(?i:cedex)(?:{ESP}\d{{1,2}})?)?")


OCTET = r"(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)"
RE_IPV4 = re.compile(rf"(?<![\d.\w])(?:{OCTET}\.){{3}}{OCTET}(?![\d\w]|\.\d)")
RE_CARTE = re.compile(r"(?<![\d-])(?:\d{4}([ -]?)\d{4}\1\d{4}\1\d{4}|3[47]\d{2}([ -]?)\d{6}\2\d{5})(?![\d-])")
LETTRE_SIV = "[A-HJ-NP-TV-Z]"      # le système SIV exclut les lettres I, O et U
RE_PLAQUE = re.compile(rf"(?<![A-Za-z0-9-]){LETTRE_SIV}{{2}}([- ]?)\d{{3}}\1{LETTRE_SIV}{{2}}(?![A-Za-z0-9-])")
RE_TVA = re.compile(
    rf"(?<![A-Za-z0-9])(?:FR{ESP}?[0-9A-HJ-NP-Z]{{2}}{ESP}?\d{{3}}{ESP}?\d{{3}}{ESP}?\d{{3}}"
    rf"|DE{ESP}?\d{{9}}|BE{ESP}?0\d{{9}}|ES{ESP}?[A-Z0-9]\d{{7}}[A-Z0-9]|IT{ESP}?\d{{11}}"
    rf"|NL{ESP}?\d{{9}}B\d{{2}}|LU{ESP}?\d{{8}}|PT{ESP}?\d{{9}}|IE{ESP}?\d{{7}}[A-Z]{{1,2}}|GB{ESP}?\d{{9}})(?![A-Za-z0-9])")
# IPv6 (complètes ou abrégées avec « :: ») et adresses MAC
H16 = r"[0-9A-Fa-f]{1,4}"
RE_IPV6 = re.compile(
    rf"(?<![\w:])(?:(?:{H16}:){{7}}{H16}|(?:{H16}:){{1,6}}(?::{H16}){{1,6}}|(?:{H16}:){{1,7}}:|::(?:{H16}:){{0,6}}{H16})(?![\w:])")
RE_MAC = re.compile(r"(?<![\w:-])(?:[0-9A-Fa-f]{2}([:-]))(?:[0-9A-Fa-f]{2}\1){4}[0-9A-Fa-f]{2}(?![\w:-])")
# Chemins : lecteur Windows (C:\Users\jean.dupont\…), partage réseau (\\serveur\partage), dossiers personnels Unix
RE_CHEMIN = re.compile(
    r"(?<![\w\\])(?:[A-Za-z]:\\(?:[\w.\-()]+(?: [\w.\-()]+){0,4}\\)*(?:[\w.\-()]+(?: [\w.\-()]+){0,4}?\.[A-Za-z0-9]{2,5}\b|[\w.\-()]+)"
    r"|\\\\[\w.\-]+(?:\\[\w.$\-]+)+"
    r"|(?:/home|/Users)/[\w.\-]+(?:/[\w.\-]+)*)")
# Coordonnées GPS en degrés décimaux (48.856614, 2.352222) : au moins quatre décimales
RE_GPS = re.compile(r"(?<![\d.])-?\d{1,2}\.\d{4,}\s*[,;]\s*-?\d{1,3}\.\d{4,}(?!\d)(?!\.\d)")
# BIC / SWIFT et numéro de châssis (VIN), reconnus à leur intitulé
RE_BIC = re.compile(r"(?i:\bBIC\b|\bSWIFT\b)[^\n\w]{0,12}([A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?)(?![A-Za-z0-9])")
RE_VIN = re.compile(r"(?i:\bVIN\b|ch[âa]ssis|serial\s+number|n°\s*de\s*s[ée]rie)[^\n\w]{0,15}([A-HJ-NPR-Z0-9]{17})(?![A-Za-z0-9])")
RE_PSEUDO = re.compile(r"(?<![\w@./-])@[A-Za-z0-9_](?:[A-Za-z0-9_.]{1,28}[A-Za-z0-9_])?(?![\w@])")
RE_PIECE = re.compile(
    r"(?i:passeport|passport|carte\s+(?:nationale\s+)?d['’]identit[ée]|\bCNI\b)[^\n\d]{0,30}?"
    r"(?<![0-9A-Za-z])([0-9]{2}[A-Z]{2}[0-9]{5}|[0-9A-Z]{9,12})(?![0-9A-Za-z])")


def _tva_fr_valide(texte):
    """Clé de TVA française : (12 + 3 × (SIREN mod 97)) mod 97, quand la clé est numérique."""
    brut = re.sub(r"\s", "", texte).upper()
    cle, siren = brut[2:4], brut[4:]
    if not cle.isdigit():
        return True            # clé alphabétique : non contrôlable
    return (12 + 3 * (int(siren) % 97)) % 97 == int(cle)


def configurer(motifs):
    """Enregistre les motifs de références internes de config.json ; ceux qui ne compilent pas sont mis de côté."""
    MOTIFS_REFERENCES.clear()
    MOTIFS_INVALIDES.clear()
    for motif in motifs or []:
        try:
            MOTIFS_REFERENCES.append(re.compile(motif))
        except re.error:
            MOTIFS_INVALIDES.append(motif)


def _nettoyer_url(valeur):
    return valeur.rstrip(".,;:!?")


def detecter(texte):
    """Toutes les informations sensibles du texte, sans chevauchement."""
    brutes = []

    for m in RE_EMAIL.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "email", m.group(), m.group().lower(), 0.99))

    for m in RE_URL.finditer(texte):
        valeur = _nettoyer_url(m.group())
        brutes.append(Trouvaille(m.start(), m.start() + len(valeur), "url", valeur,
                                 valeur.lower().rstrip("/"), 0.95))

    for m in RE_DOMAINE.finditer(texte):
        valeur = _nettoyer_url(m.group())
        hote = re.split(r"[/:]", valeur, maxsplit=1)[0].rsplit(".", 1)[0]
        if not re.search(r"[A-Za-z]", hote):          # « 2026.com » : une année suivie d'un point, pas un site
            continue
        brutes.append(Trouvaille(m.start(), m.start() + len(valeur), "url", valeur, valeur.lower().rstrip("/"), 0.85))

    for m in RE_IBAN.finditer(texte):
        if _iban_valide(m.group()):
            brutes.append(Trouvaille(m.start(), m.end(), "iban", m.group(),
                                     m.group().replace(" ", "").upper(), 0.99))

    for m in RE_NIR.finditer(texte):
        valide = _nir_cle_valide(m.group())
        if valide is False:
            continue
        cle = re.sub(r"\s", "", m.group()).upper()
        brutes.append(Trouvaille(m.start(), m.end(), "nir", m.group(), cle[:13], 0.99 if valide else 0.75))

    for m in RE_SIRET.finditer(texte):
        chiffres = _chiffres(m.group())
        if _luhn(chiffres):
            brutes.append(Trouvaille(m.start(), m.end(), "siret", m.group(), chiffres, 0.95))
    for m in RE_SIREN.finditer(texte):
        chiffres = _chiffres(m.group(1))
        if _luhn(chiffres):
            brutes.append(Trouvaille(m.start(1), m.end(1), "siret", m.group(1), chiffres, 0.9))

    for m in RE_TEL_FR.finditer(texte):
        chiffres = _chiffres(m.group())
        if chiffres.startswith("0033"):
            chiffres = chiffres[4:]
        elif chiffres.startswith("33") and m.group().lstrip().startswith("+"):
            chiffres = chiffres[2:]
        chiffres = chiffres[-9:]
        brutes.append(Trouvaille(m.start(), m.end(), "telephone", m.group(), "33" + chiffres, 0.95))
    for m in RE_TEL_INTL.finditer(texte):
        chiffres = _chiffres(m.group())
        if len(chiffres) >= 8:
            brutes.append(Trouvaille(m.start(), m.end(), "telephone", m.group(), chiffres.lstrip("0"), 0.8))

    for m in RE_ADRESSE.finditer(texte):
        valeur = m.group().rstrip(" ,.")
        brutes.append(Trouvaille(m.start(), m.start() + len(valeur), "adresse", valeur,
                                 re.sub(r"\s+", " ", valeur.lower()), 0.85))
    for m in RE_CP_VILLE.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "adresse", m.group(),
                                 re.sub(r"\s+", " ", m.group().lower()), 0.7))

    for m in RE_MONTANT.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "montant", m.group(),
                                 re.sub(r"\s", "", m.group().lower()), 0.9))

    for m in RE_DATE.finditer(texte):
        avant = texte[max(0, m.start() - 40):m.start()]
        categorie = "date_naissance" if RE_NAISSANCE.search(avant) else "date"
        brutes.append(Trouvaille(m.start(), m.end(), categorie, m.group(),
                                 re.sub(r"\s+", " ", m.group().lower()), 0.95 if categorie == "date_naissance" else 0.9))

    for m in RE_IPV4.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "ip", m.group(), m.group(), 0.8))

    for m in RE_IPV6.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "ip", m.group(), m.group().lower(), 0.8))
    for m in RE_MAC.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "ip", m.group(), m.group().lower().replace("-", ":"), 0.85))

    for m in RE_CHEMIN.finditer(texte):
        valeur = m.group().rstrip(" .,;")
        brutes.append(Trouvaille(m.start(), m.start() + len(valeur), "chemin", valeur, valeur.lower().replace("/", "\\"), 0.85))

    for m in RE_GPS.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "coordonnees", m.group(), re.sub(r"\s", "", m.group()), 0.9))

    for m in RE_BIC.finditer(texte):
        brutes.append(Trouvaille(m.start(1), m.end(1), "iban", m.group(1), m.group(1).upper(), 0.85))
    for m in RE_VIN.finditer(texte):
        if sum(c.isdigit() for c in m.group(1)) >= 3:
            brutes.append(Trouvaille(m.start(1), m.end(1), "plaque", m.group(1), m.group(1).upper(), 0.85))

    for m in RE_CARTE.finditer(texte):
        chiffres = _chiffres(m.group())
        if _luhn(chiffres):
            brutes.append(Trouvaille(m.start(), m.end(), "carte", m.group(), chiffres, 0.9))

    for m in RE_TVA.finditer(texte):
        brut = re.sub(r"\s", "", m.group()).upper()
        valide = _tva_fr_valide(brut) if brut.startswith("FR") else True
        brutes.append(Trouvaille(m.start(), m.end(), "tva", m.group(), brut, 0.95 if valide else 0.6))

    for m in RE_PLAQUE.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "plaque", m.group(), re.sub(r"[- ]", "", m.group()),
                                 0.85 if m.group(1) else 0.55))

    for m in RE_PSEUDO.finditer(texte):
        if any(c.isalpha() for c in m.group()):
            brutes.append(Trouvaille(m.start(), m.end(), "pseudo", m.group(), m.group().lower(), 0.75))

    for m in RE_PIECE.finditer(texte):
        numero = m.group(1)
        if sum(c.isdigit() for c in numero) >= 5:
            brutes.append(Trouvaille(m.start(1), m.end(1), "piece_identite", numero, numero.upper(), 0.8))

    for motif in MOTIFS_REFERENCES:
        for m in motif.finditer(texte):
            if m.group():
                brutes.append(Trouvaille(m.start(), m.end(), "reference", m.group(), m.group().upper(), 0.9))

    for m in RE_DATE_EN.finditer(texte):
        avant = texte[max(0, m.start() - 40):m.start()]
        categorie = "date_naissance" if RE_NAISSANCE.search(avant) else "date"
        brutes.append(Trouvaille(m.start(), m.end(), categorie, m.group(), re.sub(r"\s+", " ", m.group().lower()),
                                 0.95 if categorie == "date_naissance" else 0.9))

    for m in RE_TEL_US.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "telephone", m.group(), "1" + _chiffres(m.group())[-10:], 0.85))
    for m in RE_TEL_UK.finditer(texte):
        chiffres = _chiffres(m.group())
        if len(chiffres) in (10, 11):
            brutes.append(Trouvaille(m.start(), m.end(), "telephone", m.group(), "44" + chiffres[1:], 0.8))

    for m in RE_ADRESSE_EN.finditer(texte):
        valeur = m.group().rstrip(" ,.")
        brutes.append(Trouvaille(m.start(), m.start() + len(valeur), "adresse", valeur,
                                 re.sub(r"\s+", " ", valeur.lower()), 0.85))
    for m in RE_CP_EN.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "adresse", m.group(), re.sub(r"\s+", " ", m.group().lower()), 0.7))

    for m in RE_NINO.finditer(texte):
        if re.sub(r"\s", "", m.group())[:2] not in NINO_PREFIXES_INVALIDES:
            brutes.append(Trouvaille(m.start(), m.end(), "id_national", m.group(), re.sub(r"\s", "", m.group()).upper(), 0.9))
    for m in RE_SSN.finditer(texte):
        brutes.append(Trouvaille(m.start(), m.end(), "id_national", m.group(), m.group(), 0.9))
    for m in RE_NHS.finditer(texte):
        if _nhs_valide(_chiffres(m.group())):
            brutes.append(Trouvaille(m.start(), m.end(), "id_national", m.group(), _chiffres(m.group()), 0.7))

    return sans_chevauchement(brutes)


def sans_chevauchement(trouvailles):
    """Garde, en cas de recouvrement, la catégorie prioritaire puis la plus longue."""
    rang = {c: i for i, c in enumerate(PRIORITE)}
    trouvailles.sort(key=lambda t: (rang[t.categorie], -(t.fin - t.debut), t.debut))
    gardees = []
    for t in trouvailles:
        if all(t.fin <= g.debut or t.debut >= g.fin for g in gardees):
            gardees.append(t)
    gardees.sort(key=lambda t: t.debut)
    return gardees
