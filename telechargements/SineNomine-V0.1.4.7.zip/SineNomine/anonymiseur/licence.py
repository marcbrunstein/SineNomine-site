"""Licence : activation par code (une seule fois, en ligne) puis vérification hors ligne d'un justificatif signé.

GÉNÉRATION 2 (codes latins « lumen-silva-k7q2m ») : le service fixe l'expiration d'une évaluation à la fin d'un mois calendaire (heure de Paris),
COMMUNE à toutes les installations du code ; le quota d'activations est cumulatif ; l'activation est idempotente (une même installation retrouve son
justificatif sans consommer d'activation). Le justificatif (v2) porte : licence, installation, type, dates, expiration, série majeure couverte.
Il est signé par le service (Ed25519), vérifié ici avec la seule clé publique, et conservé protégé par le compte Windows (DPAPI).
Les clés de la génération 1 (SN-XXXXX-…) restent reconnues.

Hors ligne : aucune vérification périodique, aucun envoi de données. Limites : sans connexion ultérieure, rien ne protège absolument contre la
falsification de l'horloge ou du programme ; un code désactivé côté service n'invalide pas les justificatifs déjà délivrés. Le coffre ne dépend
jamais de la disponibilité du service. Le code saisi n'est ni journalisé ni conservé.

La clé d'accès est validée une seule fois par le serveur d'activation de Habeas Corpus, qui renvoie une licence
signée (Ed25519) : identifiant d'installation, date d'activation, date de fin. L'application ne contient que la clé
publique ; elle vérifie la signature et la date sur l'ordinateur, sans aucune connexion. Seuls l'activation et la
vérification de clé (`--activer`, `--verifier-cle`, lancées par l'installateur) utilisent le réseau, et ne transmettent ni
document ni nom : la clé, un identifiant d'installation aléatoire, la version et la langue.

Ce mécanisme encadre l'évaluation ; il ne prétend pas résister à une personne qui modifierait le code (voir LICENCE.md).
"""

import base64
import json
import re
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from . import VERSION, config as cfg

CLE_PUBLIQUE = "14782b72bb67f0709afdda2f78e426e554cdd8db079e54d99e81dd7369238736"
SERVEUR_PAR_DEFAUT = "https://activation.sinenomine.app"
DEFAUT_LICENCE = cfg.donnees_utilisateur() / "licence.json"           # données de l'utilisateur, hors du dossier du programme
FICHIER_LICENCE = DEFAUT_LICENCE
FICHIER_INSTALLATION = cfg.donnees_utilisateur() / "installation.id"
FICHIER_ETAT = cfg.donnees_utilisateur() / "licence.etat"             # dernier instant vu : détecte une horloge remise en arrière
ANCIENS = {"licence": cfg.RACINE / "licence.json", "installation": cfg.RACINE / "installation.id"}      # emplacement des versions antérieures
PROTEGER = None                                                        # None : DPAPI si disponible et emplacement par défaut ; True / False : forcé
ALPHABET_CODE = "abcdefghjkmnpqrstuvwxyz23456789"
RE_CODE_LATIN = re.compile(r"^([a-z]{3,7})-([a-z]{3,7})-([a-hj-km-np-z2-9]{5})$")
SERIE_MAJEURE = int(str(VERSION).split(".")[0])
TOLERANCE_HORLOGE = timedelta(days=1)
FORMAT_DATE = "%Y-%m-%dT%H:%M:%SZ"


class LicenceErreur(Exception):
    """Message destiné à l'utilisateur (activation impossible : clé refusée, serveur injoignable…)."""


def _maintenant():
    return datetime.now(timezone.utc).replace(microsecond=0)


def _date(texte):
    return datetime.strptime(texte, FORMAT_DATE).replace(tzinfo=timezone.utc)


def _canonique(donnees):
    return json.dumps(donnees, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def signature_valide(licence, signature, publique_hex=None):
    try:
        brut = base64.urlsafe_b64decode(signature + "=" * (-len(signature) % 4))
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(publique_hex or CLE_PUBLIQUE)).verify(brut, _canonique(licence))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def identifiant_installation(creer=True):
    """Identifiant aléatoire de cette installation (sans lien avec le matériel, le nom ou les fichiers)."""
    candidats = [FICHIER_INSTALLATION] + ([ANCIENS["installation"]] if FICHIER_INSTALLATION == cfg.donnees_utilisateur() / "installation.id" else [])
    for fichier in candidats:
        try:
            valeur = fichier.read_text(encoding="ascii").strip()
            if str(uuid.UUID(valeur)) == valeur:
                if fichier != FICHIER_INSTALLATION:               # identifiant d'une version antérieure : il est conservé (même installation)
                    FICHIER_INSTALLATION.parent.mkdir(parents=True, exist_ok=True)
                    FICHIER_INSTALLATION.write_text(valeur + "\n", encoding="ascii")
                return valeur
        except (OSError, ValueError):
            continue
    if not creer:
        return None
    valeur = str(uuid.uuid4())
    FICHIER_INSTALLATION.parent.mkdir(parents=True, exist_ok=True)
    FICHIER_INSTALLATION.write_text(valeur + "\n", encoding="ascii")
    return valeur


def _protection_active():
    if PROTEGER is not None:
        return PROTEGER
    from .coffre import dpapi_disponible
    return dpapi_disponible() and FICHIER_LICENCE == DEFAUT_LICENCE


def _ecrire_licence(licence, signature):
    """Écrit le justificatif ; protégé par DPAPI (lisible seulement par ce compte Windows de cet ordinateur) quand c'est possible."""
    contenu = json.dumps({"licence": licence, "signature": signature}, indent=2)
    if _protection_active():
        from .coffre import _dpapi
        contenu = json.dumps({"protege": "dpapi", "donnees": base64.b64encode(_dpapi("proteger", contenu.encode("utf-8"))).decode("ascii")})
    FICHIER_LICENCE.parent.mkdir(parents=True, exist_ok=True)
    FICHIER_LICENCE.write_text(contenu, encoding="utf-8")


def _lire_licence():
    fichiers = [FICHIER_LICENCE] + ([ANCIENS["licence"]] if FICHIER_LICENCE == DEFAUT_LICENCE else [])
    for fichier in fichiers:
        try:
            donnees = json.loads(fichier.read_text(encoding="utf-8"))
            if donnees.get("protege") == "dpapi":
                from .coffre import _dpapi
                donnees = json.loads(_dpapi("deproteger", base64.b64decode(donnees["donnees"])).decode("utf-8"))
            return donnees["licence"], donnees["signature"]
        except Exception:  # noqa: BLE001 — fichier absent, illisible, d'un autre compte Windows : l'activation est à refaire
            continue
    return None, None


def _horloge_en_retard(maintenant):
    """Vrai si l'horloge est en retard de plus d'un jour sur le dernier instant vu ; sinon mémorise l'instant."""
    try:
        dernier = _date(json.loads(FICHIER_ETAT.read_text(encoding="utf-8"))["dernier"])
    except (OSError, ValueError, KeyError, TypeError):
        dernier = None
    if dernier is not None and maintenant < dernier - TOLERANCE_HORLOGE:
        return True
    if dernier is None or maintenant - dernier > timedelta(minutes=10):
        try:
            FICHIER_ETAT.write_text(json.dumps({"dernier": maintenant.strftime(FORMAT_DATE)}), encoding="utf-8")
        except OSError:
            pass
    return False


def etat(config=None, maintenant=None):
    """{statut, type, a_vie, expire_le, jours_restants, jours_depuis_expiration, active_le}.

    statut : active, expiree, absente, invalide, horloge, non_requise ; type : evaluation ou commerciale.
    """
    vide = {"type": None, "a_vie": False, "expire_le": None, "jours_restants": None, "jours_depuis_expiration": None,
            "active_le": None}
    if config is not None and config.get("licence_requise") is False:
        return {**vide, "statut": "non_requise"}
    maintenant = maintenant or _maintenant()
    licence, signature = _lire_licence()
    if licence is None:
        return {**vide, "statut": "absente"}
    try:
        if not signature_valide(licence, signature) or licence["install_id"] != identifiant_installation(creer=False):
            return {**vide, "statut": "invalide"}
        a_vie = licence.get("expire_le") is None
        fin = None if a_vie else _date(licence["expire_le"])
        debut = _date(licence["active_le"])
    except (KeyError, ValueError, TypeError):
        return {**vide, "statut": "invalide"}
    perpetuelle = licence.get("type") in ("perpetuelle", "commerciale")
    resultat = {**vide, "type": "commerciale" if perpetuelle else "evaluation", "a_vie": a_vie, "v": licence.get("v", 1),
                "expire_le": None if a_vie else licence["expire_le"][:10], "active_le": licence["active_le"][:10],
                "valide_jusqu_au": licence.get("dernier_jour"), "commune": licence.get("v") == 2,
                "serie_majeure": licence.get("serie_majeure")}
    if licence.get("v") == 2 and licence.get("serie_majeure") is not None and SERIE_MAJEURE > licence["serie_majeure"]:
        return {**resultat, "statut": "serie_non_couverte"}        # une licence ne donne pas accès automatiquement aux versions majeures futures
    if _horloge_en_retard(maintenant) or maintenant < debut - TOLERANCE_HORLOGE:
        return {**resultat, "statut": "horloge"}
    if a_vie:
        return {**resultat, "statut": "active"}
    if maintenant >= fin:
        return {**resultat, "statut": "expiree", "jours_restants": 0, "jours_depuis_expiration": (maintenant - fin).days}
    jours = max(-(-int((fin - maintenant).total_seconds()) // 86400), 1)          # arrondi au jour supérieur
    return {**resultat, "statut": "active", "jours_restants": jours}


def autorise(config=None):
    """Vrai si l'on peut anonymiser ou pseudonymiser des fichiers (licence active, ou non exigée)."""
    return etat(config)["statut"] in ("active", "non_requise")


# ---------------------------------------------------------------- réseau : uniquement pendant l'installation

def _appel(chemin, corps, serveur=None):
    adresse = (serveur or SERVEUR_PAR_DEFAUT).rstrip("/") + chemin
    requete = urllib.request.Request(adresse, data=json.dumps(corps).encode("utf-8"),
                                     headers={"Content-Type": "application/json", "User-Agent": f"SineNomine/{VERSION}"})
    try:
        with urllib.request.urlopen(requete, timeout=20) as reponse:
            return json.load(reponse)
    except urllib.error.HTTPError as e:       # le serveur répond par un message explicite (clé inconnue, épuisée…)
        try:
            donnees = json.load(e)
        except ValueError:
            donnees = {}
        raise LicenceErreur(donnees.get("message") or f"Le serveur d'activation a refusé la demande (code {e.code}).") from None
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise LicenceErreur("Connexion au serveur d'activation impossible : vérifiez votre connexion Internet, "
                            f"puis recommencez ({type(e).__name__}).") from None


def _controle(corps):
    return ALPHABET_CODE[sum((i + 1) * ALPHABET_CODE.index(c) for i, c in enumerate(corps)) % len(ALPHABET_CODE)]


def normaliser_code(saisie):
    """Code latin normalisé (minuscules), ou None si le format ou le caractère de contrôle est faux : la faute de frappe est détectée sans réseau."""
    texte = re.sub(r"\s+", "", str(saisie or "")).lower().replace("_", "-")
    m = RE_CODE_LATIN.match(texte)
    return texte if m and _controle(m.group(3)[:-1]) == m.group(3)[-1] else None


def generation(saisie):
    """2 pour un code latin (même mal saisi), 1 pour une clé SN-…, 0 si la saisie n'est ni l'un ni l'autre."""
    texte = re.sub(r"\s+", "", str(saisie or "")).lower().replace("_", "-")
    if RE_CODE_LATIN.match(texte) or re.fullmatch(r"[a-z]{3,7}-[a-z]{3,7}-?.*", texte):
        return 2
    return 1 if re.match(r"^sn[-a-z2-9]+$", texte) else 0


def verifier_cle(cle, langue="fr", serveur=None):
    """Interroge le serveur SANS consommer d'activation : quota, activations restantes, expiration (commune si déjà fixée, sinon prévue)."""
    if generation(cle) == 2:
        code = normaliser_code(cle)
        if code is None:
            raise LicenceErreur("Ce code ne semble pas correct (faute de frappe ?). Il ressemble à lumen-silva-k7q2m.")
        reponse = _appel("/api/v2/verifier", {"code": code, "install_id": identifiant_installation(), "langue": langue}, serveur)
        return {**reponse, "generation": 2, "message": _message_verification(reponse, langue)}
    return _appel("/api/v1/verifier", {"cle": cle, "langue": langue}, serveur)


def _message_verification(r, langue="fr"):
    jour = r.get("dernier_jour")
    date = f"{jour[8:10]}/{jour[5:7]}/{jour[:4]}" if jour else None
    if langue == "en":
        base = (f"This code ({'perpetual' if r['type'] == 'perpetuelle' else str(r['duree_mois']) + '-month evaluation'}) allows {r['quota']} activation(s) in total; "
                f"{r['restantes']} remaining.")
        fin = (f" Valid through {date} inclusive, the same date for every installation of this code." if date and r["type"] == "evaluation" else "")
        return base + fin + (" This installation is already activated." if r.get("deja_activee") else "")
    base = (f"Ce code ({'licence perpétuelle' if r['type'] == 'perpetuelle' else 'évaluation de ' + str(r['duree_mois']) + ' mois'}) autorise {r['quota']} activation(s) "
            f"au total ; il en reste {r['restantes']}.")
    fin = (f" Validité jusqu'au {date} inclus, date commune à toutes les installations de ce code"
           f"{'' if r.get('expiration_commune') else ' (fixée à la première activation)'}." if date and r["type"] == "evaluation" else "")
    return base + fin + (" Cette installation est déjà activée." if r.get("deja_activee") else "")


def activer(cle, langue="fr", serveur=None):
    """Active cette installation : écrit le justificatif signé et renvoie la réponse du serveur. Répéter l'appel (échec de transmission,
    réparation) est sans risque : la même installation retrouve son justificatif sans consommer d'activation."""
    identifiant = identifiant_installation()
    if generation(cle) == 2:
        code = normaliser_code(cle)
        if code is None:
            raise LicenceErreur("Ce code ne semble pas correct (faute de frappe ?). Il ressemble à lumen-silva-k7q2m.")
        reponse = _appel("/api/v2/activer", {"code": code, "install_id": identifiant, "version": VERSION, "langue": langue}, serveur)
        licence, signature = reponse.get("licence"), reponse.get("signature", "")
        if not licence or licence.get("v") != 2 or not signature_valide(licence, signature) or licence.get("install_id") != identifiant:
            raise LicenceErreur("La réponse du serveur d'activation n'est pas authentique : licence refusée.")
        reponse["message"] = _message_activation(licence, reponse, langue)
    else:
        reponse = _appel("/api/v1/activer", {"cle": cle, "install_id": identifiant, "version": VERSION, "langue": langue}, serveur)
        licence, signature = reponse.get("licence"), reponse.get("signature", "")
        if not licence or not signature_valide(licence, signature) or licence.get("install_id") != identifiant:
            raise LicenceErreur("La réponse du serveur d'activation n'est pas authentique : licence refusée.")
    _ecrire_licence(licence, signature)
    FICHIER_ETAT.parent.mkdir(parents=True, exist_ok=True)
    FICHIER_ETAT.write_text(json.dumps({"dernier": _maintenant().strftime(FORMAT_DATE)}), encoding="utf-8")
    return reponse


def _message_activation(licence, reponse, langue="fr"):
    jour = licence.get("dernier_jour")
    date = f"{jour[8:10]}/{jour[5:7]}/{jour[:4]}" if jour else None
    if langue == "en":
        return ("Sine Nomine is activated (" + ("perpetual licence" if licence["type"] == "perpetuelle" else f"evaluation, valid through {date} inclusive") +
                f"). This code has {reponse['restantes']} activation(s) left out of {reponse['quota']}.")
    return ("Sine Nomine est activé (" + ("licence perpétuelle" if licence["type"] == "perpetuelle" else f"évaluation, valable jusqu'au {date} inclus") +
            f"). Ce code a encore {reponse['restantes']} activation(s) sur {reponse['quota']}.")
