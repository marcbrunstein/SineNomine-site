"""Profils de paramètres : des jeux de réglages d'utilisation enregistrés.

20 profils au plus AU TOTAL : 3 profils STANDARDS (en lecture seule, définis ci-dessous) et jusqu'à 17 profils PERSONNELS.

Un profil mémorise : les actions par catégorie d'information sensible (dont les règles sur dates, montants et adresses), les images, la
politique des contenus non analysables, le format de sortie, le type de périmètre de stabilité et la présélection des lieux.
Un profil NE CONTIENT JAMAIS : de noms réels, de correspondances, de passages confidentiels, de listes propres à un dossier ni le choix
silencieux d'un client ou d'un projet précis (le périmètre n'est mémorisé que par son TYPE).

Un profil métier n'est pas une garantie de conformité : les profils standards sont des points de départ rédigés par l'éditeur, à relire
et à adapter à chaque dossier (documentation : docs/PROFILS.md).
"""

import json
import os
import re
import secrets
import tempfile
from pathlib import Path

from . import config as cfg, inventaire, sensibles

MAX_PROFILS = 20
NB_STANDARDS = 3
MAX_PERSONNELS = MAX_PROFILS - NB_STANDARDS
FORMATS_SORTIE = ("origine", "pdf", "les_deux")
PORTEES = ("document", "projet", "client")
ACTIONS = ("conserver", "pseudonymiser", "supprimer", "annee")
CLES_REGLAGES = ("actions", "images", "politique", "format_sortie", "portee", "lieux_preselectionnes")


class ProfilErreur(ValueError):
    """Profil refusé (le message est affiché tel quel)."""


def _actions(**exceptions):
    base = {c: "pseudonymiser" for c in sensibles.CATEGORIES}
    base.update(exceptions)
    return base


STANDARDS = [
    {"id": "standard:ia", "nom": "Préparation pour une IA", "standard": True,
     "description": "Retire un maximum d'informations identifiantes avant de confier un texte à un outil d'IA : tout est pseudonymisé, les dates sont ramenées à l'année, les images sont supprimées, les contenus non analysables bloquent la publication.",
     "reglages": {"actions": _actions(date="annee", date_naissance="annee", montant="conserver", reference="conserver"),
                  "images": "supprimer", "politique": "renforcee", "format_sortie": "origine", "portee": "projet",
                  "lieux_preselectionnes": True}},
    {"id": "standard:juridique", "nom": "Juridique", "standard": True,
     "description": "Pour des pièces et des conclusions : les identifiants (coordonnées, comptes, numéros) sont pseudonymisés ; les dates, les montants et les références de dossier sont conservés car ils portent le raisonnement ; les images sont conservées avec signalement.",
     "reglages": {"actions": _actions(date="conserver", montant="conserver", reference="conserver", date_naissance="annee", url="pseudonymiser"),
                  "images": "conserver", "politique": "preservation", "format_sortie": "origine", "portee": "projet",
                  "lieux_preselectionnes": False}},
    {"id": "standard:recrutement", "nom": "Recrutement", "standard": True,
     "description": "Pour des CV et des fiches de candidats : coordonnées, adresses, comptes en ligne et pièces d'identité pseudonymisés, dates ramenées à l'année, photos et images supprimées ; chaque candidat a ses propres pseudonymes (périmètre Document).",
     "reglages": {"actions": _actions(date="annee", date_naissance="annee", montant="conserver", reference="conserver"),
                  "images": "supprimer", "politique": "renforcee", "format_sortie": "origine", "portee": "document",
                  "lieux_preselectionnes": True}},
]


def _fichier():
    return cfg.donnees_utilisateur() / "profils.json"


def valider_reglages(reglages):
    """Réglages nettoyés et validés (clés inconnues ignorées : un profil ne contient que ce qui est listé ci-dessus)."""
    if not isinstance(reglages, dict):
        raise ProfilErreur("Réglages invalides.")
    actions = reglages.get("actions", {})
    if not isinstance(actions, dict):
        raise ProfilErreur("Actions invalides.")
    propres = {}
    for categorie, action in actions.items():
        if categorie not in sensibles.CATEGORIES or action not in ACTIONS or (action == "annee" and categorie not in ("date", "date_naissance")):
            raise ProfilErreur(f"Action invalide pour « {categorie} ».")
        propres[categorie] = action
    resultat = {"actions": {c: propres.get(c, "conserver") for c in sensibles.CATEGORIES}}
    images = reglages.get("images", "conserver")
    politique = reglages.get("politique", "preservation")
    format_sortie = reglages.get("format_sortie", "origine")
    portee = reglages.get("portee", "projet")
    if images not in ("conserver", "supprimer") or politique not in inventaire.POLITIQUES \
            or format_sortie not in FORMATS_SORTIE or portee not in PORTEES:
        raise ProfilErreur("Réglages invalides (images, politique, format de sortie ou périmètre).")
    resultat.update({"images": images, "politique": politique, "format_sortie": format_sortie, "portee": portee,
                     "lieux_preselectionnes": bool(reglages.get("lieux_preselectionnes", False))})
    return resultat


def _nom_valide(nom, ignorer=None):
    nom = re.sub(r"\s+", " ", (nom or "")).strip()
    if not 1 <= len(nom) <= 60:
        raise ProfilErreur("Le nom du profil doit comporter de 1 à 60 caractères.")
    if any(p["nom"].lower() == nom.lower() and p["id"] != ignorer for p in lister()):
        raise ProfilErreur("Un profil porte déjà ce nom.")
    return nom


def _personnels():
    chemin = _fichier()
    if not chemin.exists():
        return []
    try:
        donnees = json.loads(chemin.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    profils = []
    for p in donnees.get("profils", []) if isinstance(donnees, dict) else []:
        try:
            profils.append({"id": p["id"], "nom": p["nom"], "standard": False, "description": "", "reglages": valider_reglages(p["reglages"])})
        except (KeyError, ProfilErreur, TypeError):
            continue                       # un profil abîmé est ignoré, les autres restent utilisables
    return profils


def _ecrire(profils):
    chemin = _fichier()
    chemin.parent.mkdir(parents=True, exist_ok=True)
    contenu = json.dumps({"version": 1, "profils": [{"id": p["id"], "nom": p["nom"], "reglages": p["reglages"]} for p in profils]},
                         ensure_ascii=False, indent=2)
    fd, temporaire = tempfile.mkstemp(dir=chemin.parent, prefix="profils-", suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(contenu)
    os.replace(temporaire, chemin)


def lister():
    return [*[json.loads(json.dumps(p)) for p in STANDARDS], *_personnels()]


def obtenir(identifiant):
    return next((p for p in lister() if p["id"] == identifiant), None)


def creer(nom, reglages):
    """Enregistre un NOUVEAU profil personnel (« enregistrer sous »). Le nombre total est plafonné."""
    personnels = _personnels()
    if len(personnels) >= MAX_PERSONNELS:
        raise ProfilErreur(f"Limite atteinte : {MAX_PROFILS} profils au total ({NB_STANDARDS} standards et {MAX_PERSONNELS} personnels). Supprimez un profil personnel.")
    profil = {"id": "perso:" + secrets.token_hex(4), "nom": _nom_valide(nom), "standard": False, "description": "",
              "reglages": valider_reglages(reglages)}
    _ecrire([*personnels, profil])
    return profil


def modifier(identifiant, nom=None, reglages=None):
    """Renomme et/ou enregistre de nouveaux réglages. Les profils standards ne sont jamais modifiés."""
    if identifiant.startswith("standard:"):
        raise ProfilErreur("Les profils standards ne sont pas modifiables : enregistrez-les sous un nouveau nom.")
    personnels = _personnels()
    profil = next((p for p in personnels if p["id"] == identifiant), None)
    if profil is None:
        raise ProfilErreur("Profil inconnu.")
    if nom is not None:
        profil["nom"] = _nom_valide(nom, ignorer=identifiant)
    if reglages is not None:
        profil["reglages"] = valider_reglages(reglages)
    _ecrire(personnels)
    return profil


def supprimer(identifiant):
    if identifiant.startswith("standard:"):
        raise ProfilErreur("Les profils standards ne peuvent pas être supprimés.")
    personnels = _personnels()
    restants = [p for p in personnels if p["id"] != identifiant]
    if len(restants) == len(personnels):
        raise ProfilErreur("Profil inconnu.")
    _ecrire(restants)
