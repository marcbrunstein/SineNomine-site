"""Calcul des remplacements à appliquer à un texte (entités validées et informations sensibles)."""

import hashlib
import re
from collections import Counter, defaultdict
from dataclasses import dataclass

from . import sensibles
from .archive import Archive
from .entites import formes_de_casse
from .graphies import graphies_etrangeres, plier

SUPPRIME = "[supprimé]"
RE_ANNEE = re.compile(r"(?<!\d)(1[89]\d\d|20\d\d)(?!\d)")
CATEGORIES_DATES = ("date", "date_naissance")
PASSAGE_SUPPRIME = "[passage supprimé]"       # masquage manuel sans conservation des correspondances

# Un nom ne doit pas être collé à une lettre ou un chiffre ; un tiret bas, en revanche, sert de séparateur.
LIMITE_AVANT = r"(?<![^\W_])"
LIMITE_APRES = r"(?![^\W_])"
ESPACE_ECHAPPE = re.escape(" ")        # un espace du nom cherché accepte plusieurs espaces dans le texte


@dataclass
class Remplacement:
    debut: int
    fin: int
    texte: str
    nature: str      # "entite" ou "sensible"
    reference: object  # id d'entité, ou (catégorie, clé)


class Correspondances:
    """Recherche les variantes des entités et les informations sensibles, puis décide du remplacement.

    Les informations sensibles pseudonymisées reçoivent un code aléatoire ([Email_ZTRPA]…),
    repris de l'archive s'il existe déjà : la même valeur garde le même code partout.
    """

    def __init__(self, entites, libelles, actions, exclusions, archive=None, numerote=False, graphies=True,
                 passages=(), gardees=None):
        """`passages` : [{"texte": texte exact, "cles": clés de contexte des occurrences à masquer}] (masquage manuel).
        `gardees` : {id d'entité: ensemble de clés de contexte} des occurrences que l'utilisateur veut CONSERVER."""
        self.archive = archive if archive is not None else Archive()
        self.passages = [p for p in passages if p.get("texte") and p.get("cles")]
        self.gardees = {k: set(v) for k, v in (gardees or {}).items() if v}
        self.numerote = numerote                  # anonymisation : [Email_1], [Email_2]… sans archive
        self.libelles = libelles                  # id d'entité -> « Personne_KQXMB »
        self.actions = actions                    # catégorie sensible -> conserver / pseudonymiser / supprimer
        self.exclusions = set(exclusions)         # {(catégorie, clé)} à conserver malgré l'action
        self.sensibles_libelles = {}              # (catégorie, clé) -> « [Email 1] »
        self.sensibles_valeurs = defaultdict(set)  # (catégorie, clé) -> valeurs d'origine rencontrées
        self._compteurs = Counter()

        # La recherche se fait sur le texte « plié » (sans accents, séparateurs uniformes) : « Inès Marchand » retrouve
        # « Ines Marchand », « Ines_Marchand » (nom de fichier) et « INÈS MARCHAND » ; « Lin-an » retrouve « Lin_an ».
        # Avec `graphies`, « Kärscher » et « Kaerscher » sont aussi tenus pour équivalents.
        self.forme_vers_id = {}
        for e in sorted(entites, key=lambda e: e.id):
            if e.id not in libelles:
                continue
            for v in e.variantes:
                v = v.strip()
                for ecriture in {v, *(graphies_etrangeres(v) if graphies else ())}:
                    for forme in formes_de_casse(ecriture):
                        f = plier(forme)
                        if len(f) >= 2:
                            self.forme_vers_id.setdefault(f, e.id)
        textes = sorted({p["texte"] for p in self.passages}, key=len, reverse=True)
        self.motif_passages = re.compile("|".join(re.escape(t) for t in textes)) if textes else None   # exact : casse et accents
        self.cles_passages = {p["texte"]: set(p["cles"]) for p in self.passages}
        formes = sorted(self.forme_vers_id, key=len, reverse=True)
        self.motif = (re.compile(LIMITE_AVANT + "(?:" + "|".join(re.escape(f).replace(ESPACE_ECHAPPE, " +") for f in formes) + ")" + LIMITE_APRES)
                      if formes else None)

    def libelle_sensible(self, categorie, cle):
        reference = (categorie, cle)
        if reference not in self.sensibles_libelles:
            if self.numerote:
                self._compteurs[categorie] += 1
                etiquette = sensibles.ETIQUETTES[categorie].replace(" ", "_")
                self.sensibles_libelles[reference] = f"[{etiquette}_{self._compteurs[categorie]}]"
            else:
                self.sensibles_libelles[reference] = self.archive.code_sensible(categorie, cle)
        return self.sensibles_libelles[reference]

    def libelle_passage(self, texte):
        """[Passage_KQXMB] en pseudonymisation (texte exact conservé dans le coffre) ; [passage supprimé] sinon."""
        if self.numerote:
            return PASSAGE_SUPPRIME
        libelle = self.libelle_sensible("passage", texte)
        self.sensibles_valeurs[("passage", texte)].add(texte)
        return libelle

    def _generaliser_date(self, t, annee):
        """Généralisation d'une date à son année. Pseudonymisation : « 2026 [Date_KQXMB] », le code étant propre au TEXTE EXACT de la
        date (présentation comprise), restitué tel quel. Sans conservation : l'année seule, aucune restauration."""
        if self.numerote:
            return Remplacement(t.debut, t.fin, annee, "sensible", (t.categorie, "annee:" + annee))
        cle = "=" + t.valeur                                   # clé exacte : deux présentations d'une date = deux codes
        self.sensibles_valeurs[(t.categorie, cle)].add(t.valeur)
        return Remplacement(t.debut, t.fin, f"{annee} {self.libelle_sensible(t.categorie, cle)}", "sensible", (t.categorie, cle))

    def passages_dans(self, texte):
        """(début, fin, texte) des passages à masquer : seules les occurrences choisies (même contexte) sont retenues."""
        if self.motif_passages is None:
            return
        for m in self.motif_passages.finditer(texte):
            if cle_contexte(texte, m.start(), m.end()) in self.cles_passages.get(m.group(), ()):
                yield m.start(), m.end(), m.group()

    def occurrences(self, texte):
        """(début, fin, id d'entité) de chaque nom trouvé, positions rapportées au texte d'origine."""
        if self.motif is None:
            return
        for m in self.motif.finditer(plier(texte)):
            yield m.start(), m.end(), self.forme_vers_id[re.sub(" +", " ", m.group())]   # plusieurs espaces = un séparateur

    def analyser(self, texte):
        """(remplacements à faire, informations sensibles conservées), sans chevauchement."""
        remplacements, conservees = [], []
        # Les passages masqués à la main ont la priorité : ils recouvrent tout ce qui s'y trouve.
        for debut, fin, passage in self.passages_dans(texte):
            if not any(debut < r.fin and fin > r.debut for r in remplacements):
                remplacements.append(Remplacement(debut, fin, self.libelle_passage(passage), "passage", ("passage", passage)))
        for t in sensibles.detecter(texte):
            if any(t.debut < r.fin and t.fin > r.debut for r in remplacements):
                continue
            action = self.actions.get(t.categorie, "conserver")
            if action == "conserver" or (t.categorie, t.cle) in self.exclusions:
                conservees.append(t)
                continue
            if action == "annee" and t.categorie in CATEGORIES_DATES:
                annee = RE_ANNEE.search(t.valeur)
                if annee:
                    remplacements.append(self._generaliser_date(t, annee.group(1)))
                    continue
                action = "pseudonymiser"        # pas d'année lisible : jamais d'année devinée, la date est pseudonymisée
            elif action == "annee":
                action = "pseudonymiser"
            self.sensibles_valeurs[(t.categorie, t.cle)].add(t.valeur)
            nouveau = SUPPRIME if action == "supprimer" else self.libelle_sensible(t.categorie, t.cle)
            remplacements.append(Remplacement(t.debut, t.fin, nouveau, "sensible", (t.categorie, t.cle)))

        for debut, fin, id_entite in self.occurrences(texte):
            if any(debut < r.fin and fin > r.debut for r in remplacements):
                continue
            if id_entite in self.gardees and cle_contexte(texte, debut, fin) in self.gardees[id_entite]:
                continue                  # occurrence que l'utilisateur a choisi de conserver
            remplacements.append(Remplacement(debut, fin, self.libelles[id_entite], "entite", id_entite))

        remplacements.sort(key=lambda r: r.debut)
        conservees = [t for t in conservees if not any(t.debut < r.fin and t.fin > r.debut for r in remplacements)]
        return remplacements, conservees

    def remplacer(self, texte):
        """Texte remplacé, remplacements faits, et informations conservées repositionnées dans le nouveau texte."""
        remplacements, conservees = self.analyser(texte)
        morceaux, position, decalages = [], 0, []
        for r in remplacements:
            morceaux.append(texte[position:r.debut])
            morceaux.append(r.texte)
            decalages.append((r.fin, len(r.texte) - (r.fin - r.debut)))
            position = r.fin
        morceaux.append(texte[position:])
        nouveau = "".join(morceaux)
        repositionnees = []
        for t in conservees:
            decalage = sum(d for fin, d in decalages if fin <= t.debut)
            repositionnees.append((t, t.debut + decalage, t.fin + decalage))
        return nouveau, remplacements, repositionnees


def cle_contexte(texte, debut, fin, mots=4):
    """Clé opaque d'une occurrence : le passage et `mots` mots avant et après, dans la même ligne (insensible aux accents et à
    la casse). Elle est calculée de la même façon à la lecture (texte entier) et à l'écriture (un paragraphe à la fois) : c'est
    ce qui permet de retrouver, dans le fichier, l'occurrence que l'utilisateur a désignée. Deux occurrences au contexte
    identique ont la même clé et sont traitées ensemble."""
    debut_ligne = texte.rfind("\n", 0, debut) + 1
    fin_ligne = texte.find("\n", fin)
    fin_ligne = len(texte) if fin_ligne < 0 else fin_ligne
    avant = texte[debut_ligne:debut].split()[-mots:]
    apres = texte[fin:fin_ligne].split()[:mots]
    brut = " ".join(avant) + "\u27e6" + texte[debut:fin] + "\u27e7" + " ".join(apres)
    return hashlib.sha256(plier(brut).lower().encode("utf-8")).hexdigest()[:20]


def contexte_mots(texte, debut, fin, mots=15):
    """Extrait en texte brut : `mots` mots avant et après l'occurrence, qui est entourée de ⟦ ⟧."""
    mots_avant = list(re.finditer(r"\S+", texte[:debut]))
    mots_apres = list(re.finditer(r"\S+", texte[fin:]))
    # Les mots collés à l'occurrence (« l'⟦Acme⟧ », « ⟦Acme⟧, ») restent collés : on coupe sur les positions d'origine.
    depart = mots_avant[-mots].start() if mots and len(mots_avant) > mots else 0
    arrivee = fin + mots_apres[mots - 1].end() if mots and len(mots_apres) >= mots else len(texte)
    if not mots:
        depart, arrivee = debut, fin
    coupe_avant = depart > 0 and bool(texte[:depart].strip())
    coupe_apres = arrivee < len(texte) and bool(texte[arrivee:].strip())
    extrait = f"{texte[depart:debut]}⟦{texte[debut:fin]}⟧{texte[fin:arrivee]}"
    return re.sub(r"\s+", " ", ("… " if coupe_avant else "") + extrait.strip() + (" …" if coupe_apres else "")).strip()


def contexte(texte, debut, fin, largeur=60):
    avant = texte[max(0, debut - largeur):debut]
    apres = texte[fin:fin + largeur]
    prefixe = "…" if debut > largeur else ""
    suffixe = "…" if fin + largeur < len(texte) else ""
    return re.sub(r"\s+", " ", f"{prefixe}{avant}⟦{texte[debut:fin]}⟧{apres}{suffixe}").strip()
