"""Désanonymisation : remet les valeurs d'origine à la place des codes (Personne_KQXMB, [Email_ZTRPA]…).

Fonctionne sur tout fichier produit par Sine Nomine, quel que soit le lot, grâce à l'archive des codes.
Les fichiers de départ ne sont jamais modifiés ; les fichiers restaurés vont dans un dossier daté.
"""

from datetime import datetime
from collections import Counter
from pathlib import Path

from . import config as cfg, formats
from .archive import NOM_FICHIER, Archive, Restaurateur
from .lots import Lot
from .rapport import Journal


def charger_archive(config, perimetre=None):
    return Archive.ouvrir(config, perimetre)


PREFIXE_CONFIDENTIEL = "restauration_CONFIDENTIEL"      # le dossier contient des noms en clair : son nom le dit


def resumer(archive, fichiers):
    """Ce que la dé-pseudonymisation réintroduirait, sans rien écrire : {fichiers: [{source, codes, categories, inconnus}], total,
    categories, inconnus}. Une catégorie est celle des données d'origine remises à la place des codes."""
    from .archive import RE_CODE
    from .formats import lire_texte
    total, inconnus = Counter(), set()
    par_fichier = []
    for chemin, relatif in fichiers:
        textes = [relatif]
        erreur = None
        try:
            textes.append(lire_texte(chemin))
        except Exception as e:  # noqa: BLE001 — signalé, les autres fichiers continuent
            erreur = f"{type(e).__name__} : {e}"
        categories, inconnus_f, codes = Counter(), set(), 0
        for texte in textes:
            for m in RE_CODE.finditer(texte):
                code = m.group()
                fiche = archive.entites.get(code) or archive.sensibles.get(code)
                if fiche is None or archive.valeur_d_origine(code) is None:
                    inconnus_f.add(code)
                else:
                    categories[fiche["categorie"]] += 1
                    codes += 1
        total.update(categories)
        inconnus |= inconnus_f
        par_fichier.append({"source": relatif, "codes": codes, "categories": dict(categories), "inconnus": sorted(inconnus_f),
                            "erreur": erreur})
    return {"fichiers": par_fichier, "categories": dict(total), "inconnus": sorted(inconnus)}


def nouveau_dossier(config, prefixe="restauration"):
    """Dossier de sortie daté, dans le dossier de sortie configuré (jamais écrasé)."""
    base = cfg.dossier(config, "sortie")
    identifiant = f"{prefixe}_" + datetime.now().strftime("%Y-%m-%d_%H%M%S")
    while (base / identifiant).exists():
        identifiant += "b"
    dossier = base / identifiant
    dossier.mkdir(parents=True)
    return identifiant, dossier


def restaurer(archive, fichiers, dossier_sortie):
    """Restaure chaque fichier ; renvoie un résultat par fichier.

    fichiers : [(chemin source, chemin relatif)]. Un code absent de l'archive reste tel quel et est signalé.
    """
    restaurateur = Restaurateur(archive)
    utilises, resultats = set(), []
    for chemin, relatif in fichiers:
        avant = dict(restaurateur.inconnus)
        journal = Journal()
        sortie_relative = Lot._nom_sortie(relatif, restaurateur, utilises)
        resultat = {"source": relatif, "sortie": sortie_relative, "remplacements": 0, "inconnus": [], "erreur": None}
        try:
            formats.ecrire_anonymise(chemin, Path(dossier_sortie) / sortie_relative, restaurateur, journal,
                                     restaurer=True)
            resultat["remplacements"] = sum(journal.entites.values())
            resultat["inconnus"] = sorted(c for c, n in restaurateur.inconnus.items() if n > avant.get(c, 0))
        except Exception as e:  # noqa: BLE001 — affiché dans l'interface, les autres fichiers continuent
            resultat["erreur"] = f"{type(e).__name__} : {e}"
        resultats.append(resultat)
    return resultats
