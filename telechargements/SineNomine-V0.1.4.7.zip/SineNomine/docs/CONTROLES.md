# Résultats provisoires, contrôles, comparaison et restauration (étape 5)

Ce document décrit ce que fait Sine Nomine depuis la V0.1.4.5, et ses limites. Il ne promet ni certification ni garantie d'anonymat.

## 1. Un export en deux temps

Après la validation, l'interface génère des **résultats provisoires** : les fichiers sont écrits dans un dossier provisoire voisin de la destination,
**rien n'est publié et aucune correspondance n'est enregistrée** (les codes sont seulement réservés). L'utilisateur peut alors :

- lire les **contrôles automatiques** ;
- **comparer** avant / après (facultatif) ;
- **revenir aux décisions** (le provisoire est supprimé, tous les choix sont conservés ; toute modification invalide les contrôles : on régénère) ;
- **abandonner** (rien n'est publié ni conservé ; en mode sans conservation, ce que le lot contenait est oublié) ;
- **finaliser et exporter** : enregistrement des correspondances dans le coffre, rapport, publication récupérable (voir COFFRE.md).

Le provisoire est un lot « en cours » du coffre : si l'application s'arrête, il est nettoyé au démarrage suivant (publication.recuperer).
La finalisation est **refusée** tant qu'un terme imposé subsiste dans un fichier produit.

## 2. Contrôles de cohérence

Effectués sur les fichiers provisoires relus tels qu'ils seront livrés :

| Contrôle | Ce qui est signalé |
|---|---|
| Nom connu resté en clair | une variante d'une entité retenue figure encore dans un fichier produit, au-delà des occurrences que l'utilisateur a choisi de conserver |
| Même nom sous plusieurs codes | dans **un même périmètre**, une même variante rattachée à deux codes (archive comprise) |
| Fusion incohérente | un même code regroupant des variantes incompatibles (par exemple deux familles de noms), y compris avec ce que l'archive a déjà conservé |
| Code inconnu | un code de pseudonyme présent dans le résultat mais inconnu du périmètre (il figurait déjà dans le document d'origine) |
| Code abîmé | un texte ressemblant à un code tronqué ou altéré (information : peut être un faux positif) |

Des codes **différents d'un périmètre à l'autre ne sont jamais signalés**. Chaque anomalie indique le fichier, le contexte et l'action possible.
**Limites** : ces contrôles cherchent des incohérences connues ; ils ne garantissent pas l'absence de toute donnée personnelle (texte dans des images,
formulations indirectes, informations déduites). Ils ne s'appliquent aux codes qu'en pseudonymisation.

## 3. Comparaison avant / après

Original à gauche, résultat à droite, lignes synchronisées, écarts mot à mot surlignés (substitutions et masquages), navigation « modification
précédente / suivante » et pages de 300 lignes. **C'est une comparaison de texte** : elle ne vérifie pas la mise en page, les images ni les mises en forme.
Elle n'est possible que sur des résultats provisoires, avant l'export définitif. L'aperçu d'un PDF final n'existe pas encore : les PDF d'entrée
produisent des fichiers Word, PowerPoint, Markdown, texte, HTML ou Excel (l'export PDF fait partie de l'étape 6).

## 4. Restauration

Avant d'écrire, l'écran résume : les fichiers, le **périmètre** (reconnu d'après les codes, ou choisi ; en cas d'ambiguïté l'utilisateur doit choisir),
le nombre de codes à remplacer par **catégorie de données réintroduites**, et les **codes inconnus** (laissés tels quels et signalés). L'écriture se fait
ensuite après confirmation, dans un dossier distinct dont le nom contient **CONFIDENTIEL** (`restauration_CONFIDENTIEL_<date>`) ; les fichiers déposés ne sont jamais modifiés.
La dé-pseudonymisation **n'est pas soumise à la licence** : l'expiration d'une licence d'évaluation ne rend pas les traitements déjà réalisés irrécupérables.

**Limites** : la restitution est celle du texte exact ; la mise en forme du fichier pseudonymisé est conservée, pas celle de l'original. Les dates et
passages masqués sont restitués selon leur texte exact (la généralisation des dates, étape 6, n'est pas encore implémentée).
