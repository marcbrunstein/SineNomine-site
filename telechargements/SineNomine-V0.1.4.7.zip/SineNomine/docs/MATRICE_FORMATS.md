# Matrice des contenus par format, politiques et limites (étape 6)

Cette matrice est **vérifiée** par `tests/test_formats_matrice.py` (fichiers synthétiques) pour les éléments marqués ✔. Légende :
**oui** = analysé et remplacé ; **partiel** ; **non** = conservé tel quel, non analysé ; « supprimable » = retiré par la confidentialité renforcée.

| Élément | Word (.docx) | PowerPoint (.pptx) | Excel (.xlsx) | Texte, Markdown, CSV, HTML | PDF (entrée) |
|---|---|---|---|---|---|
| Texte principal, en-têtes, pieds, notes, zones de texte | oui ✔ | oui | oui ✔ (cellules, textes en ligne ou partagés) | oui | texte extrait (OCR si page scannée : partiel) |
| Révisions (suivi des modifications), commentaires | oui | oui | oui (commentaires) | n/a | n/a |
| Auteurs des révisions et commentaires | masqués | masqués | masqués | n/a | métadonnées non copiées |
| Propriétés du document (titre, sujet, société, auteur) | oui ✔ | oui | oui | n/a | non copiées |
| Miniature d'aperçu | supprimée | supprimée | supprimée | n/a | n/a |
| Images | non, **supprimable** ✔ | non, supprimable | non, supprimable | non (références), supprimable | non (non reprises) |
| Objets incorporés (OLE) | non, **bloque** en renforcée ✔ | non, bloque | non, bloque | n/a | n/a |
| Parties XML personnalisées | non, **supprimable** ✔ | non, supprimable | non, supprimable | n/a | n/a |
| Graphiques (titres, valeurs en cache) | partiel | partiel | partiel | n/a | n/a |
| Liaisons externes (classeurs) | partiel | n/a | partiel | n/a | n/a |
| Noms des feuilles | n/a | n/a | **non** ✔, bloque en renforcée sauf noms génériques (Feuil1…) | n/a | n/a |
| Formules (texte littéral) | n/a | n/a | **non** ✔, bloque en renforcée | n/a | n/a |
| Tableaux croisés dynamiques, caches | n/a | n/a | non, bloque | n/a | n/a |
| Mise en page, tableaux | conservée | conservée | conservée | conservée | **non reprise** (extraction) |

## Politiques (choix du lot, mémorisé par les profils)
- **Préservation** (défaut) : les éléments non traités sont conservés ; leurs limites sont listées avant confirmation et dans le rapport.
- **Confidentialité renforcée** : images et parties XML personnalisées supprimées ; tout autre élément **non traité et non supprimable** présent
  **bloque la publication** (explication par fichier). Une image n'est jamais déclarée anonymisée : sans analyse, elle est conservée (avec signalement) ou supprimée.

## Rapport partageable
Minimal : pas de noms, **pas de miniatures d'images** (jamais intégrées automatiquement), mention explicite qu'il ne garantit pas l'absence d'informations
identifiantes. Les informations de travail confidentielles restent dans le coffre ou dans l'export explicite des correspondances.

## Limites de résistance aux fichiers malformés (`anonymiseur/limites.py`, réglables dans `config.json`)
| Limite | Valeur par défaut |
|---|---|
| taille d'un fichier | 200 Mo |
| fichiers par lot | 2 000 |
| éléments d'une archive Office | 5 000 |
| taille décompressée d'un fichier Office | 1 Go |
| taux de compression d'un élément (au-delà de 1 Mo décompressé) | 200 |
| taille d'une partie XML | 100 Mo |
| pages d'un PDF | 2 000 |
| pixels d'une image (miniature) | 100 millions |
| durée d'une conversion PDF | 300 s |
| termes imposés | 5 000 lignes, 200 caractères |

- **XML durci** : DTD et entités refusées (entités externes, « milliard de rires »), réseau interdit, très grands arbres interdits.
- Un fichier refusé ou illisible **n'arrête pas le lot** : il est signalé comme non lu, et rien n'est présenté comme vérifié à son sujet.
- Les recherches sont construites à partir de formes **littérales échappées** : aucune expression régulière fournie par l'utilisateur, donc pas d'expression « catastrophique ».
- Les modèles ne chargent aucun code distant.
- **Limites actuelles** : l'analyse d'un fichier n'a pas de délai d'expiration dur (la durée n'est limitée que pour la conversion PDF, interrompue et nettoyée) ;
  pas d'isolation en processus séparé des opérations lourdes ; l'annulation en cours d'analyse n'est pas encore proposée.
