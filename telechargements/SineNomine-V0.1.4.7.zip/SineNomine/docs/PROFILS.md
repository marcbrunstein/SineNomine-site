# Profils de paramètres, format de sortie, langues, dates (étape 6)

Ce document décrit ce que fait Sine Nomine depuis la V0.1.4.6, et ses limites. Il ne promet ni certification, ni conformité, ni garantie d'anonymat.

## 1. Profils

Un profil est un jeu de réglages d'utilisation enregistré. **20 profils au plus au total** : 3 standards (lecture seule) et 17 personnels.
Il mémorise : les actions par catégorie d'information sensible (dont les règles sur dates, montants et adresses), les images, la politique des
contenus non analysables, le format de sortie, le **type** de périmètre de stabilité et la présélection des lieux.
Il **ne contient jamais** : noms réels, correspondances, passages confidentiels, listes propres à un dossier, ni le choix d'un client ou d'un
projet précis. Il est stocké dans `profils.json` (dossier des données de l'utilisateur), sans donnée de dossier.

Utilisation : choisir le profil avant le lancement (le profil, ses principaux réglages et le format sont affichés) ; à la validation, modifier les
réglages **pour ce lot seulement** ; au choix : « Rétablir les réglages du profil », « Enregistrer dans ce profil » (profils personnels), « Enregistrer
sous un nouveau profil… ». Un simple ajustement ne modifie **jamais** le profil enregistré. Outils → Profils : dupliquer (y compris un profil standard),
renommer, supprimer (profils personnels). Les profils standards ne sont ni modifiables ni supprimables.

### Profils standards (rédigés par l'éditeur ; à relire et à faire valider)
Ce sont des points de départ, **pas une garantie de conformité** (RGPD, secret professionnel ou autre).

| | Préparation pour une IA | Juridique | Recrutement |
|---|---|---|---|
| Identifiants (e-mail, téléphone, IBAN, adresse, comptes, pièces, plaques…) | pseudonymisés | pseudonymisés | pseudonymisés |
| Dates / dates de naissance | année / année | conservées / année | année / année |
| Montants, références internes | conservés | conservés | conservés |
| Images | supprimées | conservées (signalées) | supprimées |
| Contenus non analysables | confidentialité renforcée | préservation | confidentialité renforcée |
| Périmètre (type) | Projet | Projet | Document |
| Lieux présélectionnés | oui | non | oui |
| Format de sortie | d'origine | d'origine | d'origine |

## 2. Généralisation des dates
Nouvelle action « Année » pour les catégories Dates et Dates de naissance :
- **Pseudonymisation** : `1990 [Date_KQXMB]`. Le code est propre au **texte exact** de la date (« 15 mars 1990 » et « 15/03/1990 » ont deux codes) ;
  la restauration remplace **l'ensemble** (année + code) par le texte d'origine exact. L'année qui précède un code n'est reprise que si elle figure dans
  la date d'origine : rien n'est deviné. Code absent ou altéré : signalé, texte laissé tel quel.
- **Sans conservation** : l'année seule (`1990`), aucune restauration.
- Une date dont l'année n'est pas lisible est pseudonymisée (l'année n'est jamais devinée).
**Pas encore fait** : généralisation des lieux (base géographique à choisir), des âges en tranches.

## 3. Format de sortie : PDF
Choix général du lot (**format d'origine**, **PDF**, **les deux**) puis fichier par fichier. La conversion est **locale**, par **LibreOffice**
(MPL-2.0, composant **facultatif, non fourni**, détecté ou indiqué par `conversion.libreoffice`), **après** le traitement. Aucun service distant.
- Convertibles : Word, PowerPoint, Excel, HTML, texte. Markdown et CSV : pas de conversion opérationnelle, donc non proposés.
- Tous les livrables, **PDF compris**, sont contrôlés (termes imposés, cohérence) ; un aperçu du PDF provisoire est proposé.
- Échec (LibreOffice absent, erreur, PDF vide, délai de 300 s dépassé) : message clair, fichier modifiable **conservé**.
- Pertes de mise en page possibles ; un PDF ne permet pas une restauration fidèle : **conserver la version modifiable**.
- PDF **en entrée** : seule l'extraction de texte vers un autre format existe. Le traitement qui préserve la présentation du PDF **n'est pas disponible**.
Dépendance et licence documentées ; l'installation du composant relève de l'étape 8.

## 4. Langues des documents
Distinctes de la langue de l'interface. Anglais inclus ; français facultatif ; allemand, italien, espagnol en **version de test**
(analyse des noms par GLiNER seul, sans formats locaux : règles génériques e-mail, IBAN, URL, IP, cartes). Détection par passage ;
avertissement avant lancement (Outils), à la validation et dans les rapports (prise en charge expérimentale ; langue détectée mais non activée =
analyse partielle, jamais présentée comme complète). Activation/retrait dans Outils → Langues (au prochain démarrage).
**Pas encore fait** : téléchargement explicite des modèles depuis l'application, espace disque affiché, choix à l'installation (étape 8).
