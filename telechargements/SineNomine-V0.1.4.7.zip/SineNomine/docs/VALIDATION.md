# Validation : termes imposés, rapprochements, occurrences, passages masqués (étape 4)

Ce document décrit ce que fait Sine Nomine depuis la V0.1.4.4, et ses limites. Il ne promet ni certification ni garantie d'anonymat.

## 1. Termes que l'utilisateur veut faire disparaître

Une liste facultative (un terme par ligne, « terme ; catégorie » possible) complète la détection automatique.

- **Doublons** : « Jean Dupont » et « jean dupont » (même forme normalisée) deviennent un seul terme dont les deux écritures sont cherchées.
- **Provenance** : chaque terme est affiché dans la liste des éléments à traiter (« Fourni par l'utilisateur »), avec son nombre réel d'occurrences,
  ses contextes et ses formes proches. À **zéro occurrence**, il reste affiché.
- **Pseudonymisation** : un pseudonyme est attribué même à zéro occurrence, dans le périmètre choisi (dans chaque document en périmètre Document).
- **Sans conservation des correspondances** : le terme à zéro occurrence est affiché pendant le travail ; aucune table n'est conservée ensuite.
- **Jamais désactivé en silence** : un terme imposé ne peut être ni décoché ni supprimé (y compris après une fusion) sans qu'on le **retire
  explicitement de la liste** (bouton dédié, avec confirmation) ; le serveur refuse sinon la validation. Il ne peut pas non plus être « conservé » occurrence par occurrence.
- **Liste confidentielle** : elle n'apparaît dans aucun rapport partageable. Elle figure seulement dans l'export explicite et confidentiel des correspondances.

### Règles de recherche
1. **Exacte** : le terme tel qu'écrit, entre deux limites de mot (« Dupont » n'est pas cherché dans « Dupontel »).
2. **Normalisée** : sans tenir compte de la casse, des accents, des séparateurs (espace, tiret, tiret bas, apostrophe), des espaces multiples
   et des graphies étrangères usuelles (Kärscher / Kaerscher). Pour un terme imposé, les minuscules sont cherchées aussi. Remplacée comme une exacte.
3. **Approximative** : proposition seulement, **jamais remplacée sans validation** (bouton « Ajouter comme variante »). Distance de Levenshtein
   1 pour 5 à 8 lettres, 2 au-delà, **jamais sous 5 lettres**.

### Vérification finale
Après l'écriture des fichiers et **avant** toute publication, les termes sont recherchés dans les fichiers **réellement produits** (relus tels qu'ils
seront livrés, quel que soit le format, PDF d'origine compris puisque le résultat est un fichier Word, PowerPoint, etc.).

- Terme retrouvé : **finalisation bloquée** (fichier, nombre d'occurrences), rien n'est publié, aucune correspondance enregistrée. L'utilisateur
  revient à la validation (ses choix sont conservés), corrige, relance, ou retire explicitement le terme.
- Parties non analysées (images conservées, objets incorporés, fichier illisible ou en erreur) : **signalées** ; l'absence complète du terme n'y
  est pas vérifiée et n'est pas présentée comme un contrôle réussi (le contrôle reste affiché avec ces réserves).
- **Limite** : le texte n'est vérifié que là où il peut être relu ; le texte contenu dans des images n'est pas lu.

## 2. Rapprochements (étape distincte)

Après la revue des termes, l'onglet « Rapprochements » propose, **entre termes de même catégorie uniquement** (jamais une personne avec une
société, même si l'une contient le nom de l'autre) : accents et séparateurs, formes abrégées (« J. Dupont »), nom seul, petites fautes.
Chaque proposition indique les formes, les contextes, la raison et une forme de référence modifiable. Un nom seul qui peut rejoindre plusieurs
noms complets est signalé comme **ambigu**.

On peut accepter, refuser (et annuler le refus), choisir la forme de référence, fusionner à la main des termes non suggérés (cases à cocher),
et **séparer** une fusion décidée. Les termes imposés et les occurrences conservées sont reportés sur le terme fusionné.
**Limite** : séparer une fusion restaure l'état du terme de référence au moment de la fusion ; les modifications faites depuis sont perdues (l'utilisateur est prévenu).

## 3. Choix occurrence par occurrence ou global

« Examiner le contexte » liste chaque occurrence avec une case « Remplacer cette occurrence ». La portée est rappelée (ce lot, ce périmètre) :
une décision n'est jamais étendue à un autre client ou projet. « Remplacer toutes » / « Conserver toutes » sont les décisions globales.

Technique : une occurrence est repérée par une **clé de contexte** (le passage et 4 mots avant et après, dans la même ligne, sans accents ni
casse), calculée de la même façon à la lecture et à l'écriture des fichiers. **Limite** : deux occurrences au contexte identique ont la même clé
et sont traitées ensemble.

## 4. Masquage manuel de passages

Dans l'onglet « Passages à masquer », on sélectionne un passage dans le texte extrait d'un fichier puis « Masquer le passage ». Le mode décide seul :

- **Pseudonymisation** : `[Passage_KQXMB]` ; le texte **exact** (casse et accents) est conservé chiffré dans le coffre du périmètre ; la dé-pseudonymisation
  le restitue sans le retraiter.
- **Sans conservation** : `[passage supprimé]`, rien n'est conservé.

Seule la sélection est masquée par défaut ; les autres occurrences identiques sont proposées avec leur contexte, à cocher une à une. Les
masquages sont listés, modifiables (cases) et annulables. En cas de chevauchement, le passage masqué l'emporte sur les détections qu'il recouvre.

**Limites** : masquage **textuel** (pas un outil de caviardage d'images) ; un passage tient dans un seul paragraphe (2 000 caractères au plus) ;
la mise en forme d'origine du passage (gras, liens…) n'est pas restituée à la restauration, seul le texte exact l'est ; la correspondance est exacte
(un passage différent par la casse n'est pas masqué).

## 5. Historique

Chaque validation inscrit dans l'historique chiffré et chaîné du coffre un événement ne contenant que des **comptes** (fusions, passages,
occurrences conservées, termes imposés ou retirés), jamais de texte. **Pas encore fait** : sauvegarde de la validation en cours avec reprise après
fermeture de l'application, détection des modifications des documents sources, et historique détaillé annulable après finalisation.
