"use strict";
// Interface bilingue français / anglais. Fichier généré par tests/generer_i18n.py à partir du dictionnaire
// français -> anglais : ne pas l'éditer à la main (modifier le dictionnaire puis régénérer).
const EN = {
 "Rapport d'anonymisation": "Anonymisation report",
 "Rapport d'anonymisation Sine Nomine": "Sine Nomine anonymisation report",
 "Rapport Sine Nomine — {lot}": "Sine Nomine report — {lot}",
 "Lot": "Batch",
 "Mode : {mode}": "Mode: {mode}",
 "Mode": "Mode",
 "Date": "Date",
 "Avertissement accepté le {a}. Détections validées par l'utilisateur le {v}.": "Notice accepted on {a}. Detections reviewed by the user on {v}.",
 "Avertissement accepté le": "Notice accepted on",
 "Validé le": "Reviewed on",
 "Synthèse": "Summary",
 "Fichiers traités": "Files processed",
 "Entités remplacées": "Entities replaced",
 "Informations sensibles remplacées": "Sensitive items replaced",
 "Informations sensibles conservées": "Sensitive items kept",
 "Choix appliqués aux informations sensibles": "Choices applied to sensitive information",
 "Catégorie": "Category",
 "Action": "Action",
 "Éléments exclus (conservés)": "Excluded items (kept)",
 "conserver": "keep",
 "pseudonymiser": "pseudonymise",
 "supprimer": "delete",
 "Images": "Images",
 "Images supprimées": "Images removed",
 "non (conservées)": "no (kept)",
 "Images (supprimées)": "Images (removed)",
 "{n} image(s) supprimée(s), remplacée(s) par « [image supprimée] ».": "{n} image(s) removed, replaced by “[image supprimée]”.",
 "{n} image(s) supprimée(s).": "{n} image(s) removed.",
 "Erreur : {x}": "Error: {x}",
 "Identifiant": "Identifier",
 "Type": "Type",
 "Occurrences": "Occurrences",
 "Aucune.": "None.",
 "Remplacements": "Replacements",
 "Informations potentiellement sensibles conservées": "Potentially sensitive information kept",
 "Extrait (texte anonymisé)": "Excerpt (anonymised text)",
 "Confiance": "Confidence",
 "Image {n}": "Image {n}",
 "Aperçu impossible pour ce format.": "Preview not available for this format.",
 "Propriété intellectuelle.": "Intellectual property.",
 "Responsabilité.": "Liability.",
 "Pseudonymisation.": "Pseudonymisation.",
 "Anonymisation.": "Anonymisation.",
 "Confidentialité.": "Confidentiality.",
 "Loi applicable.": "Governing law.",
 "Contact.": "Contact.",
 "Fiabilité": "Reliability",
 "Éditeur": "Publisher",
 "Fichier": "File",
 "Message": "Message",
 "Avertissements": "Warnings",
 "Sensibles remplacées": "Sensitive items replaced",
 "Sensibles conservées": "Sensitive items kept",
 "DOCUMENT CONFIDENTIEL — permet de lever la pseudonymisation du lot {lot}": "CONFIDENTIAL DOCUMENT — makes it possible to reverse the pseudonymisation of batch {lot}",
 "Entités": "Entities",
 "Nom d'origine": "Original name",
 "Variantes recherchées": "Searched variants",
 "Informations sensibles": "Sensitive information",
 "Remplacé par": "Replaced by",
 "Valeur(s) d'origine": "Original value(s)",
 "[supprimé]": "[deleted]",
 "Personne": "Person",
 "Société": "Company",
 "Produit": "Product",
 "Lieu": "Place",
 "E-mails": "Emails",
 "Téléphones": "Phone numbers",
 "IBAN et BIC": "IBAN and BIC",
 "N° de sécurité sociale": "Social security number (France)",
 "SIRET / SIREN": "SIRET / SIREN",
 "Adresses": "Addresses",
 "Dates de naissance": "Dates of birth",
 "Montants": "Amounts",
 "URL et noms de domaine": "URLs and domain names",
 "Dates": "Dates",
 "Adresses IP et MAC": "IP and MAC addresses",
 "Cartes bancaires": "Bank cards",
 "N° de TVA": "VAT numbers",
 "Plaques d'immatriculation et n° de châssis": "Number plates and chassis numbers",
 "Comptes et pseudos (@nom)": "Accounts and handles (@name)",
 "Passeports et cartes d'identité": "Passports and ID cards",
 "Références internes (motifs configurés)": "Internal references (configured patterns)",
 "Identifiants nationaux étrangers (NINO, SSN, NHS…)": "Foreign national identifiers (NINO, SSN, NHS…)",
 "Chemins de fichiers et de réseau": "File and network paths",
 "Coordonnées GPS": "GPS coordinates",
 "Image distante : non affichée (aucune connexion n'est faite).": "Remote image: not shown (no connection is made).",
 "Fichier image introuvable à côté du document. Pour le voir, indiquez le chemin du dossier plutôt que de déposer le seul fichier Markdown.": "Image file not found next to the document. To see it, enter the folder path rather than dropping the Markdown file alone.",
 "Image introuvable dans le document.": "Image not found in the document.",
 "Image liée (hors du document) : non affichée.": "Linked image (outside the document): not shown.",
 "{n} image(s) conservée(s) et non analysée(s) : vérifiez qu'elles ne contiennent pas d'informations identifiantes (logos, signatures, captures d'écran).": "{n} image(s) kept and not analysed: check that they contain no identifying information (logos, signatures, screenshots).",
 "PDF : le résultat est un nouveau fichier de texte seul. Les images, tableaux et la mise en page d'origine ne sont pas repris, et les métadonnées du PDF (auteur, titre…) ne sont pas copiées.": "PDF: the result is a new plain-text file. Images, tables and the original layout are not carried over, and the PDF metadata (author, title…) is not copied.",
 "Aucun texte n'a pu être extrait de ce PDF.": "No text could be extracted from this PDF.",
 "La reconnaissance de caractères est désactivée (config.json).": "Optical character recognition is disabled (config.json).",
 "Tesseract n'est pas installé : les PDF scannés (images sans texte) ne pourront pas être lus. Relancez installer.bat pour l'installer.": "Tesseract is not installed: scanned PDFs (images without text) cannot be read. Run installer.bat again to install it.",
 "Tesseract est installé, mais sans données de langue (français, anglais) : relancez installer.bat.": "Tesseract is installed, but without language data (French, English): run installer.bat again.",
 "PDF protégé par un mot de passe : retirez la protection avant de le traiter.": "PDF protected by a password: remove the protection before processing it.",
 "{n} page(s) sans texte (document scanné ?) non lue(s) : {m}": "{n} page(s) without text (scanned document?) not read: {m}",
 "{n} page(s) lue(s) par reconnaissance de caractères (OCR) : le texte peut contenir des erreurs, surtout sur les noms propres. Relisez attentivement la validation et le résultat.": "{n} page(s) read by optical character recognition (OCR): the text may contain errors, especially on proper names. Review the validation and the result carefully.",
 "Objets incorporés (tableaux Excel, autres documents) non analysés, y compris leur image d'aperçu.": "Embedded objects (Excel tables, other documents) were not analysed, including their preview image.",
 "La miniature d'aperçu intégrée au fichier (image de la première page) a été supprimée.": "The preview thumbnail embedded in the file (image of the first page) was removed.",
 "Excel : les textes des cellules et des commentaires sont traités ; les noms des feuilles, les formules, les nombres, les tableaux croisés dynamiques et les liens externes ne le sont pas.": "Excel: cell and comment texts are processed; sheet names, formulas, numbers, pivot tables and external links are not.",
 "PowerPoint : les images d'arrière-plan et les objets incorporés ne sont pas analysés.": "PowerPoint: background images and embedded objects are not analysed.",
 "Fichier d'origine endommagé, réparé dans la version anonymisée : {n} élément(s) sans type déclaré (Word proposait de « récupérer le contenu » de l'original).": "Damaged original file, repaired in the anonymised version: {n} element(s) with no declared type (Word offered to “recover the contents” of the original).",
 "Anonymiseur de fichiers local · Habeas Corpus Consulting": "Local file anonymiser · Habeas Corpus Consulting",
 "Avertissement": "Notice",
 "Fichiers": "Files",
 "Validation": "Review",
 "Résultat": "Result",
 "Menu": "Menu",
 "Quitter": "Quit",
 "Avant de commencer": "Before you start",
 "Ces conditions s'appliquent à chaque traitement. Lisez-les puis acceptez-les pour continuer.": "These terms apply to every processing run. Please read and accept them to continue.",
 "Propriété intellectuelle et usage": "Intellectual property and use",
 "Garantie et responsabilité": "Warranty and liability",
 "Fiabilité de la détection": "Detection reliability",
 "Confidentialité et emplacement des fichiers": "Confidentiality and file locations",
 "Table de correspondance": "Correspondence table",
 "Loi applicable": "Governing law",
 "J'ai lu et j'accepte ces conditions. Je vérifierai les détections et relirai les fichiers produits avant toute diffusion.": "I have read and accept these terms. I will check the detections and proofread the files produced before sharing them.",
 "Accepter et continuer": "Accept and continue",
 "Fichiers à anonymiser": "Files to anonymise",
 "Fichiers à pseudonymiser": "Files to pseudonymise",
 "Word (.docx), PowerPoint (.pptx), Excel (.xlsx), Markdown (.md), texte (.txt), CSV (.csv, .tsv), HTML (.html) et PDF (.pdf). Les fichiers d'origine ne sont jamais modifiés.": "Word (.docx), PowerPoint (.pptx), Excel (.xlsx), Markdown (.md), text (.txt), CSV (.csv, .tsv), HTML (.html) and PDF (.pdf). Original files are never modified.",
 "Fichiers PDF": "PDF files",
 "Format du fichier produit à partir d'un PDF": "Format of the file produced from a PDF",
 "Word (.docx)": "Word (.docx)",
 "PowerPoint (.pptx)": "PowerPoint (.pptx)",
 "Markdown (.md)": "Markdown (.md)",
 "Texte (.txt)": "Text (.txt)",
 "HTML (.html)": "HTML (.html)",
 "Excel (.xlsx)": "Excel (.xlsx)",
 "Le texte du PDF est extrait puis anonymisé : les images, tableaux et la mise en page d'origine ne sont pas repris. Les PDF scannés sont lus par reconnaissance de caractères (OCR), moins fiable : relisez-les avec soin.": "The PDF text is extracted and then anonymised: images, tables and the original layout are not carried over. Scanned PDFs are read by optical character recognition (OCR), which is less reliable: review them carefully.",
 "Glissez-déposez des fichiers ou des dossiers ici": "Drag and drop files or folders here",
 "ou": "or",
 "parcourez votre ordinateur": "browse your computer",
 "Dossier à traiter (sous-dossiers compris)": "Folder to process (subfolders included)",
 "Mode de traitement": "Processing mode",
 "Options": "Options",
 "Dossier de sortie (facultatif)": "Output folder (optional)",
 "Analyser": "Analyse",
 "Analyse en cours": "Analysis in progress",
 "Anonymisation en cours": "Anonymisation in progress",
 "Pseudonymisation en cours": "Pseudonymisation in progress",
 "Validation des détections": "Review of detections",
 "Cochés seulement": "Ticked only",
 "Tout cocher": "Tick all",
 "Tout décocher": "Untick all",
 "Fusionner la sélection": "Merge selection",
 "Toujours détecter (dictionnaire)": "Always detect (dictionary)",
 "Ajouter": "Add",
 "Fusion": "Merge",
 "Remplacer": "Replace",
 "Nom détecté et variantes recherchées": "Detected name and searched variants",
 "Occ.": "Occ.",
 "Rien à afficher.": "Nothing to show.",
 "En confirmant, vous attestez avoir vérifié les détections de tous les onglets.": "By confirming, you certify that you have checked the detections in all tabs.",
 "Onglet précédent": "Previous tab",
 "Passer à l'onglet suivant": "Go to next tab",
 "Confirmer et anonymiser": "Confirm and anonymise",
 "Confirmer et anonymiser (irréversible)": "Confirm and anonymise (irreversible)",
 "Confirmer et pseudonymiser": "Confirm and pseudonymise",
 "Anonymisation terminée": "Anonymisation complete",
 "Pseudonymisation terminée": "Pseudonymisation complete",
 "Relisez les fichiers produits avant de les diffuser. Le rapport liste ce qui a été remplacé et ce qui a été conservé.": "Proofread the files produced before sharing them. The report lists what was replaced and what was kept.",
 "Ouvrir le rapport": "Open the report",
 "Ouvrir le dossier de sortie": "Open the output folder",
 "Ouvrir le dossier des correspondances": "Open the correspondences folder",
 "Fichier produit": "Output file",
 "Fichier d'origine": "Original file",
 "Nouveau lot": "New batch",
 "Menu principal": "Main menu",
 "Que souhaitez-vous faire ?": "What would you like to do?",
 "Traiter des documents": "Process documents",
 "Remplacer les noms par des numéros (anonymisation)": "Replace names with numbers (anonymisation)",
 "Remplace les noms par des numéros (Personne_1…). Sans retour possible : aucune table ni archive n'est conservée.": "Replaces names with numbers (Personne_1…). No way back: no table or archive is kept.",
 "Remplacer les noms par des pseudonymes (pseudonymisation)": "Replace names with pseudonyms (pseudonymisation)",
 "Remplace les noms par des codes aléatoires (Personne_KQXMB). Réversible grâce à l'archive des codes.": "Replaces names with random codes (Personne_KQXMB). Reversible thanks to the code archive.",
 "Travailler sur des pseudonymes": "Work on pseudonyms",
 "Corriger des pseudonymes (re‑pseudonymisation)": "Correct pseudonyms (re‑pseudonymisation)",
 "Complète des fichiers déjà pseudonymisés : noms oubliés, avec ou sans accents, y compris dans les noms de fichiers.": "Completes files that are already pseudonymised: missed names, with or without accents, including in file names.",
 "Remplacer les pseudonymes par des noms (dé‑pseudonymisation)": "Replace pseudonyms with names (de‑pseudonymisation)",
 "Remet les noms d'origine dans des fichiers pseudonymisés par Sine Nomine.": "Puts the original names back into files pseudonymised by Sine Nomine.",
 "Consulter un pseudonyme": "Look up a pseudonym",
 "Retrouve le nom d'origine d'un code, ou le code attribué à un nom.": "Finds the original name behind a code, or the code assigned to a name.",
 "Réglages": "Settings",
 "Configurer Sine Nomine": "Configure Sine Nomine",
 "Mots exclus, dictionnaires, options par défaut (téléphones, IBAN, images…), archive des codes.": "Excluded words, dictionaries, default options (phone numbers, IBAN, images…), code archive.",
 "Arrête Sine Nomine.": "Stops Sine Nomine.",
 "Pour des fichiers déjà pseudonymisés par Sine Nomine dans lesquels des noms sont restés : par exemple « Ines » à côté d'un code, ou « Elise_Wu » dans un nom de fichier. Les fichiers déposés ne sont pas modifiés : les versions corrigées vont dans un dossier daté. Un aperçu s'affiche avant toute écriture.": "For files already pseudonymised by Sine Nomine in which some names remain: for example “Ines” next to a code, or “Elise_Wu” in a file name. The files you drop are not modified: corrected versions go into a dated folder. A preview is shown before anything is written.",
 "Glissez-déposez ici les fichiers pseudonymisés à corriger": "Drag and drop the pseudonymised files to correct here",
 "ou dossier à corriger (sous-dossiers compris)": "or folder to correct (subfolders included)",
 "Que corriger ?": "What to correct?",
 "Règles à la main": "Manual rules",
 "Pour un texte que l'archive ne connaît pas, ou qu'elle ne relie pas au bon pseudonyme.": "For text the archive does not know, or does not link to the right pseudonym.",
 "est une nouvelle personne": "is a new person",
 "est une nouvelle société": "is a new company",
 "est un nouveau produit": "is a new product",
 "est un nouveau lieu": "is a new place",
 "est une variante d'un pseudonyme existant": "is a variant of an existing pseudonym",
 "Ajouter la règle": "Add the rule",
 "Retour au menu": "Back to menu",
 "Aperçu des corrections": "Preview corrections",
 "Appliquer les corrections": "Apply corrections",
 "Aperçu": "Preview",
 "Origine": "Source",
 "Pseudonyme": "Pseudonym",
 "Contexte": "Context",
 "Corrections": "Corrections",
 "Nouveau nom": "New name",
 "Corrections appliquées": "Corrections applied",
 "Fichier corrigé": "Corrected file",
 "Fichier déposé": "Dropped file",
 "Rechercher": "Search",
 "Code": "Code",
 "Valeur d'origine": "Original value",
 "Variantes": "Variants",
 "Lots": "Batches",
 "Mots exclus et dictionnaires": "Excluded words and dictionaries",
 "Options par défaut": "Default options",
 "Archive des codes": "Code archive",
 "Liste à modifier": "List to edit",
 "Enregistrer": "Save",
 "Ouvrir le dossier de l'archive": "Open the archive folder",
 "Glissez-déposez ici les fichiers à désanonymiser": "Drag and drop the files to de-pseudonymise here",
 "ou dossier à traiter (sous-dossiers compris)": "or folder to process (subfolders included)",
 "Dé-pseudonymiser": "De-pseudonymise",
 "Fichier restauré": "Restored file",
 "Codes remplacés": "Codes replaced",
 "Codes inconnus": "Unknown codes",
 "Sine Nomine est arrêté": "Sine Nomine has stopped",
 "Vous pouvez fermer cet onglet. Pour relancer, double-cliquez sur le raccourci Sine Nomine.": "You can close this tab. To restart, double-click the Sine Nomine shortcut.",
 "Une erreur est survenue": "An error occurred",
 "Recommencer": "Start over",
 "Licences tierces": "Third-party licences",
 "État des modèles de détection": "Status of the detection models",
 "Retour au menu principal": "Back to main menu",
 "Arrêter Sine Nomine": "Stop Sine Nomine",
 "G:\\Mon Drive\\…\\Dossier client": "G:\\My Drive\\…\\Client folder",
 "Rechercher…": "Search…",
 "Ajouter un nom oublié…": "Add a missed name…",
 "Cochez au moins deux lignes qui désignent la même chose, puis « Fusionner la sélection »": "Tick at least two rows that refer to the same thing, then “Merge selection”",
 "Texte à remplacer (ex. Ines, Mila_Lin_an_Park)": "Text to replace (e.g. Ines, Mila_Lin_an_Park)",
 "Code ou nom du pseudonyme": "Pseudonym code or name",
 "Code ou nom…": "Code or name…",
 "Un terme par ligne": "One term per line",
 "Langue": "Language",
 "Erreur {n}": "Error {n}",
 "Modèles : attention": "Models: warning",
 "Modèles prêts": "Models ready",
 "Modèles : en attente…": "Models: waiting…",
 "Modèles : chargement du modèle spaCy…": "Models: loading the spaCy model…",
 "Modèles : chargement du modèle spaCy anglais…": "Models: loading the English spaCy model…",
 "Modèles : chargement du modèle GLiNER…": "Models: loading the GLiNER model…",
 "Modèles : prêt…": "Models: ready…",
 "Modèles : erreur…": "Models: error…",
 "Serveur injoignable": "Server unreachable",
 "Arrêté": "Stopped",
 "Déposez des fichiers ou indiquez un dossier à traiter.": "Drop files or enter a folder to process.",
 "Déposez des fichiers ou indiquez un dossier à désanonymiser.": "Drop files or enter a folder to de-pseudonymise.",
 "Déposez des fichiers ou indiquez un dossier à corriger.": "Drop files or enter a folder to correct.",
 "Arrêter Sine Nomine ?": "Stop Sine Nomine?",
 "Un traitement est en cours et sera interrompu. Arrêter quand même ?": "A batch is being processed and will be interrupted. Stop anyway?",
 "Abandonner la validation en cours ? Les choix faits seront perdus.": "Abandon the review in progress? Your choices will be lost.",
 "Le serveur Sine Nomine ne répond pas. Relancez lancer.bat.": "The Sine Nomine server is not responding. Restart lancer.bat.",
 "Chargement des modèles": "Loading models",
 "Lecture des fichiers": "Reading files",
 "Détection des noms": "Detecting names",
 "Regroupement et calculs": "Grouping and calculations",
 "Préparation": "Preparation",
 "Remplacement dans les fichiers": "Replacing in files",
 "Rapport et archive": "Report and archive",
 "En attente": "Waiting",
 "En attente des modèles de détection": "Waiting for the detection models",
 "Chargement des modèles de détection (20 à 90 secondes au démarrage)": "Loading the detection models (20 to 90 seconds at start-up)",
 "Détection des noms, sociétés, produits et lieux": "Detecting names, companies, products and places",
 "Regroupement des entités et calcul des occurrences": "Grouping entities and counting occurrences",
 "Préparation des remplacements": "Preparing replacements",
 "Rédaction du rapport et de l'archive": "Writing the report and the archive",
 "Fichier en cours : {f}": "Current file: {f}",
 "Détection des noms, sociétés, produits et lieux — {d}": "Detecting names, companies, products and places — {d}",
 "{n} fichier(s) · lot {l}": "{n} file(s) · batch {l}",
 "Durée écoulée": "Elapsed time",
 "Temps restant estimé": "Estimated time left",
 "Mots": "Words",
 "calcul en cours…": "calculating…",
 "Détectés jusqu'ici (formes distinctes)": "Detected so far (distinct forms)",
 "Substitutions effectuées : {n}": "Replacements made: {n}",
 "Personnes": "People",
 "Sociétés": "Companies",
 "Produits": "Products",
 "Lieux": "Places",
 "Produits et marques": "Products and brands",
 "À jour.": "Up to date.",
 "Dernière mise à jour du traitement il y a {s} s. Un long document peut prendre plusieurs minutes.": "Last progress update {s} s ago. A long document can take several minutes.",
 "Fichiers ignorés (format non pris en charge) : {x}": "Files ignored (unsupported format): {x}",
 "Impossible de lire {f} : {m}": "Unable to read {f}: {m}",
 "Informations sensibles et images": "Sensitive information and images",
 "Sélectionner pour fusionner": "Select to merge",
 "Remplacer cette entité": "Replace this entity",
 "Nom de référence (modifiable)": "Reference name (editable)",
 "Retirer cette variante": "Remove this variant",
 "Afficher toutes les variantes recherchées": "Show all searched variants",
 "+ {n} autres": "+ {n} more",
 "+ variante": "+ variant",
 "Ajouter une variante, puis Entrée": "Add a variant, then press Enter",
 "Contexte · {x}": "Context · {x}",
 "Décocher et ne plus jamais détecter ce terme": "Untick and never detect this term again",
 "Examiner le contexte": "Review context",
 "Voir les passages où ce terme apparaît": "See the passages where this term appears",
 "Actions": "Actions",
 "Contexte d'utilisation": "Context of use",
 "Terme examiné :": "Term reviewed:",
 "Mots affichés avant et après": "Words shown before and after",
 "Revenir à la validation": "Back to review",
 "Recherche des passages…": "Looking for passages…",
 "Aucun passage trouvé : ce terme a été ajouté à la main ou n'apparaît plus tel quel dans le texte.": "No passage found: this term was added by hand or no longer appears as such in the text.",
 "{n} passage(s) au total, les {m} premiers sont affichés.": "{n} passage(s) in total, the first {m} are shown.",
 "{n} passage(s).": "{n} passage(s).",
 "remplacé par": "replaced by",
 "non remplacé": "not replaced",
 "Version d'évaluation : il vous reste {n} jour(s), jusqu'au {date}.": "Evaluation version: {n} day(s) left, until {date}.",
 "Sine Nomine n'est pas activé : saisissez votre clé d'accès avec « activer.bat » (ou relancez l'installation). Pour en obtenir une : contact@hcorpus.com.": "Sine Nomine is not activated: enter your access key with \"activer.bat\" (or run the installation again). To get one: contact@hcorpus.com.",
 "La licence est invalide : relancez « activer.bat » avec votre clé d'accès.": "The licence is invalid: run \"activer.bat\" again with your access key.",
 "L'horloge de l'ordinateur est en retard sur la dernière utilisation : corrigez la date et l'heure.": "The computer clock is behind the last time Sine Nomine was used: correct the date and time.",
 "Votre période d'évaluation est terminée. Pour continuer, demandez une nouvelle clé d'accès : contact@hcorpus.com. La dé-pseudonymisation de vos fichiers reste possible.": "Your evaluation period has ended. To continue, ask for a new access key: contact@hcorpus.com. De-pseudonymising your files is still possible.",
 "Toujours ignorer": "Always ignore",
 "Retirer": "Remove",
 "Voir en grand": "View full size",
 "dictionnaire": "dictionary",
 "refusé précédemment": "previously rejected",
 "manuel": "manual",
 "Exception": "Exception",
 "Valeur": "Value",
 "Conserver": "Keep",
 "Pseudonymiser": "Pseudonymise",
 "Supprimer": "Delete",
 "Voir les éléments détectés et exclure ceux à conserver": "Show detected items and exclude those to keep",
 "Aucun élément détecté.": "No items detected.",
 "Images des documents": "Document images",
 "Les images ne sont pas analysées : logos, signatures et captures d'écran peuvent contenir des informations identifiantes. Supprimées, elles sont remplacées par le texte « [image supprimée] ». Les graphiques, zones de texte et SmartArt sont conservés.": "Images are not analysed: logos, signatures and screenshots may contain identifying information. When removed, they are replaced by the text “[image supprimée]”. Charts, text boxes and SmartArt are kept.",
 "Aucune image détectée.": "No images detected.",
 "À remplacer : {a} personne(s), {b} société(s), {c} produit(s), {d} lieu(x), {e} information(s) sensible(s).": "To replace: {a} person(s), {b} company(ies), {c} product(s), {d} place(s), {e} sensitive item(s).",
 "À remplacer : {a} personne(s), {b} société(s), {c} produit(s), {d} lieu(x), {e} information(s) sensible(s), images supprimées.": "To replace: {a} person(s), {b} company(ies), {c} product(s), {d} place(s), {e} sensitive item(s), images removed.",
 "Onglet {n} sur {m} : {x}": "Tab {n} of {m}: {x}",
 "Reste à vérifier avant de confirmer :": "Still to review before confirming:",
 "Tous les onglets ont été vérifiés.": "All tabs have been reviewed.",
 "Suivant : {x}": "Next: {x}",
 "Mots traités": "Words processed",
 "Substitutions": "Replacements",
 "Durée de l'analyse": "Analysis time",
 "Durée du traitement": "Processing time",
 "{n} image(s) supprimée(s)": "{n} image(s) removed",
 "Anonymisation irréversible :": "Irreversible anonymisation:",
 "Table de correspondance :": "Correspondence table:",
 "Aucun code trouvé": "No code found",
 "Archive des codes :": "Code archive:",
 "{a} nom(s) et {b} information(s) sensible(s) archivés.": "{a} name(s) and {b} sensitive item(s) archived.",
 "{a} nom(s) et {b} information(s) sensible(s).": "{a} name(s) and {b} sensitive item(s).",
 "Archive vide :": "Empty archive:",
 "aucun lot n'a encore été anonymisé avec cette installation.": "no batch has been anonymised with this installation yet.",
 "aucun lot n'a encore été pseudonymisé.": "no batch has been pseudonymised yet.",
 "{n} résultat(s).": "{n} result(s).",
 "{n} résultat(s) (liste tronquée : précisez la recherche).": "{n} result(s) (list truncated: refine your search).",
 "Aucun résultat.": "No results.",
 "L'archive est vide : aucun lot n'a encore été pseudonymisé.": "The archive is empty: no batch has been pseudonymised yet.",
 "Plusieurs pseudonymes correspondent à « {x} » : précisez le code (par exemple {c}).": "Several pseudonyms match “{x}”: specify the code (for example {c}).",
 "Aucun pseudonyme ne correspond à « {x} » dans l'archive.": "No pseudonym matches “{x}” in the archive.",
 "→ variante de {c} ({v})": "→ variant of {c} ({v})",
 "→ nouveau : personne": "→ new: person",
 "→ nouveau : société": "→ new: company",
 "→ nouveau : produit": "→ new: product",
 "→ nouveau : lieu": "→ new: place",
 "Règle :": "Rule:",
 "(nouveau pseudonyme)": "(new pseudonym)",
 "Archive": "Archive",
 "Rien à corriger avec ces réglages.": "Nothing to correct with these settings.",
 "{n} correction(s) seraient faites dans {m} fichier(s). Rien n'est encore écrit.": "{n} correction(s) would be made in {m} file(s). Nothing has been written yet.",
 "Aucune correction à faire avec ces réglages.": "No correction to make with these settings.",
 "Enregistré : {n} terme(s). Pris en compte au prochain lot.": "Saved: {n} term(s). Applied from the next batch.",
 "Enregistré. Appliqué à partir du prochain lot.": "Saved. Applied from the next batch.",
 "Détection": "Detection",
 "Lieux détectés par les modèles": "Places detected by the models",
 "Cochés par défaut": "Ticked by default",
 "Seuil de présélection": "Pre-selection threshold",
 "confiance minimale pour cocher une entité (0 à 1)": "minimum confidence to tick an entity (0 to 1)",
 "Termes qui ne seront plus jamais détectés comme personne, société, produit ou lieu (faux positifs récurrents).": "Terms that will never again be detected as a person, company, product or place (recurring false positives).",
 "Noms de personnes toujours détectés et cochés d'office.": "Names of people that are always detected and ticked automatically.",
 "Sociétés toujours détectées et cochées d'office.": "Companies that are always detected and ticked automatically.",
 "Produits et marques toujours détectés et cochés d'office.": "Products and brands that are always detected and ticked automatically.",
 "Villes, pays et lieux toujours détectés et cochés d'office (les lieux trouvés par les modèles sont décochés par défaut).": "Cities, countries and places that are always detected and ticked automatically (places found by the models are unticked by default).",
 "Mots exclus (jamais détectés)": "Excluded words (never detected)",
 "Personnes à toujours détecter": "People to always detect",
 "Sociétés à toujours détecter": "Companies to always detect",
 "Produits et marques à toujours détecter": "Products and brands to always detect",
 "Lieux à toujours détecter": "Places to always detect",
 "L'avertissement doit être accepté avant tout traitement.": "The notice must be accepted before any processing.",
 "Mode inconnu : {x}": "Unknown mode: {x}",
 "Dossier introuvable : {x}": "Folder not found: {x}",
 "Aucun fichier à traiter (formats : {x}).": "No file to process (formats: {x}).",
 "Ce lot n'est pas en attente de validation.": "This batch is not waiting for review.",
 "Confirmez avoir vérifié les détections.": "Confirm that you have checked the detections.",
 "Aucune table de correspondance : ce lot a été anonymisé sans rien conserver.": "No correspondence table: this batch was anonymised without keeping anything.",
 "Aucun fichier à désanonymiser.": "No file to de-pseudonymise.",
 "Aucun fichier à corriger.": "No file to correct.",
 "Liste de termes attendue.": "A list of terms is expected.",
 "Actions invalides pour les informations sensibles.": "Invalid actions for sensitive information.",
 "Choix d'images invalide.": "Invalid image choice.",
 "Mode inconnu.": "Unknown mode.",
 "Seuil invalide.": "Invalid threshold.",
 "Le seuil doit être compris entre 0 et 1.": "The threshold must be between 0 and 1.",
 "Un traitement est en cours.": "A batch is being processed.",
 "Terme vide.": "Empty term.",
 "Liste inconnue.": "Unknown list.",
 "Règle {n} : le texte à remplacer est trop court.": "Rule {n}: the text to replace is too short.",
 "Règle {n} : le pseudonyme {c} n'existe pas dans l'archive.": "Rule {n}: pseudonym {c} does not exist in the archive.",
 "Règle {n} : type inconnu ({x}).": "Rule {n}: unknown type ({x}).",
 "Modèle spaCy anglais indisponible : les textes anglais ne seront analysés que par GLiNER. Relancez installer.bat pour l'installer. ({x})": "English spaCy model unavailable: English texts will only be analysed by GLiNER. Run installer.bat again to install it. ({x})",
 "spaCy indisponible : {x}": "spaCy unavailable: {x}"
};

const EN_BLOCS = {
 "mode.pseudo": "<strong>Pseudonymise</strong> (reversible): random codes such as <code>Personne_KQXMB</code>. The code archive is kept, so you can de-pseudonymise later.",
 "mode.anon": "<strong>Anonymise</strong> (irreversible): <code>Personne_1</code>, <code>Société_1</code>… No table or archive is kept, and the copies of the files you dropped are deleted: Sine Nomine will no longer be able to recover the original names. The text may remain identifiable by cross-referencing: proofread it.",
 "valid.intro": "Tick what should be replaced, correct the names and their variants, merge duplicates, add anything missed. Items below <span id=\"seuil\"></span> confidence are unticked by default.",
 "sortie.defaut": "Default: a dated subfolder in <code id=\"sortie-defaut\"></code>",
 "corr.auto": "<strong>Names known from the archive</strong> that are still present: with or without accents (Inès / Ines), with foreign spellings (Kärscher / Kaerscher) and in file names (Mila_Lin_an_Park).",
 "corr.prenoms": "Also include the <strong>first names alone</strong> of known people (“Inès” for “Inès Marchand”). Risk of replacing a common word: check the preview.",
 "pseudo.intro": "Enter a code (<code>Personne_KQXMB</code>, <code>[Email_ZTRPA]</code> or just <code>KQXMB</code>) or an original name. The results show information in clear: do not display them on screen in front of others. Leave empty to see the first entries.",
 "outils.options": "Choices offered by default for each batch. You can always change them on the review screen. They are saved in <code>config.utilisateur.json</code> (the <code>config.json</code> file is not modified).",
 "outils.archive": "The archive contains the original names in clear: keep it private and back it up. Without it, files that are already pseudonymised cannot be restored. Copy the <code>archive_codes.json</code> file to back it up.",
 "resto.intro": "Puts the original names and information back in place of the codes (<code>Personne_KQXMB</code>, <code>[Email_ZTRPA]</code>…), using the code archive of all batches already processed. The files you drop are not modified: restored versions go into a dated folder. A code missing from the archive is left as is and flagged."
};

// ------------------------------------------------------------------ moteur de traduction
const CLE_LANGUE = "sn_langue";
const ATTRIBUTS = ["title", "placeholder", "alt", "aria-label"];
const NON_TRADUITS = new Set(["SCRIPT", "STYLE", "CODE", "TEXTAREA", "PRE"]);

function langueInitiale() {
  try {
    const stockee = localStorage.getItem(CLE_LANGUE);
    if (stockee === "fr" || stockee === "en") return stockee;
  } catch { /* stockage indisponible : on prend la langue du navigateur */ }
  const nav = ((navigator.languages && navigator.languages[0]) || navigator.language || "fr").toLowerCase();
  return nav.startsWith("en") ? "en" : "fr";
}
let LANGUE = langueInitiale();

const normaliserTexte = (texte) => texte.replace(/\s+/g, " ").trim();
const PATRONS = Object.entries(EN).filter(([fr]) => fr.includes("{")).map(([fr, en]) => {
  const noms = [];
  const source = fr.replace(/[.*+?^$()|[\]\\]/g, "\\$&").replace(/\{(\w+)\}/g, (_, n) => { noms.push(n); return "(.+?)"; });
  return { re: new RegExp("^" + source + "$"), noms, en };
});

// Texte anglais d'un texte français (tel quel s'il n'a pas de traduction), en conservant les espaces autour.
function traduire(fr) {
  if (LANGUE !== "en" || typeof fr !== "string") return fr;
  const cle = normaliserTexte(fr);
  if (!cle) return fr;
  let en = EN[cle];
  if (en === undefined) {
    for (const p of PATRONS) {
      const m = p.re.exec(cle);
      if (m) {
        // Les valeurs insérées (nom d'onglet, catégorie…) sont traduites à leur tour si elles ont une traduction.
        en = p.en.replace(/\{(\w+)\}/g, (_, n) => { const v = m[p.noms.indexOf(n) + 1]; const vn = EN[normaliserTexte(v)]; return vn === undefined ? v : vn; });
        break;
      }
    }
  }
  if (en === undefined) return fr;
  const debut = fr.match(/^\s*/)[0], fin = fr.match(/\s*$/)[0];
  return debut + en + fin;
}
// Pour le code JavaScript : t("Texte {x}", { x: 3 }) -> traduit puis remplit les variables.
function t(fr, variables = {}) {
  const gabarit = LANGUE === "en" && EN[fr] !== undefined ? EN[fr] : fr;
  return gabarit.replace(/\{(\w+)\}/g, (m, n) => (n in variables ? variables[n] : m));
}

const ETAT_TEXTE = new WeakMap();      // nœud texte -> { fr, rendu }
function dansZoneNonTraduite(noeud) {
  for (let p = noeud.parentElement; p; p = p.parentElement) {
    if (NON_TRADUITS.has(p.tagName) || p.hasAttribute("data-i18n-html") || p.hasAttribute("data-i18n-skip")) return true;
  }
  return false;
}
function appliquerTexte(noeud) {
  let etat = ETAT_TEXTE.get(noeud);
  if (!etat && LANGUE !== "en") return;                       // en français, rien à suivre tant qu'aucune traduction n'a eu lieu
  if (dansZoneNonTraduite(noeud)) return;
  const fr = etat && noeud.nodeValue === etat.rendu ? etat.fr : noeud.nodeValue;   // texte modifié par le code : nouvel original
  const voulu = LANGUE === "en" ? traduire(fr) : fr;
  if (voulu !== noeud.nodeValue) noeud.nodeValue = voulu;
  ETAT_TEXTE.set(noeud, { fr, rendu: voulu });
}
function appliquerAttribut(el, nom) {
  const valeur = el.getAttribute(nom);
  if (valeur === null) return;
  el.__attributs = el.__attributs || {};
  let etat = el.__attributs[nom];
  if (!etat && LANGUE !== "en") return;
  const fr = etat && valeur === etat.rendu ? etat.fr : valeur;
  const voulu = LANGUE === "en" ? traduire(fr) : fr;
  if (voulu !== valeur) el.setAttribute(nom, voulu);
  el.__attributs[nom] = { fr, rendu: voulu };
}
function appliquerBloc(el) {
  if (el.__blocFr === undefined) el.__blocFr = el.innerHTML;
  if (el.__blocLangue === LANGUE) return;
  const en = EN_BLOCS[el.getAttribute("data-i18n-html")];
  el.innerHTML = LANGUE === "en" && en ? en : el.__blocFr;
  el.__blocLangue = LANGUE;
}
// Traduit (ou restaure en français) un élément et tout ce qu'il contient.
function traduirePage(racine = document.body) {
  if (racine.nodeType === 3) return appliquerTexte(racine);
  const elements = [racine, ...racine.querySelectorAll("*")];
  elements.filter((el) => el.hasAttribute && el.hasAttribute("data-i18n-html")).forEach(appliquerBloc);
  const marcheur = document.createTreeWalker(racine, NodeFilter.SHOW_TEXT);
  const noeuds = [];
  while (marcheur.nextNode()) noeuds.push(marcheur.currentNode);
  noeuds.forEach(appliquerTexte);
  for (const el of elements) for (const nom of ATTRIBUTS) if (el.hasAttribute && el.hasAttribute(nom)) appliquerAttribut(el, nom);
}

let occupe = false;
const observateur = new MutationObserver((mutations) => {
  if (occupe) return;
  occupe = true;
  try {
    for (const m of mutations) {
      if (m.type === "childList") m.addedNodes.forEach((n) => { if (n.nodeType === 1 || n.nodeType === 3) traduirePage(n); });
      else if (m.type === "attributes") appliquerAttribut(m.target, m.attributeName);
    }
  } finally { observateur.takeRecords(); occupe = false; }
});
observateur.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ATTRIBUTS });

function changerLangue(langue) {
  if (langue !== "fr" && langue !== "en") return;
  LANGUE = langue;
  try { localStorage.setItem(CLE_LANGUE, langue); } catch { /* sans importance */ }
  document.documentElement.lang = langue;
  occupe = true;
  try { traduirePage(document.body); } finally { observateur.takeRecords(); occupe = false; }
  document.querySelectorAll(".drapeau").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.langue === langue)));
  if (typeof window.surChangementLangue === "function") window.surChangementLangue(langue);
}
document.querySelectorAll(".langues .drapeau").forEach((b) => b.addEventListener("click", () => changerLangue(b.dataset.langue)));
changerLangue(LANGUE);
