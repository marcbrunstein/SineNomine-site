"""Licence d'évaluation : activation par clé d'accès (pendant l'installation) puis vérification hors ligne.

La clé d'accès est validée une seule fois par le serveur d'activation de Habeas Corpus S.A.S., qui renvoie une licence
signée (Ed25519) : identifiant d'installation, date d'activation, date de fin. L'application ne contient que la clé
publique ; elle vérifie la signature et la date sur l'ordinateur, sans aucune connexion. Seuls l'activation et la
vérification de clé (`--activer`, `--verifier-cle`, lancées par l'installateur) utilisent le réseau, et ne transmettent ni
document ni nom : la clé, un identifiant d'installation aléatoire, la version et la langue.

Ce mécanisme encadre l'évaluation ; il ne prétend pas résister à une personne qui modifierait le code (voir LICENCE.md).
"""

import base64
import json
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from . import VERSION, config as cfg

CLE_PUBLIQUE = "14782b72bb67f0709afdda2f78e426e554cdd8db079e54d99e81dd7369238736"
SERVEUR_PAR_DEFAUT = "https://activation.sinenomine.app"
FICHIER_LICENCE = cfg.RACINE / "licence.json"
FICHIER_INSTALLATION = cfg.RACINE / "installation.id"
FICHIER_ETAT = cfg.RACINE / "licence.etat"          # dernier instant vu : détecte une horloge remise en arrière
TOLERANCE_HORLOGE = timedelta(days=1)
FORMAT_DATE = "%Y-%m-%dT%H:%M:%SZ"


class LicenceErreur(Exception):
    """Message destiné à l'utilisateur (activation impossible : clé refusée, serveur injoignable…)."""


def _maintenant():
    return datetime.now(timezone.utc).replace(microsecond=0)


def _date(texte):
    return datetime.strptime(texte, FORMAT_DATE).replace(tzinfo=timezone.utc)


def _canonique(donnees):
    return json.dumps(donnees, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def signature_valide(licence, signature, publique_hex=None):
    try:
        brut = base64.urlsafe_b64decode(signature + "=" * (-len(signature) % 4))
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(publique_hex or CLE_PUBLIQUE)).verify(brut, _canonique(licence))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def identifiant_installation(creer=True):
    """Identifiant aléatoire de cette installation (sans lien avec le matériel, le nom ou les fichiers)."""
    try:
        valeur = FICHIER_INSTALLATION.read_text(encoding="ascii").strip()
        if str(uuid.UUID(valeur)) == valeur:
            return valeur
    except (OSError, ValueError):
        pass
    if not creer:
        return None
    valeur = str(uuid.uuid4())
    FICHIER_INSTALLATION.write_text(valeur + "\n", encoding="ascii")
    return valeur


def _lire_licence():
    try:
        donnees = json.loads(FICHIER_LICENCE.read_text(encoding="utf-8"))
        return donnees["licence"], donnees["signature"]
    except (OSError, ValueError, KeyError, TypeError):
        return None, None


def _horloge_en_retard(maintenant):
    """Vrai si l'horloge est en retard de plus d'un jour sur le dernier instant vu ; sinon mémorise l'instant."""
    try:
        dernier = _date(json.loads(FICHIER_ETAT.read_text(encoding="utf-8"))["dernier"])
    except (OSError, ValueError, KeyError, TypeError):
        dernier = None
    if dernier is not None and maintenant < dernier - TOLERANCE_HORLOGE:
        return True
    if dernier is None or maintenant - dernier > timedelta(minutes=10):
        try:
            FICHIER_ETAT.write_text(json.dumps({"dernier": maintenant.strftime(FORMAT_DATE)}), encoding="utf-8")
        except OSError:
            pass
    return False


def etat(config=None, maintenant=None):
    """{statut, expire_le, jours_restants, active_le} ; statut : active, expiree, absente, invalide, horloge, non_requise."""
    if config is not None and config.get("licence_requise") is False:
        return {"statut": "non_requise", "expire_le": None, "jours_restants": None, "active_le": None}
    maintenant = maintenant or _maintenant()
    licence, signature = _lire_licence()
    if licence is None:
        return {"statut": "absente", "expire_le": None, "jours_restants": None, "active_le": None}
    try:
        if not signature_valide(licence, signature) or licence["install_id"] != identifiant_installation(creer=False):
            return {"statut": "invalide", "expire_le": None, "jours_restants": None, "active_le": None}
        fin, debut = _date(licence["expire_le"]), _date(licence["active_le"])
    except (KeyError, ValueError, TypeError):
        return {"statut": "invalide", "expire_le": None, "jours_restants": None, "active_le": None}
    resultat = {"expire_le": licence["expire_le"][:10], "active_le": licence["active_le"][:10]}
    if _horloge_en_retard(maintenant) or maintenant < debut - TOLERANCE_HORLOGE:
        return {**resultat, "statut": "horloge", "jours_restants": None}
    if maintenant >= fin:
        return {**resultat, "statut": "expiree", "jours_restants": 0}
    jours = max(-(-int((fin - maintenant).total_seconds()) // 86400), 1)          # arrondi au jour supérieur
    return {**resultat, "statut": "active", "jours_restants": jours}


def autorise(config=None):
    """Vrai si l'on peut anonymiser ou pseudonymiser des fichiers (licence active, ou non exigée)."""
    return etat(config)["statut"] in ("active", "non_requise")


# ---------------------------------------------------------------- réseau : uniquement pendant l'installation

def _appel(chemin, corps, serveur=None):
    adresse = (serveur or SERVEUR_PAR_DEFAUT).rstrip("/") + chemin
    requete = urllib.request.Request(adresse, data=json.dumps(corps).encode("utf-8"),
                                     headers={"Content-Type": "application/json", "User-Agent": f"SineNomine/{VERSION}"})
    try:
        with urllib.request.urlopen(requete, timeout=20) as reponse:
            return json.load(reponse)
    except urllib.error.HTTPError as e:       # le serveur répond par un message explicite (clé inconnue, épuisée…)
        try:
            donnees = json.load(e)
        except ValueError:
            donnees = {}
        raise LicenceErreur(donnees.get("message") or f"Le serveur d'activation a refusé la demande (code {e.code}).") from None
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise LicenceErreur("Connexion au serveur d'activation impossible : vérifiez votre connexion Internet, "
                            f"puis recommencez ({type(e).__name__}).") from None


def verifier_cle(cle, langue="fr", serveur=None):
    """Interroge le serveur sans consommer d'installation : {valide, restantes, duree_jours, message}."""
    return _appel("/api/v1/verifier", {"cle": cle, "langue": langue}, serveur)


def activer(cle, langue="fr", serveur=None):
    """Active cette installation : écrit la licence signée et renvoie la réponse du serveur."""
    identifiant = identifiant_installation()
    reponse = _appel("/api/v1/activer", {"cle": cle, "install_id": identifiant, "version": VERSION, "langue": langue}, serveur)
    licence, signature = reponse.get("licence"), reponse.get("signature", "")
    if not licence or not signature_valide(licence, signature) or licence.get("install_id") != identifiant:
        raise LicenceErreur("La réponse du serveur d'activation n'est pas authentique : licence refusée.")
    FICHIER_LICENCE.write_text(json.dumps({"licence": licence, "signature": signature}, indent=2), encoding="utf-8")
    FICHIER_ETAT.write_text(json.dumps({"dernier": _maintenant().strftime(FORMAT_DATE)}), encoding="utf-8")
    return reponse
