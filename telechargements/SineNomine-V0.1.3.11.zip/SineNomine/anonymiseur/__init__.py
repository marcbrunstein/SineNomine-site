"""Sine Nomine — anonymiseur de fichiers local. © Habeas Corpus Consulting, marque de Habeas Corpus S.A.S."""

VERSION = "0.1.3.11"
