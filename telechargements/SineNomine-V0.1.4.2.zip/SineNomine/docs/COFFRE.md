# Coffre chiffré, publication récupérable et migration (étape 2)

Ce document décrit ce que fait réellement Sine Nomine depuis la V0.1.4.2, et ses limites. Il ne promet ni certification ni
garantie d'anonymat.

## 1. Ce que le coffre protège

Le coffre (`coffre.db`, dossier `coffre` du profil de l'utilisateur : `%LOCALAPPDATA%\SineNomine\coffre`) contient :

| Donnée | Stockage |
|---|---|
| Identités (nom d'origine, variantes, lots) | chiffrées, champ par champ |
| Valeurs sensibles (e-mails, téléphones, IBAN…) | chiffrées |
| Refus de détection | formes chiffrées |
| Détail des lots et état de publication (chemins) | chiffrés |
| Historique (création, lots, sauvegardes, migration, exports) | chiffré et chaîné |

**Métadonnées visibles** dans le fichier : noms des tables, nombre de lignes, catégorie (personne, société…), code de pseudonyme
(`Personne_KQXMB`), identifiants aléatoires de lots et de lignes, dates, états de lot, tailles des champs chiffrés, index aveugles
(HMAC : ils permettent de retrouver une identité à qui détient la clé, sans révéler le nom). **Jamais** en clair : noms, valeurs
sensibles, passages, listes, clés.

## 2. Cryptographie (aucune construction maison)

- **Chiffrement authentifié** : AES-256-GCM (bibliothèque `cryptography`). L'additional data de chaque champ contient l'identifiant
  du coffre, la table, la colonne et l'identifiant de ligne : un champ modifié, ou copié sur une autre ligne, est détecté.
- **Dérivation** : une clé de données de 32 octets aléatoires ; trois sous-clés (champs, index, historique) dérivées par HKDF-SHA256.
- **Protection de la clé de données** : (a) DPAPI de Windows (compte utilisateur de cet ordinateur) ; (b) facultativement, une
  **phrase de récupération** : clé dérivée par scrypt (N=2^15, r=8, p=1) qui enveloppe la clé de données avec AES-256-GCM.
  Aucune clé en clair n'est écrite à côté du coffre ; aucun fichier temporaire en clair n'est créé pour contourner le chiffrement.
- **Verrouillage** : `Coffre.verrouiller()` oublie les clés en mémoire (Python ne garantit pas l'effacement physique de la mémoire).

## 3. Perte d'accès et récupération

| Situation | Conséquence |
|---|---|
| Compte Windows ou ordinateur perdu, sans phrase | **Coffre définitivement illisible** : il n'existe aucune porte dérobée |
| Phrase de récupération conservée | Ouverture sur un autre compte ou ordinateur (`ouvrir_avec_phrase`) |
| Phrase perdue, compte Windows intact | Le coffre s'ouvre ; en créer une nouvelle (Outils, Coffre chiffré) |
| Fichier altéré ou clé fausse | Erreur claire (« Donnée altérée ou clé incorrecte… »), le coffre n'est pas utilisé ; restaurer une sauvegarde |

**Sauvegarde portable chiffrée** : `Coffre.sauvegarder(fichier, phrase)` (Outils, « Créer une sauvegarde chiffrée »). Le fichier
`.sncoffre` contient une copie cohérente de la base et la clé de données, chiffrées ensemble par la phrase (AES-256-GCM, scrypt).
`Coffre.restaurer(fichier, phrase, dossier)` recrée un coffre, vérifié avant d'être accepté. Elle refuse d'écraser un coffre existant.

**Intégrité** : `Coffre.verifier()` (Outils, « Vérifier l'intégrité ») contrôle la base SQLite, déchiffre et authentifie chaque champ,
vérifie la chaîne de l'historique (modification ou retrait d'un événement du milieu détectés). Elle ne détecte **pas** un retour à
une ancienne copie complète du coffre (rollback).

## 4. Transactions et concurrence

- SQLite en mode WAL, `synchronous=FULL`, clés étrangères, contraintes d'unicité (code par périmètre ; identité par catégorie et
  index aveugle ; suffixe de code par périmètre).
- Toute écriture : `BEGIN IMMEDIATE` (un seul écrivain à la fois, entre threads **et** processus), tout ou rien.
- **Allocation d'un code** : transaction courte et durable ; deux lots simultanés qui rencontrent le même nom obtiennent le même code.
- **Enregistrement d'un lot** : fusion avec l'état courant (réunion des variantes, des lots et des valeurs) au lieu d'un écrasement :
  l'ancien défaut (chaque lot chargeait l'archive puis l'écrasait) n'existe plus.
- Erreurs d'écriture (disque plein, base occupée) : message clair, transaction annulée.

## 5. Publication récupérable d'un lot

Une transaction de base ne couvre pas les fichiers. Protocole (`anonymiseur/publication.py`) :

1. le lot est déclaré dans le coffre (« en_cours ») et ses codes sont réservés durablement ;
2. les résultats sont écrits dans un dossier provisoire voisin de la destination (`.sn-en-cours-<lot>`, même disque) ;
3. contrôle : chaque résultat attendu existe et n'est pas vide ; manifeste SHA-256 de tous les fichiers ;
4. correspondances définitives enregistrées dans le coffre, lot « pret » avec son manifeste ;
5. publication : un renommage atomique du dossier (destination nouvelle) ou un déplacement fichier par fichier, sans écrasement ;
6. lot « publie ».

**Reprise au démarrage** : « en_cours » → dossier provisoire supprimé, lot « abandonne » ; « pret » → si le manifeste correspond encore,
la publication est terminée, sinon abandon. Les codes réservés par un lot abandonné restent inoffensifs. Un résultat incomplet n'est
jamais présenté comme réussi.

**Limites** : un renommage de dossier est atomique sur un même disque ; le déplacement fichier par fichier (destination existante)
ne l'est pas, mais il est repris au démarrage. Un arrêt brutal de l'ordinateur peut laisser un dossier provisoire jusqu'au démarrage
suivant. Le mode « Remplacement sans conservation des correspondances » suit le même protocole ; seul l'état du lot (sans nom) est enregistré.

## 6. Migration de l'archive historique (JSON en clair)

Au premier usage du coffre, `archive_codes.json` est migré **sans rien détruire** :

1. copie de sécurité `archive_codes.avant-migration-AAAAMMJJ-HHMMSS.json`, empreinte SHA-256 vérifiée ;
2. validation : JSON lisible, codes bien formés, catégories connues, aucune identité ni valeur sous deux codes, suffixes uniques ;
3. import en **une transaction** dans le périmètre « historique », avec relecture et comparaison de chaque entrée avant validation :
   la moindre différence annule tout (rien n'est importé) ;
4. enregistrement du compte rendu (empreinte, comptes) et d'un événement dans l'historique.

Elle est **relançable sans doublons**. Les anciennes données ne sont pas rattachées à un client. Retour arrière : l'original est intact
(l'ancienne version du programme le lit toujours) ; `exporter_json` exporte le coffre au format historique, **en clair**, sur action explicite.
Les copies en clair (archive JSON, `.bak`, tables Excel) ne sont supprimées qu'après **accord explicite** (Outils, Coffre chiffré) et
seulement si la migration est enregistrée. La suppression ne garantit **pas** l'effacement physique (disques SSD, copies de synchronisation,
corbeille, sauvegardes).

## 7. Table de correspondance en clair

Elle n'est plus écrite à chaque lot. Un **export explicite** (bouton de l'écran de résultat, avec confirmation) crée
`<lot>_correspondances_CONFIDENTIEL.xlsx`. Il n'est pas nécessaire à la restauration : le coffre suffit.

## 8. Ce qui n'est pas encore fait (étapes suivantes)

Périmètres Document / Projet / Client (le périmètre « historique » est déjà la base), phrase de récupération exigée à la création,
sauvegarde du travail en cours de validation, historique des corrections, stockage des listes confidentielles dans le coffre, emplacement
des dépôts et résultats hors du dossier du programme, nettoyage configurable des dépôts et aperçus.
