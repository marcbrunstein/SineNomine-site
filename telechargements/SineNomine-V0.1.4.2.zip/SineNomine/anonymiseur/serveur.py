"""Serveur web local (127.0.0.1 uniquement) qui sert l'interface et pilote les lots."""

import os
from datetime import datetime
import subprocess
import sys
import threading
from pathlib import Path

from flask import Flask, Response, abort, jsonify, redirect, request, send_from_directory
from werkzeug.utils import safe_join

import shutil
import tempfile

from . import VERSION, chemins, config as cfg, correction, formats, licence, migration, pdf, publication, restauration, sensibles, textes
from .coffre import CoffreErreur
from .detection import CATEGORIES_ENTITES
from .securite import (CSP_APPLICATION, CSP_DOCUMENT_ISOLE, METHODES_ECRITURE, PUBLICS, Securite)
from .lots import LOTS, MODES, Lot, ajouter_au_dictionnaire, fichiers_du_dossier, maintenant

STATIQUE = Path(__file__).resolve().parent / "static"
RESTAURATIONS = {}   # identifiant -> dossier de sortie d'une désanonymisation
DICTIONNAIRES = {"personne": "personnes.txt", "societe": "societes.txt", "produit": "produits.txt",
                 "lieu": "lieux.txt"}
# Listes modifiables dans Outils : nom -> (fichier, libellé)
LISTES = {"exclusions": ("exclusions.txt", "Mots exclus (jamais détectés)"),
          "personnes": ("personnes.txt", "Personnes à toujours détecter"),
          "societes": ("societes.txt", "Sociétés à toujours détecter"),
          "produits": ("produits.txt", "Produits et marques à toujours détecter"),
          "lieux": ("lieux.txt", "Lieux à toujours détecter")}
ACTIONS_VALIDES = {"conserver", "pseudonymiser", "supprimer"}


def ouvrir_dans_explorateur(chemin):
    """Ouvre le dossier dans l'Explorateur, puis amène sa fenêtre au premier plan.

    Windows laisse un programme en arrière-plan (le serveur) ouvrir une fenêtre, mais pas
    la placer devant le navigateur : elle s'ouvrirait cachée derrière.
    """
    if sys.platform == "win32":
        os.startfile(chemin)  # noqa: S606 — ouverture locale dans l'Explorateur
        threading.Thread(target=_premier_plan, args=(Path(chemin).name,), daemon=True).start()
        return
    # macOS : « open » ; Linux : le gestionnaire de fichiers du bureau, ou l'Explorateur de Windows sous WSL.
    if sys.platform == "darwin":
        commandes = [["open", str(chemin)]]
    else:
        commandes = [["xdg-open", str(chemin)], ["wslview", str(chemin)], ["explorer.exe", str(chemin)]]
    for commande in commandes:
        if shutil.which(commande[0]):
            subprocess.Popen(commande, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  # noqa: S603
            return


def _premier_plan(titre):
    import ctypes
    import time
    from ctypes import wintypes

    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    rappel_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    for _ in range(40):  # la fenêtre peut mettre un moment à apparaître (jusqu'à 4 s)
        time.sleep(0.1)
        trouvees = []

        def rappel(hwnd, _):
            classe = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(hwnd, classe, 64)
            if classe.value == "CabinetWClass":
                longueur = user32.GetWindowTextLengthW(hwnd)
                texte = ctypes.create_unicode_buffer(longueur + 1)
                user32.GetWindowTextW(hwnd, texte, longueur + 1)
                if titre in texte.value:
                    trouvees.append(hwnd)
            return True

        user32.EnumWindows(rappel_type(rappel), 0)
        if trouvees:
            fenetre = trouvees[0]  # la plus haute dans l'ordre d'affichage : celle qu'on vient d'ouvrir
            # S'attacher au fil de la fenêtre active permet de lui « passer la main ».
            active = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
            courant = kernel32.GetCurrentThreadId()
            user32.AttachThreadInput(courant, active, True)
            user32.ShowWindow(fenetre, 9)  # SW_RESTORE : la ressort si elle est réduite
            user32.BringWindowToTop(fenetre)
            user32.SetForegroundWindow(fenetre)
            user32.AttachThreadInput(courant, active, False)
            return


REFUS_LICENCE = {
    "absente": "Sine Nomine n'est pas activé. Saisissez votre clé d'accès. Pour en obtenir une : contact@sinenomine.app.",
    "invalide": "La licence est invalide. Saisissez à nouveau votre clé d'accès.",
    "horloge": "L'horloge de l'ordinateur est en retard sur la dernière utilisation : corrigez la date et l'heure.",
    "expiree": "Votre licence a expiré. Saisissez un nouveau code d'activation. La dé-pseudonymisation de vos fichiers "
               "reste possible.",
}


def _resume_archive(config):
    try:
        return restauration.charger_archive(config).resume()
    except CoffreErreur as e:
        return {"entites": 0, "sensibles": 0, "chemin": None, "erreur": str(e)}


def _enregistrer_depots(envois, base, extensions):
    """Enregistre les fichiers reçus sous `base`, avec des noms validés et confinés (voir chemins.py).

    Renvoie ([(chemin, nom relatif)], [noms ignorés]). Un nom invalide ou une extension non prise en charge est ignoré ;
    deux fichiers de même nom (casse comprise) ne s'écrasent pas : le second reçoit « (2) ».
    """
    base = Path(base)
    base.mkdir(parents=True, exist_ok=True)
    fichiers, ignores = [], []
    for envoi in envois:
        try:
            relatif = chemins.nom_relatif_sur(envoi.filename)
            if Path(relatif).suffix.lower() not in extensions:
                ignores.append(relatif)
                continue
            destination = chemins.unique(chemins.confiner(base, relatif))
        except chemins.CheminInvalide:
            ignores.append("(nom de fichier invalide)")
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        envoi.save(destination)
        fichiers.append((destination, destination.relative_to(base.resolve()).as_posix()))
    return fichiers, ignores


def creer_application(config, modeles, securite=True):
    """`securite=False` : uniquement pour les tests unitaires de l'API (pas de session ni de jeton CSRF)."""
    app = Flask(__name__, static_folder=None)
    garde = Securite()
    app.extensions["securite"] = garde

    def refus_licence():
        """None si la licence permet de traiter des fichiers, sinon la réponse d'erreur (la dé-pseudonymisation reste libre)."""
        statut = licence.etat(config)["statut"]
        if statut in ("active", "non_requise"):
            return None
        return jsonify({"erreur": REFUS_LICENCE.get(statut, REFUS_LICENCE["invalide"]), "licence": statut}), 403

    app.config["MAX_CONTENT_LENGTH"] = None
    app.json.sort_keys = False  # garder l'ordre des catégories (Personnes, Sociétés, Produits…)

    # ------------------------------------------------------------------ sécurité du serveur local

    PAGE_REFUSEE = ("<!DOCTYPE html><meta charset=utf-8><title>Sine Nomine</title><body style='font-family:sans-serif;"
                    "padding:2rem'><h1>Sine Nomine</h1><p>Ouvrez Sine Nomine avec son raccourci ou « lancer.bat » : cette "
                    "adresse nécessite une session.</p><p>Open Sine Nomine with its shortcut or \"lancer.bat\": this "
                    "address requires a session.</p>")

    @app.before_request
    def controler_acces():
        if not securite:
            return None
        if not garde.hote_autorise(request.headers.get("Host")):
            return Response("Hôte non autorisé.", status=400, mimetype="text/plain")
        chemin = request.path
        if chemin == "/" and request.method == "GET":
            jeton = request.args.get("jeton")
            if jeton:
                if not garde.consommer_jeton(jeton):
                    return Response(PAGE_REFUSEE, status=403, mimetype="text/html")
                reponse = redirect("/", code=302)
                reponse.set_cookie("sn_session", garde.session, httponly=True, samesite="Strict", path="/")
                return reponse
        if chemin in PUBLICS or chemin.startswith("/static/"):
            return None
        if not garde.session_valide(request.cookies.get("sn_session")):
            if chemin == "/":
                return Response(PAGE_REFUSEE, status=403, mimetype="text/html")
            return jsonify({"erreur": "Session absente ou expirée : rouvrez Sine Nomine avec son raccourci."}), 401
        if request.method in METHODES_ECRITURE:
            if not garde.csrf_valide(request.headers.get("X-CSRF-Token")):
                return jsonify({"erreur": "Requête refusée (jeton de sécurité absent ou invalide)."}), 403
            if not garde.origine_valide(request.headers.get("Origin"), request.headers.get("Referer"),
                                        request.headers.get("Host"), request.headers.get("Sec-Fetch-Site")):
                return jsonify({"erreur": "Requête refusée (origine non autorisée)."}), 403
        return None

    @app.after_request
    def en_tetes(reponse):
        reponse.headers.setdefault("X-Content-Type-Options", "nosniff")
        reponse.headers.setdefault("Referrer-Policy", "no-referrer")
        reponse.headers.setdefault("X-Frame-Options", "DENY")
        reponse.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
        chemin = request.path
        if chemin.startswith("/api/") or chemin == "/":
            reponse.headers["Cache-Control"] = "no-store"
        if chemin == "/":
            reponse.headers["Content-Security-Policy"] = CSP_APPLICATION
        elif "/sortie/" in chemin or "/api/restaurations/" in chemin:
            # un document HTML produit (rapport) n'est jamais exécuté avec les droits de l'application
            reponse.headers["Content-Security-Policy"] = CSP_DOCUMENT_ISOLE
        return reponse

    @app.get("/api/ping")
    def ping():
        """Seule route sans session : permet à un second lancement de savoir qu'une instance tourne déjà."""
        return jsonify({"version": VERSION})

    @app.post("/api/instance/jeton")
    def jeton_instance():
        """Nouveau jeton d'ouverture pour un second lancement ; exige le secret écrit dans instance.json."""
        if not garde.secret_instance_valide(request.headers.get("X-Instance-Secret")):
            return jsonify({"erreur": "Secret invalide."}), 403
        return jsonify({"jeton": garde.nouveau_jeton()})

    @app.get("/")
    def accueil():
        page = (STATIQUE / "index.html").read_text(encoding="utf-8").replace("__CSRF__", garde.csrf)
        return Response(page, mimetype="text/html")

    @app.get("/licences")
    def licences():
        """Licences des composants tiers (fichier THIRD_PARTY_NOTICES.md), affichées en texte brut."""
        chemin = cfg.RACINE / "THIRD_PARTY_NOTICES.md"
        if not chemin.exists():
            abort(404)
        return Response(chemin.read_text(encoding="utf-8"), mimetype="text/plain; charset=utf-8")

    @app.get("/static/<path:nom>")
    def statique(nom):
        return send_from_directory(STATIQUE, nom)

    @app.get("/api/etat")
    def etat():
        return jsonify({
            "version": VERSION,
            "modeles": {"etat": modeles.etat, "pret": modeles.pret, "erreurs": modeles.erreurs,
                        "gliner": modeles.gliner is not None},
            "avertissement": textes.avertissement(),
            "avertissements": {langue: textes.avertissement(langue) for langue in textes.LANGUES},
            "categories_entites": CATEGORIES_ENTITES,
            "categories_sensibles": sensibles.CATEGORIES,
            "actions_par_defaut": config["actions_par_defaut"],
            "listes": {nom: libelle for nom, (_, libelle) in LISTES.items()},
            "images_par_defaut": config["images_par_defaut"],
            "mode_par_defaut": config["mode_par_defaut"],
            "seuil": config["seuil_preselection"],
            "dossiers": {nom: str(cfg.dossier(config, nom)) for nom in config["dossiers"]},
            "extensions": sorted(formats.EXTENSIONS),
            "extensions_entree": sorted(formats.EXTENSIONS_ENTREE),
            "pdf": {"formats": list(pdf.FORMATS_SORTIE), "format_defaut": config.get("pdf_format_sortie", pdf.FORMAT_DEFAUT),
                    "ocr": pdf.etat_ocr(config)},
            "archive": _resume_archive(config),
            "coffre": migration.etat_coffre(config),
            "licence": licence.etat(config),
        })

    def _lot(identifiant):
        lot = LOTS.get(identifiant)
        if lot is None:
            abort(404)
        return lot

    @app.post("/api/lots")
    def creer_lot():
        if (refus := refus_licence()) is not None:
            return refus
        accepte = request.form.get("avertissement_accepte")
        if not accepte:
            return jsonify({"erreur": "L'avertissement doit être accepté avant tout traitement."}), 400
        dossier_sortie = request.form.get("dossier_sortie", "").strip() or None
        dossier = request.form.get("dossier", "").strip().strip('"')
        envois = request.files.getlist("fichiers")
        mode = request.form.get("mode") or config["mode_par_defaut"]
        langue = textes.langue_valide(request.form.get("langue"))
        format_pdf = request.form.get("format_pdf") or None
        if format_pdf is not None and format_pdf not in pdf.FORMATS_SORTIE:
            return jsonify({"erreur": f"Format de sortie inconnu : {format_pdf}"}), 400
        if mode not in MODES:
            return jsonify({"erreur": f"Mode inconnu : {mode}"}), 400

        if envois:
            lot = Lot(config, modeles, [], [], accepte, dossier_sortie, mode, langue, format_pdf)
            depot = cfg.dossier(config, "entree") / lot.id
            lot.depot_copie = depot
            ignores = []
            lot.fichiers, lot.ignores = _enregistrer_depots(envois, depot, formats.EXTENSIONS_ENTREE)
        elif dossier:
            if not Path(dossier).is_dir():
                return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
            fichiers, ignores = fichiers_du_dossier(dossier)
            lot = Lot(config, modeles, fichiers, ignores, accepte, dossier_sortie, mode, langue, format_pdf)
        else:
            return jsonify({"erreur": "Déposez des fichiers ou indiquez un dossier à traiter."}), 400

        if not lot.fichiers:
            del LOTS[lot.id]
            return jsonify({"erreur": "Aucun fichier à traiter (formats : " + ", ".join(sorted(formats.EXTENSIONS_ENTREE)) + ").",
                            "ignores": lot.ignores}), 400
        lot.avancement.total = len(lot.fichiers)
        lot.lancer_analyse()
        return jsonify({"id": lot.id})

    @app.post("/api/licence/activer")
    def activer_licence():
        """Active une clé d'accès saisie dans l'application (seule fonction qui se connecte à Internet en cours d'usage :
        elle n'envoie que la clé, l'identifiant d'installation, la version et la langue)."""
        corps = request.get_json(silent=True) or {}
        langue = "en" if request.headers.get("X-Langue", "fr").lower().startswith("en") else "fr"
        serveur = (config.get("licence") or {}).get("serveur") or licence.SERVEUR_PAR_DEFAUT
        try:
            reponse = licence.activer(str(corps.get("cle", "")), langue, serveur)
        except licence.LicenceErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"message": reponse["message"], "licence": licence.etat(config)})

    @app.get("/api/lots/<identifiant>")
    def lire_lot(identifiant):
        return jsonify(_lot(identifiant).vers_dict())

    @app.post("/api/lots/<identifiant>/valider")
    def valider(identifiant):
        if (refus := refus_licence()) is not None:
            return refus
        lot = _lot(identifiant)
        choix = request.get_json(force=True)
        if lot.etat != "a_valider":
            return jsonify({"erreur": "Ce lot n'est pas en attente de validation."}), 409
        if not choix.get("verification_confirmee"):
            return jsonify({"erreur": "Confirmez avoir vérifié les détections."}), 400
        lot.valider(choix)
        return jsonify({"ok": True})

    @app.post("/api/lots/<identifiant>/extraits")
    def extraits(identifiant):
        lot = _lot(identifiant)
        corps = request.get_json(force=True) or {}
        variantes = corps.get("variantes")
        if not isinstance(variantes, list):
            return jsonify({"erreur": "Indiquez les variantes à rechercher."}), 400
        return jsonify(lot.extraits(variantes, corps.get("mots", 15)))

    @app.get("/api/lots/<identifiant>/sortie/<path:chemin>")
    def fichier_sortie(identifiant, chemin):
        lot = _lot(identifiant)
        if safe_join(str(lot.dossier_sortie), chemin) is None:
            abort(404)
        return send_from_directory(lot.dossier_sortie, chemin)

    @app.get("/api/lots/<identifiant>/apercu/<int:index>")
    def apercu_image(identifiant, index):
        taille = min(max(request.args.get("taille", 320, type=int), 64), 2000)
        mini = _lot(identifiant).apercu(index, taille)
        if mini is None:
            abort(404)
        return Response(mini[0], mimetype=mini[1], headers={"Cache-Control": "private, max-age=3600"})

    @app.post("/api/lots/<identifiant>/ouvrir")
    def ouvrir(identifiant):
        lot = _lot(identifiant)
        cible = request.get_json(force=True).get("cible")
        if cible != "sortie" and not lot.fichier_correspondances:
            return jsonify({"erreur": "Aucune table de correspondance : ce lot a été anonymisé sans rien conserver."}), 400
        chemin = lot.dossier_sortie if cible == "sortie" else Path(lot.fichier_correspondances).parent
        ouvrir_dans_explorateur(chemin)
        return jsonify({"ok": True})

    @app.post("/api/lots/<identifiant>/exporter-correspondances")
    def exporter_correspondances(identifiant):
        """Export EN CLAIR de la table de correspondance : uniquement sur demande explicite et confirmée."""
        lot = _lot(identifiant)
        if not (request.get_json(silent=True) or {}).get("confirmation"):
            return jsonify({"erreur": "Confirmez l'export : le fichier contiendra les noms d'origine en clair."}), 400
        try:
            chemin = lot.exporter_correspondances()
        except ValueError as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"fichier": str(chemin)})

    # ------------------------------------------------------------------ coffre chiffré

    @app.get("/api/coffre")
    def etat_du_coffre():
        return jsonify(migration.etat_coffre(config))

    @app.post("/api/coffre/verifier")
    def verifier_le_coffre():
        try:
            return jsonify(migration.obtenir_coffre(config).verifier())
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/coffre/phrase")
    def phrase_de_recuperation():
        """Crée la phrase de récupération (affichée UNE SEULE fois). Remplacer une phrase existante demande une confirmation."""
        corps = request.get_json(silent=True) or {}
        try:
            coffre = migration.obtenir_coffre(config)
            if coffre.a_phrase() and not corps.get("remplacer"):
                return jsonify({"erreur": "Une phrase de récupération existe déjà. Confirmez pour la remplacer."}), 409
            return jsonify({"phrase": coffre.definir_phrase()})
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/coffre/sauvegarde")
    def sauvegarde_du_coffre():
        """Sauvegarde portable chiffrée par la phrase de récupération, dans le dossier de données de l'utilisateur."""
        corps = request.get_json(silent=True) or {}
        phrase = str(corps.get("phrase", ""))
        dossier = cfg.donnees_utilisateur() / "sauvegardes"
        fichier = dossier / f"coffre-{datetime.now():%Y%m%d-%H%M%S}.sncoffre"
        try:
            octets = migration.obtenir_coffre(config).sauvegarder(fichier, phrase)
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"fichier": str(fichier), "octets": octets})

    @app.post("/api/coffre/copies-en-clair/supprimer")
    def supprimer_copies_clair():
        """Supprime les anciens fichiers en clair (archive JSON, tables Excel) : accord explicite requis, migration vérifiée."""
        corps = request.get_json(silent=True) or {}
        try:
            supprimes = migration.supprimer_copies_en_clair(config, migration.obtenir_coffre(config),
                                                            accord_explicite=bool(corps.get("accord")))
        except CoffreErreur as e:
            return jsonify({"erreur": str(e)}), 400
        return jsonify({"supprimes": supprimes})

    @app.post("/api/restaurations")
    def desanonymiser():
        """Désanonymise des fichiers produits par Sine Nomine, à partir de l'archive des codes."""
        archive = restauration.charger_archive(config)
        if not archive.entites and not archive.sensibles:
            return jsonify({"erreur": "L'archive des codes est vide : aucun lot n'a encore été anonymisé "
                                      f"avec cette installation ({archive.chemin})."}), 400
        envois = request.files.getlist("fichiers")
        dossier = request.form.get("dossier", "").strip().strip('"')
        with tempfile.TemporaryDirectory(prefix="sine-nomine-") as temporaire:
            fichiers, ignores = [], []
            if envois:
                fichiers, ignores = _enregistrer_depots(envois, Path(temporaire), formats.EXTENSIONS)
            elif dossier:
                if not Path(dossier).is_dir():
                    return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
                fichiers, ignores = fichiers_du_dossier(dossier)
            if not fichiers:
                return jsonify({"erreur": "Aucun fichier à désanonymiser.", "ignores": ignores}), 400
            identifiant, dossier_sortie = restauration.nouveau_dossier(config)
            resultats = restauration.restaurer(archive, fichiers, dossier_sortie)
        RESTAURATIONS[identifiant] = dossier_sortie
        return jsonify({"id": identifiant, "dossier": str(dossier_sortie), "resultats": resultats,
                        "ignores": ignores})

    @app.get("/api/restaurations/<identifiant>/<path:chemin>")
    def fichier_restaure(identifiant, chemin):
        dossier = RESTAURATIONS.get(identifiant)
        if dossier is None or safe_join(str(dossier), chemin) is None:
            abort(404)
        return send_from_directory(dossier, chemin)

    @app.post("/api/restaurations/<identifiant>/ouvrir")
    def ouvrir_restauration(identifiant):
        dossier = RESTAURATIONS.get(identifiant)
        if dossier is None:
            abort(404)
        ouvrir_dans_explorateur(dossier)
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ menu : corriger des pseudonymes

    def _session(identifiant):
        session = correction.SESSIONS.get(identifiant)
        if session is None:
            abort(404)
        return session

    @app.post("/api/corrections")
    def creer_correction():
        if (refus := refus_licence()) is not None:
            return refus
        """Reçoit les fichiers déjà pseudonymisés à corriger (déposés ou indiqués par un dossier)."""
        envois = request.files.getlist("fichiers")
        dossier = request.form.get("dossier", "").strip().strip('"')
        fichiers, ignores, temporaire = [], [], None
        if envois:
            temporaire = Path(tempfile.mkdtemp(prefix="sine-nomine-correction-"))
            fichiers, ignores = _enregistrer_depots(envois, temporaire, formats.EXTENSIONS)
        elif dossier:
            if not Path(dossier).is_dir():
                return jsonify({"erreur": f"Dossier introuvable : {dossier}"}), 400
            fichiers, ignores = fichiers_du_dossier(dossier)
        if not fichiers:
            if temporaire:
                shutil.rmtree(temporaire, ignore_errors=True)
            return jsonify({"erreur": "Aucun fichier à corriger.", "ignores": ignores}), 400
        session = correction.creer_session(fichiers, temporaire)
        return jsonify({"id": session.id, "fichiers": [r for _, r in fichiers], "ignores": ignores})

    def _parametres_correction():
        donnees = request.get_json(force=True)
        return (donnees.get("regles", []), bool(donnees.get("automatique", True)),
                bool(donnees.get("prenoms_seuls", False)))

    @app.post("/api/corrections/<identifiant>/apercu")
    def apercu_correction(identifiant):
        try:
            return jsonify(correction.apercu(config, _session(identifiant), *_parametres_correction()))
        except correction.ErreurRegle as e:
            return jsonify({"erreur": str(e)}), 400

    @app.post("/api/corrections/<identifiant>/appliquer")
    def appliquer_correction(identifiant):
        if (refus := refus_licence()) is not None:
            return refus
        session = _session(identifiant)
        try:
            resultat = correction.appliquer(config, session, *_parametres_correction())
        except correction.ErreurRegle as e:
            return jsonify({"erreur": str(e)}), 400
        RESTAURATIONS[resultat["id"]] = Path(resultat["dossier"])      # mêmes liens de téléchargement que la restauration
        return jsonify(resultat)

    @app.delete("/api/corrections/<identifiant>")
    def annuler_correction(identifiant):
        _session(identifiant).nettoyer()
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ menu : consulter un pseudonyme

    @app.get("/api/pseudonymes")
    def consulter_pseudonymes():
        """Cherche dans l'archive un code (Personne_KQXMB) ou un nom d'origine. Affiche des données en clair."""
        archive = restauration.charger_archive(config)
        trouvees, tronque = archive.rechercher(request.args.get("q", ""))
        return jsonify({"resultats": trouvees, "tronque": tronque, "total_archive": archive.resume()})

    # ------------------------------------------------------------------ menu : outils

    def _chemin_liste(nom):
        if nom not in LISTES:
            abort(404)
        return cfg.dossier(config, "dictionnaires") / LISTES[nom][0]

    @app.get("/api/outils/listes")
    def listes():
        return jsonify({nom: libelle for nom, (_, libelle) in LISTES.items()})

    @app.get("/api/outils/listes/<nom>")
    def lire_liste(nom):
        chemin = _chemin_liste(nom)
        lignes = chemin.read_text(encoding="utf-8-sig").splitlines() if chemin.exists() else []
        termes = [l.strip() for l in lignes if l.strip() and not l.lstrip().startswith("#")]
        return jsonify({"nom": nom, "libelle": LISTES[nom][1], "termes": termes,
                        "commentaires": [l for l in lignes if l.lstrip().startswith("#")]})

    @app.put("/api/outils/listes/<nom>")
    def ecrire_liste(nom):
        chemin = _chemin_liste(nom)
        termes = request.get_json(force=True).get("termes", [])
        if not isinstance(termes, list):
            return jsonify({"erreur": "Liste de termes attendue."}), 400
        propres = list(dict.fromkeys(t.strip() for t in termes
                                     if isinstance(t, str) and t.strip() and not t.strip().startswith("#")))
        existant = chemin.read_text(encoding="utf-8-sig").splitlines() if chemin.exists() else []
        commentaires = [l for l in existant if l.lstrip().startswith("#")]   # les consignes en tête de fichier restent
        chemin.write_text("\n".join(commentaires + propres) + "\n", encoding="utf-8")
        return jsonify({"ok": True, "nombre": len(propres)})

    def _options_courantes():
        actions = {c: config["actions_par_defaut"].get(c, "conserver") for c in sensibles.CATEGORIES}
        return {"actions_par_defaut": actions, "images_par_defaut": config["images_par_defaut"],
                "mode_par_defaut": config["mode_par_defaut"], "lieux_preselectionnes": bool(config["lieux_preselectionnes"]),
                "seuil_preselection": config["seuil_preselection"]}

    @app.get("/api/outils/options")
    def lire_options():
        return jsonify(_options_courantes())

    @app.put("/api/outils/options")
    def ecrire_options():
        """Enregistre les options par défaut dans config.utilisateur.json (config.json reste intact)."""
        donnees = request.get_json(force=True)
        options = {}
        if "actions_par_defaut" in donnees:
            actions = donnees["actions_par_defaut"]
            if not isinstance(actions, dict) or any(c not in sensibles.CATEGORIES or a not in ACTIONS_VALIDES
                                                    for c, a in actions.items()):
                return jsonify({"erreur": "Actions invalides pour les informations sensibles."}), 400
            options["actions_par_defaut"] = actions
        if "images_par_defaut" in donnees:
            if donnees["images_par_defaut"] not in ("conserver", "supprimer"):
                return jsonify({"erreur": "Choix d'images invalide."}), 400
            options["images_par_defaut"] = donnees["images_par_defaut"]
        if "mode_par_defaut" in donnees:
            if donnees["mode_par_defaut"] not in MODES:
                return jsonify({"erreur": "Mode inconnu."}), 400
            options["mode_par_defaut"] = donnees["mode_par_defaut"]
        if "lieux_preselectionnes" in donnees:
            options["lieux_preselectionnes"] = bool(donnees["lieux_preselectionnes"])
        if "seuil_preselection" in donnees:
            try:
                seuil = float(donnees["seuil_preselection"])
            except (TypeError, ValueError):
                return jsonify({"erreur": "Seuil invalide."}), 400
            if not 0 <= seuil <= 1:
                return jsonify({"erreur": "Le seuil doit être compris entre 0 et 1."}), 400
            options["seuil_preselection"] = seuil
        cfg.enregistrer_utilisateur(config, options)
        return jsonify({"ok": True, **_options_courantes()})

    @app.post("/api/outils/archive/ouvrir")
    def ouvrir_archive():
        ouvrir_dans_explorateur(cfg.dossier(config, "correspondances"))
        return jsonify({"ok": True})

    @app.post("/api/quitter")
    def quitter():
        en_cours = [l.id for l in LOTS.values() if l.etat in ("analyse", "traitement")]
        if en_cours and not (request.get_json(silent=True) or {}).get("forcer"):
            return jsonify({"erreur": "Un traitement est en cours.", "en_cours": en_cours}), 409
        # Laisse le temps à la réponse de partir avant d'arrêter le processus.
        threading.Timer(0.5, os._exit, args=(0,)).start()
        return jsonify({"ok": True})

    @app.post("/api/dictionnaire")
    def dictionnaire():
        donnees = request.get_json(force=True)
        terme = (donnees.get("terme") or "").strip()
        if not terme:
            return jsonify({"erreur": "Terme vide."}), 400
        if donnees.get("liste") == "exclusions":
            ajouter_au_dictionnaire(config, "exclusions.txt", terme)
        elif donnees.get("liste") in DICTIONNAIRES:
            ajouter_au_dictionnaire(config, DICTIONNAIRES[donnees["liste"]], terme)
        else:
            return jsonify({"erreur": "Liste inconnue."}), 400
        return jsonify({"ok": True, "date": maintenant()})

    return app
