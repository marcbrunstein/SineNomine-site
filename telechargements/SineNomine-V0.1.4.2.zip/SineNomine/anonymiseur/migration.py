"""Obtention du coffre de l'application et migration de l'ancienne archive des codes (JSON en clair).

La migration est non destructive et relançable :
  1. copie de sécurité du fichier d'origine (empreinte SHA-256 vérifiée) ;
  2. validation complète de sa lisibilité et de sa cohérence (codes, catégories, doublons) ;
  3. import dans le coffre, périmètre « historique », en UNE transaction ; relecture et comparaison avant validation :
     la moindre différence annule tout ;
  4. enregistrement de l'opération (empreinte, comptes) dans le coffre et son historique.
Les anciens fichiers en clair ne sont JAMAIS supprimés ici : voir `supprimer_copies_en_clair` (accord explicite requis).
Retour arrière : le fichier d'origine reste intact (l'ancienne version du programme le lit toujours) ; les codes créés
depuis la migration peuvent être exportés avec `exporter_json` (export en clair, sur action explicite).
"""

import hashlib
import json
import re
import threading
from datetime import datetime
from pathlib import Path

from . import config as cfg, sensibles
from .archive import MOTIF_ENTITE, MOTIF_SENSIBLE, NOM_FICHIER
from .coffre import PERIMETRE_HISTORIQUE, Coffre, CoffreErreur, maintenant
from .detection import CATEGORIES_ENTITES
from .graphies import cle_nom

META_MIGRATION = "migration_historique"
_COFFRES = {}
_VERROU = threading.Lock()
RE_ENTITE = re.compile(f"^{MOTIF_ENTITE}$")
RE_SENSIBLE = re.compile(f"^{MOTIF_SENSIBLE}$")


class MigrationImpossible(CoffreErreur):
    """L'archive d'origine n'a pas pu être migrée : rien n'a été modifié (le message dit pourquoi)."""


def obtenir_coffre(config):
    """Le coffre de l'application (un seul objet par dossier et par processus), créé au premier usage."""
    dossier = cfg.dossier_coffre(config)
    with _VERROU:
        coffre = _COFFRES.get(str(dossier))
        if coffre is None or coffre.verrouille:
            coffre = Coffre.ouvrir(dossier) if Coffre.existe(dossier) else Coffre.creer(dossier)
            _COFFRES[str(dossier)] = coffre
        return coffre


def oublier_coffres():
    """Verrouille et oublie les coffres ouverts (tests, arrêt de l'application)."""
    with _VERROU:
        for coffre in _COFFRES.values():
            coffre.verrouiller()
        _COFFRES.clear()


def chemin_archive_json(config):
    return cfg.dossier(config, "correspondances") / NOM_FICHIER


def migrer_si_necessaire(config, coffre):
    """Migre l'ancienne archive au premier usage du coffre. Renvoie le compte rendu, ou None s'il n'y avait rien à faire."""
    if coffre.valeur_meta(META_MIGRATION):
        return None
    source = chemin_archive_json(config)
    if not source.exists():
        coffre.definir_meta(META_MIGRATION, json.dumps({"date": maintenant(), "source": None}))
        return None
    return migrer(source, coffre)


# ---------------------------------------------------------------- validation de l'archive d'origine

def valider(donnees):
    """Lève MigrationImpossible avec un message précis si l'archive d'origine est illisible ou incohérente."""
    if not isinstance(donnees, dict):
        raise MigrationImpossible("L'archive des codes n'a pas le format attendu (objet JSON).")
    entites, sensibles_, refuses = donnees.get("entites", {}), donnees.get("sensibles", {}), donnees.get("refuses", {})
    if not isinstance(entites, dict) or not isinstance(sensibles_, dict) or not isinstance(refuses, dict):
        raise MigrationImpossible("L'archive des codes est incomplète : sections « entites », « sensibles » ou « refuses » invalides.")
    vus = {}
    for code, fiche in entites.items():
        if not RE_ENTITE.match(code):
            raise MigrationImpossible(f"Code d'identité invalide dans l'archive : {code!r}.")
        if (not isinstance(fiche, dict) or fiche.get("categorie") not in CATEGORIES_ENTITES
                or not isinstance(fiche.get("canonique"), str) or not fiche["canonique"].strip()
                or not isinstance(fiche.get("variantes", []), list) or not isinstance(fiche.get("lots", []), list)):
            raise MigrationImpossible(f"Fiche invalide pour le code {code}.")
        cle = (fiche["categorie"], cle_nom(fiche["canonique"]))
        if cle in vus:
            raise MigrationImpossible(f"La même identité apparaît sous deux codes ({vus[cle]} et {code}) : "
                                      "corrigez l'archive avant la migration.")
        vus[cle] = code
    vus = {}
    for code, fiche in sensibles_.items():
        if not RE_SENSIBLE.match(code):
            raise MigrationImpossible(f"Code de valeur sensible invalide dans l'archive : {code!r}.")
        if (not isinstance(fiche, dict) or fiche.get("categorie") not in sensibles.CATEGORIES
                or not isinstance(fiche.get("cle"), str) or not isinstance(fiche.get("valeurs", []), list)
                or not isinstance(fiche.get("lots", []), list)):
            raise MigrationImpossible(f"Fiche invalide pour le code {code}.")
        cle = (fiche["categorie"], fiche["cle"])
        if cle in vus:
            raise MigrationImpossible(f"La même valeur sensible apparaît sous deux codes ({vus[cle]} et {code}).")
        vus[cle] = code
    for categorie, formes in refuses.items():
        if categorie not in CATEGORIES_ENTITES or not isinstance(formes, list) or not all(isinstance(f, str) for f in formes):
            raise MigrationImpossible(f"Refus de détection invalides pour la catégorie {categorie!r}.")
    suffixes = [c.rstrip("]")[-5:] for c in [*entites, *sensibles_]]
    if len(suffixes) != len(set(suffixes)):
        raise MigrationImpossible("Deux codes de l'archive partagent le même suffixe : archive incohérente.")


def _donnees_identite(fiche):
    return {"canonique": fiche["canonique"], "variantes": list(fiche.get("variantes", [])),
            "lots": list(fiche.get("lots", [])), "cree": fiche.get("cree")}


def _donnees_sensible(fiche):
    return {"cle": fiche["cle"], "valeurs": list(fiche.get("valeurs", [])), "lots": list(fiche.get("lots", []))}


def migrer(source, coffre):
    """Importe l'archive JSON `source` dans le périmètre « historique » du coffre. Voir l'en-tête du module."""
    source = Path(source)
    brut = source.read_bytes()
    empreinte = hashlib.sha256(brut).hexdigest()
    # 1. copie de sécurité vérifiée (jamais écrasée : un horodatage la rend unique)
    copie = source.with_name(f"{source.stem}.avant-migration-{datetime.now():%Y%m%d-%H%M%S}{source.suffix}")
    copie.write_bytes(brut)
    if hashlib.sha256(copie.read_bytes()).hexdigest() != empreinte:
        copie.unlink(missing_ok=True)
        raise MigrationImpossible("La copie de sécurité de l'archive n'est pas identique à l'original : migration annulée.")
    # 2. lisibilité et cohérence
    try:
        donnees = json.loads(brut.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        raise MigrationImpossible(f"L'archive des codes est illisible ({type(e).__name__}) : migration annulée. "
                                  f"L'original et sa copie de sécurité sont intacts ({copie.name}).") from e
    valider(donnees)
    # 3. import atomique et vérifié
    entites, sensibles_, refuses = donnees.get("entites", {}), donnees.get("sensibles", {}), donnees.get("refuses", {})
    ajoutes = {"identites": 0, "sensibles": 0, "refus": 0, "lots": 0}
    with coffre.ecriture() as c:
        for code, fiche in entites.items():
            if coffre.importer_dans(c, "identites", PERIMETRE_HISTORIQUE, code, fiche["categorie"], cle_nom(fiche["canonique"]),
                                    _donnees_identite(fiche)):
                ajoutes["identites"] += 1
        for code, fiche in sensibles_.items():
            if coffre.importer_dans(c, "sensibles", PERIMETRE_HISTORIQUE, code, fiche["categorie"], fiche["cle"],
                                    _donnees_sensible(fiche)):
                ajoutes["sensibles"] += 1
        for categorie, formes in refuses.items():
            for forme in formes:
                idx = coffre.indexer(PERIMETRE_HISTORIQUE, categorie, forme)
                if not c.execute("SELECT 1 FROM refus WHERE perimetre_id = ? AND categorie = ? AND idx = ?",
                                 (PERIMETRE_HISTORIQUE, categorie, idx)).fetchone():
                    import uuid
                    uid = uuid.uuid4().hex
                    c.execute("INSERT INTO refus (uid, perimetre_id, categorie, idx, donnees) VALUES (?, ?, ?, ?, ?)",
                              (uid, PERIMETRE_HISTORIQUE, categorie, idx, coffre._json_chiffre("refus", "donnees", uid, {"forme": forme})))
                    ajoutes["refus"] += 1
        lots = {lot for fiche in [*entites.values(), *sensibles_.values()] for lot in fiche.get("lots", [])}
        for lot in sorted(lots):
            cur = c.execute("INSERT OR IGNORE INTO lots (id, perimetre_id, mode, etat, debut, donnees) VALUES (?, ?, 'pseudonymisation', "
                            "'historique', ?, ?)", (lot, PERIMETRE_HISTORIQUE, maintenant(), coffre._json_chiffre("lots", "donnees", lot, {})))
            ajoutes["lots"] += cur.rowcount
        # relecture dans la même transaction : tout doit correspondre, sinon rien n'est enregistré
        for code, fiche in entites.items():
            ligne = c.execute("SELECT uid, donnees FROM identites WHERE perimetre_id = ? AND code = ?", (PERIMETRE_HISTORIQUE, code)).fetchone()
            if ligne is None or coffre._json_dechiffre("identites", "donnees", ligne[0], ligne[1]) != _donnees_identite(fiche):
                raise MigrationImpossible(f"Vérification échouée pour {code} : migration annulée, rien n'a été modifié.")
        for code, fiche in sensibles_.items():
            ligne = c.execute("SELECT uid, donnees FROM sensibles WHERE perimetre_id = ? AND code = ?", (PERIMETRE_HISTORIQUE, code)).fetchone()
            if ligne is None or coffre._json_dechiffre("sensibles", "donnees", ligne[0], ligne[1]) != _donnees_sensible(fiche):
                raise MigrationImpossible(f"Vérification échouée pour {code} : migration annulée, rien n'a été modifié.")
        compte = {"date": maintenant(), "source": source.name, "sha256": empreinte, "copie": copie.name,
                  "identites": len(entites), "sensibles": len(sensibles_), "ajoutes": ajoutes}
        c.execute("INSERT OR REPLACE INTO meta (cle, valeur) VALUES (?, ?)", (META_MIGRATION, json.dumps(compte)))
    coffre.journaliser("migration_archive", {"source": source.name, "sha256": empreinte, "identites": len(entites),
                                             "sensibles": len(sensibles_)})
    return compte


# ---------------------------------------------------------------- copies en clair, export, retour arrière

def etat_coffre(config):
    """État du coffre pour l'interface : existence, phrase de récupération, migration, copies en clair restantes, erreur."""
    resultat = {"dossier": None, "phrase_definie": False, "migration": None, "copies_en_clair": 0, "erreur": None}
    try:
        coffre = obtenir_coffre(config)
        migrer_si_necessaire(config, coffre)
        brut = coffre.valeur_meta(META_MIGRATION)
        resultat.update({"dossier": str(coffre.dossier), "phrase_definie": coffre.a_phrase(),
                         "migration": json.loads(brut) if brut else None,
                         "copies_en_clair": len(copies_en_clair(config))})
    except CoffreErreur as e:
        resultat["erreur"] = str(e)
    return resultat


def copies_en_clair(config):
    """Fichiers en clair de l'ancien fonctionnement : archive JSON, copies, tables Excel de correspondances."""
    dossier = cfg.dossier(config, "correspondances")
    return sorted([*dossier.glob("archive_codes*.json"), *dossier.glob("archive_codes*.bak"), *dossier.glob("*_correspondances.xlsx")])


def supprimer_copies_en_clair(config, coffre, accord_explicite=False):
    """Supprime les copies en clair, seulement si la migration est enregistrée ET après accord explicite.

    Ne garantit pas l'effacement physique (disques SSD, copies de synchronisation, corbeille) : voir la documentation."""
    if not accord_explicite:
        raise CoffreErreur("Suppression refusée : l'accord explicite de l'utilisateur est requis.")
    if not coffre.valeur_meta(META_MIGRATION):
        raise CoffreErreur("Suppression refusée : l'archive n'a pas été migrée et vérifiée.")
    supprimes = []
    for chemin in copies_en_clair(config):
        chemin.unlink(missing_ok=True)
        supprimes.append(chemin.name)
    coffre.journaliser("suppression_copies_en_clair", {"fichiers": len(supprimes)})
    return supprimes


def exporter_json(coffre, fichier, perimetre=PERIMETRE_HISTORIQUE):
    """Export EN CLAIR de l'archive au format JSON historique (retour arrière). À n'utiliser que sur action explicite."""
    donnees = {"version": 1, "entites": coffre.lire_table("identites", perimetre), "sensibles": coffre.lire_table("sensibles", perimetre),
               "refuses": coffre.lire_refus(perimetre)}
    Path(fichier).write_text(json.dumps(donnees, ensure_ascii=False, indent=1), encoding="utf-8")
    coffre.journaliser("export_clair", {"perimetre": perimetre})
    return len(donnees["entites"]) + len(donnees["sensibles"])
