"""Correction d'une pseudonymisation (re-pseudonymisation).

Complète des fichiers DÉJÀ pseudonymisés par Sine Nomine, dans lesquels des noms sont restés :
- automatiquement : tous les noms connus de l'archive (nom, variantes, avec ou sans accents, graphies étrangères,
  séparateurs de noms de fichiers), et, si on le demande, les prénoms seuls des personnes connues ;
- à la main : des règles « ce texte est une variante de tel pseudonyme » ou « ce texte est une nouvelle personne,
  société, produit ou lieu ».

Les fichiers de départ ne sont jamais modifiés. Un aperçu montre ce qui changerait avant toute écriture.
Les nouvelles variantes et les nouveaux noms sont ajoutés à l'archive, pour les lots suivants.
"""

import re
import secrets
import shutil
from collections import Counter, defaultdict

from . import config as cfg, formats
from .archive import NOM_FICHIER, Archive
from .detection import CATEGORIES_ENTITES
from .entites import Entite, _decouper_nom
from .lots import Lot, maintenant
from .rapport import Journal
from .remplacement import Correspondances, contexte
from .restauration import nouveau_dossier

SESSIONS = {}          # identifiant -> Session : fichiers déposés, en attente d'aperçu ou d'application
CONTEXTES_PAR_REGLE = 3
LIGNES_AUTO_MAX = 60


class ErreurRegle(ValueError):
    """Règle de correction invalide (message destiné à l'utilisateur)."""


class Session:
    def __init__(self, fichiers, dossier_temp=None):
        self.id = "correction_" + secrets.token_hex(4)
        self.fichiers = fichiers                 # [(chemin, chemin relatif)]
        self.dossier_temp = dossier_temp         # copie des fichiers déposés : à effacer à la fin

    def nettoyer(self):
        if self.dossier_temp:
            shutil.rmtree(self.dossier_temp, ignore_errors=True)
        SESSIONS.pop(self.id, None)


def creer_session(fichiers, dossier_temp=None):
    session = Session(fichiers, dossier_temp)
    SESSIONS[session.id] = session
    return session


def charger_archive(config):
    return Archive.ouvrir(config)


def _entites_manuelles(archive, regles):
    """Entités tirées des règles saisies : (entités, libellés, descriptions). Crée au besoin un code dans `archive`."""
    entites, libelles, descriptions = [], {}, []
    for i, regle in enumerate(regles or []):
        texte = (regle.get("texte") or "").strip()
        if len(texte) < 2:
            raise ErreurRegle(f"Règle {i + 1} : le texte à remplacer est trop court.")
        lisible = re.sub(r"[_\s]+", " ", texte).strip()       # « Mila_Lin_an_Park » → « Mila Lin an Park »
        cible = regle.get("cible") or {}
        if cible.get("code"):
            code = cible["code"].strip()
            fiche = archive.entites.get(code)
            if fiche is None:
                raise ErreurRegle(f"Règle {i + 1} : le pseudonyme {code} n'existe pas dans l'archive.")
            categorie, canonique, nouveau = fiche["categorie"], fiche["canonique"], False
        else:
            categorie = cible.get("categorie")
            if categorie not in CATEGORIES_ENTITES:
                raise ErreurRegle(f"Règle {i + 1} : type inconnu ({categorie}).")
            canonique = (cible.get("nom") or lisible).strip()
            nouveau = archive.chercher_entite(categorie, canonique) is None   # « Elise Wu » = « Élise Wu » déjà connue
            code = archive.code_entite(categorie, canonique)
        entite = Entite(id=i + 1, categorie=categorie, canonique=canonique,
                        variantes=list(dict.fromkeys([texte, lisible])), score=1.0, sources=["correction"])
        entites.append(entite)
        libelles[entite.id] = code
        descriptions.append({"index": i, "texte": texte, "code": code, "categorie": categorie,
                             "canonique": canonique, "nouveau": nouveau, "variantes": entite.variantes})
    return entites, libelles, descriptions


def _entites_archive(archive, depart, prenoms_seuls):
    """Une entité par pseudonyme connu, avec toutes ses variantes archivées (et le prénom seul si demandé)."""
    entites, libelles = [], {}
    for k, (code, fiche) in enumerate(archive.entites.items()):
        variantes = list(dict.fromkeys([fiche["canonique"], *fiche["variantes"]]))
        if prenoms_seuls and fiche["categorie"] == "personne":
            _, prenom, nom = _decouper_nom(fiche["canonique"])
            if prenom and nom and len(prenom.rstrip(".")) >= 3:
                variantes.append(prenom)
        entite = Entite(id=depart + k, categorie=fiche["categorie"], canonique=fiche["canonique"],
                        variantes=variantes, score=1.0, sources=["archive"])
        entites.append(entite)
        libelles[entite.id] = code
    return entites, libelles


def _construire(config, archive, regles, automatique, prenoms_seuls):
    manuelles, libelles, descriptions = _entites_manuelles(archive, regles)
    auto = []
    if automatique:
        auto, libelles_auto = _entites_archive(archive, len(manuelles) + 1, prenoms_seuls)
        libelles.update(libelles_auto)
    graphies = bool(config.get("filtres", {}).get("graphies_etrangeres", True))
    # Les règles saisies passent avant l'archive : elles l'emportent si une même forme est dans les deux.
    correspondances = Correspondances(manuelles + auto, libelles, {}, (), archive, graphies=graphies)
    return correspondances, len(manuelles), descriptions, libelles


def apercu(config, session, regles, automatique=True, prenoms_seuls=False):
    """Ce que la correction changerait, sans rien écrire : occurrences par règle, par pseudonyme connu et par fichier."""
    archive = charger_archive(config)
    corr, n_manuelles, descriptions, libelles = _construire(config, archive, regles, automatique, prenoms_seuls)
    par_regle = {d["index"]: {"occurrences": 0, "fichiers": Counter(), "contextes": []} for d in descriptions}
    auto = defaultdict(lambda: {"occurrences": 0, "contextes": []})
    fichiers = []
    for chemin, relatif in session.fichiers:
        ligne = {"source": relatif, "corrections": 0, "nouveau_nom": None, "erreur": None}
        try:
            texte = formats.lire_texte(chemin)
        except Exception as e:  # noqa: BLE001 — signalé, les autres fichiers continuent
            ligne["erreur"] = f"{type(e).__name__} : {e}"
            fichiers.append(ligne)
            continue
        for debut, fin, identifiant in corr.occurrences(texte):
            ligne["corrections"] += 1
            if identifiant <= n_manuelles:
                stats = par_regle[identifiant - 1]
                stats["occurrences"] += 1
                stats["fichiers"][relatif] += 1
            else:
                stats = auto[libelles[identifiant]]
                stats["occurrences"] += 1
            if len(stats["contextes"]) < CONTEXTES_PAR_REGLE:
                stats["contextes"].append(contexte(texte, debut, fin))
        nouveau_nom = Lot._nom_sortie(relatif, corr, set())
        if nouveau_nom != relatif:
            ligne["nouveau_nom"] = nouveau_nom
            ligne["corrections"] += 1
        fichiers.append(ligne)
    return {
        "regles": [{**d, **{"occurrences": par_regle[d["index"]]["occurrences"],
                            "fichiers": dict(par_regle[d["index"]]["fichiers"]),
                            "contextes": par_regle[d["index"]]["contextes"]}} for d in descriptions],
        "automatique": [{"code": code, "occurrences": s["occurrences"], "contextes": s["contextes"]}
                        for code, s in sorted(auto.items(), key=lambda kv: -kv[1]["occurrences"])][:LIGNES_AUTO_MAX],
        "fichiers": fichiers,
        "total": sum(f["corrections"] for f in fichiers),
    }


def appliquer(config, session, regles, automatique=True, prenoms_seuls=False):
    """Écrit les fichiers corrigés dans un dossier daté, met l'archive à jour, efface la copie des fichiers déposés."""
    archive = charger_archive(config)
    corr, _, descriptions, _ = _construire(config, archive, regles, automatique, prenoms_seuls)
    identifiant, dossier = nouveau_dossier(config, "correction")
    utilises, resultats = set(), []
    for chemin, relatif in session.fichiers:
        sortie_relative = Lot._nom_sortie(relatif, corr, utilises)
        journal = Journal()
        resultat = {"source": relatif, "sortie": sortie_relative, "corrections": 0, "erreur": None}
        try:
            formats.ecrire_anonymise(chemin, dossier / sortie_relative, corr, journal)
            resultat["corrections"] = sum(journal.entites.values()) + (1 if sortie_relative != relatif else 0)
        except Exception as e:  # noqa: BLE001
            resultat["erreur"] = f"{type(e).__name__} : {e}"
        resultats.append(resultat)

    # Ce que l'utilisateur a enseigné à l'outil est conservé pour les lots suivants.
    date = maintenant()
    for d in descriptions:
        fiche = archive.entites[d["code"]]
        fiche["variantes"] = list(dict.fromkeys([*fiche["variantes"], *d["variantes"]]))
        if d["nouveau"]:
            fiche["canonique"], fiche["cree"] = d["canonique"], date
        if identifiant not in fiche["lots"]:
            fiche["lots"].append(identifiant)
    archive.sauver()
    session.nettoyer()
    return {"id": identifiant, "dossier": str(dossier), "resultats": resultats,
            "total": sum(r["corrections"] for r in resultats),
            "regles": [{k: d[k] for k in ("texte", "code", "nouveau")} for d in descriptions]}
