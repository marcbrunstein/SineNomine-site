"""Coffre chiffré de Sine Nomine : identités, valeurs sensibles, passages, refus et historique.

CONCEPTION (voir docs/COFFRE.md)

- Un fichier SQLite (`coffre.db`) dans le dossier de données de l'utilisateur. SQLite ne chiffre rien : chaque donnée
  sensible est chiffrée CHAMP PAR CHAMP avec AES-256-GCM (chiffrement authentifié, bibliothèque `cryptography`). L'additional
  data de chaque champ contient l'identifiant du coffre, la table, la colonne et l'identifiant (uid) de la ligne : un champ
  copié sur une autre ligne, ou modifié, est détecté à la lecture.
- Les recherches se font par « index aveugles » : HMAC-SHA256 (clé distincte) de la forme normalisée d'un nom. Le fichier ne
  contient donc jamais un nom en clair, mais le détenteur de la clé retrouve une identité sans tout déchiffrer.
- Clé de données : 32 octets aléatoires, jamais écrits en clair. Elle est enveloppée (a) par DPAPI de Windows (compte
  utilisateur de cet ordinateur) et (b), si l'utilisateur en définit une, par une PHRASE DE RÉCUPÉRATION (scrypt + AES-GCM).
  Perdre à la fois le compte Windows et la phrase rend le coffre définitivement illisible.
- Écritures transactionnelles (BEGIN IMMEDIATE, journal WAL, synchronous=FULL) : un seul écrivain à la fois, même entre
  processus ; contraintes d'unicité sur les codes et sur les identités ; rien n'est à moitié écrit après une panne.
- Historique protégé : chaque événement est chiffré et chaîné (HMAC du précédent) : on détecte la modification ou le retrait
  d'un événement du milieu de la chaîne (pas le retour à une ancienne copie complète du coffre).

MÉTADONNÉES VISIBLES dans le fichier : noms des tables, nombre de lignes, catégories (personne, société…), codes de
pseudonymes (Personne_KQXMB), identifiants aléatoires de périmètres, de lots et de lignes, dates, états, tailles des
champs chiffrés et index aveugles. Jamais : noms, valeurs sensibles, passages, listes, clés.
"""

import base64
import contextlib
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

VERSION_SCHEMA = 1
NOM_BASE = "coffre.db"
NOM_CLES = "cle.json"
PERIMETRE_HISTORIQUE = "historique"
LETTRES = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
LONGUEUR_CODE = 5
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 15, 8, 1
ENTROPIE_DPAPI = b"SineNomine-coffre-v1"
LONGUEUR_PHRASE_MIN = 12
MAGIE_SAUVEGARDE = b"SNCOFFRE1"


class CoffreErreur(Exception):
    """Erreur du coffre : le message est destiné à l'utilisateur (aucune donnée confidentielle)."""


class CoffreVerrouille(CoffreErreur):
    pass


class CoffreCleInvalide(CoffreErreur):
    pass


class CoffreAltere(CoffreErreur):
    pass


class CoffreEcriture(CoffreErreur):
    pass


def maintenant():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _b64(octets):
    return base64.b64encode(octets).decode("ascii")


def _debase64(texte):
    return base64.b64decode(texte.encode("ascii"))


# ---------------------------------------------------------------- protection de la clé : DPAPI (Windows)

def dpapi_disponible():
    return sys.platform == "win32"


def _dpapi(fonction, octets):
    """CryptProtectData / CryptUnprotectData : la clé n'est lisible que par ce compte Windows sur cet ordinateur."""
    import ctypes
    from ctypes import wintypes
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32

    class DataBlob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def blob(contenu):
        tampon = ctypes.create_string_buffer(contenu, len(contenu))
        return DataBlob(len(contenu), ctypes.cast(tampon, ctypes.POINTER(ctypes.c_char))), tampon

    entree, _t1 = blob(octets)
    entropie, _t2 = blob(ENTROPIE_DPAPI)
    sortie = DataBlob()
    if fonction == "proteger":
        ok = crypt32.CryptProtectData(ctypes.byref(entree), "Sine Nomine", ctypes.byref(entropie), None, None, 0x1,
                                      ctypes.byref(sortie))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(entree), None, ctypes.byref(entropie), None, None, 0x1,
                                        ctypes.byref(sortie))
    if not ok:
        raise CoffreCleInvalide("Windows n'a pas pu déverrouiller la clé du coffre : ce coffre a été créé par un autre compte "
                                "Windows ou sur un autre ordinateur. Utilisez la phrase de récupération.")
    try:
        return ctypes.string_at(sortie.pbData, sortie.cbData)
    finally:
        kernel32.LocalFree(sortie.pbData)


# ---------------------------------------------------------------- clés

def _derivee(cle, info):
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=info).derive(cle)


def _cle_depuis_phrase(phrase, sel, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P):
    return Scrypt(salt=sel, length=32, n=n, r=r, p=p).derive(phrase.encode("utf-8"))


def generer_phrase():
    """Phrase de récupération de 120 bits : six groupes de quatre lettres et chiffres (ex. K3QF-7XMD-…)."""
    brut = base64.b32encode(secrets.token_bytes(15)).decode("ascii")
    return "-".join(brut[i:i + 4] for i in range(0, 24, 4))


def _normaliser_phrase(phrase):
    return " ".join(str(phrase or "").strip().upper().split())


class Coffre:
    """Accès au coffre d'un dossier. Utiliser `Coffre.creer`, `Coffre.ouvrir`, ou `Coffre.ouvrir_avec_phrase`."""

    def __init__(self, dossier):
        self.dossier = Path(dossier)
        self.base = self.dossier / NOM_BASE
        self._fichier_cles = self.dossier / NOM_CLES
        self._cle_champs = self._cle_index = self._cle_journal = None
        self._coffre_id = None

    # ------------------------------------------------------------------ création, ouverture, verrouillage

    @classmethod
    def existe(cls, dossier):
        return (Path(dossier) / NOM_BASE).exists() and (Path(dossier) / NOM_CLES).exists()

    @classmethod
    def creer(cls, dossier, cle_donnees=None):
        """Crée un coffre protégé par DPAPI (Windows). Sur un autre système : définir ensuite une phrase de récupération."""
        coffre = cls(dossier)
        if cls.existe(dossier):
            raise CoffreErreur("Un coffre existe déjà dans ce dossier.")
        coffre.dossier.mkdir(parents=True, exist_ok=True)
        cle = cle_donnees or secrets.token_bytes(32)
        coffre._coffre_id = str(uuid.uuid4())
        meta = {"version": VERSION_SCHEMA, "coffre_id": coffre._coffre_id, "dpapi": None, "phrase": None}
        if dpapi_disponible():
            meta["dpapi"] = _b64(_dpapi("proteger", cle))
        coffre._ecrire_cles(meta)
        coffre._installer_cles(cle)
        coffre._initialiser_base()
        return coffre

    @classmethod
    def ouvrir(cls, dossier):
        coffre = cls(dossier)
        meta = coffre._lire_cles()
        if not meta.get("dpapi"):
            raise CoffreVerrouille("Ce coffre se déverrouille avec sa phrase de récupération.")
        coffre._coffre_id = meta["coffre_id"]
        coffre._installer_cles(_dpapi("deproteger", _debase64(meta["dpapi"])))
        coffre._verifier_cle()
        return coffre

    @classmethod
    def ouvrir_avec_phrase(cls, dossier, phrase):
        coffre = cls(dossier)
        meta = coffre._lire_cles()
        bloc = meta.get("phrase")
        if not bloc:
            raise CoffreCleInvalide("Ce coffre n'a pas de phrase de récupération.")
        coffre._coffre_id = meta["coffre_id"]
        coffre._installer_cles(coffre._cle_par_phrase(bloc, phrase))
        coffre._verifier_cle()
        return coffre

    def verrouiller(self):
        """Oublie les clés en mémoire (Python ne garantit pas leur effacement physique)."""
        self._cle_champs = self._cle_index = self._cle_journal = None

    @property
    def verrouille(self):
        return self._cle_champs is None

    def _installer_cles(self, cle_donnees):
        self._cle_champs = _derivee(cle_donnees, b"champs")
        self._cle_index = _derivee(cle_donnees, b"index")
        self._cle_journal = _derivee(cle_donnees, b"journal")
        self._cle_donnees = cle_donnees

    def _exiger_ouvert(self):
        if self.verrouille:
            raise CoffreVerrouille("Le coffre est verrouillé.")

    def _lire_cles(self):
        try:
            return json.loads(self._fichier_cles.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise CoffreAltere("Le fichier de clés du coffre est illisible ou absent.") from e

    def _ecrire_cles(self, meta):
        temporaire = self._fichier_cles.with_suffix(".tmp")
        temporaire.write_text(json.dumps(meta, indent=1), encoding="utf-8")
        os.replace(temporaire, self._fichier_cles)

    def _cle_par_phrase(self, bloc, phrase):
        cle_phrase = _cle_depuis_phrase(_normaliser_phrase(phrase), _debase64(bloc["sel"]), bloc["n"], bloc["r"], bloc["p"])
        try:
            return AESGCM(cle_phrase).decrypt(_debase64(bloc["nonce"]), _debase64(bloc["cle"]), b"cle-donnees")
        except InvalidTag:
            raise CoffreCleInvalide("Phrase de récupération incorrecte.") from None

    def _verifier_cle(self):
        """Une mauvaise clé ou un fichier altéré est détecté dès l'ouverture (champ témoin authentifié)."""
        with self._lecture() as c:
            ligne = c.execute("SELECT valeur FROM meta WHERE cle = 'temoin'").fetchone()
        if ligne is None:
            raise CoffreAltere("Le coffre est incomplet ou a été modifié (témoin absent).")
        self._dechiffrer("meta", "temoin", "temoin", _debase64(ligne[0]))

    def definir_phrase(self, phrase=None):
        """Ajoute (ou remplace) la phrase de récupération. Renvoie la phrase (à afficher une seule fois à l'utilisateur)."""
        self._exiger_ouvert()
        phrase = _normaliser_phrase(phrase or generer_phrase())
        if len(phrase) < LONGUEUR_PHRASE_MIN:
            raise CoffreErreur(f"La phrase de récupération doit faire au moins {LONGUEUR_PHRASE_MIN} caractères.")
        sel, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
        cle_phrase = _cle_depuis_phrase(phrase, sel)
        meta = self._lire_cles()
        meta["phrase"] = {"kdf": "scrypt", "n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P, "sel": _b64(sel), "nonce": _b64(nonce),
                          "cle": _b64(AESGCM(cle_phrase).encrypt(nonce, self._cle_donnees, b"cle-donnees"))}
        self._ecrire_cles(meta)
        self.journaliser("phrase_recuperation", {"definie": True})
        return phrase

    def a_phrase(self):
        return bool(self._lire_cles().get("phrase"))

    def reproteger_pour_ce_compte(self):
        """Après une ouverture par phrase sur un autre compte Windows : protège la clé pour le compte courant."""
        self._exiger_ouvert()
        if not dpapi_disponible():
            return
        meta = self._lire_cles()
        meta["dpapi"] = _b64(_dpapi("proteger", self._cle_donnees))
        self._ecrire_cles(meta)

    # ------------------------------------------------------------------ chiffrement de champs

    def _aad(self, table, colonne, uid):
        return f"{self._coffre_id}|{table}|{colonne}|{uid}".encode("utf-8")

    def _chiffrer(self, table, colonne, uid, octets):
        nonce = secrets.token_bytes(12)
        return nonce + AESGCM(self._cle_champs).encrypt(nonce, octets, self._aad(table, colonne, uid))

    def _dechiffrer(self, table, colonne, uid, blob):
        self._exiger_ouvert()
        try:
            return AESGCM(self._cle_champs).decrypt(bytes(blob[:12]), bytes(blob[12:]), self._aad(table, colonne, uid))
        except InvalidTag:
            raise CoffreAltere(f"Donnée altérée ou clé incorrecte ({table}.{colonne}). Le coffre n'est pas utilisable "
                               "tel quel : restaurez une sauvegarde chiffrée.") from None

    def _json_chiffre(self, table, colonne, uid, objet):
        return self._chiffrer(table, colonne, uid, json.dumps(objet, ensure_ascii=False).encode("utf-8"))

    def _json_dechiffre(self, table, colonne, uid, blob):
        return json.loads(self._dechiffrer(table, colonne, uid, blob).decode("utf-8"))

    def indexer(self, perimetre, categorie, valeur):
        """Index aveugle : égalité testable sans conserver la valeur."""
        self._exiger_ouvert()
        return hmac.new(self._cle_index, f"{perimetre}|{categorie}|{valeur}".encode("utf-8"), hashlib.sha256).digest()

    # ------------------------------------------------------------------ base SQLite

    def _connexion(self):
        c = sqlite3.connect(self.base, timeout=15, isolation_level=None)
        c.execute("PRAGMA foreign_keys = ON")
        c.execute("PRAGMA synchronous = FULL")
        c.execute("PRAGMA busy_timeout = 15000")
        return c

    @contextlib.contextmanager
    def _lecture(self):
        c = self._connexion()
        try:
            yield c
        finally:
            c.close()

    @contextlib.contextmanager
    def ecriture(self):
        """Transaction exclusive : tout est enregistré, ou rien. Un seul écrivain à la fois (threads et processus)."""
        self._exiger_ouvert()
        c = self._connexion()
        try:
            try:
                c.execute("BEGIN IMMEDIATE")
            except sqlite3.OperationalError as e:
                raise CoffreEcriture("Le coffre est occupé par une autre opération : réessayez dans un instant.") from e
            try:
                yield c
                c.execute("COMMIT")
            except sqlite3.IntegrityError:
                c.execute("ROLLBACK")
                raise
            except sqlite3.OperationalError as e:
                with contextlib.suppress(sqlite3.Error):
                    c.execute("ROLLBACK")
                plein = "full" in str(e).lower() or "disk" in str(e).lower()
                raise CoffreEcriture("Écriture impossible dans le coffre" + (" : disque plein." if plein else f" ({e}).")) from e
            except BaseException:
                with contextlib.suppress(sqlite3.Error):
                    c.execute("ROLLBACK")
                raise
        finally:
            c.close()

    def _initialiser_base(self):
        c = self._connexion()
        try:
            c.execute("PRAGMA journal_mode = WAL")
            c.executescript("""
CREATE TABLE IF NOT EXISTS meta (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS perimetres (
    id TEXT PRIMARY KEY, type TEXT NOT NULL, nom BLOB, cree_le TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS codes_utilises (
    perimetre_id TEXT NOT NULL REFERENCES perimetres(id), suffixe TEXT NOT NULL,
    PRIMARY KEY (perimetre_id, suffixe));
CREATE TABLE IF NOT EXISTS identites (
    uid TEXT PRIMARY KEY, perimetre_id TEXT NOT NULL REFERENCES perimetres(id), categorie TEXT NOT NULL,
    code TEXT NOT NULL, idx BLOB NOT NULL, donnees BLOB NOT NULL, cree_le TEXT NOT NULL,
    UNIQUE (perimetre_id, code), UNIQUE (perimetre_id, categorie, idx));
CREATE TABLE IF NOT EXISTS sensibles (
    uid TEXT PRIMARY KEY, perimetre_id TEXT NOT NULL REFERENCES perimetres(id), categorie TEXT NOT NULL,
    code TEXT NOT NULL, idx BLOB NOT NULL, donnees BLOB NOT NULL, cree_le TEXT NOT NULL,
    UNIQUE (perimetre_id, code), UNIQUE (perimetre_id, categorie, idx));
CREATE TABLE IF NOT EXISTS refus (
    uid TEXT PRIMARY KEY, perimetre_id TEXT NOT NULL REFERENCES perimetres(id), categorie TEXT NOT NULL,
    idx BLOB NOT NULL, donnees BLOB NOT NULL, UNIQUE (perimetre_id, categorie, idx));
CREATE TABLE IF NOT EXISTS lots (
    id TEXT PRIMARY KEY, perimetre_id TEXT NOT NULL REFERENCES perimetres(id), mode TEXT NOT NULL,
    etat TEXT NOT NULL CHECK (etat IN ('en_cours', 'pret', 'publie', 'abandonne', 'historique')),
    debut TEXT NOT NULL, fin TEXT, donnees BLOB);
CREATE TABLE IF NOT EXISTS journal (
    id INTEGER PRIMARY KEY AUTOINCREMENT, instant TEXT NOT NULL, genre TEXT NOT NULL, charge BLOB NOT NULL,
    uid TEXT NOT NULL, chaine BLOB NOT NULL);
""")
            temoin = self._chiffrer("meta", "temoin", "temoin", b"sine-nomine-coffre")
            c.execute("INSERT OR REPLACE INTO meta (cle, valeur) VALUES ('schema', ?)", (str(VERSION_SCHEMA),))
            c.execute("INSERT OR REPLACE INTO meta (cle, valeur) VALUES ('coffre_id', ?)", (self._coffre_id,))
            c.execute("INSERT OR REPLACE INTO meta (cle, valeur) VALUES ('temoin', ?)", (_b64(temoin),))
            c.execute("INSERT OR IGNORE INTO perimetres (id, type, nom, cree_le) VALUES (?, 'historique', NULL, ?)",
                      (PERIMETRE_HISTORIQUE, maintenant()))
        finally:
            c.close()
        self.journaliser("creation", {"version": VERSION_SCHEMA})

    # ------------------------------------------------------------------ identités et valeurs sensibles

    def _suffixe_libre(self, c, perimetre):
        for _ in range(10000):
            suffixe = "".join(secrets.choice(LETTRES) for _ in range(LONGUEUR_CODE))
            try:
                c.execute("INSERT INTO codes_utilises (perimetre_id, suffixe) VALUES (?, ?)", (perimetre, suffixe))
                return suffixe
            except sqlite3.IntegrityError:
                continue
        raise CoffreEcriture("Plus de code libre dans ce périmètre.")

    def obtenir_ou_creer(self, table, perimetre, categorie, forme, etiquette, donnees_initiales, entourer=False):
        """Code d'une identité (table « identites ») ou d'une valeur sensible (« sensibles ») : le code existant pour cette
        forme normalisée, sinon un nouveau code unique, enregistré de façon durable avant de répondre."""
        idx = self.indexer(perimetre, categorie, forme)
        with self.ecriture() as c:
            ligne = c.execute(f"SELECT code FROM {table} WHERE perimetre_id = ? AND categorie = ? AND idx = ?",
                              (perimetre, categorie, idx)).fetchone()
            if ligne:
                return ligne[0], False
            suffixe = self._suffixe_libre(c, perimetre)
            code = f"[{etiquette}_{suffixe}]" if entourer else f"{etiquette}_{suffixe}"
            uid = uuid.uuid4().hex
            c.execute(f"INSERT INTO {table} (uid, perimetre_id, categorie, code, idx, donnees, cree_le) VALUES (?, ?, ?, ?, ?, ?, ?)",
                      (uid, perimetre, categorie, code, idx, self._json_chiffre(table, "donnees", uid, donnees_initiales),
                       maintenant()))
            return code, True

    def lire_table(self, table, perimetre):
        """{code: {categorie, **donnees}} déchiffré (sans l'index aveugle)."""
        self._exiger_ouvert()
        resultat = {}
        with self._lecture() as c:
            for uid, categorie, code, donnees, cree in c.execute(
                    f"SELECT uid, categorie, code, donnees, cree_le FROM {table} WHERE perimetre_id = ? ORDER BY cree_le, code",
                    (perimetre,)):
                fiche = self._json_dechiffre(table, "donnees", uid, donnees)
                fiche["categorie"] = categorie
                resultat[code] = fiche
        return resultat

    def lire_fiche(self, table, perimetre, code):
        """Une seule fiche déchiffrée, ou None."""
        self._exiger_ouvert()
        with self._lecture() as c:
            ligne = c.execute(f"SELECT uid, categorie, donnees FROM {table} WHERE perimetre_id = ? AND code = ?",
                              (perimetre, code)).fetchone()
        if ligne is None:
            return None
        fiche = self._json_dechiffre(table, "donnees", ligne[0], ligne[2])
        fiche["categorie"] = ligne[1]
        return fiche

    def fusionner(self, table, perimetre, fiches_modifiees, fusion):
        """Applique `fusion(fiche_en_base, fiche_locale) -> fiche` aux codes modifiés, dans une seule transaction (pas de
        mise à jour perdue entre deux lots simultanés)."""
        if not fiches_modifiees:
            return
        with self.ecriture() as c:
            for code, locale in fiches_modifiees.items():
                ligne = c.execute(f"SELECT uid, donnees FROM {table} WHERE perimetre_id = ? AND code = ?",
                                  (perimetre, code)).fetchone()
                if ligne is None:
                    raise CoffreErreur(f"Code inconnu du coffre : {code}")
                uid, donnees = ligne
                courante = self._json_dechiffre(table, "donnees", uid, donnees)
                nouvelle = fusion(courante, {k: v for k, v in locale.items() if k != "categorie"})
                c.execute(f"UPDATE {table} SET donnees = ? WHERE uid = ?",
                          (self._json_chiffre(table, "donnees", uid, nouvelle), uid))

    # Import idempotent (migration) : à appeler dans `ecriture()` ; renvoie True si une ligne a été ajoutée.
    def importer_dans(self, c, table, perimetre, code, categorie, forme, donnees):
        idx = self.indexer(perimetre, categorie, forme)
        existant = c.execute(f"SELECT uid, code, donnees FROM {table} WHERE perimetre_id = ? AND (code = ? OR (categorie = ? AND idx = ?))",
                             (perimetre, code, categorie, idx)).fetchall()
        if existant:
            for uid, code_base, blob in existant:
                if code_base != code:
                    raise CoffreErreur(f"Conflit à l'import : la même identité a déjà un autre code ({table}).")
                if self._json_dechiffre(table, "donnees", uid, blob) != donnees:
                    raise CoffreErreur(f"Conflit à l'import : le code {code} existe déjà avec un contenu différent.")
            return False
        uid = uuid.uuid4().hex
        suffixe = code.rstrip("]")[-LONGUEUR_CODE:]
        c.execute("INSERT OR IGNORE INTO codes_utilises (perimetre_id, suffixe) VALUES (?, ?)", (perimetre, suffixe))
        c.execute(f"INSERT INTO {table} (uid, perimetre_id, categorie, code, idx, donnees, cree_le) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (uid, perimetre, categorie, code, idx, self._json_chiffre(table, "donnees", uid, donnees), maintenant()))
        return True

    # ------------------------------------------------------------------ refus de détection

    def lire_refus(self, perimetre):
        self._exiger_ouvert()
        resultat = {}
        with self._lecture() as c:
            for uid, categorie, donnees in c.execute("SELECT uid, categorie, donnees FROM refus WHERE perimetre_id = ?", (perimetre,)):
                resultat.setdefault(categorie, []).append(self._json_dechiffre("refus", "donnees", uid, donnees)["forme"])
        return resultat

    def refuser(self, perimetre, categorie, forme):
        idx = self.indexer(perimetre, categorie, forme)
        with self.ecriture() as c:
            if not c.execute("SELECT 1 FROM refus WHERE perimetre_id = ? AND categorie = ? AND idx = ?",
                             (perimetre, categorie, idx)).fetchone():
                uid = uuid.uuid4().hex
                c.execute("INSERT INTO refus (uid, perimetre_id, categorie, idx, donnees) VALUES (?, ?, ?, ?, ?)",
                          (uid, perimetre, categorie, idx, self._json_chiffre("refus", "donnees", uid, {"forme": forme})))

    def accepter(self, perimetre, categorie, forme):
        idx = self.indexer(perimetre, categorie, forme)
        with self.ecriture() as c:
            c.execute("DELETE FROM refus WHERE perimetre_id = ? AND categorie = ? AND idx = ?", (perimetre, categorie, idx))

    # ------------------------------------------------------------------ lots

    def etat_lot(self, lot_id):
        with self._lecture() as c:
            ligne = c.execute("SELECT etat FROM lots WHERE id = ?", (lot_id,)).fetchone()
        return ligne[0] if ligne else None

    def declarer_lot(self, lot_id, perimetre, mode, donnees=None):
        with self.ecriture() as c:
            c.execute("INSERT OR IGNORE INTO lots (id, perimetre_id, mode, etat, debut, donnees) VALUES (?, ?, ?, 'en_cours', ?, ?)",
                      (lot_id, perimetre, mode, maintenant(), self._json_chiffre("lots", "donnees", lot_id, donnees or {})))

    def changer_etat_lot(self, lot_id, etat, donnees=None):
        with self.ecriture() as c:
            c.execute("UPDATE lots SET etat = ?, fin = CASE WHEN ? IN ('publie', 'abandonne') THEN ? ELSE fin END WHERE id = ?",
                      (etat, etat, maintenant(), lot_id))
            if donnees is not None:
                c.execute("UPDATE lots SET donnees = ? WHERE id = ?", (self._json_chiffre("lots", "donnees", lot_id, donnees), lot_id))
        self.journaliser("lot", {"id": lot_id, "etat": etat})

    def lots_en_cours(self):
        with self._lecture() as c:
            return [(i, e) for i, e in c.execute("SELECT id, etat FROM lots WHERE etat IN ('en_cours', 'pret')")]

    def donnees_lot(self, lot_id):
        with self._lecture() as c:
            ligne = c.execute("SELECT donnees FROM lots WHERE id = ?", (lot_id,)).fetchone()
        return self._json_dechiffre("lots", "donnees", lot_id, ligne[0]) if ligne and ligne[0] else {}

    # ------------------------------------------------------------------ historique chaîné

    def journaliser(self, genre, charge):
        """Ajoute un événement chiffré à l'historique ; chaque entrée est liée à la précédente (HMAC)."""
        self._exiger_ouvert()
        uid = uuid.uuid4().hex
        blob = self._json_chiffre("journal", "charge", uid, charge)
        instant = maintenant()
        with self.ecriture() as c:
            precedente = c.execute("SELECT chaine FROM journal ORDER BY id DESC LIMIT 1").fetchone()
            chaine = hmac.new(self._cle_journal, (precedente[0] if precedente else b"") + instant.encode() + genre.encode() + blob
                              + uid.encode(), hashlib.sha256).digest()
            c.execute("INSERT INTO journal (instant, genre, charge, uid, chaine) VALUES (?, ?, ?, ?, ?)",
                      (instant, genre, blob, uid, chaine))

    def lire_journal(self, limite=200):
        """Événements récents, du plus récent au plus ancien : {instant, genre, ...charge}."""
        self._exiger_ouvert()
        with self._lecture() as c:
            lignes = c.execute("SELECT instant, genre, charge, uid FROM journal ORDER BY id DESC LIMIT ?", (limite,)).fetchall()
        resultat = []
        for instant, genre, charge, uid in lignes:
            contenu = self._json_dechiffre("journal", "charge", uid, charge)
            resultat.append({"instant": instant, "genre": genre, **(contenu if isinstance(contenu, dict) else {})})
        return resultat

    # ------------------------------------------------------------------ intégrité

    def verifier(self):
        """Contrôle complet : base SQLite, déchiffrement authentifié de tous les champs, chaîne de l'historique, unicité.

        Renvoie {ok, anomalies[], comptes{}}. Ne lève pas d'exception pour une altération : elle est rapportée."""
        self._exiger_ouvert()
        anomalies, comptes = [], {}
        with self._lecture() as c:
            etat = c.execute("PRAGMA integrity_check").fetchone()[0]
            if etat != "ok":
                anomalies.append(f"Intégrité SQLite : {etat}")
            if c.execute("PRAGMA foreign_key_check").fetchall():
                anomalies.append("Références brisées entre tables.")
            for table in ("identites", "sensibles", "refus"):
                n = 0
                for uid, donnees in c.execute(f"SELECT uid, donnees FROM {table}"):
                    n += 1
                    try:
                        self._dechiffrer(table, "donnees", uid, donnees)
                    except CoffreAltere as e:
                        anomalies.append(str(e))
                comptes[table] = n
            for lot_id, donnees in c.execute("SELECT id, donnees FROM lots WHERE donnees IS NOT NULL"):
                try:
                    self._dechiffrer("lots", "donnees", lot_id, donnees)
                except CoffreAltere as e:
                    anomalies.append(str(e))
            comptes["lots"] = c.execute("SELECT COUNT(*) FROM lots").fetchone()[0]
            precedente, n = b"", 0
            for instant, genre, charge, uid, chaine in c.execute("SELECT instant, genre, charge, uid, chaine FROM journal ORDER BY id"):
                n += 1
                attendue = hmac.new(self._cle_journal, precedente + instant.encode() + genre.encode() + bytes(charge) + uid.encode(),
                                    hashlib.sha256).digest()
                if not hmac.compare_digest(attendue, bytes(chaine)):
                    anomalies.append(f"Historique : l'événement n° {n} a été modifié ou son prédécesseur retiré.")
                    break
                try:
                    self._dechiffrer("journal", "charge", uid, charge)
                except CoffreAltere as e:
                    anomalies.append(str(e))
                precedente = bytes(chaine)
            comptes["journal"] = n
        return {"ok": not anomalies, "anomalies": anomalies, "comptes": comptes}

    def valeur_meta(self, cle):
        with self._lecture() as c:
            ligne = c.execute("SELECT valeur FROM meta WHERE cle = ?", (cle,)).fetchone()
        return ligne[0] if ligne else None

    def definir_meta(self, cle, valeur):
        with self.ecriture() as c:
            c.execute("INSERT OR REPLACE INTO meta (cle, valeur) VALUES (?, ?)", (cle, valeur))

    # ------------------------------------------------------------------ sauvegarde portable chiffrée

    def sauvegarder(self, fichier, phrase):
        """Sauvegarde portable : copie cohérente du coffre + clé enveloppée par la phrase, le tout chiffré par la phrase
        (AES-256-GCM, scrypt). Utilisable sur un autre ordinateur ou un autre compte avec la seule phrase."""
        self._exiger_ouvert()
        phrase = _normaliser_phrase(phrase)
        if len(phrase) < LONGUEUR_PHRASE_MIN:
            raise CoffreErreur(f"La phrase doit faire au moins {LONGUEUR_PHRASE_MIN} caractères.")
        Path(fichier).parent.mkdir(parents=True, exist_ok=True)
        temporaire = Path(fichier).with_suffix(".sauvegarde.tmp")
        source = self._connexion()
        copie = sqlite3.connect(temporaire)
        try:
            source.backup(copie)
        finally:
            copie.close()
            source.close()
        try:
            base = temporaire.read_bytes()
        finally:
            with contextlib.suppress(OSError):
                temporaire.unlink()
        contenu = json.dumps({"coffre_id": self._coffre_id, "cle": _b64(self._cle_donnees), "base": _b64(base)}).encode("utf-8")
        sel, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
        chiffre = AESGCM(_cle_depuis_phrase(phrase, sel)).encrypt(nonce, contenu, MAGIE_SAUVEGARDE)
        octets = MAGIE_SAUVEGARDE + sel + nonce + chiffre
        cible = Path(fichier)
        cible.parent.mkdir(parents=True, exist_ok=True)
        ecrit = cible.with_suffix(cible.suffix + ".tmp")
        ecrit.write_bytes(octets)
        os.replace(ecrit, cible)
        self.journaliser("sauvegarde", {"octets": len(octets)})
        return len(octets)

    @classmethod
    def restaurer(cls, fichier, phrase, dossier):
        """Recrée un coffre dans `dossier` (qui ne doit pas contenir de coffre) depuis une sauvegarde portable."""
        if cls.existe(dossier):
            raise CoffreErreur("Un coffre existe déjà dans ce dossier : déplacez-le ou choisissez un autre dossier.")
        octets = Path(fichier).read_bytes()
        if not octets.startswith(MAGIE_SAUVEGARDE) or len(octets) < len(MAGIE_SAUVEGARDE) + 28:
            raise CoffreAltere("Ce fichier n'est pas une sauvegarde de coffre Sine Nomine.")
        sel = octets[len(MAGIE_SAUVEGARDE):len(MAGIE_SAUVEGARDE) + 16]
        nonce = octets[len(MAGIE_SAUVEGARDE) + 16:len(MAGIE_SAUVEGARDE) + 28]
        try:
            contenu = AESGCM(_cle_depuis_phrase(_normaliser_phrase(phrase), sel)).decrypt(
                nonce, octets[len(MAGIE_SAUVEGARDE) + 28:], MAGIE_SAUVEGARDE)
        except InvalidTag:
            raise CoffreCleInvalide("Phrase incorrecte, ou sauvegarde altérée.") from None
        donnees = json.loads(contenu.decode("utf-8"))
        dossier = Path(dossier)
        dossier.mkdir(parents=True, exist_ok=True)
        coffre = cls(dossier)
        coffre._coffre_id = donnees["coffre_id"]
        coffre._installer_cles(_debase64(donnees["cle"]))
        meta = {"version": VERSION_SCHEMA, "coffre_id": coffre._coffre_id, "dpapi": None, "phrase": None}
        if dpapi_disponible():
            meta["dpapi"] = _b64(_dpapi("proteger", coffre._cle_donnees))
        coffre._ecrire_cles(meta)
        coffre.base.write_bytes(_debase64(donnees["base"]))
        try:
            coffre._verifier_cle()
            rapport = coffre.verifier()
        except CoffreErreur:
            coffre.base.unlink(missing_ok=True)
            coffre._fichier_cles.unlink(missing_ok=True)
            raise
        if not rapport["ok"]:
            coffre.base.unlink(missing_ok=True)
            coffre._fichier_cles.unlink(missing_ok=True)
            raise CoffreAltere("La sauvegarde est altérée : " + "; ".join(rapport["anomalies"][:3]))
        coffre.definir_phrase(phrase)
        coffre.journaliser("restauration", {"depuis": "sauvegarde portable"})
        return coffre
