def edit(p, pairs):
    raw = open(p, "rb").read().decode("utf-8")
    crlf = "\r\n" in raw
    s = raw.replace("\r\n", "\n")
    for a, b in pairs:
        assert a in s, (p, a[:80])
        s = s.replace(a, b, 1)
    open(p, "wb").write((s.replace("\n", "\r\n") if crlf else s).encode("utf-8"))


edit("anonymiseur/static/index.html", [
    ('<button id="btn-ouvrir-correspondances">Ouvrir le dossier des correspondances</button>',
     '<button id="btn-ouvrir-correspondances">Exporter la table de correspondance (en clair)…</button>'),
    ('''        <button data-outil="archive">Archive des codes</button>
''', '''        <button data-outil="archive">Archive des codes</button>
        <button data-outil="coffre">Coffre chiffré</button>
'''),
    ('''        <p class="intro" data-i18n-html="outils.archive">L'archive contient les noms d'origine en clair : gardez-la privée et sauvegardez-la. Sans elle, les fichiers déjà
          pseudonymisés ne pourront plus être restaurés. Copiez le fichier <code>archive_codes.json</code> pour la sauvegarder.</p>
        <div class="actions gauche"><button id="btn-ouvrir-archive">Ouvrir le dossier de l'archive</button></div>
      </div>
''', '''        <p class="intro" data-i18n-html="outils.archive">L'archive des codes est conservée dans le <strong>coffre chiffré</strong> de cet ordinateur. Sans elle, les fichiers déjà
          pseudonymisés ne pourront plus être restaurés : créez une sauvegarde chiffrée dans l'onglet « Coffre chiffré ».</p>
        <div class="actions gauche"><button id="btn-ouvrir-archive">Ouvrir le dossier de l'archive</button></div>
      </div>

      <div id="outil-coffre" hidden>
        <div class="alerte" id="info-coffre"></div>
        <p class="intro" data-i18n-html="outils.coffre">Le coffre chiffre les noms d'origine, les valeurs sensibles et les passages (AES-256-GCM). Sa clé est protégée par votre compte Windows :
          <strong>créez une phrase de récupération</strong> et gardez-la dans votre gestionnaire de mots de passe, sinon une perte du compte Windows rend le coffre illisible.
          Une <strong>sauvegarde chiffrée</strong> est utilisable sur un autre ordinateur avec cette seule phrase.</p>
        <div class="actions gauche">
          <button id="btn-coffre-verifier">Vérifier l'intégrité</button>
          <button id="btn-coffre-phrase">Créer la phrase de récupération</button>
          <button id="btn-coffre-sauvegarde">Créer une sauvegarde chiffrée…</button>
          <button id="btn-coffre-supprimer-clair">Supprimer les anciens fichiers en clair…</button>
        </div>
        <p class="discret" id="retour-coffre" role="status"></p>
      </div>
'''),
])

edit("anonymiseur/static/app.js", [
    ('''  $("#btn-ouvrir-correspondances").hidden = anonymise;
  $("#info-correspondances").innerHTML = anonymise
    ? `<strong>Anonymisation irréversible :</strong> ${echapper(avertissementLangue().anonymisation)}`
    : `<strong>Table de correspondance :</strong> <code>${echapper(lot.correspondances)}</code><br>${echapper(avertissementLangue().pseudonymisation)}`;''',
     '''  $("#btn-ouvrir-correspondances").hidden = anonymise;
  $("#info-correspondances").innerHTML = anonymise
    ? `<strong>Anonymisation irréversible :</strong> ${echapper(avertissementLangue().anonymisation)}`
    : `<strong>${echapper(traduire("Correspondances"))} :</strong> ${echapper(traduire("Les correspondances sont conservées dans le coffre chiffré de cet ordinateur ; aucune table en clair n'a été écrite."))}`
      + (lot.correspondances ? `<br>${echapper(traduire("Table exportée (en clair) :"))} <code>${echapper(lot.correspondances)}</code>` : "")
      + `<br>${echapper(avertissementLangue().pseudonymisation)}`;'''),
    ('''$("#btn-ouvrir-correspondances").addEventListener("click", () => ouvrir("correspondances"));''',
     '''$("#btn-ouvrir-correspondances").addEventListener("click", async () => {
  // Export en clair : jamais automatique, et seulement après confirmation.
  if (!confirmer("Ce fichier contiendra les noms d'origine en clair, à côté de leurs pseudonymes : toute personne qui l'ouvre pourra lever la pseudonymisation. Il n'est pas nécessaire à la restauration (le coffre chiffré suffit). Continuer ?")) return;
  try {
    const r = await api(`/api/lots/${etat.lot.id}/exporter-correspondances`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirmation: true }) });
    etat.lot.correspondances = r.fichier;
    afficherResultats(etat.lot);
    await ouvrir("correspondances");
  } catch (e) { alerter(e.message); }
});'''),
    ('''  for (const o of ["listes", "options", "archive"]) $("#outil-" + o).hidden = o !== outil;
  if (outil === "listes") chargerListe();
  else if (outil === "options") chargerOptions();
  else chargerArchive();''', '''  for (const o of ["listes", "options", "archive", "coffre"]) $("#outil-" + o).hidden = o !== outil;
  if (outil === "listes") chargerListe();
  else if (outil === "options") chargerOptions();
  else if (outil === "coffre") chargerCoffre();
  else chargerArchive();'''),
    ('''function montrerOutil(outil) {''', '''// ------------------------------------------------------------------ coffre chiffré
async function chargerCoffre() {
  const info = $("#info-coffre");
  try {
    const c = await api("/api/coffre");
    etat.config.coffre = c;
    if (c.erreur) { info.innerHTML = `<strong>${echapper(traduire("Coffre inutilisable :"))}</strong> ${echapper(c.erreur)}`; return; }
    const lignes = [`${echapper(traduire("Emplacement du coffre :"))} <code>${echapper(c.dossier)}</code>`];
    if (c.migration && c.migration.source) {
      lignes.push(echapper(t("Archive historique migrée le {date} : {n} identité(s) et {m} valeur(s) sensible(s). Les fichiers d'origine n'ont pas été supprimés.",
        { date: c.migration.date.slice(0, 10), n: c.migration.identites, m: c.migration.sensibles })));
    }
    lignes.push(echapper(c.phrase_definie ? traduire("Phrase de récupération définie.")
      : traduire("Aucune phrase de récupération : si votre compte Windows est perdu, le coffre sera définitivement illisible. Créez-la maintenant.")));
    lignes.push(echapper(c.copies_en_clair ? t("{n} ancien(s) fichier(s) en clair (archive JSON, tables Excel) subsiste(nt) : supprimez-les une fois votre sauvegarde faite.", { n: c.copies_en_clair })
      : traduire("Aucun ancien fichier en clair.")));
    info.innerHTML = lignes.join("<br>");
    $("#btn-coffre-supprimer-clair").hidden = !c.copies_en_clair;
  } catch (e) { info.textContent = e.message; }
}
$("#btn-coffre-verifier").addEventListener("click", async () => {
  const retour = $("#retour-coffre");
  retour.textContent = traduire("Vérification en cours…");
  try {
    const r = await api("/api/coffre/verifier", { method: "POST" });
    const n = Object.values(r.comptes).reduce((a, b) => a + b, 0);
    retour.textContent = r.ok ? t("Contrôle terminé : coffre intact ({n} entrées vérifiées).", { n })
      : traduire("Anomalies détectées : ") + r.anomalies.join(" · ");
  } catch (e) { retour.textContent = e.message; }
});
$("#btn-coffre-phrase").addEventListener("click", async () => {
  const retour = $("#retour-coffre");
  let remplacer = false;
  if (etat.config.coffre && etat.config.coffre.phrase_definie) {
    if (!confirmer("Une phrase de récupération existe déjà. La remplacer rend l'ancienne inutilisable. Continuer ?")) return;
    remplacer = true;
  }
  try {
    const r = await api("/api/coffre/phrase", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ remplacer }) });
    retour.innerHTML = `${echapper(traduire("Votre phrase de récupération (notez-la maintenant, elle ne sera plus affichée) :"))} <code style="font-size:1.2em">${echapper(r.phrase)}</code>`;
    chargerCoffre();
  } catch (e) { retour.textContent = e.message; }
});
$("#btn-coffre-sauvegarde").addEventListener("click", async () => {
  const phrase = window.prompt(traduire("Phrase de récupération qui chiffrera la sauvegarde (12 caractères au moins) :"));
  if (!phrase) return;
  try {
    const r = await api("/api/coffre/sauvegarde", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ phrase }) });
    $("#retour-coffre").innerHTML = `${echapper(traduire("Sauvegarde créée :"))} <code>${echapper(r.fichier)}</code>`;
  } catch (e) { $("#retour-coffre").textContent = e.message; }
});
$("#btn-coffre-supprimer-clair").addEventListener("click", async () => {
  if (!confirmer("Supprimer les anciens fichiers en clair ? La suppression ne garantit pas leur effacement physique (disques SSD, copies de synchronisation, corbeille). Vérifiez que vous avez une sauvegarde chiffrée.")) return;
  try {
    const r = await api("/api/coffre/copies-en-clair/supprimer", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accord: true }) });
    $("#retour-coffre").textContent = t("{n} fichier(s) supprimé(s).", { n: r.supprimes.length });
    chargerCoffre();
  } catch (e) { $("#retour-coffre").textContent = e.message; }
});

function montrerOutil(outil) {'''),
    ('''  rafraichirModeles();
  preparerAvertissement();
  afficherLicence();
  allerMenu();''', '''  rafraichirModeles();
  preparerAvertissement();
  afficherLicence();
  if (etat.config.coffre && etat.config.coffre.erreur) alerter(etat.config.coffre.erreur);
  allerMenu();'''),
])

edit("tests/generer_i18n.py", [
    ('    "Toujours ignorer": "Always ignore",', '''    "Coffre chiffré": "Encrypted vault", "Exporter la table de correspondance (en clair)…": "Export the correspondence table (in clear)…",
    "Ce fichier contiendra les noms d'origine en clair, à côté de leurs pseudonymes : toute personne qui l'ouvre pourra lever la pseudonymisation. Il n'est pas nécessaire à la restauration (le coffre chiffré suffit). Continuer ?":
        "This file will contain the original names in clear, next to their pseudonyms: anyone who opens it can reverse the pseudonymisation. It is not needed for restoration (the encrypted vault is enough). Continue?",
    "Correspondances": "Correspondences",
    "Les correspondances sont conservées dans le coffre chiffré de cet ordinateur ; aucune table en clair n'a été écrite.":
        "The correspondences are kept in this computer's encrypted vault; no table in clear was written.",
    "Table exportée (en clair) :": "Table exported (in clear):",
    "Coffre inutilisable :": "Vault unusable:", "Emplacement du coffre :": "Vault location:",
    "Archive historique migrée le {date} : {n} identité(s) et {m} valeur(s) sensible(s). Les fichiers d'origine n'ont pas été supprimés.":
        "Historical archive migrated on {date}: {n} identity(ies) and {m} sensitive value(s). The original files were not deleted.",
    "Phrase de récupération définie.": "Recovery phrase set.",
    "Aucune phrase de récupération : si votre compte Windows est perdu, le coffre sera définitivement illisible. Créez-la maintenant.":
        "No recovery phrase: if your Windows account is lost, the vault will be permanently unreadable. Create it now.",
    "{n} ancien(s) fichier(s) en clair (archive JSON, tables Excel) subsiste(nt) : supprimez-les une fois votre sauvegarde faite.":
        "{n} old file(s) in clear (JSON archive, Excel tables) remain: delete them once your backup is done.",
    "Aucun ancien fichier en clair.": "No old file in clear.",
    "Vérifier l'intégrité": "Check integrity", "Créer la phrase de récupération": "Create the recovery phrase",
    "Créer une sauvegarde chiffrée…": "Create an encrypted backup…", "Supprimer les anciens fichiers en clair…": "Delete the old files in clear…",
    "Vérification en cours…": "Checking…", "Contrôle terminé : coffre intact ({n} entrées vérifiées).": "Check complete: vault intact ({n} entries verified).",
    "Anomalies détectées : ": "Anomalies detected: ",
    "Une phrase de récupération existe déjà. La remplacer rend l'ancienne inutilisable. Continuer ?":
        "A recovery phrase already exists. Replacing it makes the old one unusable. Continue?",
    "Votre phrase de récupération (notez-la maintenant, elle ne sera plus affichée) :": "Your recovery phrase (write it down now, it will not be shown again):",
    "Phrase de récupération qui chiffrera la sauvegarde (12 caractères au moins) :": "Recovery phrase that will encrypt the backup (at least 12 characters):",
    "Sauvegarde créée :": "Backup created:",
    "Supprimer les anciens fichiers en clair ? La suppression ne garantit pas leur effacement physique (disques SSD, copies de synchronisation, corbeille). Vérifiez que vous avez une sauvegarde chiffrée.":
        "Delete the old files in clear? Deletion does not guarantee physical erasure (SSD drives, sync copies, recycle bin). Make sure you have an encrypted backup.",
    "{n} fichier(s) supprimé(s).": "{n} file(s) deleted.",
    "La phrase doit faire au moins 12 caractères.": "The phrase must be at least 12 characters long.",
    "Une phrase de récupération existe déjà. Confirmez pour la remplacer.": "A recovery phrase already exists. Confirm to replace it.",
    "Suppression refusée : l'accord explicite de l'utilisateur est requis.": "Deletion refused: the user's explicit agreement is required.",
    "Confirmez l'export : le fichier contiendra les noms d'origine en clair.": "Confirm the export: the file will contain the original names in clear.",
    "Toujours ignorer": "Always ignore",'''.replace('    "Toujours ignorer": "Always ignore",', '    "Toujours ignorer": "Always ignore",', 1)),
])
print("ok")
