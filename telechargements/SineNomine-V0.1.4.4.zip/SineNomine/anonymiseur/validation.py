"""Aides à la validation : termes imposés, propositions de fusion, vérification finale des fichiers produits.

RÈGLES DE RECHERCHE d'un terme (documentées dans docs/VALIDATION.md) :

1. EXACTE : le texte du terme, tel qu'écrit (casse et accents compris), entre deux limites de mot.
2. NORMALISÉE : mêmes lettres sans tenir compte de la casse, des accents ni des séparateurs (espace, tiret, tiret bas, apostrophe),
   et des graphies étrangères usuelles (Kärscher / Kaerscher). Une équivalence normalisée est remplacée comme une exacte.
3. APPROXIMATIVE : proposition SEULEMENT, jamais remplacée sans validation de l'utilisateur. Distance de Levenshtein d'au plus 1
   pour un terme de 5 à 8 lettres, 2 au-delà, jamais en dessous de 5 lettres (trop de faux positifs).

Les limites de mot : un terme n'est pas cherché à l'intérieur d'un mot plus long (« Dupont » n'est pas trouvé dans « Dupontel »).
"""

import re
from collections import defaultdict

from .detection import normaliser
from .entites import Entite, _decouper_nom, _prenoms_compatibles
from .graphies import plier
from .remplacement import Correspondances, contexte

RE_MOT = re.compile(r"[^\W_]+(?:['’\-][^\W_]+)*")
LIMITE_RESULTATS = 20


def lettres(texte):
    return re.sub(r"[^a-z0-9]", "", plier(texte).lower())


def distance_permise(terme):
    """Distance maximale acceptée pour une proximité approximative : 0 (aucune) sous 5 lettres, 1 de 5 à 8, 2 au-delà."""
    n = len(lettres(terme))
    return 0 if n < 5 else 1 if n <= 8 else 2


def levenshtein(a, b, plafond):
    """Distance d'édition entre a et b, ou plafond + 1 dès qu'elle dépasse le plafond."""
    if abs(len(a) - len(b)) > plafond:
        return plafond + 1
    precedent = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        courant = [i]
        for j, cb in enumerate(b, start=1):
            courant.append(min(precedent[j] + 1, courant[j - 1] + 1, precedent[j - 1] + (ca != cb)))
        if min(courant) > plafond:
            return plafond + 1
        precedent = courant
    return precedent[-1]


# ---------------------------------------------------------------- termes imposés


def nettoyer_termes(termes, categories):
    """Liste de termes imposés propre : [{"id", "terme", "variantes", "categorie"}].

    Une entrée par ligne (« terme » ou « terme ; catégorie »), doublons retirés SANS perdre de variante : « Jean Dupont » et
    « jean dupont » (même forme normalisée) deviennent un seul terme dont les deux écritures sont cherchées."""
    regroupes, ordre = {}, []
    for brut in termes or []:
        if isinstance(brut, dict):
            terme, categorie = (brut.get("terme") or ""), brut.get("categorie")
        else:
            terme, _, categorie = str(brut).partition(";")
            categorie = categorie.strip() or None
        terme = re.sub(r"\s+", " ", terme).strip()
        if not terme or terme.startswith("#"):
            continue
        if categorie not in categories:
            categorie = None
        cle = normaliser(terme)
        if cle not in regroupes:
            regroupes[cle] = {"terme": terme, "variantes": [terme], "categorie": categorie}
            ordre.append(cle)
        else:
            groupe = regroupes[cle]
            if terme not in groupe["variantes"]:
                groupe["variantes"].append(terme)
            groupe["categorie"] = groupe["categorie"] or categorie
    return [{"id": f"t{i}", **regroupes[cle]} for i, cle in enumerate(ordre, start=1)]


def occurrences_du_terme(textes, variantes, graphies=True):
    """{"exactes": n, "normalisees": m, "fichiers": {fichier: n}} : recherche exacte puis équivalence normalisée."""
    entite = Entite(0, "personne", variantes[0], list(variantes), 1.0, [])
    corr = Correspondances([entite], {0: ""}, {}, (), graphies=graphies)
    exactes = normalisees = 0
    fichiers = {}
    if corr.motif is None:
        return {"exactes": 0, "normalisees": 0, "fichiers": {}}
    ecritures = set(variantes)
    for relatif, texte in textes.items():
        for debut, fin, _ in corr.occurrences(texte):
            fichiers[relatif] = fichiers.get(relatif, 0) + 1
            if texte[debut:fin] in ecritures:
                exactes += 1
            else:
                normalisees += 1
    return {"exactes": exactes, "normalisees": normalisees, "fichiers": fichiers}


def approximations(textes, terme, deja_trouves=(), limite=LIMITE_RESULTATS):
    """Formes proches du terme, à valider par l'utilisateur : [{texte, fichier, contexte, distance}]."""
    permise = distance_permise(terme)
    if not permise:
        return []
    cible = lettres(terme)
    nombre_mots = max(len(RE_MOT.findall(terme)), 1)
    ecartes = {lettres(t) for t in deja_trouves} | {cible}
    trouvees, vues = [], set()
    for relatif, texte in textes.items():
        mots = list(RE_MOT.finditer(texte))
        for i in range(len(mots)):
            for k in {max(nombre_mots - 1, 1), nombre_mots, nombre_mots + 1}:
                if i + k > len(mots):
                    continue
                debut, fin = mots[i].start(), mots[i + k - 1].end()
                surface = texte[debut:fin]
                candidat = lettres(surface)
                if candidat in ecartes or not candidat or cible in candidat:   # forme exacte englobée dans une fenêtre plus large
                    continue
                if levenshtein(candidat, cible, permise) <= permise:
                    cle = (relatif, debut)
                    if cle in vues:
                        continue
                    vues.add(cle)
                    trouvees.append({"texte": surface, "fichier": relatif, "contexte": contexte(texte, debut, fin),
                                     "distance": levenshtein(candidat, cible, permise)})
                    if len(trouvees) >= limite:
                        return trouvees
    return trouvees


# ---------------------------------------------------------------- propositions de fusion


def _raison(a, b):
    """(code, explication) si les deux entités de même catégorie se ressemblent assez pour être PROPOSÉES, sinon None.

    La proximité textuelle ne prouve pas l'identité : rien n'est jamais fusionné sans décision de l'utilisateur."""
    na, nb = normaliser(a["canonique"]), normaliser(b["canonique"])
    pa, pb = plier(a["canonique"]).lower(), plier(b["canonique"]).lower()
    sep = lambda s: re.sub(r"[^a-z0-9]", "", s)  # noqa: E731
    if na == nb or pa == pb:
        return "accents", "Même nom écrit avec des accents ou des séparateurs différents."
    if sep(pa) == sep(pb):
        return "accents", "Même nom écrit avec des séparateurs différents."
    if a["categorie"] == "personne":
        _, prenom_a, nom_a = _decouper_nom(a["canonique"])
        _, prenom_b, nom_b = _decouper_nom(b["canonique"])
        if nom_a and nom_b and normaliser(nom_a) == normaliser(nom_b) and prenom_a and prenom_b \
                and _prenoms_compatibles(prenom_a, prenom_b) and normaliser(prenom_a).rstrip(".") != normaliser(prenom_b).rstrip("."):
            return "abrege", "Forme abrégée (initiale ou prénom écourté) du même nom."
        for court, long_, nom_long in ((a, b, nom_b), (b, a, nom_a)):
            mots = court["canonique"].split()
            _, prenom_long, _ = _decouper_nom(long_["canonique"])
            if len(mots) == 1 and nom_long and prenom_long and normaliser(court["canonique"]) == normaliser(nom_long):
                return "nom_seul", "Le nom seul figure aussi dans un nom complet (plusieurs personnes peuvent le porter)."
    permise = min(distance_permise(a["canonique"]), distance_permise(b["canonique"]))
    if permise and levenshtein(sep(pa), sep(pb), permise) <= permise:
        return "orthographe", "Orthographe très proche (faute de frappe possible)."
    return None


def propositions_fusion(entites):
    """Rapprochements proposés entre entités de MÊME catégorie (jamais personne et organisation) : liste de dictionnaires
    {id, formes: [id…], reference, raison, code, ambigu, occurrences, contextes}. Rien n'est appliqué."""
    par_categorie = defaultdict(list)
    for e in entites:
        par_categorie[e["categorie"]].append(e)
    propositions = []
    for categorie, groupe in par_categorie.items():
        for i, a in enumerate(groupe):
            for b in groupe[i + 1:]:
                trouve = _raison(a, b)
                if not trouve:
                    continue
                code, explication = trouve
                if code == "nom_seul":
                    court = a if len(a["canonique"].split()) == 1 else b
                    reference = b if court is a else a                               # la forme complète
                else:
                    reference = a if (a.get("occurrences", 0), len(a["canonique"])) >= (b.get("occurrences", 0), len(b["canonique"])) else b
                propositions.append({
                    "id": f"f{len(propositions) + 1}", "formes": [a["id"], b["id"]], "reference": reference["id"],
                    "categorie": categorie, "code": code, "raison": explication, "ambigu": False,
                    "occurrences": (a.get("occurrences") or 0) + (b.get("occurrences") or 0),
                    "contextes": list(dict.fromkeys([*(a.get("contextes") or [])[:2], *(b.get("contextes") or [])[:2]])),
                })
    # un nom seul qui rejoint plusieurs noms complets : ambigu
    nombre = defaultdict(int)
    for p in propositions:
        if p["code"] == "nom_seul":
            court = next(f for f in p["formes"] if f != p["reference"])
            nombre[court] += 1
    for p in propositions:
        if p["code"] == "nom_seul":
            court = next(f for f in p["formes"] if f != p["reference"])
            p["ambigu"] = nombre[court] > 1
    return propositions


# ---------------------------------------------------------------- vérification finale des fichiers produits


def verifier_termes(termes, fichiers_sortie, lire, graphies=True):
    """Cherche les termes imposés dans les fichiers RÉELLEMENT produits.

    `termes` : [{"id", "variantes": [...]}], `fichiers_sortie` : [(chemin, nom relatif)], `lire` : fonction de lecture du texte.
    Renvoie (restes, illisibles) : restes = [{terme, fichier, occurrences}] ; illisibles = fichiers dont le texte n'a pas pu
    être relu (l'absence complète des termes n'y est alors pas vérifiée)."""
    restes, illisibles = [], []
    textes = {}
    for chemin, relatif in fichiers_sortie:
        try:
            textes[relatif] = lire(chemin)
        except Exception as e:  # noqa: BLE001 — signalé : un fichier non relu n'est jamais présenté comme vérifié
            illisibles.append({"fichier": relatif, "raison": f"{type(e).__name__} : {e}"})
    for terme in termes:
        if not terme.get("variantes"):
            continue
        trouves = occurrences_du_terme(textes, terme["variantes"], graphies)
        for fichier, nombre in trouves["fichiers"].items():
            restes.append({"terme": terme["id"], "fichier": fichier, "occurrences": nombre})
    return restes, illisibles
