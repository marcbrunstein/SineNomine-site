"""Un lot = un ensemble de fichiers traités ensemble, avec une table de correspondance commune.

Déroulé : analyse (détection) → validation par l'utilisateur → remplacement et rapport.
Les fichiers d'origine ne sont jamais modifiés.
"""

import base64
import hashlib
import re
import shutil
import threading
import traceback
from collections import Counter
from datetime import datetime
from pathlib import Path

from . import config as cfg
from . import apercu, migration, pdf, publication, detection, entites as ent, formats, rapport, sensibles, textes, validation
from .archive import NOM_FICHIER as NOM_ARCHIVE, RE_CODE_REPETE, Archive
from .coffre import PERIMETRE_HISTORIQUE
from .avancement import Avancement
from .remplacement import Correspondances, cle_contexte, contexte, contexte_mots

EXTRAITS_MAX = 50          # extraits renvoyés au plus pour un terme (le total est indiqué à part)

LOTS = {}
RE_DOSSIER_LOT = re.compile(r"^lot_\d{4}-\d{2}-\d{2}_\d{6}b*$")


def maintenant():
    return datetime.now().strftime("%d/%m/%Y à %H:%M:%S")


def fichiers_du_dossier(dossier):
    """Fichiers pris en charge du dossier (sous-dossiers compris) et fichiers ignorés."""
    dossier = Path(dossier)
    retenus, ignores = [], []
    for chemin in sorted(dossier.rglob("*")):
        if not chemin.is_file():
            continue
        relatif = chemin.relative_to(dossier).as_posix()
        # Copies déposées par l'interface (entree\lot_AAAA-MM-JJ_HHMMSS\) : déjà dans le lot, à ne pas retraiter.
        if any(RE_DOSSIER_LOT.match(p) for p in Path(relatif).parts[:-1]):
            continue
        if chemin.name.startswith("~$") or chemin.name.startswith("."):
            continue
        if chemin.suffix.lower() in formats.EXTENSIONS_ENTREE:
            retenus.append((chemin, relatif))
        else:
            ignores.append(relatif)
    return retenus, ignores


MODE_PSEUDONYMISATION = "pseudonymisation"   # codes aléatoires + archive : réversible
MODE_ANONYMISATION = "anonymisation"         # Personne_1, Société_1… : rien n'est conservé, irréversible
MODES = (MODE_PSEUDONYMISATION, MODE_ANONYMISATION)


class _Bloque(Exception):
    """Un terme imposé subsiste dans un fichier produit."""


class Lot:
    @property
    def pseudonymisation(self):
        return self.mode == MODE_PSEUDONYMISATION

    def __init__(self, config, modeles, fichiers, ignores, avertissement_accepte, dossier_sortie=None,
                 mode=MODE_PSEUDONYMISATION, langue="fr", format_pdf=None, portee=None, termes_imposes=None):
        if mode not in MODES:
            raise ValueError(f"Mode inconnu : {mode}")
        # Termes que l'utilisateur veut voir ABSENTS du résultat (voir validation.py) : traités comme des entités obligatoires.
        self.termes_imposes = validation.nettoyer_termes(termes_imposes, detection.CATEGORIES_ENTITES)
        self.passages = []                          # passages masqués à la main : [{"texte", "cles"}]
        self.choix_precedent = None                 # actions, exceptions et images choisies avant un blocage (reprise de la validation)
        self.termes_retires = set()                 # termes imposés que l'utilisateur a explicitement retirés de la liste
        self.verification = None                    # contrôle final des fichiers produits (termes imposés)
        self.decisions = {}                         # décisions de validation, comptées (sans aucun texte) pour l'historique
        self.mode = mode
        # Périmètre de stabilité des pseudonymes (voir perimetres.py) : OBLIGATOIRE pour pseudonymiser, jamais implicite.
        # Sans conservation des correspondances, il ne sert qu'à choisir les listes du client ou du projet (lecture seule).
        if portee is None and mode == MODE_PSEUDONYMISATION:
            raise ValueError("Choisissez le périmètre des pseudonymes (document, projet ou client).")
        self.portee = portee
        self.documents = {}                         # périmètre Document : chemin relatif -> identifiant du document logique
        # Format des fichiers produits à partir d'un PDF (docx, pptx, md, txt, html, xlsx)
        self.format_pdf = format_pdf if format_pdf in pdf.FORMATS_SORTIE else config.get("pdf_format_sortie", pdf.FORMAT_DEFAUT)
        pdf.configurer(config)
        self.langue = textes.langue_valide(langue)     # langue du rapport : celle de l'interface au lancement
        sensibles.configurer(config.get("references_motifs", []))
        self.depot_copie = None                    # copie des fichiers déposés dans l'interface (à effacer en anonymisation)
        self.config = config
        self.modeles = modeles
        self.id = "lot_" + datetime.now().strftime("%Y-%m-%d_%H%M%S")
        while self.id in LOTS:
            self.id += "b"
        self.fichiers = fichiers                    # [(chemin source, chemin relatif)]
        self.ignores = ignores
        self.avertissement_accepte = avertissement_accepte
        self.dossier_sortie = Path(dossier_sortie) if dossier_sortie else cfg.dossier(config, "sortie") / self.id
        self.etat = "analyse"
        self.avancement = Avancement(len(fichiers))
        self.avancement.maj("modeles", "En attente des modèles de détection", 0.0)
        self.erreur = None
        self.textes = {}
        self.erreurs_lecture = {}
        self.mots = {}                              # chemin relatif -> nombre de mots du texte extrait
        self.entites = []
        self.sensibles = {}
        self.images = {}                            # chemin relatif -> nombre d'images
        self.apercus = []                           # [(chemin source, image, chemin relatif)], indexés pour l'interface
        self.supprimer_images = False
        self.resultats = []
        self.date_validation = None
        self.date_traitement = None
        self.fichier_rapport = None
        self.fichier_correspondances = None
        self._pour_export = None                    # (libellés, entités, correspondances) en mémoire, pour l'export explicite
        LOTS[self.id] = self

    # ------------------------------------------------------------------ analyse

    def lancer_analyse(self):
        threading.Thread(target=self._proteger, args=(self._analyser,), daemon=True).start()

    def _proteger(self, fonction, *args):
        try:
            fonction(*args)
        except Exception as e:  # noqa: BLE001 — affiché dans l'interface
            traceback.print_exc()
            self.etat, self.erreur = "erreur", f"{type(e).__name__} : {e}"

    def _analyser(self):
        av = self.avancement
        av.demarrer("analyse")
        av.maj("modeles", "Chargement des modèles de détection (20 à 90 secondes au démarrage)", 0.0)
        self.modeles.attendre()
        coffre = self._coffre()
        dictionnaires = detection.Dictionnaires.pour_perimetre(
            cfg.dossier(self.config, "dictionnaires"), coffre, self._perimetre_partage())
        candidats = []
        sensibles_trouves = {}
        total = max(len(self.fichiers), 1)
        for i, (chemin, relatif) in enumerate(self.fichiers):
            av.maj("lecture", "Lecture des fichiers", 0.01 + 0.07 * i / total, courant=i, fichier=relatif)
            try:
                texte = formats.lire_texte(chemin, progression=lambda page, nb, f=relatif, k=i: av.maj(
                    "lecture", "Lecture des fichiers", 0.01 + 0.07 * k / total, courant=k, fichier=f,
                    detail=f"page {page} / {nb}") if str(chemin).lower().endswith(".pdf") else None)
            except Exception as e:  # noqa: BLE001 — fichier illisible : signalé, le lot continue
                self.erreurs_lecture[relatif] = f"{type(e).__name__} : {e}"
                continue
            self.textes[relatif] = texte
            if coffre is not None and self.portee["type"] == "document":
                self.documents[relatif] = coffre.document_pour(hashlib.sha256(Path(chemin).read_bytes()).hexdigest(), relatif)
            self.images[relatif] = formats.compter_images(chemin)
            if self.images[relatif]:
                self.apercus += [(chemin, image, relatif) for image in formats.images_du_fichier(chemin)]
        mots_courants = detection.lexique(self.textes.values())

        formes_vues = {c: set() for c in detection.CATEGORIES_ENTITES}
        lisibles = [(i, c, r) for i, (c, r) in enumerate(self.fichiers) if r in self.textes]
        self.mots = {r: len(t.split()) for r, t in self.textes.items()}
        av.mots_total, av.mots, mots_faits = sum(self.mots.values()), 0, 0
        for rang, (i, chemin, relatif) in enumerate(lisibles):
            texte = self.textes[relatif]
            sous = {"spaCy": 0.0, "GLiNER": 0.0}

            def rappel(modele, k, n_total, rang=rang, relatif=relatif, i=i, sous=sous):
                """Appelé par la détection pendant un fichier : fait avancer la barre au sein du fichier."""
                sous[modele] = k / max(n_total, 1)
                poids_spacy = 0.3 if self.modeles.gliner is not None else 1.0
                part = poids_spacy * sous["spaCy"] + (1 - poids_spacy) * sous["GLiNER"]
                av.mots = mots_faits + int(part * self.mots[relatif])      # avance aussi au sein d'un long fichier
                av.maj("detection", "Détection des noms, sociétés, produits et lieux",
                       0.08 + 0.84 * (rang + part) / max(len(lisibles), 1), courant=i, fichier=relatif,
                       detail=f"{modele} : {k} / {n_total}")

            av.maj("detection", "Détection des noms, sociétés, produits et lieux",
                   0.08 + 0.84 * rang / max(len(lisibles), 1), courant=i, fichier=relatif)
            nouveaux = detection.analyser(texte, relatif, self.modeles, dictionnaires, mots_courants, rappel)
            candidats += nouveaux
            mots_faits += self.mots[relatif]
            av.mots = mots_faits
            for c in nouveaux:
                if c.source != "suggestion":
                    formes_vues[c.categorie].add(detection.normaliser(c.surface))
            av.decouverts = {**{c: len(v) for c, v in formes_vues.items()},
                             "sensible": sum(it["occurrences"] for it in sensibles_trouves.values())}
            for t in sensibles.detecter(texte):
                cle = (t.categorie, t.cle)
                item = sensibles_trouves.setdefault(cle, {
                    "categorie": t.categorie, "cle": t.cle, "valeurs": set(), "occurrences": 0,
                    "fichiers": Counter(), "contextes": [], "score": t.score})
                item["valeurs"].add(t.valeur)
                item["occurrences"] += 1
                item["fichiers"][relatif] += 1
                item["score"] = max(item["score"], t.score)
                if len(item["contextes"]) < 3:
                    item["contextes"].append(contexte(texte, t.debut, t.fin))
            av.decouverts["sensible"] = sum(it["occurrences"] for it in sensibles_trouves.values())

        av.maj("regroupement", "Regroupement des entités et calcul des occurrences", 0.93, courant=len(self.fichiers))
        entites = ent.regrouper(candidats)
        self._integrer_termes_imposes(entites)
        self._compter(entites)
        seuil = self.config["seuil_preselection"]
        self.entites = [e for e in entites if e.occurrences > 0 or e.termes]       # un terme imposé reste affiché à zéro occurrence
        n = len([r for r in self.fichiers if r[1] in self.textes])
        archive = Archive.ouvrir(self.config, self._perimetre_partage()) if self._perimetre_partage() and self.pseudonymisation else None
        for e in self.entites:
            penalite = 0.0
            partout = n >= 4 and len(e.fichiers) >= 0.5 * n
            if not set(e.sources) & detection.SOURCES_SURES:
                # Une « personne » présente dans la plupart des fichiers est souvent du vocabulaire de gabarit.
                if e.categorie == "personne" and partout:
                    penalite = 0.3
                # Un prénom seul présent dans plusieurs fichiers est souvent un produit ou une marque (« Claude »).
                elif e.categorie == "personne" and " " not in e.canonique and n >= 4 and len(e.fichiers) >= 4:
                    penalite = 0.3
                # spaCy seul (GLiNER n'a rien vu) : très souvent des titres, des intitulés d'onglets, des mots courants.
                if set(e.sources) == {"spaCy"} and e.categorie in ("personne", "societe", "produit"):
                    if partout:                                       # présent partout : vocabulaire de gabarit
                        penalite = max(penalite, 0.3)
                    elif any(detection._mot_courant(m, mots_courants, 1) for m in e.canonique.split()
                             if m.lower() not in detection.PARTICULES):  # contient un mot courant (« Stock », « Centre »)
                        penalite = max(penalite, 0.2)
            if penalite:
                e.score = round(max(e.score - penalite, 0.0), 2)
            e.selection = e.score >= seuil
            # Les lieux (Paris, Londres…) reviennent dans presque tout document : décochés d'office,
            # sauf ceux du dictionnaire des lieux (choix explicite de l'utilisateur).
            if (e.categorie == "lieu" and "dictionnaire" not in e.sources
                    and not self.config.get("lieux_preselectionnes")):
                e.selection = False
            if archive is None:      # anonymisation : on ne lit rien de ce qui a été conservé auparavant
                continue
            # Mémoire des lots précédents : un nom déjà anonymisé garde son code et reste coché ;
            # un terme décoché à une validation précédente le reste (visible dans la colonne des sources).
            e.code = archive.chercher_entite(e.categorie, e.canonique)
            if e.code:
                e.selection, e.score = True, max(e.score, 0.95)
                e.sources = sorted({*e.sources, "archive"})
            elif archive.est_refuse(e.categorie, e.canonique) and "dictionnaire" not in e.sources:
                e.selection = False
                e.sources = sorted({*e.sources, "refusé précédemment"})
        for e in self.entites:                                     # un terme imposé reste coché, quel que soit son score
            if e.termes:
                e.selection = True
                e.sources = sorted({*e.sources, "fourni par l'utilisateur"})
        self._proposer_approximations()
        self.sensibles = sensibles_trouves
        av.terminer()
        self.etat = "a_valider"

    def _integrer_termes_imposes(self, entites):
        """Ajoute les termes imposés aux entités détectées : une entité existante qui les contient, sinon une nouvelle entité.
        Les écritures en minuscules sont cherchées aussi (une exigence d'absence vaut pour toutes les casses)."""
        prochain = max([e.id for e in entites] + [0]) + 1
        for t in self.termes_imposes:
            ecritures = list(dict.fromkeys([*t["variantes"], *(v.lower() for v in t["variantes"])]))
            cles = {detection.normaliser(v) for v in ecritures}
            cible = next((e for e in entites if cles & {detection.normaliser(v) for v in e.variantes}), None)
            if cible is None:
                cible = ent.Entite(prochain, t["categorie"] or "personne", t["terme"], ecritures, 1.0, ["fourni par l'utilisateur"])
                prochain += 1
                entites.append(cible)
            else:
                cible.variantes = list(dict.fromkeys([*cible.variantes, *ecritures]))
                cible.sources = sorted({*cible.sources, "fourni par l'utilisateur"})
                if t["categorie"]:
                    cible.categorie = t["categorie"]
            cible.termes.append(t["id"])
            cible.selection = True

    def _proposer_approximations(self):
        """Formes proches d'un terme imposé, proposées à l'utilisateur (distance 1 ou 2, jamais sous 5 lettres)."""
        for e in self.entites:
            for t in self.termes_imposes:
                if t["id"] in e.termes:
                    for a in validation.approximations(self.textes, t["terme"], deja_trouves=e.variantes):
                        if a["texte"] not in {x["texte"] for x in e.approximatives}:
                            e.approximatives.append(a)

    def verifier_choix(self, choix):
        """Refuse un choix qui écarterait un terme imposé sans que l'utilisateur l'ait retiré de la liste, explicitement."""
        retires = set(choix.get("termes_retires", []))
        couverts = {detection.normaliser(v) for e in self._entites_validees(choix) if e.selection for v in e.variantes}
        manquants = [t["terme"] for t in self.termes_imposes
                     if t["id"] not in retires and detection.normaliser(t["terme"]) not in couverts]
        if manquants:
            raise ValueError("Termes imposés non traités (cochez-les, ou retirez-les explicitement de la liste) : "
                             + ", ".join(manquants))

    def passage(self, fichier, debut, fin):
        """Passage sélectionné à la main dans le texte d'un fichier : {texte, cle, autres} ; `autres` = autres occurrences
        identiques (même texte exact), à examiner une à une. Une sélection sur plusieurs paragraphes est refusée."""
        texte = (self.textes.get(fichier) or "").replace("\r\n", "\n") if fichier in self.textes else None
        if texte is None or not (isinstance(debut, int) and isinstance(fin, int)) or not 0 <= debut < fin <= len(texte):
            raise ValueError("Sélection invalide.")
        passage = texte[debut:fin]
        if not passage.strip():
            raise ValueError("Sélectionnez du texte.")
        if "\n" in passage:
            raise ValueError("Sélectionnez un passage d'un seul paragraphe (un masquage par paragraphe).")
        if len(passage) > 2000:
            raise ValueError("Passage trop long (2 000 caractères au plus).")
        occurrences, trouvees = [], 0
        for relatif, contenu in self.textes.items():
            contenu = contenu.replace("\r\n", "\n")
            position = contenu.find(passage)
            while position >= 0:
                trouvees += 1
                if len(occurrences) < 200:
                    occurrences.append({"fichier": relatif, "debut": position, "cle": cle_contexte(contenu, position, position + len(passage)),
                                        "extrait": contexte_mots(contenu, position, position + len(passage), 8)})
                position = contenu.find(passage, position + len(passage))
        cle = cle_contexte(texte, debut, fin)
        return {"texte": passage, "cle": cle, "occurrences": occurrences, "total": trouvees}

    def occurrences_de(self, variantes, limite=200, mots=10):
        """Occurrences d'un terme (mêmes règles que le remplacement) avec leur clé de contexte : [{fichier, extrait, cle}]."""
        variantes = [v.strip() for v in variantes if isinstance(v, str) and v.strip()]
        if not variantes:
            return {"total": 0, "occurrences": []}
        terme = ent.Entite(0, "personne", variantes[0], variantes, 1.0, [])
        corr = Correspondances([terme], {0: ""}, {}, (), graphies=self._graphies())
        total, resultats = 0, []
        for _, relatif in self.fichiers:
            texte = self.textes.get(relatif)
            if texte is None or corr.motif is None:
                continue
            for debut, fin, _ in corr.occurrences(texte):
                total += 1
                if len(resultats) < limite:
                    resultats.append({"fichier": relatif, "cle": cle_contexte(texte, debut, fin),
                                      "extrait": contexte_mots(texte, debut, fin, min(max(int(mots), 0), 100))})
        return {"total": total, "occurrences": resultats}

    def reprendre(self):
        """Après un blocage (terme resté dans un fichier produit) : retour à la validation, avec les mêmes choix."""
        if self.etat != "bloque":
            raise ValueError("Ce lot n'est pas bloqué.")
        self.etat = "a_valider"
        self.verification = None

    def extraits(self, variantes, mots=15):
        """Extraits de texte (`mots` mots avant et après) où apparaît l'une des variantes d'un terme."""
        variantes = [v.strip() for v in variantes if isinstance(v, str) and v.strip()]
        if not variantes:
            return {"total": 0, "extraits": []}
        mots = min(max(int(mots), 0), 100)
        terme = ent.Entite(0, "personne", variantes[0], variantes, 1.0, [])
        correspondances = Correspondances([terme], {0: ""}, {}, (), graphies=self._graphies())
        total, extraits = 0, []
        for _, relatif in self.fichiers:
            texte = self.textes.get(relatif)
            if texte is None or correspondances.motif is None:
                continue
            for debut, fin, _ in correspondances.occurrences(texte):
                total += 1
                if len(extraits) < EXTRAITS_MAX:
                    extraits.append({"fichier": relatif, "extrait": contexte_mots(texte, debut, fin, mots)})
        return {"total": total, "extraits": extraits}

    def _perimetre_partage(self):
        """Identifiant du périmètre commun à tous les fichiers (projet ou client) ; None en périmètre Document ou sans périmètre."""
        if self.portee and self.portee["type"] in ("projet", "client"):
            return self.portee["perimetre_id"]
        return None

    def _coffre(self):
        """Coffre de l'application (migré si besoin), ou None si le lot n'a besoin d'aucun périmètre."""
        if self.portee is None:
            return None
        coffre = migration.obtenir_coffre(self.config)
        migration.migrer_si_necessaire(self.config, coffre)
        return coffre

    def _graphies(self):
        """Graphies étrangères équivalentes (Kärscher = Kaerscher) : réglage `filtres.graphies_etrangeres`."""
        return bool(self.config.get("filtres", {}).get("graphies_etrangeres", True))

    def _chemin_archive(self):
        return cfg.dossier(self.config, "correspondances") / NOM_ARCHIVE

    def _compter(self, entites):
        """Occurrences, fichiers, contextes et première apparition, avec la même recherche que le remplacement."""
        correspondances = Correspondances(entites, {e.id: "" for e in entites}, {}, (),
                                          graphies=self._graphies())
        for e in entites:
            e.occurrences, e.fichiers, e.contextes, e.premiere = 0, {}, [], (10**9, 10**9)
        par_id = {e.id: e for e in entites}
        for index, (_, relatif) in enumerate(self.fichiers):
            texte = self.textes.get(relatif)
            if texte is None or correspondances.motif is None:
                continue
            for debut, fin, id_entite in correspondances.occurrences(texte):
                e = par_id[id_entite]
                e.occurrences += 1
                e.fichiers[relatif] = e.fichiers.get(relatif, 0) + 1
                e.premiere = min(e.premiere, (index, debut))
                if len(e.contextes) < 3:
                    e.contextes.append(contexte(texte, debut, fin))

    # ------------------------------------------------------------------ état pour l'interface

    def vers_dict(self):
        donnees = {
            "id": self.id, "mode": self.mode, "etat": self.etat, "progression": self.avancement.vers_dict(),
            "erreur": self.erreur,
            "fichiers": [r for _, r in self.fichiers], "ignores": self.ignores,
            "erreurs_lecture": self.erreurs_lecture, "dossier_sortie": str(self.dossier_sortie),
            "images": {f: n for f, n in self.images.items() if n},
            "apercus": self.apercus_par_fichier(),
            "portee": self.portee, "verification": self.verification,
        }
        # En anonymisation, plus aucun nom d'origine n'est renvoyé une fois le traitement terminé.
        if self.etat in ("a_valider", "traitement", "bloque") or (self.etat == "termine" and self.pseudonymisation):
            donnees["termes_imposes"] = [{"id": t["id"], "terme": t["terme"]} for t in self.termes_imposes]
            donnees["termes_retires"] = sorted(self.termes_retires)
            donnees["passages"] = self.passages
            donnees["choix_precedent"] = self.choix_precedent
            donnees["entites"] = [e.vers_dict() for e in sorted(self.entites, key=lambda e: e.premiere)]
            donnees["sensibles"] = [
                {**{k: v for k, v in item.items() if k not in ("valeurs", "fichiers")},
                 "valeurs": sorted(item["valeurs"]), "fichiers": dict(item["fichiers"])}
                for item in sorted(self.sensibles.values(), key=lambda i: (i["categorie"], -i["occurrences"]))]
        if self.etat == "termine":
            donnees["resultats"] = [{k: v for k, v in r.items() if k not in ("journal", "apercus_rapport", "libelles")}
                                    for r in self.resultats]
            donnees["rapport"] = self.fichier_rapport
            donnees["correspondances"] = str(self.fichier_correspondances) if self.fichier_correspondances else None
        return donnees

    def apercus_par_fichier(self):
        """Description des images de chaque fichier ; l'image elle-même est servie par /apercu/<index>."""
        resultat = {}
        for index, (_, image, relatif) in enumerate(self.apercus):
            resultat.setdefault(relatif, []).append({
                "index": index, "nom": image["nom"], "occurrences": image["occurrences"],
                "note": image["note"], "accessible": bool(image.get("membre") or image.get("chemin"))})
        return resultat

    def apercu(self, index, taille):
        """Miniature (octets, type MIME) de l'image n° index, ou None."""
        if not 0 <= index < len(self.apercus):
            return None
        source, image, _ = self.apercus[index]
        donnees = formats.lire_image(source, image)
        return apercu.miniature(donnees, image["nom"], taille) if donnees else None

    def _apercus_rapport(self, relatif):
        """Miniatures intégrées au rapport HTML (en base64), pour un fichier dont les images sont conservées."""
        liste = []
        for index, (_, image, fichier) in enumerate(self.apercus):
            if fichier != relatif:
                continue
            mini = self.apercu(index, 240)
            liste.append({"nom": image["nom"], "occurrences": image["occurrences"], "note": image["note"],
                          "type": mini[1] if mini else None,
                          "donnees": base64.b64encode(mini[0]).decode("ascii") if mini else None,
                          "dimensions": mini[2] if mini else None})
        return liste

    # ------------------------------------------------------------------ validation et remplacement

    def valider(self, choix):
        self.etat = "traitement"
        self.date_validation = maintenant()
        threading.Thread(target=self._proteger, args=(self._appliquer, choix), daemon=True).start()

    def _entites_validees(self, choix):
        prochain = max([e.id for e in self.entites] + [0]) + 1
        validees = []
        for donnee in choix.get("entites", []):
            variantes = [v.strip() for v in donnee.get("variantes", []) if v and v.strip()]
            canonique = (donnee.get("canonique") or "").strip() or (variantes[0] if variantes else "")
            if not canonique or donnee.get("categorie") not in detection.CATEGORIES_ENTITES:
                continue
            if canonique not in variantes:
                variantes.insert(0, canonique)
            identifiant = donnee.get("id") or prochain
            if not donnee.get("id"):
                prochain += 1
            valides = {t["id"] for t in self.termes_imposes} - set(choix.get("termes_retires", []))
            validees.append(ent.Entite(id=identifiant, categorie=donnee["categorie"], canonique=canonique,
                                       variantes=variantes, score=donnee.get("score", 1.0),
                                       sources=donnee.get("sources", ["manuel"]),
                                       selection=bool(donnee.get("selection")),
                                       termes=[t for t in donnee.get("termes", []) if t in valides],
                                       gardees=[g for g in donnee.get("gardees", []) if isinstance(g, str)]))
        return validees

    def _appliquer(self, choix):
        av = self.avancement
        av.demarrer("traitement")
        av.substitutions.clear()
        mots_faits = 0
        av.maj("preparation", "Préparation des remplacements", 0.01)
        self.entites = self._entites_validees(choix)
        retenues = [e for e in self.entites if e.selection]
        categorie_de = {e.id: e.categorie for e in retenues}
        self._compter(retenues)
        self.passages = [{"texte": p["texte"], "cles": [c for c in p["cles"] if isinstance(c, str)]}
                         for p in choix.get("passages", []) if isinstance(p, dict) and isinstance(p.get("texte"), str)
                         and p["texte"].strip() and isinstance(p.get("cles"), list) and "\n" not in p["texte"]]
        gardees = {e.id: set(e.gardees) for e in retenues if e.gardees}
        retires = set(choix.get("termes_retires", []))
        self.termes_retires = retires
        self.choix_precedent = {"actions": choix.get("actions", {}), "exclusions": choix.get("exclusions", []), "images": choix.get("images")}
        self.decisions = {"fusions": int(choix.get("fusions", 0) or 0), "passages": len(self.passages),
                          "occurrences_conservees": sum(len(v) for v in gardees.values()),
                          "termes_imposes": len(self.termes_imposes) - len(retires & {t["id"] for t in self.termes_imposes}),
                          "termes_retires": len(retires)}
        total = max(len([r for r in self.fichiers if r[1] not in self.erreurs_lecture]), 1)
        actions = {c: choix.get("actions", {}).get(c, "conserver") for c in sensibles.CATEGORIES}
        exclusions = {tuple(x) for x in choix.get("exclusions", []) if isinstance(x, (list, tuple)) and len(x) == 2}
        par_document = self.pseudonymisation and self.portee["type"] == "document"
        coffre = migration.obtenir_coffre(self.config)
        migration.migrer_si_necessaire(self.config, coffre)
        jeux = {}            # chemin relatif -> (archive, entités, codes, correspondances) ; une seule entrée partagée sauf périmètre Document
        # 1. état du lot dans le coffre : sans correspondances en mode « sans conservation » (rien d'identifiant n'y figure)
        perimetre_lot = (self._perimetre_partage() or next(iter(self.documents.values()), PERIMETRE_HISTORIQUE)
                         if self.pseudonymisation else PERIMETRE_HISTORIQUE)
        coffre.declarer_lot(self.id, perimetre_lot, self.mode, {"portee": self.portee["type"] if self.portee else None})

        def jeu(archive, entites):
            codes = ent.libelles(entites, archive) if archive else ent.libelles_numerotes(entites)      # codes réservés durablement
            return (archive, entites, codes, Correspondances(entites, codes, actions, exclusions, archive,
                                                             numerote=not self.pseudonymisation, graphies=self._graphies(),
                                                             passages=self.passages, gardees=gardees))

        if par_document:
            for relatif in self.documents:
                en_fichier = [e for e in retenues if relatif in e.fichiers or e.termes]   # un terme imposé a un pseudonyme dans chaque document
                jeux[relatif] = jeu(Archive.ouvrir(self.config, self.documents[relatif]), en_fichier)
        else:
            partage = jeu(Archive.ouvrir(self.config, self._perimetre_partage()) if self.pseudonymisation else None, retenues)
            for _, relatif in self.fichiers:
                jeux[relatif] = partage
        libelles = {} if par_document else next(iter(jeux.values()), (None, None, {}, None))[2]
        correspondances = next(iter(jeux.values()), (None, None, None, None))[3]
        self.supprimer_images = choix.get("images") == "supprimer"

        # 2. tout est écrit dans un dossier provisoire voisin de la destination
        provisoire = publication.preparer(publication.dossier_provisoire(self.dossier_sortie, self.id))
        coffre.changer_etat_lot(self.id, "en_cours", {"provisoire": str(provisoire), "destination": str(self.dossier_sortie)})
        try:
            utilises = {p.relative_to(self.dossier_sortie).as_posix().lower()
                        for p in self.dossier_sortie.rglob("*") if p.is_file()} if self.dossier_sortie.exists() else set()
            self.resultats = []
            fait = 0
            for i, (chemin, relatif) in enumerate(self.fichiers):
                if relatif in self.erreurs_lecture:
                    continue
                av.maj("remplacement", "Remplacement dans les fichiers", 0.06 + 0.84 * fait / total, courant=i, fichier=relatif)
                fait += 1
                archive_f, entites_f, codes_f, corr_f = jeux[relatif]
                sortie_relative = self._nom_sortie(relatif, corr_f, utilises, self.format_pdf)
                journal = rapport.Journal()
                resultat = {"source": relatif, "sortie_relative": sortie_relative, "journal": journal,
                            "avertissements": [], "erreur": None}
                if par_document:
                    resultat["libelles"] = codes_f
                try:
                    resultat["avertissements"] = formats.avertissements(chemin, self.supprimer_images)
                    formats.ecrire_anonymise(chemin, provisoire / sortie_relative, corr_f, journal,
                                             supprimer_images=self.supprimer_images)
                except Exception as e:  # noqa: BLE001
                    traceback.print_exc()
                    resultat["erreur"] = f"{type(e).__name__} : {e}"
                resultat["entites"] = sum(journal.entites.values())
                resultat["sensibles"] = sum(journal.sensibles.values())
                resultat["conservees"] = len(journal.conservees)
                resultat["images"] = journal.images_supprimees
                resultat["passages"] = journal.passages
                for identifiant, nombre in journal.entites.items():          # substitutions comptées par catégorie
                    av.substitutions[categorie_de.get(identifiant, "personne")] += nombre
                av.substitutions["sensible"] += resultat["sensibles"]
                av.substitutions["image"] += journal.images_supprimees
                mots_faits += self.mots.get(relatif, 0)
                av.mots = mots_faits
                if journal.parties_reparees:
                    resultat["avertissements"].append(
                        f"Fichier d'origine endommagé, réparé dans la version anonymisée : {journal.parties_reparees} "
                        "élément(s) sans type déclaré (Word proposait de « récupérer le contenu » de l'original).")
                resultat["apercus_rapport"] = [] if self.supprimer_images else self._apercus_rapport(relatif)
                self.resultats.append(resultat)

            self._controler_termes_imposes(retenues, retires, provisoire)
            av.maj("rapport", "Rédaction du rapport et de l'archive", 0.92, courant=len(self.fichiers))
            self.date_traitement = maintenant()
            if self.pseudonymisation:
                # Les correspondances sont enregistrées AVANT la publication : sans elles, les fichiers produits ne pourraient
                # plus être restaurés. Fusion transactionnelle : un autre lot simultané ne peut pas les écraser.
                deja = set()
                for relatif, (archive_f, entites_f, codes_f, corr_f) in jeux.items():
                    if id(archive_f) in deja:
                        continue
                    deja.add(id(archive_f))
                    archive_f.enregistrer_lot(self.id, self.date_traitement, entites_f, codes_f,
                                              corr_f.sensibles_libelles, corr_f.sensibles_valeurs)
                    if not par_document:                      # refus de détection : mémorisés pour CE client ou projet seulement
                        for e in self.entites:
                            if e.selection:
                                archive_f.accepter(e.categorie, e.canonique)
                            elif set(e.sources) != {"suggestion"}:   # les suggestions sont décochées d'office : rien à retenir
                                archive_f.refuser(e.categorie, e.canonique)
                    archive_f.sauver()
            rapport.ecrire_html(provisoire / "rapport.html", self, self.resultats, libelles, retenues, correspondances)
            rapport.ecrire_excel(provisoire / "rapport.xlsx", self, self.resultats, libelles, retenues)
            # 3. contrôle et manifeste ; 4. lot « pret » ; 5. publication ; 6. lot « publie »
            attendus = [r["sortie_relative"] for r in self.resultats if not r["erreur"]] + ["rapport.html", "rapport.xlsx"]
            manifeste = publication.manifeste(provisoire, attendus)
            coffre.changer_etat_lot(self.id, "pret", {"provisoire": str(provisoire), "destination": str(self.dossier_sortie),
                                                      "manifeste": manifeste})
            publication.publier(provisoire, self.dossier_sortie, manifeste)
            coffre.changer_etat_lot(self.id, "publie", {})
        except _Bloque:
            # Un terme imposé subsiste dans un fichier produit : rien n'est publié, aucune correspondance n'est enregistrée.
            publication.nettoyer(provisoire)
            coffre.changer_etat_lot(self.id, "abandonne", {})
            coffre.journaliser("validation", {"lot": self.id, "decisions": self.decisions, "bloque": True})
            self.etat = "bloque"
            return
        except BaseException:
            publication.nettoyer(provisoire)
            coffre.changer_etat_lot(self.id, "abandonne", {})
            raise
        coffre.journaliser("validation", {"lot": self.id, "decisions": self.decisions})
        if self.pseudonymisation:
            # Aucune table en clair n'est écrite d'office : l'export est une action explicite (exporter_correspondances).
            self._pour_export = [(relatif, entites_f, codes_f, corr_f) for relatif, (_, entites_f, codes_f, corr_f) in jeux.items()
                                 if par_document] or [("", retenues, libelles, correspondances)]
        else:
            self._oublier()
        self.fichier_rapport = "rapport.html"
        av.terminer()
        self.etat = "termine"

    def _controler_termes_imposes(self, retenues, retires, provisoire):
        """Cherche les termes imposés dans les fichiers RÉELLEMENT produits ; bloque la publication s'il en reste un.
        Les fichiers dont une partie n'est pas analysée sont signalés : l'absence complète n'y est pas garantie."""
        effectifs = [{"id": t["id"], "variantes": next((e.variantes for e in retenues if t["id"] in e.termes), t["variantes"])}
                     for t in self.termes_imposes if t["id"] not in retires]
        if not effectifs:
            self.verification = None
            return
        sorties = [(provisoire / r["sortie_relative"], r["sortie_relative"]) for r in self.resultats if not r["erreur"]]
        restes, illisibles = validation.verifier_termes(effectifs, sorties, formats.lire_texte, self._graphies())
        non_verifiables = list(illisibles)
        non_verifiables += [{"fichier": r["sortie_relative"], "raison": a} for r in self.resultats for a in r["avertissements"]
                            if "miniature" not in a]
        non_verifiables += [{"fichier": f, "raison": "Fichier non lu : " + m} for f, m in self.erreurs_lecture.items()]
        non_verifiables += [{"fichier": r["sortie_relative"], "raison": r["erreur"]} for r in self.resultats if r["erreur"]]
        noms = {t["id"]: t["terme"] for t in self.termes_imposes}
        self.verification = {"ok": not restes, "termes": len(effectifs), "non_verifiables": non_verifiables,
                             "restes": [{**r, "terme_nom": noms.get(r["terme"], "")} for r in restes]}
        if restes:
            raise _Bloque()

    def exporter_correspondances(self, dossier=None):
        """EXPORT EN CLAIR de la table de correspondance (noms d'origine et pseudonymes), sur action explicite de l'utilisateur."""
        if not self.pseudonymisation or getattr(self, "_pour_export", None) is None:
            raise ValueError("Aucune table de correspondance n'est disponible pour ce lot.")
        dossier = Path(dossier) if dossier else cfg.dossier(self.config, "correspondances")
        dossier.mkdir(parents=True, exist_ok=True)
        chemins = []
        for numero, (relatif, entites_f, codes_f, corr_f) in enumerate(self._pour_export, start=1):
            suffixe = f"_{numero}" if len(self._pour_export) > 1 else ""      # périmètre Document : un fichier par document
            chemin = dossier / f"{self.id}{suffixe}_correspondances_CONFIDENTIEL.xlsx"
            rapport.ecrire_correspondances(chemin, self, codes_f, entites_f, corr_f)
            chemins.append(chemin)
        self.fichier_correspondances = chemins[0]
        return chemins[0]

    def _oublier(self):
        """Anonymisation irréversible : on efface ce qui permettrait de retrouver les noms d'origine.

        Textes lus, entités (noms, contextes), valeurs sensibles et aperçus en mémoire ; copies des fichiers
        déposés dans l'interface. Les fichiers que l'utilisateur a indiqués par un dossier ne sont jamais touchés.
        """
        self.textes, self.entites, self.sensibles, self.apercus = {}, [], {}, []
        self.passages, self.choix_precedent = [], None
        self._pour_export = None
        pdf.oublier()
        if self.depot_copie is not None:
            shutil.rmtree(self.depot_copie, ignore_errors=True)
            self.depot_copie = None

    @staticmethod
    def _nom_sortie(relatif, correspondances, utilises, format_pdf=pdf.FORMAT_DEFAUT):
        """Le nom du fichier peut lui-même contenir un nom : il est anonymisé aussi.
        Un PDF devient un fichier du format choisi (.docx, .pptx, .md…)."""
        parties = []
        for partie in Path(relatif).parts:
            p = Path(partie)
            radical, extension = (p.stem, p.suffix) if p.suffix.lower() in formats.EXTENSIONS_ENTREE else (partie, "")
            if extension.lower() == ".pdf":
                extension = "." + format_pdf
            nouveau = correspondances.remplacer(radical)[0]
            nouveau = RE_CODE_REPETE.sub(r"\1", nouveau)      # « Ines_Marchand » : un seul code, pas deux à la suite
            nouveau = re.sub(r'[<>:"/\\|?*]', "_", nouveau).strip() or "fichier"
            parties.append(nouveau + extension)
        candidat = Path(*parties).as_posix()
        base, n = candidat, 2
        while candidat.lower() in utilises:
            p = Path(base)
            candidat = p.with_name(f"{p.stem} ({n}){p.suffix}").as_posix()
            n += 1
        utilises.add(candidat.lower())
        return candidat


def ajouter_au_dictionnaire(config, nom_fichier, terme):
    chemin = cfg.dossier(config, "dictionnaires") / nom_fichier
    contenu = chemin.read_text(encoding="utf-8-sig") if chemin.exists() else ""
    terme = terme.strip()
    if terme and terme not in (l.strip() for l in contenu.splitlines()):
        with chemin.open("a", encoding="utf-8") as f:
            if contenu and not contenu.endswith("\n"):
                f.write("\n")
            f.write(terme + "\n")
