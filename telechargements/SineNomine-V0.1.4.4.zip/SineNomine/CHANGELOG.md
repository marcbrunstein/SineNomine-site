# Historique des versions de Sine Nomine

Chaque version est publiée sur GitHub avec une étiquette `V<numéro>` (V0.1.3.5, V0.1.3.6…).

## V0.1.4.4
Étape 4 de la version commercialisable : validation. Liste facultative de **termes à faire disparaître** (provenance « fourni par
l'utilisateur », occurrences réelles, zéro occurrence conservée avec pseudonyme, règles de recherche exacte / normalisée / approximative à
valider, jamais désactivés en silence) avec **vérification finale des fichiers réellement produits** (finalisation bloquée si un terme
subsiste ; parties non analysées signalées) ; étape distincte de **rapprochements** (propositions justifiées, acceptation, refus, forme de
référence, fusion manuelle, séparation) ; **choix occurrence par occurrence** ou global ; **masquage manuel de passages** (code et texte exact
dans le coffre en pseudonymisation, « [passage supprimé] » sinon) ; historique chiffré des décisions (comptes seulement). Les noms
écrits avec plusieurs espaces sont désormais retrouvés. Voir docs/VALIDATION.md.

## V0.1.4.3
Étape 3 de la version commercialisable : périmètres de stabilité des pseudonymes. Avant de pseudonymiser, l'utilisateur choisit
explicitement le périmètre : Document, Projet (choix par défaut ; un nouveau projet s'appelle « Nouveau projet », nom modifiable) ou
Client (avec avertissement : il facilite les recoupements). Un même nom garde son pseudonyme dans un périmètre, jamais d'un périmètre
à l'autre ; deux projets d'un même client restent indépendants ; aucune fusion automatique. Variantes apprises, refus de détection et
listes de noms sont propres à chaque périmètre ; seuls les mots exclus « généraux » restent communs. L'ancienne archive reste un
périmètre « historique », jamais rattachée à un client. Dé-pseudonymisation et correction reconnaissent le périmètre d'après les codes
(choix demandé en cas d'ambiguïté) ; la consultation étiquette chaque résultat. Nouvel onglet « Clients et projets ». Voir docs/PERIMETRES.md.

## V0.1.4.2
Étape 2 de la version commercialisable : coffre chiffré (AES-256-GCM champ par champ, clé protégée par DPAPI + phrase de récupération
facultative, historique chaîné, vérification d'intégrité, sauvegarde portable chiffrée), archive des codes transactionnelle (fin de
l'écrasement entre lots simultanés), publication des résultats récupérable après panne (dossier provisoire, contrôle, manifeste SHA-256,
reprise au démarrage), migration non destructive de l'ancienne archive JSON vers le coffre (« archive historique »), table de
correspondance en clair désormais exportée seulement sur demande confirmée. Voir docs/COFFRE.md.

## V0.1.4.1
Écriture neutre de l'éditeur : « Habeas Corpus » (sans « S.A.S. » ni « SASU ») dans l'application, les conditions d'utilisation, l'installateur,
le site et la documentation ; mentions légales : « société par actions simplifiée », dans l'attente de la confirmation de la forme exacte.

## V0.1.4.0
Étape 1 de la version commercialisable (voir docs/FEUILLE_DE_ROUTE.md) : sécurité du serveur local (session par jeton d'ouverture à
usage unique, protection CSRF, validation de l'hôte et de l'origine contre le DNS rebinding, politique de sécurité de contenu,
en-têtes sans cache, rapports HTML isolés), validation et confinement centralisés des chemins et noms de fichiers (lecteurs, chemins
réseau, flux NTFS, noms réservés, jonctions, collisions), neutralisation des formules dans les tableurs produits. Contact unique :
contact@sinenomine.app ; mentions légales complétées.

## V0.1.3.11
Types de licence (évaluation ou commerciale) et licences à vie : le bandeau de l'application indique le type et la date de fin, ou
« valable à vie » ; à l'expiration, le message précise depuis combien de jours et le bouton « Saisir une clé » permet de saisir un
nouveau code d'activation directement dans l'application. Textes juridiques, politique de confidentialité et site mis à jour.

## V0.1.3.10
Version d'évaluation sur clé d'accès : serveur d'activation (clés avec nombre d'installations et durée, licence signée Ed25519,
vérification hors ligne), page de clé dans l'installateur Windows (vérification avant installation, nombre d'utilisations restantes),
bandeau de licence, blocage du traitement sans licence valable (la dé-pseudonymisation reste libre), textes juridiques et politique
de confidentialité mis à jour. Correction : installer.bat sautait le téléchargement des modèles de détection depuis la V0.1.3.7.

## V0.1.3.9
Préparation de Linux et macOS (install.sh, lancer.sh, Sine Nomine.command, creer-raccourci.sh ; ouverture des dossiers, journal et
Tesseract selon le système). Installateur Windows (Inno Setup) : dossier d'installation au choix, raccourcis en option,
environnement Python dans le dossier de Sine Nomine. Vérification des licences des composants et des modèles.

## V0.1.3.8
Console : les avertissements sans effet de torch et huggingface_hub ne s'affichent plus au démarrage.

## V0.1.3.7
Lecture des fichiers PDF en entrée : le texte est extrait (pypdf), anonymisé, puis écrit dans le format choisi (Word, PowerPoint,
Markdown, texte, HTML ou Excel). Les PDF scannés sont lus par reconnaissance de caractères (Tesseract, installé par installer.bat).

## V0.1.3.6
Correction de l'erreur « ValueError : not enough values to unpack (expected 2, got 1) » à la confirmation d'un lot quand une
exception « Conserver » était cochée dans l'onglet des informations sensibles : le séparateur invisible de la clé était
effacé par le navigateur. Le serveur ignore désormais une exception mal formée au lieu de s'arrêter.

## V0.1.3.5
Première version enregistrée dans le dépôt. Fonctions : anonymisation et pseudonymisation (docx, pptx, xlsx, csv, html, txt, md),
archive des codes et dé-pseudonymisation, correction de pseudonymes, validation guidée par onglets avec examen du contexte,
indicateur d'avancement, interface bilingue français / anglais, documents en français et en anglais (UK et US),
détection des URL, noms de domaine, chemins de fichiers, IPv6/MAC, coordonnées GPS, BIC et numéros de châssis.
